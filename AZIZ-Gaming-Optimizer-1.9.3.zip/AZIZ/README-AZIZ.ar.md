# AZIZ Gaming Optimizer 1.9.3

فك الضغط كامل ثم شغّل AZIZGamingOptimizer.exe كمسؤول.

## الجديد
- كل تفعيل وتعطيل يشتغل في الخلفية؛ الواجهة ما تعلق وتقدر تكمل استخدام التطبيق.
- خيارات الشبكة (Auto-Tuning وغيرها) تتطبق فوراً بإعادة تشغيل كرت الشبكة تلقائياً.
- قراءات المعالج والكرت والرام لحظية في الرئيسية كل ثانية من أول ما يفتح التطبيق، وتتوقف في باقي الصفحات.
- الأدوات: NVIDIA (Clean Install · Profile · Per game · P0) · BIOS Drivers لجهازك · AMD Chipset بضغطة.
- Deep Debloat يعرض الموجود في جهازك فقط ويحذفه فعلياً.
- Competitive Mode يطبّق الأنوية على اللانشر عشان ألعاب الأنتي شيت تقبلها، وزر NoSteamWebHelper.

## ملاحظات
- لا تُنشأ اختصارات تلقائياً؛ زر Shortcut لمن يريد.
- بعض تغييرات ويندوز والتعريفات تحتاج إعادة تشغيل وتظهر علامة ذلك في تفاصيل الخيار.
- خيارات الطاقة تتغير على الكهرباء (AC) بس، والبطارية تبقى مثل ما هي.
- خطة الطاقة FSOS مرخّصة للاستخدام غير التجاري؛ الترخيص داخل ThirdPartyNotices.

## 1.9.3
- شعار جديد: AZ مع برق يشقهم. داخل التطبيق بدون إطار، وبرا التطبيق داخل مربع.
- AZIZ recommended بدون نجمة. في التوقلز والتويكس تختار Basic أو Ultra Low Latency، والشبكة وضع واحد.
- البروفايلات: Create profile وSave profile وExport وImport، والبروفايلات محفوظة داخل التطبيق.
- Recent changes: نافذة صغيرة تظهر بس إذا طبقت بروفايل أو AZIZ recommended وبعدها تغيّر شي، وفيها Keep changes أو Revert changes.
- Windows Default صار فعلياً قيم ويندوز الأصلية لكل خيار.
- الخدمات: Manual all وDisable all ما يلمسون الخدمات الأساسية، والخدمات المحمية تتغير من الريجستري، وDisplay Broker يبقى Automatic.
- P0 يشتغل فوراً بدون ريستارت.
- Set Timer Resolution 0.5: خدمة التايمر ترجع تشتغل لحالها لو توقفت.
- Competitive Mode يشتغل من أول ضغطة، والبروفايل التلقائي يطبّق على اللعبة واللانشر حتى لو AZIZ مقفل.
- Restore System يفتح استعادة النظام في ويندوز نفسه.
- التنزيلات: البرامج اللي تنزل كمثبّت تتثبت وتنفتح لحالها.
- تاب الأدوات فيه الشعار الحقيقي لكل أداة.
- Power Saving دمج USB/HID وUSB ROOT، وUSB 3 Link Power صار مفتاح.
- System tray battery percentage صار يشتغل فوراً.
- Disable interrupt steering لمعالجات AMD بس.
- أوصاف جديدة لـ Memory Compression وUSB selective suspend وHPET.
- إغلاق التطبيق يخليه شغال في التاسك بار تحت.

## 1.9.2
- Set Timer Resolution 0.5: خدمة التايمر تجدد الطلب كل ثانية إذا ويندوز تركه، وما يطلع خطأ 0xC0000245.
- NVIDIA Profile: الإعدادات اللي ما يعرفها الدرايفر تتخطى بدل ما توقف الاستيراد، وProfile Inspector ينفتح دايماً.
- DPC Latency Checker يفتح LatencyMon المثبت، ولو مو مثبت يشغّل المثبّت ثم يفتحه.
- أسماء الأدوات: Mouse & Controller Overclock وCRU 1.5.3.

## 1.9.1
- Hyper-V وOther Virtualization رجعت لتاب Security، وisolatedcontext مدموج مع Other Virtualization.
- Disable Early Launch Anti-Malware يطبّق إعداد BCD مباشرة.
- إصلاح استيراد بروفايل NVIDIA.
- خيارات جديدة: Disable Serialize Timer Expiration، Disable Energy Estimation، Allowed In-Memory Settings.
- التنزيلات تعرض تطبيقات القائمة فقط، والتحميل متوازي بأقصى سرعة.
