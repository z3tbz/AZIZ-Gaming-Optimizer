# AZIZ Gaming Optimizer 1.9.1

فك الضغط كامل ثم شغّل AZIZGamingOptimizer.exe كمسؤول.

## الجديد
- كل تفعيل وتعطيل يشتغل في الخلفية؛ الواجهة ما تعلق وتقدر تكمل استخدام التطبيق.
- خيارات الشبكة (Auto-Tuning وغيرها) تتطبق فوراً بإعادة تشغيل كرت الشبكة تلقائياً.
- قراءات المعالج والكرت والرام لحظية في الرئيسية فقط، وباقي الصفحات خاملة وهي مخفية.
- CPU Low Latency Tolerance وGPU Low Latency Tolerance منفصلين، وNVMe primary/secondary مدموجين.
- Cortana & Copilot وSearch Indexing & Web Search مدموجة مع السكربتات المطلوبة.
- Hyper-V وOther Virtualization في التوقلز تحت Security.
- Restore System في الرئيسية: إنشاء نقطة باسمك واستعادة حقيقية من قائمة النقاط.
- الأدوات: NVIDIA (Clean Install · Profile · Per game · P0) · BIOS Drivers لجهازك · AMD Chipset بضغطة.
- Deep Debloat يقرأ الويندوز ويعرض الموجود فقط، والمحذوف يظهر رمادي.
- Competitive Mode يطبّق الأنوية على اللانشر عشان ألعاب الأنتي شيت تقبلها، وزر NoSteamWebHelper.
- تنزيلات للبنشمارك، كيبورد الشاشة، وتطبيقات ويندوز بدون المتجر.
- شعار موحد A+Z مع برق داخل التطبيق وخارجه.

## ملاحظات
- لا تُنشأ اختصارات تلقائياً؛ زر Shortcut لمن يريد.
- بعض تغييرات ويندوز والتعريفات تحتاج إعادة تشغيل وتظهر علامة ذلك في تفاصيل الخيار.
- خطة الطاقة FSOS مرخّصة للاستخدام غير التجاري؛ الترخيص داخل ThirdPartyNotices.

## 1.9.1
- Hyper-V وOther Virtualization رجعت لتاب Security، وisolatedcontext مدموج مع Other Virtualization.
- Disable Early Launch Anti-Malware يطبّق إعداد BCD مباشرة.
- إصلاح استيراد بروفايل NVIDIA، وزر P0 بنفس لون الأزرار ويصير أحمر وهو شغال.
- خيارات جديدة: Disable Serialize Timer Expiration، Disable Energy Estimation، Allowed In-Memory Settings.
- Set Timer Resolution 0.5 يفعّل طلبات التايمر على مستوى النظام (ريستارت مرة وحدة).
- التنزيلات تعرض تطبيقات القائمة فقط، والتحميل متوازي بأقصى سرعة.
