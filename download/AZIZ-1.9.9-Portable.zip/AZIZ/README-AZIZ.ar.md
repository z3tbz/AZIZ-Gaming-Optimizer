# AZIZ Gaming Optimizer 1.9.9

فك الضغط كامل ثم شغّل AZIZGamingOptimizer.exe كمسؤول.

## الجديد
- كل تفعيل وتعطيل يشتغل في الخلفية؛ الواجهة ما تعلق وتقدر تكمل استخدام التطبيق.
- خيارات الشبكة (Auto-Tuning وغيرها) تتطبق فوراً بإعادة تشغيل كرت الشبكة تلقائياً.
- قراءات المعالج والكرت والرام لحظية في الرئيسية وتتوقف لما تنزل تحت أو تغيّر الصفحة.
- الأدوات: NVIDIA (Clean Install · Profile · Per game · P0) · BIOS Drivers لجهازك · AMD Chipset بضغطة.
- Deep Debloat يقرأ الموجود فعلياً في جهازك ويحذفه من جذوره.
- Competitive Mode يطبّق الأنوية على اللانشر عشان ألعاب الأنتي شيت تقبلها، وزر NoSteamWebHelper.

## ملاحظات
- لا تُنشأ اختصارات تلقائياً؛ زر Shortcut لمن يريد.
- بعض تغييرات ويندوز والتعريفات تحتاج إعادة تشغيل وتظهر علامة ذلك في تفاصيل الخيار.
- خيارات الطاقة تتغير على الكهرباء (AC) بس، والبطارية تبقى مثل ما هي.
- خطة الطاقة FSOS مرخّصة للاستخدام غير التجاري؛ الترخيص داخل ThirdPartyNotices.

## 1.9.6
- أول فتح للتطبيق ما يغيّر أي إعداد في ويندوز. يقرأ قيم جهازك ويحفظها في بروفايل Windows Default، ويسوي نقطة استعادة باسم AZIZ Backup.
- ما فيه بروفايل نشط إلى أن تغيّر أول خيار: يطلع لك مربع صغير في النص تسمّي فيه بروفايلك (الاسم الافتراضي My Profile)، وكل تعديلاتك تنحفظ فيه.
- تعديلات أول جلسة تنحفظ في البروفايل تلقائياً، فما يطلع لك Keep / Restore في الفتح الثاني. بعدها زر Save فوق يحفظ، ونافذة Keep / Restore تطلع بس لو عدّلت وما حفظت، وما يتطبق شي إلا باختيارك.
- البروفايلات: Windows Default (قراءات ويندوز حقتك قبل AZIZ) · AZIZ Recommended · AZIZ Ultra Low Latency. ولو ما حلّ Windows Default مشكلتك، فيه زر Restore AZIZ Backup.
- الرئيسية: زر Optimize your PC for Gaming بخيارين: AZIZ Ultra Low Latency (تويكس Ultra + خدمات Minimal) وAZIZ Basic (تويكس Basic + خدمات Recommended)، مع أنيميشن برق من 0% إلى 100% يقوى كل ما قرب من الاكتمال.
- التوقلز والتويكس: أزرار Recommended · Low Latency · Default بدل Enable all / Disable all.
- الشبكة: زر Recommended بس.
- الخدمات: أزرار Minimal · Recommended · Default من قوائم AZIZ. تظهر بس الخدمات اللي في القوائم، والباقي تحت زر Show more services ما ينحمّل إلا لما تفتحه. كل خدمة تبيّن قيمتها في القوائم الثلاث.
- تعطيل خدمة مهمة لويندوز يطلع لك تحذير يقول وش اللي بيتعطل. وتعريفات الإقلاع ما تتعطل من الأزرار إلا لو اخترتها بنفسك.
- استهلاك أقل بكثير: قراءات الخيارات صارت مباشرة من داخل التطبيق بدل PowerShell، والتطبيق يرتاح تماماً لما يكون مخفي أو مصغّر، ويقرأ بس الصفحة اللي قدامك.
- تاب الخدمات والتويكس يفتح فوراً.
- Scan & Debloat: كل عنصر يبيّن نتيجته أول ما يخلص، واللي انحذف يطلع من القائمة مباشرة. Virtualization ما يرجع يطلع بعد حذفه. المهام المجدولة صارت يدوية من Task Scheduler.
- Windows 10 Debloater (Sycnex) صار داخل التطبيق، وزر Remove Microsoft Edge.
- Scan & Debloat وWindows 10 Debloater يحذفون Microsoft Edge وWebView2 تلقائياً مرة وحدة، وأداة الحذف تنحذف من الجهاز بعدها.
- Security: خيار BitLocker بدل Disable BitLocker: إذا شغّلته يشتغل BitLocker، وإذا طفّيته يتعطل.
- التنزيلات: البرامج اللي توصل مضغوطة (مثل MSI Afterburner) تنفك وتفتح صفحة التثبيت مباشرة.
- نقاط الاستعادة: الإنشاء والاسترجاع صارت مباشرة عبر ويندوز، وزر System Restore يفتح أداة ويندوز الأصلية.
- AME Wizard: التثبيت يحفظ قراءات ويندوز ونقطة AZIZ Backup أول، وبعدها يطبّق AZIZ Recommended. وUltra Low Latency تختاره أنت من داخل التطبيق.

## 1.9.5
- شعار جديد للتطبيق بدون الإطار الأزرق، بألوان أغمق وأوضح وبجودة عالية على كل مقاسات ويندوز.
- التنقل بين التابات صار فوري (الخدمات، التنزيلات، التويكس): الصفحات تتجهز في الخلفية.
- إصلاح: بعد حذف تطبيق من Uninstaller والرجوع للهوم، الهوم كانت تتحول لصفحة Uninstaller.
- الخدمات: زر AZIZ فيه خيارين:
  - AZIZ Recommended: الأساسي Automatic، المحتاج Manual، واللي ما يحتاجه القيمر Disabled.
  - AZIZ Minimal: أقل خدمات ممكنة حسب إعداد AZIZ المرجعي.
  - الاثنين يغيرون خدمات ويندوز بس، وخدمات البرامج والتعريفات والأنتي شيت ما تنلمس.
- الخدمات المحمية اللي كانت ترفض التعطيل صارت تتعطل فعلياً.
- Deep Debloat: المهام المعطّلة أصلاً ما تطلع كأنها موجودة، وزر Task Scheduler.

## 1.9.4
- Deep Sleep جديد في التوقلز جنب Power Saving (على الكهرباء AC بس)، ومعطّل في AZIZ Default وUltra Low Latency.
- Low latency CPU: بدل تعطيل الـ Idle صار يخلي كل الأنوية شغالة (Core parking 100%) ويرجّع الـ Idle طبيعي.
- التوقلز والتويكس تتطبق مع بعض بالتوازي وبسرعة، والمفتاح يتغير فوراً بدون "Applying"، وEnable/Disable all ما يعلّق التطبيق.
- التطبيق ياخذ أولوية عالية وسرعة كاملة من المعالج وقت الفتح ووقت تطبيق التغييرات، وبعدها يرجع طبيعي.
- الأخطاء ما تطلع كأكواد برمجية: بس اسم الخيار وأنه ما تطبق، والتفاصيل في السجل.
- إصلاح Disable dynamic tick وDisable HPET (كانت تفشل بعد ما تنطفي)، وإصلاح SysMain وAudio Enhancements.
- Windows Update وTelemetry وApp Telemetry وNVIDIA telemetry تتعطل من كل مكان: الخدمات والمهام المجدولة والسياسات.
- AZIZ Default (Basic) وUltra Low Latency بالقيم الجديدة، وMSI للكرت الأساسي يتشغّل بدون ما يغيّر الأولوية أو الأفينيتي.
- Windows Default صار حالة جهازك قبل AZIZ: أول تشغيل يحفظ كل القيم (الموجودة والمحذوفة) ويرجعها بالضبط.
- نافذة التغييرات عند الفتح: تبين البروفايل النشط وقيمته وقيمتك الحالية، Keep changes يحفظها في البروفايل وRestore يرجّعها.
- السجل بتصميم جديد: الوقت بنظام 12 ساعة، واسم البروفايل اللي كان نشط وقت التغيير.
- الخدمات: كل خدمات جهازك في صفحة وحدة ومقسّمة، Manual all ذكي للقيمر، وDisable all يخلي الأساسي والألعاب والأنتي شيت بس.
- Competitive Mode: إصلاح الأخطاء اللي كانت تطلع تحت، وSave & run automatically يطبّق كل الخيارات حتى لو AZIZ مقفل.
- Allowed In-Memory Settings انتقل لتاب Security، وخيار جديد Disable BitLocker (يفك التشفير ويعطّل الخدمة).
- Deep Debloat: قسم Windows components (Kernel debugging · Smart card · Printing · Spell check · Search indexing · Mixed reality · Speech · Windows Update · Touch · Virtualization · Recovery · Cortana · VPN · NFC · Floppy · Telephony · Get Started · Easy Transfer · Embedded mode · Backup · Biometric · Defender · Windows To Go · BitLocker)، والغير موجود يطلع رمادي تحت مع السبب.
- Restore apps: استعادة الخدمات المحذوفة من النسخة الاحتياطية، وتشغيل Windows Update وSearch من جديد.
- تطبيقات Windows apps (الآلة الحاسبة، الرسام، الصور، الساعة، الكاميرا، Media Player…) تتثبت بدون Microsoft Store.
- Restore points تفتح داخل التطبيق: إنشاء نقطة استعادة أو الرجوع لنقطة مباشرة.
- Power Settings Explorer بشعار خاص في تاب الأدوات.
- Set Timer Resolution 0.5 مضبوط على أي جهاز جديد (خدمة SYSTEM من بداية الويندوز).

## 1.9.3
- شعار جديد: AZ مع برق يشقهم. داخل التطبيق بدون إطار، وبرا التطبيق داخل مربع.
- AZIZ recommended بدون نجمة. في التوقلز والتويكس تختار Basic أو Ultra Low Latency، والشبكة وضع واحد.
- البروفايلات: Create profile وSave profile وExport وImport، والبروفايلات محفوظة داخل التطبيق.
- Windows Default صار فعلياً قيم ويندوز الأصلية لكل خيار.
- P0 يشتغل فوراً بدون ريستارت.
- Competitive Mode يشتغل من أول ضغطة، والبروفايل التلقائي يطبّق على اللعبة واللانشر حتى لو AZIZ مقفل.
- التنزيلات: البرامج اللي تنزل كمثبّت تتثبت وتنفتح لحالها.
- تاب الأدوات فيه الشعار الحقيقي لكل أداة.
- Disable interrupt steering لمعالجات AMD بس.
- إغلاق التطبيق يخليه شغال في التاسك بار تحت.

## 1.9.2
- Set Timer Resolution 0.5: خدمة التايمر تجدد الطلب كل ثانية إذا ويندوز تركه، وما يطلع خطأ 0xC0000245.
- NVIDIA Profile: الإعدادات اللي ما يعرفها الدرايفر تتخطى بدل ما توقف الاستيراد، وProfile Inspector ينفتح دايماً.
- أسماء الأدوات: Mouse & Controller Overclock وCRU 1.5.3.
