AZIZ Gaming Optimizer

The AZIZ application interface and deployment scripts are implemented for this application.
Bundled third-party utilities retain their own licenses in ThirdPartyNotices.
Windows power schemes are optional imports. No scheme is automatically activated at installation.
Downloaded applications retain their publishers' terms.
