AZIZ telemetry and sensor support
================================
The application samples actual Windows CPU system-time deltas and physical-memory availability. It scans local WMI hardware information at launch / rescan: processors, GPUs and drivers, motherboard, BIOS, DIMMs, disks and volumes, OS/build, physical network adapters, and battery where available.

GPU usage uses LibreHardwareMonitor / NVIDIA NVML when available, with a fallback to Windows GPU engine counters. The fallback sums processes per engine and displays the busiest engine. Across multiple GPUs the summary displays the maximum reported load / core temperature, rather than an average. CPU temperature prefers package / Tctl / Tdie readings; otherwise the highest exposed CPU temperature.

A dash/unavailable means the device, driver, permissions or provider did not return that value. No temperatures are estimated. Some machines do not expose all requested hardware information. WMI may be blocked in a sandbox; the normal read-only hardware diagnostic returned 24 specification rows on the development laptop.

Optional library: LibreHardwareMonitor 0.9.6 (unmodified), .NET Framework build.
Source: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/tree/v0.9.6
Release: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/tag/v0.9.6
Original archive: https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/releases/download/v0.9.6/LibreHardwareMonitor.zip

CPU low-level sensors in this version may require an existing PawnIO installation and administrator access. AZIZ does not install PawnIO or any hardware driver automatically, and does not bundle the LibreHardwareMonitor GUI or its embedded setup executable. The sensor library opens an existing PawnIO device only when sensors are enabled. Missing support leaves CPU temperature unavailable. NVIDIA NVML is used only from the installed NVIDIA driver, never downloaded by AZIZ. No fan, clock, voltage or power controls are invoked.

Diagnostics constructs Telemetry(false), which does not load the optional sensor library, NVML or low-level hardware modules. Validation performed: compile with .NET Framework compiler, then read-only hardware scan and CPU/RAM/GPU Windows-counter sampling with sensors disabled. CPU/GPU temperature readings require a separate manual test on supported hardware.

Third-party libraries are unmodified and remain replaceable DLLs in this folder. LibreHardwareMonitor, DiskInfoToolkit, RAMSPDToolkit and BlackSharp are MPL 2.0. Their source is available at:
https://github.com/LibreHardwareMonitor/LibreHardwareMonitor/tree/v0.9.6
https://github.com/Blacktempel/DiskInfoToolkit
https://github.com/Blacktempel/RAMSPDToolkit
https://github.com/Blacktempel/BlackSharp
HidSharp: https://github.com/IntergatedCircuits/HidSharp (Apache 2.0)
Microsoft support libraries: https://github.com/dotnet/runtime (MIT)
Embedded PawnIO modules: https://github.com/namazso/PawnIO.Modules (LGPL 2.1)
License texts and notices are in licenses/. Versions and SHA-256 hashes are in dependency-manifest.json.

Final sensor smoke test: LHM/NVML read-only sampling succeeded and GPU temperature was read. The CPU provider returned a zero sentinel; AZIZ now rejects zero temperature readings and correctly reports CPU temperature unavailable. No driver was installed and no hardware controls were used.
