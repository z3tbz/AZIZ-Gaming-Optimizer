using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("AZIZ Gaming Optimizer")]
[assembly: AssemblyDescription("AZIZ V1H2: live hardware monitoring and optional Windows configuration controls")]
[assembly: AssemblyCompany("AZIZ")]
[assembly: AssemblyCopyright("Copyright © 2026 AZIZ. All rights reserved.")]
[assembly: AssemblyTrademark("AZIZ Gaming Optimizer")]
[assembly: AssemblyProduct("AZIZ Gaming Optimizer")]
[assembly: AssemblyFileVersion("1.9.7.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.9.7.0")]
