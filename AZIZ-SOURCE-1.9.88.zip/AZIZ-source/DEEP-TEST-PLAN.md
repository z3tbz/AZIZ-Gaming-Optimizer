# Deep test round (2026-10-17) — fix plan from 5 reviewers + lab

Lab v2 run 39009929570 pushed 06:26 UTC (bench/.NET10, first-run, oneclick 2025+2022, toggle). Results → branch `results`.
Poll task b032gn1zi. Reminder trig_01L4n2CDx9FzLaNkEhcckd1P (06:29) — re-arm every ~20 min while working.

## DONE
- MemoryCleaner: skip manual/GameWatch/Reflex games, foreground, dwm/audiodg/anticheat/Discord/RTSS…
- Reflex: Serialized Apply/Remove (mutex+lock, newest slider wins), Games() case-insensitive, no backup of AZIZ profile,
  RemoveAll no KeepRunning + kill hidden RTSS when last game removed (unless Afterburner), shared-memory Layout() bounds,
  EntryName bounded, reflex-api AtomicWrite, LiveLimit void delegates, Conceal probes each window only first 60 s / taskbar,
  winget RTSSSetup wait before DirectInstall, Reflex page prefetch skipped while Afterburner runs
- SecureWork: owner Administrators, protected DACL on ProgramData\AZIZ + Work, untrusted/linked → delete & recreate, old leftovers purge
- SilentSetup.Run: copy to SecureWork, re-verify, run copy
- DebloatList: apps query once (600 s), tasks script $ErrorActionPreference Continue + TaskJournal (+ prefix), auditpol backup;
  TaskJournal.RestoreAll wired into Windows Default + uninstall; Utilities.Run(timeout)

## DONE (07:00) batches A-D mostly: journal originals index, Native restorable, snapshot Owned()+Base64, service restore start-only,
   heavy probes alone/600 s, per-feature DISM, no -Remove, captures robust, Wi-Fi/BT best-effort, MMAgent skip, hibernate menu,
   audit GUIDs, power Unavailable, busy guard, journals save-before-write/lock/validation/.bad, UltraLite reg import check +
   script in SecureWork, InstallerRun signed copy/de-elevate, AMD copy, vendor O= pin, Tool() System32 + explorer full path,
   PSModulePath machine, WinGet AllUsers, GameWatch pausable list, single-option rescan, literal captures, inactive deferral,
   ProfileValue single lookup. Workflow v3 (log printing) edited locally, NOT pushed (wait for run 39009929570 to finish).
## (old) TODO batch A (restore correctness)
- A1 MatchesOriginal native options (compute differs off-thread for Windows Default)
- A2 RestoreSnapshot: drop ServiceRunning compare; remove Running from capture (printing, location, hotspot, sysmain)
- A3 RegistryJournal.Remember uses option snapshot original for owned keys (Originals index) + snapshot save patched from journal
- A4 heavy probe timeouts (ScanOne/Scan batch 600 s, restore servicing 1800 s), hyper-v no -Remove, per-feature queries
- A5 ntfs-last-access/auto-defrag/tcp-congestion capture robustness
- A6 memory-compression early return; wifi enable drivers Start=3; bluetooth drivers no Stop-Service
- A7 auditpol GUIDs; A8 unsupported power settings → Unavailable; A9 hibernation ShowSleepOption→ShowHibernateOption
## TODO batch B (pipeline)
- profileBusy guard (UseProfile/RunOptimize/Uninstall/Restore), after wait check ActiveProfile, exit guard (workers/pending)
- journals saved before writes (SilentTweaks, StartupApps), StartupApps lock, Remember bool, corrupt journal → .bad
- uninstall: busy, rescan states after journal restore, SetActiveProfile late
## TODO batch C (security)
- Snapshot Native as base64 data; RestoreSnapshot only writes keys in tweak's own ops
- Journal restore validation (silent.reg/debloat keys; Start 2..4; StartupApproved keys)
- UltraLite reg import: only Services\<name> keys; deep debloat script into SecureWork
- InstallerRun elevated unsigned → de-elevate via explorer; NVIDIA signer pin O=NVIDIA Corporation
- PSModulePath for child powershell; winget absolute path
## TODO batch D (perf)
- restore page: rescan one id; literal CaptureScript no PowerShell; SelfTest: ApplyRest + TaskJournal restore
## Report to user (Arabic): not fixed by design/needs decision: update signing (#12), elevated game launch (#8), portable
  Highest task (#9), named objects (#13), services preset vs safety lists (EventSystem, Themes, VaultSvc, WinHttpAutoProxySvc,
  LanmanWorkstation, Tcpip6, luafv, EhStorClass, WlanSvc, rdyboost, WinDefend, SgrmBroker), windows-update/telemetry per-task restore.

## 11:26 status
- Round 23 lab (run 39012825544): scan 90 s → 12 s (2 vCPU), first start 98 → 24 s, One Click 2025 1434 s → 80 s,
  Windows Default notBack = [] on 2022 + 2025 both profiles. First run: 0 option/service/task changes (only AZIZ autostart task).
  .NET: 4.8 peak WS 73-80 MB vs 10: 101-112; UI preview CPU 4.5 s vs 11.7 s; JSON 2.5 s vs 0.35 s /20x; scan equal → stay 4.8.
  Idle: window 3.5% one core (2 vCPU), tray 0.23%, agents ~0%.
- Fixed after round 23: NativeProbes.Walk dynamic → static (obfuscation), task/app lists via RunRaw (CleanMessage flattened 600 chars),
  mitigationLane + sysmainLane, restore mismatch detail, tray memory release (EmptyWorkingSet).
- Round 24 pushed 11:25 (lab run in progress, poll bxjhvgind). Then: final Arabic report + round 24 zips + source zip + screenshots.
