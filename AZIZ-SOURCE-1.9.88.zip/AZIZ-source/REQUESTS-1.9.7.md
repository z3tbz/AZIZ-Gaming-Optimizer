# AZIZ 1.9.7: requests from the user (2026-10-15), saved before work starts

## Wallpaper & brand
- Keep the two approved wallpapers: Horizon (k=1) and Split (k=2). Code: scratchpad/wp/blend2.py, blend_joined.py.
- Logo: the small notch on the A must point outward on the left, mirroring the one on the right.
- Set wallpaper: render at the screen's native resolution and aspect (smart scale, multi-monitor if possible).
- Optimize (Ultra / Low Latency) applies the wallpaper automatically; Settings keeps a "Set wallpaper" button.
- In-app logo = the wallpaper logo (the 2nd design is preferred).
- App background colours closer to the wallpapers (mauve + blue + black), tuned for the app.

## Names
- Optimize modes: "Ultra Low Latency" and "Low Latency".
- Tabs presets: "Recommended" becomes "Low Latency"; the other one "Ultra Low Latency".
- Tweaks/Toggles tabs show "Tweaks" / "Toggles" wording for the two modes.

## Services
- Both Optimize modes use Services = Recommended. Minimal only by hand from the Services tab.
- Minimal: Task Scheduler (Schedule) = Manual, not Disabled.
- Recommended: disable all Wi-Fi and Bluetooth services.
- Windows Update service: the Toggles switch does not touch the service itself; Recommended = Manual; Minimal = Disabled.

## Toggles behaviour (no conflicts)
- Bluetooth off (toggle or Optimize) also disables Bluetooth services. Same for Wi-Fi.
- Windows Update toggle off disables auto update, forced updates, auto restart, etc. (as now) but not the wuauserv service.
- State reading: a toggle shows OFF only when all "off" conditions hold; hidden/missing components count as off.
  Any real "on" part → shown ON; partial → "Mixed" and the info lists which parts are on and which are off. Same rule for every card.

## Card info (ⓘ)
- Short paths (HKLM\SYSTEM → sys, etc.), cleaner design.
- Remove the "auto configured…" text. Show: Default (this PC's value at first start), Current (on/off), active profile name.

## Profile values (confirmed by the user)
- Set Timer Resolution: ON in Ultra only.
- Disable interrupt steering: ON in both modes, AMD only.
- Disable Serialize Timer Expiration: ON in both modes, AMD only.
- Disable timer coalescing, Disable dynamic tick, TSC legacy: ON in both modes (AMD and Intel).
- Audio enhancements: OFF in Ultra only.
- Event processor: OFF in every mode, any CPU.
- Every other Toggles/Tweaks option: ask the user one by one (Ultra / Low) before saving.

## Profiles
- Ultra Low Latency and Low Latency are static profiles; details show they are static.
- Changing an option not in the static profile → choose a saved profile or name a new one.
- On restart, read Windows fully; if it differs from the static profile → Restore / Keep changes.
  Restore = stay on the static profile. Keep changes → then ask to create or choose a profile.
- Restore / Keep changes screen: same style as the Optimize picker (blurred app, two choices, details on top).

## Home
- Competitive mode: verify every option works.
- "Clear standby on game start": with Save & run automatically it must clear standby whenever a game starts
  (from Steam, with AZIZ closed, or from AZIZ). Toggling the option applies at once.
- Optimize overlay: bolt more golden, more detail, prettier; background colours unchanged, only blur over the app.

## Steam
- "Install No Steam Web Helper": the current one does not install/run. The user will send a newer tool.
  Install next to Steam, start with Windows, automatic mode.

## Testing
- Test the app end to end and fix problems found.

## Tweaks confirmed by the user (round 2)
- All 40 Toggles: keep as listed.
- Tweaks: keep as listed, except:
  - Disable Energy Estimation: ON in both.
  - Fixed page file: ON in both.
  - MSI mode for GPU (both profiles): detect the main (discrete) GPU; if MSI is off, turn it on; no priority, no other config.
    Ultra + AMD: MSI priority High and interrupt affinity "specific processor" on one core. (asked: AMD CPU or GPU, which core)
- Steam No Web Helper: user will send a PowerShell script.
- CPU minimum state 100%: reading 99% must NOT count as on (only exactly 100).
- Low latency CPU · all cores unparked (no core parking): ON in both profiles.

## Round 3 (user, 2026-10-15)
- MSI: AMD CPU detected → main GPU (NVIDIA or AMD) MSI priority High + affinity Specific processor = CPU 1 (logical thread 1, i.e. core 0's second thread). Both profiles. Intel: MSI on only.
- Bug: after Ultra, "Search Indexing & Web Search" shows ON though profile says OFF. Investigate.
- Bug: Low Latency shows "GPU Low Latency Tolerance" ON; should be OFF in both.
- All cores active (no parking) in both (done).
- Top grey title bar: same dark colour as the left tab bar; remove "AZIZ Gaming Optimizer" text at the top.
- Home: make the One Click Optimize card visually distinct from the Hardware info card.
- "Create profile" prompt (after changing an option on a static profile): same blurred two-choice design as Keep changes / Optimize picker.
- Profile button at top: open straight on the profile (Mark view) and put the editable values in a second tab; redesign both like Keep changes.
- Toggle ON colour: nicer violet with a slight gradient — send design options first.
- NoSteamWebHelper: not working. Install must open the setup so the user picks the folder, then verify it installed (it should run in the tray / Task Manager after install).
- Home metrics: remove the captions "Total processor", "Graphics load", "RAM…" under CPU/GPU/RAM.
- RAM tile: new nicer "cup" design; click = memory clean (working sets + standby, no defrag, light).
  After first click: automatic background cleaner (no app needed): when RAM ≥ 80% and also every hour regardless, lightweight.
- Standby option (competitive): switching it on or off clears standby now.
- Home: Optimize card has its own distinct colour, Hardware info its own; the cards below share one unified non-grey style.
- BitLocker off in both profiles (Security already Disabled) and BDESVC disabled in Services Recommended.
- Info panel: send design options; fix the default reading (use this PC's real first-start value).

## Round 4
- A: left notch becomes an outward spike (arrow pointing left, outside the letter).
- Services Recommended = both profiles: disable search/indexing, BitLocker, all Bluetooth, Wi-Fi, wireless and remote services.
- Windows Update toggle: all its tweaks back, only the wuauserv service key removed (Services decide: Recommended Manual, Minimal Disabled).
- Registry set: keep everything; the CPU latency values (the ~12 in Control\Power / GraphicsDrivers\Power) move into CPU Low Latency Tolerance: ON in Ultra, OFF in Low. GPU Low Latency Tolerance OFF in both.
- CPU minimum 100% off must not drop to 5%.
- Toggle design: option 4 (deep violet, soft edge).
- Info panel: design C.
- Uninstaller: Deep / Simple as two blurred violet choices, no confirm, act at once.
- Optimize: no confirm message after choosing the mode; apply at once (History lists it).
- Install prompts: same blurred violet style.
- Optimize (both modes) applies the whole registry set (tolerance values now live in the CPU tolerance toggle; GPU never) and the whole debloat file automatically, except Xbox / Microsoft Store items, which stay manual (Recommended in Scan & Debloat).
- Scan & Debloat page: redesign to the new identity.
- App icon / logo files still old: new mark, new colours, background like the new wallpapers.

## Round 5 (show designs first)
- Settings tab → move to the top bar, same as the background, no highlight.
- Minimize (window) button smaller, normal.
- Icon colours/gradient look nicer than the wallpaper → app should follow the icon.
- "DirectX 11 and earlier · Per-game fullscreen settings" button: restyle outside and inside.
- Profile chip: short names (ULL / LL), gold dot = active; other colours for odd states; explain states inside Profiles. Save button same colour.
  Explain: a newly applied profile keeps settings only after Save; changes apply live but the profile is "hybrid"; next start asks Keep / Restore;
  Keep saves automatically and stops asking; static profiles can't be kept into.
- Forced create-profile sheet: different colours so it doesn't blend with other sheets.
- Optimize picker cards: darker like the background, slightly brighter.
- Power plans: imported plans can be deleted (not Windows defaults).

## Round 7
- DX11 button: "DX11 Fullscreen", design A2 (violet outline). Done.
- Optimize picker cards: keep as they are.
- Wallpaper letters: less gradient, matching the logo → options W1–W3 sent, waiting for choice.
- NoSteamWebHelper still not working → install now reads the setup's own log for installed files (exe or DLL), restarts Steam.
- Optimize (Ultra / Low): no white popups; History is enough.

## Round 8
- Profile button: AZIZ violet like Save, gold dot + short name (ULL / LL), updated descriptions. Done.
- RAM tile: no "RAM" word; flask higher and near the middle. Done.
- Window opens larger (86% of screen first time) and remembers the user's size. Done.
- Tools: NVIDIA buttons (Clean Install / Profile / Per game / P0) spaced so a wrap never stacks them. Done.
- Mixed rule for every control: partial = opposite of the AZIZ target (switch AZIZ turns off → On; tweak AZIZ turns on → Off). Details say Mixed and list parts on / off (cause); "Live parts" list per value in ⓘ. Done.
- Windows Update toggle: service Start values (UsoSvc, BITS, DoSvc, WaaSMedic, uhssvc) removed (they caused Mixed against Recommended). Services/profiles decide them. Done.
- Services Recommended (Optimize Ultra / Low and the Services button alike): also Wi-Fi filter drivers, pairing services, remote access miniports disabled. BitLocker off in every profile. Done.
- Minimal resource mode setting removed. Done.
- Services page: only Main services open; others folded every time (not remembered). Done.
- Timer Resolution Test keeps one name. Done.

## Round 9
- Search indexing flipped between on and off: the debloat file set DisableWebSearch=0 (web search on) after the toggle turned it off. Fixed to 1. Every profile turns it off (toggle + Services WSearch Disabled). Partial now reads Mixed with the cause.
- Cross-check of debloat file and registry set against every profile value: also fixed IconsOnly (debloat) and removed the 3 values Animations shared with Visual effects (they fought each other).
- Splash logo bigger: 300 px (was 190), bar 240 px.
- Cortana & Copilot: Off in every profile; reads Off from the policies that decide it (AllowCortana, TurnOffWindowsCopilot), extras no longer flip it.
- Visual effects · custom performance: On in every profile; reading ignores UserPreferencesMask (Windows rewrites its bits itself).
- Letters colour G3 (deep, vertical gradient, soft glowing middle band) on the wallpaper, the in-app logo, the splash and the app icon.
- Custom performance reading: decided by VisualFXSetting 3 + MinAnimate 0 + TaskbarAnimations 0; the rest listed in details. On in every profile.

## Round 10
- Windows Update off disables BITS, Delivery Optimization (DoSvc), Update Orchestrator (UsoSvc), Update Medic and Update Health in every profile; Services Recommended and Minimal set the same (no conflict). wuauserv: Recommended Manual, Minimal Disabled.
- Full scan of every value Optimize writes (toggles, tweaks, network, security, services, debloat file, registry set) for both profiles: 0 conflicts. Fixed NPSMSvc (Recommended now Disabled like Telemetry), Delivery Optimization P2P (off everywhere), PreventHandwritingDataSharing (1 everywhere).
- Horizon (G3) is the official wallpaper: Optimize applies it unless the user picked one with Set wallpaper; site social preview uses it.

## Round 11
- Logo/icon: same geometry as the wallpaper (A cut by the bolt, Z close). Wallpaper: the official PNG files exactly (assets\wallpapers), Horizon official.
- NoSteamWebHelper: silent install straight into the Steam folder, automatic in Optimize (any profile). Competitive: Steam web helper priority option removed.
- Optimize writes the Aziz Low-Latency NVIDIA profile to the driver (no Profile Inspector window). Low Latency file: user will send changes.
- Windows Update: clean-up deletes without an Off part are not listed as parts. Animations no longer touches DragFullWindows / font smoothing (custom performance keeps them on); shadows off.
- Title bar: day/night (drawn moon / sun) top-left, settings gear top-right with no highlight, smaller low minimize. Softer day colours.
- NVIDIA tools buttons in one compact row. AMD chipset card replaced by AMD GPU Driver (official page for now).
- Debloat apps: Edge / Chrome / Brave policies (telemetry, background, hardware acceleration off). Steam and Discord: waiting for details.
- NVIDIA: Low Latency uses its own profile file (Aziz_Low-Latency-LL.nip), Ultra the main one.
- Steam debloat: illustrated step-by-step guide (drawn Steam settings, gold frame on each option).
- Reflex Fallback (Tools): detects games, marks games with native Reflex, Apply writes the RTSS profile (Reflex limiter, fallback, low latency, sleep 2, per frame) with the chosen FPS; installs RTSS via winget if missing; RTSS starts with Windows in the tray; AZIZ Reflex tray helper (--reflex-tray) changes limits with AZIZ closed.
- Debloat Discord: closes Discord, hardware acceleration off; overlays: user switches off (path shown). Deeper Discord debloat tomorrow.
- Reflex limiter changes apply live while the game runs (RTSSHooks LoadProfile/SetProfileProperty FramerateLimit/SaveProfile/UpdateProfiles), no RTSS restart.
- NVIDIA files renamed: AZIZ_Ultra-Low-Latency.nip (old file, Ultra) and AZIZ_Low-Latency.nip (latest file, Low Latency).
- AMD GPU Driver opens AMD's page for the exact Radeon RX model.

## Round 12
- Game discovery picks the real game exe (not trial/demo/tools; name like the game folder; root folder first) → Reflex and NVIDIA Per game use FC27.exe, not the trial.
- Window buttons: Windows' own minimize/maximize/close glyphs, same size and line.
- Animations & Visual Effects: one option (custom performance merged). Off: everything off except Show window contents while dragging + Smooth edges of screen fonts (on in both states). On: Windows decides (default).
- No forced profile without Optimize; static profiles only. Without a profile, next start asks Keep / Restore for changes; Keep is not asked again.
- Static profile sheet in gold; inner pages (DX11, NVIDIA drivers, …) are the modern sheet, NVIDIA in green.
- "Disable per-interrupt DPC queueing" (renamed, On = disabled; NVIDIA only, AMD has no such setting).
- CPU Low Latency Tolerance: removed ExitLatencyCheckEnabled, RtlCapabilityCheckLatency, MaxIAverageGraphicsLatencyInOneBucket, MiracastPerfTrackGraphicsLatency.
- Reflex: per game NVIDIA Reflex ON (green) / OFF (dim); limit only when On, applies live on Enter; 0 = no cap. RTSS window hidden (tray only).
- AZIZ tray icon only while AZIZ is hidden to the tray.
- Debloat Apps: compact card → sheet (Discord, Steam guide, browsers). Discord: also removes old update packages, old versions, non-English languages, caches.

## Round 17 (performance & audit)
- Fewer processes: service start types through the Windows service API (no sc.exe per service), one bcdedit per scan, at most 2 PowerShell batches at startup, NGen native image after the first start, 11 of 141 status reads still use PowerShell.
- Background: Game Watch reads its config only after a save and backs off pending restores; background RAM clean never trims game memory; sensors every 3 s while AZIZ is behind other windows; idle prewarm; no dialogs from helpers.
- Reflex: folder scan off the UI thread (game folder only), user's RTSS profile kept and restored on Off, tray closes with the last game.
- Fixes: Restore at start never disables a boot volume filter; Keep / Restore now shown without a profile; dependency-blocked services keep their start type; an older scan cannot undo a newer change; Animations reads Aero Peek correctly; merged custom performance keeps its originals and saved values; Windows Default restores only options that differ; bulk changes respect static profiles; Steam helper never guesses in the Steam root.
- .NET: stays on 4.8 (built into Windows, no runtime download).
