// .NET 10 benchmark build only: the parts of System.Web's JavaScriptSerializer that AZIZ uses, on System.Text.Json.
using System;
using System.Collections.Generic;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace System.Web.Script.Serialization;

public class JavaScriptSerializer
{
	public int MaxJsonLength { get; set; }

	public int RecursionLimit { get; set; }

	private static readonly JsonSerializerOptions Options = Create();

	private static JsonSerializerOptions Create()
	{
		JsonSerializerOptions o = new JsonSerializerOptions
		{
			PropertyNameCaseInsensitive = true,
			IncludeFields = true,
			AllowTrailingCommas = true,
			ReadCommentHandling = JsonCommentHandling.Skip,
			NumberHandling = JsonNumberHandling.AllowReadingFromString,
			Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
			MaxDepth = 256
		};
		o.Converters.Add(new LooseObject());
		return o;
	}

	public string Serialize(object obj)
	{
		return JsonSerializer.Serialize(obj, obj?.GetType() ?? typeof(object), Options);
	}

	public T Deserialize<T>(string input)
	{
		return JsonSerializer.Deserialize<T>(input, Options);
	}

	public object DeserializeObject(string input)
	{
		return JsonSerializer.Deserialize<object>(input, Options);
	}

	// object-typed values come back as Dictionary<string, object>, object[], string, bool, int/long/decimal/double or null,
	// like JavaScriptSerializer.
	private sealed class LooseObject : JsonConverter<object>
	{
		public override object Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
		{
			switch (reader.TokenType)
			{
			case JsonTokenType.StartObject:
			{
				Dictionary<string, object> d = new Dictionary<string, object>(StringComparer.Ordinal);
				while (reader.Read() && reader.TokenType != JsonTokenType.EndObject)
				{
					string key = reader.GetString();
					reader.Read();
					d[key] = Read(ref reader, typeof(object), options);
				}
				return d;
			}
			case JsonTokenType.StartArray:
			{
				List<object> l = new List<object>();
				while (reader.Read() && reader.TokenType != JsonTokenType.EndArray)
				{
					l.Add(Read(ref reader, typeof(object), options));
				}
				return l.ToArray();
			}
			case JsonTokenType.String:
				return reader.GetString();
			case JsonTokenType.True:
				return true;
			case JsonTokenType.False:
				return false;
			case JsonTokenType.Number:
				if (reader.TryGetInt32(out int i))
				{
					return i;
				}
				if (reader.TryGetInt64(out long n))
				{
					return n;
				}
				if (reader.TryGetDecimal(out decimal m))
				{
					return m;
				}
				return reader.GetDouble();
			default:
				return null;
			}
		}

		public override void Write(Utf8JsonWriter writer, object value, JsonSerializerOptions options)
		{
			if (value == null)
			{
				writer.WriteNullValue();
				return;
			}
			if (value.GetType() == typeof(object))
			{
				writer.WriteStartObject();
				writer.WriteEndObject();
				return;
			}
			JsonSerializer.Serialize(writer, value, value.GetType(), options);
		}
	}
}
