"""AZIZ logic tests: catalog, profiles, services presets, debloat file and registry set must agree.

Run: python3 -I tests/test_logic.py   (from the source root)
Exit code 1 if any check fails.
"""
import collections
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FAILS = []
WARNS = []


def fail(msg):
    FAILS.append(msg)


def warn(msg):
    WARNS.append(msg)


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8-sig", errors="ignore") as f:
        return f.read()


catalog = json.loads(read("Aziz.catalog.json"))
byid = {t["Id"]: t for t in catalog}
presets_src = read("Aziz/AzizPresets.cs")
main_src = read("Aziz/MainWindow.cs")
services = json.loads(read("Aziz.services-presets.json"))
debloat = json.loads(read("Aziz.debloat.json"))


def ids(name):
    m = re.search(name + r' = Ids\("([^"]*)"\)', presets_src)
    return m.group(1).split() if m else []


BOTH_ON, BOTH_OFF, BASIC, ULTRA = ids("BothOn"), ids("BothOff"), ids("BasicOnly"), ids("UltraOnly")
NET_ON = ids("Network")
NET_OFF = re.search(r'string\[\] array = Ids\("([^"]*)"\)', presets_src).group(1).split()
SEC_ON = ids("SecurityOn")
NOT_PROFILEABLE = {"Unavailable", "Shortcut", "Action", "GpuMsi", "SystemRestore", "PowerConfigure"}

# 1. unique ids, required fields
dupes = [k for k, v in collections.Counter(t["Id"] for t in catalog).items() if v > 1]
if dupes:
    fail("duplicate tweak ids: %s" % dupes)
for t in catalog:
    if t["Kind"] == "Registry" and not t.get("ReadMode") and not t.get("ProbeScript"):
        if not t.get("Enable") or not t.get("Disable"):
            fail("%s: registry tweak without Enable/Disable values" % t["Id"])

# 2. every id named by a profile list exists and can be part of a profile
lists = {"BothOn": BOTH_ON, "BothOff": BOTH_OFF, "BasicOnly": BASIC, "UltraOnly": ULTRA,
         "Network on": NET_ON, "Network off": NET_OFF, "SecurityOn": SEC_ON}
seen = collections.defaultdict(list)
for name, lst in lists.items():
    for i in lst:
        seen[i].append(name)
        if i not in byid:
            fail("profile list %s names unknown tweak '%s'" % (name, i))
        elif byid[i]["Kind"] in NOT_PROFILEABLE:
            fail("profile list %s names '%s' whose kind %s is never applied by a profile" % (name, i, byid[i]["Kind"]))
for i, where in seen.items():
    core = [w for w in where if w in ("BothOn", "BothOff", "BasicOnly", "UltraOnly")]
    if len(core) > 1:
        fail("tweak '%s' is in more than one profile list: %s" % (i, core))

# 3. other hard-coded id lists in the UI
for m in re.finditer(r'new string\[\d+\] \{ ((?:"[a-z0-9\-]+", )*"[a-z0-9\-]+") \}', main_src):
    for i in re.findall(r'"([a-z0-9\-]+)"', m.group(1)):
        if "-" in i and i not in byid and i.count("-") >= 1 and re.match(r"^[a-z]+(-[a-z0-9]+)+$", i):
            # only flag strings that look like tweak ids and sit next to known ids
            neighbours = re.findall(r'"([a-z0-9\-]+)"', m.group(1))
            if any(n in byid for n in neighbours) and i not in ("show-file-extensions", "nvidia-primary-latency", "timer-resolution"):
                warn("MainWindow id list mentions unknown tweak id '%s'" % i)

# 4. services presets
for preset, values in services.items():
    for svc, start in values.items():
        if start not in (0, 1, 2, 3, 4):
            fail("services %s: %s has start type %r" % (preset, svc, start))
for svc in ("BDESVC", "WSearch", "bthserv", "WlanSvc", "PhoneSvc", "UsoSvc", "BITS", "DoSvc", "WaaSMedicSvc"):
    if services["recommended"].get(svc) != 4:
        fail("services recommended: %s should be Disabled (4), is %r" % (svc, services["recommended"].get(svc)))
if services["minimal"].get("Schedule") != 2:
    fail("services minimal: Task Scheduler must stay Automatic (2)")
if services["recommended"].get("wuauserv") != 3 or services["minimal"].get("wuauserv") != 4:
    fail("wuauserv must be Manual in Recommended and Disabled in Minimal")

# 5. one value, one owner: every value Optimize writes agrees in both profiles
def norm(h, p, n):
    h = h.upper().replace("HKEY_LOCAL_MACHINE", "HKLM").replace("HKEY_CURRENT_USER", "HKCU").rstrip(":")
    return h, p.strip("\\").lower().replace("currentcontrolset", "ccs"), n.lower()


def profile(ultra):
    d = {}
    for i in BOTH_ON:
        d[i] = "Enabled"
    for i in BOTH_OFF:
        d[i] = "Disabled"
    for i in BASIC:
        d[i] = "Disabled" if ultra else "Enabled"
    for i in ULTRA:
        d[i] = "Enabled" if ultra else "Disabled"
    for i in NET_ON:
        d.setdefault(i, "Enabled")
    for i in NET_OFF:
        d.setdefault(i, "Disabled")
    for t in catalog:
        if t["Category"] == "Security" and t["Id"] not in d:
            d[t["Id"]] = "Enabled" if t["Id"] in SEC_ON else "Disabled"
    d["bitlocker"] = "Disabled"
    return d


def walk(x):
    if isinstance(x, dict):
        if "P" in x and "N" in x:
            yield x
        else:
            for v in x.values():
                yield from walk(v)
    elif isinstance(x, list):
        for v in x:
            yield from walk(v)


silent = []
cur = None
for line in read("Aziz.silent.reg").splitlines():
    line = line.strip()
    m = re.match(r'^\[(-?)(HKEY_[A-Z_]+)\\(.*)\]$', line)
    if m:
        cur = (m.group(2), m.group(3))
        continue
    m = re.match(r'^"([^"]+)"=(dword:([0-9a-fA-F]+)|"(.*)"|-)', line)
    if m and cur:
        val = None if m.group(2) == "-" else (int(m.group(3), 16) if m.group(3) else m.group(4))
        silent.append((norm(cur[0], cur[1], m.group(1)), val))

for ultra in (True, False):
    writes = collections.defaultdict(list)
    d = profile(ultra)
    for t in catalog:
        v = d.get(t["Id"])
        if t["Kind"] == "Service" and t.get("Service") in services["recommended"]:
            writes[norm("HKLM", "SYSTEM\\CurrentControlSet\\Services\\" + t["Service"], "Start")].append(("svc:" + t["Id"], services["recommended"][t["Service"]]))
            continue
        ops = t.get("Enable") if v == "Enabled" else (t.get("Disable") if v == "Disabled" else None)
        for o in ops or []:
            if "{" in o["Path"] or o.get("Token") or o.get("Kind") in ("PageVisibility", "StickyFlags"):
                continue
            writes[norm(o["Hive"], o["Path"], o["Name"])].append((t["Id"], o["Value"]))
    for s, v in services["recommended"].items():
        writes[norm("HKLM", "SYSTEM\\CurrentControlSet\\Services\\" + s, "Start")].append(("services-recommended", v))
    for e in walk(debloat.get("Registry", {})):
        h, p = e["P"].replace(":\\", "\\").split("\\", 1)
        writes[norm(h, p, e["N"])].append(("debloat", e.get("D")))
    for n in debloat.get("Services", []):
        name = n if isinstance(n, str) else (n.get("N") or n.get("Name"))
        if name:
            writes[norm("HKLM", "SYSTEM\\CurrentControlSet\\Services\\" + name, "Start")].append(("debloat-services", 4))
    for k, v in silent:
        writes[k].append(("silent.reg", v))
    for k, v in writes.items():
        if len(set(str(x[1]) for x in v)) > 1:
            fail("%s profile: %s\\%s written with different values %s" % ("Ultra" if ultra else "Low", k[1], k[2], v))

# 6. tweaks whose On and Off write the same thing (no-op switches)
for t in catalog:
    e = {(o["Hive"], o["Path"].lower(), o["Name"].lower()): str(o["Value"]) for o in t.get("Enable") or []}
    di = {(o["Hive"], o["Path"].lower(), o["Name"].lower()): str(o["Value"]) for o in t.get("Disable") or []}
    if e and e == di and not t.get("EnableScript") and not t.get("DisableScript") and not t.get("Choices"):
        fail("%s: On and Off write identical values" % t["Id"])

# 7. PowerShell-only status reads (informational)
np_src = read("Aziz/NativeProbes.cs")
native = set(re.findall(r'case "([a-z0-9\-]+)":', np_src))


def cs_regex(name):
    m = re.search(r"Regex " + name + r' = new Regex\("((?:[^"\\]|\\.)*)"\)', np_src)
    return re.compile(bytes(m.group(1), "utf-8").decode("unicode_escape"))


R = {n: cs_regex(n) for n in ("RegistryProbe", "ServiceProbe", "PowerProbe", "PowerMap", "NicProbe")}
ps_only = []
for t in catalog:
    s = t.get("ProbeScript")
    if not s or t["Id"] in native:
        continue
    if R["RegistryProbe"].search(s) or R["ServiceProbe"].search(s) or (R["PowerProbe"].search(s) and R["PowerMap"].search(s)) or R["NicProbe"].search(s):
        continue
    ps_only.append(t["Id"])

print("tweaks: %d · profile ids: %d · PowerShell-only status reads: %d %s" % (len(catalog), len(seen), len(ps_only), ps_only))
for w in WARNS:
    print("WARN", w)
for f in FAILS:
    print("FAIL", f)
print("RESULT:", "PASS" if not FAILS else "FAIL (%d)" % len(FAILS))
sys.exit(1 if FAILS else 0)
