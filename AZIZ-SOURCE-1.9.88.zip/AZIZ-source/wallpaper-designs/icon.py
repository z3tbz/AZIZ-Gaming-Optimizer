import sys, numpy as np, math
sys.path.insert(0,'.')
import importlib.util
spec=importlib.util.spec_from_file_location('bj','blend_joined.py'); bj=importlib.util.module_from_spec(spec); spec.loader.exec_module(bj)
from PIL import Image, ImageDraw
N=1024
# background: Split-style blend (violet top-left -> ink -> blue bottom-right), rounded square
yy,xx=np.mgrid[0:N,0:N].astype(np.float32)/N
t=xx*0.5+yy*0.5
img=bj.ramp(t,[(0,bj.VIOLET*0.75),(0.45,bj.INK),(0.55,bj.INK),(1,bj.BLUE*0.8)])
d=np.sqrt((xx-0.5)**2+(yy-0.45)**2)
img=img*(1-0.35*np.clip((d-0.2)/0.6,0,1))[...,None]
img=np.clip(1-np.exp(-img*1.3),0,1)*255
# mark: reuse logo() at a size filling ~78% of the badge
H=int(N/0.44*0.80)
canvas=np.zeros((H,H,3),np.float32)
canvas=bj.logo(canvas,H,H)
# extract mark alpha by rendering on black vs using masks: simpler — render masks directly
L=int(N*0.80); big=L*4; tf=(0.80,10.8,10.8)
from PIL import ImageFilter
cut=bj.mask([bj.CUT],[],big)
mA=np.minimum(bj.mask([bj.A_OUT,bj.A_BAR,bj.A_SPIKE],bj.A_NOTCH,big,tf),255-cut)
hug=np.array(Image.fromarray(bj.mask([bj.BOLT],[],big)).filter(ImageFilter.MaxFilter(int(big*0.012)|1)))
mZ=np.minimum(bj.mask([bj.ZED],[],big,tf),255-hug); mZ=np.minimum(mZ,255-bj.mask([bj.LEFT_OF_BOLT],[],big))
mB=bj.mask([bj.BOLT],[],big)
sm=lambda m: np.array(Image.fromarray(m).resize((L,L),Image.LANCZOS)).astype(np.float32)/255
mA,mZ,mB=sm(mA),sm(mZ),sm(mB)
cA=bj.bbox_grad(mA,[(0,(150,205,255)),(0.35,(40,135,235)),(0.7,(70,50,205)),(1,(55,20,150))])
cZ=bj.bbox_grad(mZ,[(0,(92,30,190)),(0.5,(92,30,190)),(0.75,(118,70,212)),(1,(150,115,232))])
cB=bj.bbox_grad(mB,[(0,(255,247,200)),(0.5,(255,200,40)),(1,(234,120,0))],True)
o=(N-L)//2
reg=img[o:o+L,o:o+L]
for m,c in zip((mA,mZ,mB),(cA,cZ,cB)): reg=reg*(1-m[...,None])+c*m[...,None]
img[o:o+L,o:o+L]=reg
rgb=Image.fromarray(np.clip(img,0,255).astype(np.uint8))
mask=Image.new('L',(N*2,N*2),0); ImageDraw.Draw(mask).rounded_rectangle((0,0,N*2-1,N*2-1),radius=int(N*2*0.22),fill=255)
mask=mask.resize((N,N),Image.LANCZOS)
out=rgb.convert('RGBA'); out.putalpha(mask)
out.save('aziz-logo-1024.png')
out.resize((512,512),Image.LANCZOS).save('aziz-logo.png')
out.save('aziz.ico',sizes=[(16,16),(24,24),(32,32),(48,48),(64,64),(128,128),(256,256)])
