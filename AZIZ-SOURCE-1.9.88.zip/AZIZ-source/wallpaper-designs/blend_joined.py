import numpy as np, sys, math
from PIL import Image, ImageDraw

def hx(h): return np.array([int(h[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.float32) / 255.0

# Logo palette, darkened for backgrounds.
NAVY, INK, INDIGO, VIOLET, BLUE, CYAN, MAUVE, PLUM = (hx(c) for c in
    ("#04061A", "#0B0A2A", "#231C78", "#4A23A8", "#163C9E", "#0A5C86", "#4E1F78", "#2A1050"))

def grid(W, H):
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    return (xx + 0.5) / W, (yy + 0.5) / H, W / H

def ramp(t, stops):
    t = np.clip(t, 0, 1)[..., None]
    out = np.zeros(t.shape[:-1] + (3,), np.float32)
    for (o0, c0), (o1, c1) in zip(stops, stops[1:]):
        m = ((t >= o0) & (t <= o1)).astype(np.float32)
        f = np.clip((t - o0) / (o1 - o0), 0, 1)
        f = f * f * (3 - 2 * f)
        out = out * (1 - m) + (c0 * (1 - f) + c1 * f) * m
    return out

def blob(u, v, a, x, y, r, c, s):
    d2 = ((u - x) * a) ** 2 + (v - y) ** 2
    return (np.exp(-d2 / (2 * r * r)) * s)[..., None] * c

def mesh(u, v, a, seed, n=6):
    r = np.random.RandomState(seed)
    pal = [INDIGO, VIOLET * 0.75, BLUE * 0.8, MAUVE * 0.8, PLUM, CYAN * 0.5, INK]
    img = NAVY * np.ones_like(u)[..., None]
    for _ in range(n):
        img = img + blob(u, v, a, r.rand(), r.rand(), 0.18 + r.rand() * 0.3, pal[r.randint(len(pal))], 0.5 + r.rand() * 0.7)
    return img

def mesh(u, v, a, seed, n=6):
    r = np.random.RandomState(seed)
    pal = [INDIGO, VIOLET * 0.75, BLUE * 0.8, MAUVE * 0.8, PLUM, CYAN * 0.5, INK]
    img = NAVY * np.ones_like(u)[..., None]
    for _ in range(n):
        img = img + blob(u, v, a, r.rand(), r.rand(), 0.18 + r.rand() * 0.3, pal[r.randint(len(pal))], 0.5 + r.rand() * 0.7)
    return img

def bg(W, H, k):
    u, v, a = grid(W, H)
    if k == 0:
        img = ramp(u * 0.6 + v * 0.4, [(0, INDIGO), (0.45, NAVY), (0.75, BLUE * 0.7), (1, NAVY)])
    elif k == 1:
        img = ramp(v, [(0, MAUVE * 0.8), (0.4, INK), (0.75, NAVY), (1, BLUE * 0.6)])
    elif k == 2:
        t = (u - 0.5) * a * 0.9 + (v - 0.5) * 0.5 + 0.5
        img = ramp(t, [(0, VIOLET * 0.7), (0.45, INK), (0.55, INK), (1, BLUE * 0.75)])
    elif k == 3:
        ang = (np.arctan2(v - 0.45, (u - 0.5) * a) / (2 * math.pi) + 0.5)
        d = np.sqrt(((u - 0.5) * a) ** 2 + (v - 0.45) ** 2)
        t = (ang + d * 0.6) % 1.0
        img = ramp(np.abs(t * 2 - 1), [(0, VIOLET * 0.7), (0.5, INDIGO * 0.9), (1, BLUE * 0.7)])
        img = img * (0.35 + 0.65 * np.exp(-d * 1.4))[..., None]
    elif k == 4:
        tl, tr, bl, br = MAUVE * 0.75, BLUE * 0.7, INDIGO, CYAN * 0.45
        uu = (u * u * (3 - 2 * u))[..., None]; vv = (v * v * (3 - 2 * v))[..., None]
        img = ((tl * (1 - uu) + tr * uu) * (1 - vv) + (bl * (1 - uu) + br * uu) * vv) * 0.8
    elif k == 5:
        d = np.sqrt(((u - 0.5) * a) ** 2 + (v - 0.45) ** 2)
        img = ramp(d / 0.95, [(0, INDIGO), (0.5, VIOLET * 0.45), (1, NAVY * 0.5)]) * (0.8 + 0.2 * (0.5 + 0.5 * np.cos(d * 16.0)))[..., None]
    else:
        if k == 10:
            t = np.clip(u * 0.35 + v * 0.65, 0, 1)
            img = ramp(t, [(0, PLUM * 0.9), (0.5, NAVY), (1, INDIGO * 0.8)])
            img = img + blob(u, v, a, 0.82, 0.3, 0.32, BLUE * 0.6, 0.9) + blob(u, v, a, 0.18, 0.78, 0.3, VIOLET * 0.5, 0.8)
        else:
            img = mesh(u, v, a, [7, 19, 42, 123][k - 6])
    img = img * 0.82
    cx = (u - 0.5) * a; cy = v - 0.45
    dist = np.sqrt(cx * cx + cy * cy) / math.sqrt((a * 0.5) ** 2 + 0.25)
    img = img * (1 - 0.6 * np.clip((dist - 0.3) / 0.8, 0, 1) ** 1.5)[..., None]
    img = 1 - np.exp(-img * 1.2)
    return np.clip(img, 0, 1) * 255

# Original AZIZ wordmark (BrandArt), letters slimmer, A notched at mid-height, feet kept apart.
A_OUT = "M7,76 L25,22 L39,22 L54.5,76 L44.5,76 L32,37 L19,76 Z"
A_BAR = "M22,60 L42,60 L44,67 L20,67 Z"
A_NOTCH = ["M47.8,48.5 L45.4,50 L48.3,51.5 Z"]
A_SPIKE = "M16.9,48.2 L13.2,50 L16.1,51.8 Z"
ZED = "M54,22 L91,22 L91,31 L69,67 L91,67 L91,76 L56,76 L56,67 L78,31 L54,31 Z"
CUT = "M77.52,6.0 L40.00,50.0 L54.00,50.0 L22.48,94.0 L68.48,44.0 L54.48,44.0 L83.52,6.0 Z"
BOLT = "M74.04,12.0 L44.24,47.0 L57.24,47.0 L32.44,82.0 L63.24,47.0 L50.24,47.0 Z"

def pts(p, size, tf):
    out = []
    for q in p.replace('M', '').replace('Z', '').replace('L', '').split():
        x, y = (float(n) for n in q.split(','))
        if tf: x, y = x * tf[0] + tf[1], y * tf[0] + tf[2]
        out.append((x * size / 100, y * size / 100))
    return out

def mask(fill, holes, size, tf=None):
    im = Image.new('L', (size, size), 0); d = ImageDraw.Draw(im)
    for p in fill: d.polygon(pts(p, size, tf), fill=255)
    for p in holes: d.polygon(pts(p, size, tf), fill=0)
    return np.array(im)

def bbox_grad(m, stops, vertical=False):
    ys, xs = np.nonzero(m > 0)
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    L = m.shape[0]
    yy, xx = np.mgrid[0:L, 0:L].astype(np.float32)
    fx = (xx - x0) / max(1, x1 - x0); fy = (yy - y0) / max(1, y1 - y0)
    t = fy if vertical else (fx + fy) / 2
    return ramp(t, [(o, np.array(c, np.float32)) for o, c in stops])

RIGHT_OF_CUT = "M83.52,0 L83.52,6 L54.48,44 L68.48,44 L22.48,94 L22.48,100 L100,100 L100,0 Z"
LEFT_OF_BOLT = "M0,0 L84.25,0 L74.04,12 L44.24,47 L57.24,47 L32.44,82 L32.44,100 L0,100 Z"
LEFT_OF_CUT = "M0,0 L77.52,0 L77.52,6 L40,50 L54,50 L22.48,94 L22.48,100 L0,100 Z"

def logo(img, W, H):
    from PIL import ImageFilter
    L = int(H * 0.44); big = L * 8; tf = (0.80, 10.8, 10.8)
    cut = mask([CUT], [], big)
    mA = np.minimum(mask([A_OUT, A_BAR, A_SPIKE], A_NOTCH, big, tf), 255 - cut)
    from PIL import ImageFilter as _F
    hug = np.array(Image.fromarray(mask([BOLT], [], big)).filter(_F.MaxFilter(int(big * 0.012) | 1)))
    mZ = np.minimum(mask([ZED], [], big, tf), 255 - hug)
    mZ = np.minimum(mZ, 255 - mask([LEFT_OF_BOLT], [], big))
    mB = mask([BOLT], [], big)
    # metal details: bevel highlight on the bolt's inner edge, dark rim outside
    rim = int(big * 0.0025)
    inner = np.array(Image.fromarray(mB).filter(ImageFilter.MinFilter(rim * 2 + 1)))
    outer = np.array(Image.fromarray(mB).filter(ImageFilter.MaxFilter(rim * 2 + 1)))
    edge = (mB.astype(np.int32) - inner).clip(0, 255).astype(np.uint8)
    shell = (outer.astype(np.int32) - mB).clip(0, 255).astype(np.uint8)
    sm = lambda m: np.array(Image.fromarray(m).resize((L, L), Image.LANCZOS)).astype(np.float32) / 255
    mA, mZ, mB, edge, shell = sm(mA), sm(mZ), sm(mB), sm(edge), sm(shell)
    cA = bbox_grad(mA, [(0, (150, 205, 255)), (0.35, (40, 135, 235)), (0.7, (70, 50, 205)), (1, (55, 20, 150))])
    cZ = bbox_grad(mZ, [(0, (92, 30, 190)), (0.5, (92, 30, 190)), (0.75, (118, 70, 212)), (1, (150, 115, 232))])
    cB = bbox_grad(mB, [(0, (255, 247, 200)), (0.5, (255, 200, 40)), (1, (234, 120, 0))], True)
    ys, xs = np.mgrid[0:L, 0:L].astype(np.float32) / L
    brushed = 0.5 + 0.5 * np.sin((xs * 0.8 + ys) * 160.0) * np.sin((xs * 0.8 + ys) * 23.0)
    sheen = np.exp(-((xs - ys * 0.55 - 0.18) ** 2) / 0.004)
    ox = (W - L) // 2; oy = int(H * 0.45) - L // 2
    reg = img[oy:oy + L, ox:ox + L]
    for m, c in zip((mA, mZ, mB), (cA, cZ, cB)):
        reg = reg * (1 - m[..., None]) + c * m[..., None]
    img[oy:oy + L, ox:ox + L] = reg
    return img

def render(W, H, k):
    img = logo(bg(W, H, k), W, H)
    img = img + (np.random.rand(H, W, 3) - np.random.rand(H, W, 3))
    return np.clip(img, 0, 255).astype(np.uint8)

if __name__ == "__main__":
    W, H = int(sys.argv[1]), int(sys.argv[2]); p = sys.argv[3]
    only = [int(x) for x in sys.argv[4:]] or range(11)
    for k in only:
        Image.fromarray(render(W, H, k)).save(f"{p}-{k + 1:02d}.png", optimize=True)
