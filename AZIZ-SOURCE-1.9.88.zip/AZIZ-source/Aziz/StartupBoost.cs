using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace Aziz;

internal sealed class StartupBoost : IDisposable
{
	private struct Throttle
	{
		public uint Version;

		public uint ControlMask;

		public uint StateMask;
	}

	internal static int Active;

	private static ProcessPriorityClass original;

	private static bool changed;

	private int disposed;

	[DllImport("kernel32.dll")]
	private static extern bool SetProcessInformation(IntPtr process, int kind, ref Throttle state, uint size);

	private static void Speed(bool full)
	{
		try
		{
			Throttle throttle = default(Throttle);
			throttle.Version = 1u;
			throttle.ControlMask = (full ? 1u : 0u);
			throttle.StateMask = 0u;
			Throttle state = throttle;
			SetProcessInformation(new IntPtr(-1), 4, ref state, 12u);
		}
		catch
		{
		}
	}

	public StartupBoost()
	{
		if (Interlocked.Increment(ref Active) != 1)
		{
			return;
		}
		try
		{
			using (Process process = Process.GetCurrentProcess())
			{
				original = process.PriorityClass;
				changed = original == ProcessPriorityClass.Normal || original == ProcessPriorityClass.AboveNormal;
				if (changed)
				{
					process.PriorityClass = ProcessPriorityClass.High;
				}
			}
			Speed(full: true);
		}
		catch
		{
		}
	}

	public void Dispose()
	{
		if (Interlocked.Exchange(ref disposed, 1) != 0 || Interlocked.Decrement(ref Active) != 0)
		{
			return;
		}
		try
		{
			using Process process = Process.GetCurrentProcess();
			if (changed && process.PriorityClass == ProcessPriorityClass.High)
			{
				process.PriorityClass = original;
			}
		}
		catch
		{
		}
		changed = false;
		Speed(full: false);
	}
}
