using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class DisplayHardware
{
	private static readonly object gate = new object();

	private static List<DisplayDevice> cache;

	public static void Invalidate()
	{
		lock (gate)
		{
			cache = null;
		}
		GpuInterrupt.Invalidate();
	}

	internal static string ResolveClassPath(string instance, Func<string, string, object> read)
	{
		if (string.IsNullOrEmpty(instance) || !instance.StartsWith("PCI\\VEN_10DE&", StringComparison.OrdinalIgnoreCase))
		{
			return null;
		}
		string text = Convert.ToString(read("SYSTEM\\CurrentControlSet\\Enum\\" + instance, "Driver"));
		if (!Regex.IsMatch(text ?? "", "^\\{4d36e968-e325-11ce-bfc1-08002be10318\\}\\\\[0-9]{4}$", RegexOptions.IgnoreCase))
		{
			return null;
		}
		return "SYSTEM\\CurrentControlSet\\Control\\Class\\" + text;
	}

	private static object Read(string path, string name)
	{
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(path);
		return registryKey?.GetValue(name);
	}

	public static List<DisplayDevice> Nvidia()
	{
		lock (gate)
		{
			if (cache == null)
			{
				cache = (from d in PciDisplays()
					where d.Instance.StartsWith("PCI\\VEN_10DE&", StringComparison.OrdinalIgnoreCase)
					select d).ToList();
			}
			return (from d in cache
				select new DisplayDevice
				{
					Name = d.Name,
					Instance = d.Instance,
					DriverPath = ResolveClassPath(d.Instance, Read)
				} into d
				where d.DriverPath != null
				select d).ToList();
		}
	}

	// Name of the first NVIDIA GPU, also when Windows has no NVIDIA driver yet (fresh install: "Microsoft Basic Display
	// Adapter"): then the PCI device id is looked up in the GeForce list.
	public static string NvidiaName()
	{
		List<DisplayDevice> list = Nvidia();
		if (list.Count > 0 && list[0].Name.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return list[0].Name;
		}
		foreach (DisplayDevice item in PciDisplays().Where((DisplayDevice d) => d.Instance.StartsWith("PCI\\VEN_10DE&", StringComparison.OrdinalIgnoreCase)))
		{
			System.Text.RegularExpressions.Match match = System.Text.RegularExpressions.Regex.Match(item.Instance, "DEV_([0-9A-F]{4})", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
			if (match.Success && NvidiaPciNames.Names.TryGetValue(match.Groups[1].Value.ToUpperInvariant(), out var value))
			{
				return "NVIDIA " + System.Text.RegularExpressions.Regex.Replace(value, "\\s+(Mobile|Max-Q|Laptop GPU)(\\s*/\\s*Max-Q)?$", " Laptop GPU");
			}
		}
		return null;
	}

	public static List<DisplayDevice> PciDisplays()
	{
		List<DisplayDevice> list = new List<DisplayDevice>();
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		string[] array = new string[2] { "SELECT Name,DeviceID FROM Win32_PnPEntity WHERE PNPClass='Display'", "SELECT Name,PNPDeviceID FROM Win32_VideoController" };
		foreach (string text in array)
		{
			try
			{
				using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(text);
				using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
				foreach (ManagementObject item in managementObjectCollection)
				{
					using (item)
					{
						string text2 = Convert.ToString(item[text.Contains("PnPEntity") ? "DeviceID" : "PNPDeviceID"]);
						if (!string.IsNullOrEmpty(text2) && text2.StartsWith("PCI\\", StringComparison.OrdinalIgnoreCase) && hashSet.Add(text2))
						{
							list.Add(new DisplayDevice
							{
								Name = Convert.ToString(item["Name"]),
								Instance = text2
							});
						}
					}
				}
			}
			catch
			{
			}
		}
		return list;
	}

	public static TweakStatus MemoryCompression(Tweak t)
	{
		List<DisplayDevice> list = Nvidia();
		t.Enable = list.Select((DisplayDevice d) => new RegistryOperation
		{
			Hive = "HKLM",
			Path = d.DriverPath,
			Name = "RMDisablePostL2Compression",
			Kind = "DWord",
			Value = 1
		}).ToList();
		t.Disable = t.Enable.Select((RegistryOperation o) => new RegistryOperation
		{
			Hive = o.Hive,
			Path = o.Path,
			Name = o.Name,
			Kind = o.Kind,
			Value = null
		}).ToList();
		if (list.Count == 0)
		{
			return new TweakStatus
			{
				State = "Unavailable",
				Detail = "No NVIDIA driver key detected."
			};
		}
		int num = list.Count((DisplayDevice d) => object.Equals(Read(d.DriverPath, "RMDisablePostL2Compression"), 1));
		return new TweakStatus
		{
			State = ((num == list.Count) ? "Enabled" : ((num == 0) ? "Disabled" : "Mixed")),
			Detail = num + " / " + list.Count + " NVIDIA post-L2 overrides configured. Restart required; driver behavior is not measured."
		};
	}

	public static TweakStatus Hdcp(Tweak t)
	{
		List<DisplayDevice> list = Nvidia();
		t.Enable = list.Select((DisplayDevice d) => new RegistryOperation
		{
			Hive = "HKLM",
			Path = d.DriverPath,
			Name = "RMHdcpKeyglobZero",
			Kind = "DWord",
			Value = 1
		}).ToList();
		t.Disable = t.Enable.Select((RegistryOperation o) => new RegistryOperation
		{
			Hive = o.Hive,
			Path = o.Path,
			Name = o.Name,
			Kind = o.Kind,
			Value = 0
		}).ToList();
		if (list.Count == 0)
		{
			return new TweakStatus
			{
				State = "Unavailable",
				Detail = "No active NVIDIA display-driver class key was detected."
			};
		}
		int num = list.Count((DisplayDevice d) => object.Equals(Read(d.DriverPath, "RMHdcpKeyglobZero"), 1));
		TweakStatus tweakStatus = new TweakStatus();
		tweakStatus.State = ((num == list.Count) ? "Enabled" : ((num == 0) ? "Disabled" : "Mixed"));
		tweakStatus.Detail = num + " / " + list.Count + " NVIDIA GPUs have the HDCP disable override. Restart and check NVIDIA Control Panel to verify active HDCP status.\n" + string.Join("\n", list.Select((DisplayDevice d) => d.Name + " · HKLM\\" + d.DriverPath));
		return tweakStatus;
	}
}
