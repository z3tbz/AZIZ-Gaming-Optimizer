namespace Aziz;

internal interface ITimerApi
{
	uint Query();

	uint Set(bool enabled);

	bool Honor(bool enabled);

	void WaitHalfMillisecond();
}
