using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Win32;

namespace Aziz;

internal static class ComponentRecovery
{
	public static ActionResult BeforeEnable(Tweak t)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>
		{
			{ "wifi", "WlanSvc" },
			{ "bluetooth", "bthserv" },
			{ "printing", "Spooler" },
			{ "windows-update", "wuauserv" }
		};
		if (t.Id != null && dictionary.TryGetValue(t.Id, out var value))
		{
			return BeforeEnable(new Tweak
			{
				Kind = "Service",
				Service = value
			});
		}
		if (t.Kind == "Service")
		{
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + t.Service))
			{
				if (registryKey != null)
				{
					return new ActionResult
					{
						Success = true
					};
				}
			}
			if (t.Service.StartsWith("Xbl", StringComparison.OrdinalIgnoreCase) || t.Service.StartsWith("Xbox", StringComparison.OrdinalIgnoreCase))
			{
				return Recovery.Install(Recovery.Apps.First((RestoreApp x) => x.Name == "Xbox"));
			}
			if (t.Service == "GamingServices" || t.Service == "GamingServicesNet")
			{
				return Recovery.Install(Recovery.Apps.First((RestoreApp x) => x.Name == "Gaming Services"));
			}
			ActionResult actionResult = Recovery.Repair(null);
			if (!actionResult.Success)
			{
				return actionResult;
			}
			ActionResult actionResult2 = Recovery.LongRun("sfc.exe", "/scannow");
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + t.Service))
			{
				if (registryKey2 != null)
				{
					return new ActionResult
					{
						Success = true,
						Message = "Component repair completed; applying the selected service mode."
					};
				}
			}
			return new ActionResult
			{
				Message = "Windows repair could not restore " + t.Service + " on this installation. A matching Windows repair image or in-place repair is required. " + actionResult2.Message
			};
		}
		return new ActionResult
		{
			Success = true
		};
	}
}
