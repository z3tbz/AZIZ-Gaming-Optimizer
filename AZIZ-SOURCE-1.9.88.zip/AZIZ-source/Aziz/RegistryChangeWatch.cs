using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace Aziz;

internal sealed class RegistryChangeWatch : IDisposable
{
	private sealed class Watch : IDisposable
	{
		public RegistryKey Key;

		public AutoResetEvent Signal;

		public RegisteredWaitHandle Wait;

		public string[] Ids;

		public volatile bool Closed;

		public void Dispose()
		{
			Closed = true;
			if (Wait != null)
			{
				Wait.Unregister(null);
			}
			if (Key != null)
			{
				Key.Dispose();
			}
			if (Signal != null)
			{
				Signal.Dispose();
			}
		}
	}

	private readonly List<Watch> watches = new List<Watch>();

	private volatile bool disposed;

	[DllImport("advapi32.dll")]
	private static extern int RegNotifyChangeKeyValue(SafeRegistryHandle key, bool subtree, uint filter, IntPtr handle, bool asynchronous);

	public RegistryChangeWatch(IEnumerable<Tweak> tweaks, Action<string[]> changed)
	{
		RegistryChangeWatch registryChangeWatch = this;
		Dictionary<string, HashSet<string>> paths = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
		Action<string, string, string> action = delegate(string h, string p, string id)
		{
			if (!string.IsNullOrEmpty(p))
			{
				int num2 = p.IndexOf('*');
				if (num2 >= 0)
				{
					p = p.Substring(0, num2).TrimEnd('\\');
				}
				string key = h + "|" + p;
				if (!paths.TryGetValue(key, out var value))
				{
					HashSet<string> hashSet2 = (paths[key] = new HashSet<string>());
					value = hashSet2;
				}
				value.Add(id);
			}
		};
		foreach (Tweak tweak in tweaks)
		{
			foreach (RegistryOperation item in (tweak.Enable ?? new List<RegistryOperation>()).Concat(tweak.Disable ?? new List<RegistryOperation>()))
			{
				action(item.Hive, item.Path, tweak.Id);
			}
			if (tweak.Kind == "Service")
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Services", tweak.Id);
			}
			if (tweak.Kind == "NvidiaScaling")
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Control\\Video", tweak.Id);
			}
			if (tweak.Kind == "NvidiaHdcp" || tweak.Kind == "NvidiaMemoryCompression")
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}", tweak.Id);
				action("HKLM", "SYSTEM\\CurrentControlSet\\Enum", tweak.Id);
			}
			string text = tweak.ProbeScript ?? "";
			if (tweak.Kind == "Bcd" || text.Contains("bcdedit"))
			{
				action("HKLM", "BCD00000000", tweak.Id);
			}
			if (tweak.Category == "Network")
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Services\\Tcpip", tweak.Id);
				action("HKLM", "SYSTEM\\CurrentControlSet\\Services\\Tcpip6", tweak.Id);
				action("HKLM", "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}", tweak.Id);
			}
			if (text.Contains("ScheduledTask"))
			{
				action("HKLM", "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Schedule\\TaskCache", tweak.Id);
			}
			if (text.Contains("MMAgent") || text.Contains("PageFile"))
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management", tweak.Id);
			}
			if (text.Contains("fsutil"))
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Control\\FileSystem", tweak.Id);
			}
			if (text.Contains("powercfg"))
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Control\\Power\\User\\PowerSchemes", tweak.Id);
			}
			if (tweak.Kind == "Native" && (text.Contains("Win32_Service") || text.Contains("Get-Service")))
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Services", tweak.Id);
			}
			if (tweak.Id == "power-saving" || tweak.Id == "usb-device-power" || tweak.Id == "usb-root-power" || tweak.Kind == "GpuMsi")
			{
				action("HKLM", "SYSTEM\\CurrentControlSet\\Enum", tweak.Id);
			}
		}
		action("HKLM", "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "@apps");
		action("HKLM", "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "@apps");
		action("HKCU", "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "@apps");
		action("HKCU", "Software\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\CurrentVersion\\AppModel\\Repository\\Packages", "@apps");
		foreach (KeyValuePair<string, HashSet<string>> item2 in paths)
		{
			try
			{
				string[] array = item2.Key.Split(new char[1] { '|' }, 2);
				using RegistryKey registryKey2 = RegistryKey.OpenBaseKey((array[0] == "HKCU") ? RegistryHive.CurrentUser : RegistryHive.LocalMachine, Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32);
				string text2 = array[1];
				RegistryKey registryKey = null;
				while (!string.IsNullOrEmpty(text2) && (registryKey = registryKey2.OpenSubKey(text2)) == null)
				{
					int num = text2.LastIndexOf('\\');
					text2 = ((num < 0) ? null : text2.Substring(0, num));
				}
				if (registryKey == null)
				{
					continue;
				}
				Watch w = new Watch
				{
					Key = registryKey,
					Signal = new AutoResetEvent(initialState: false),
					Ids = item2.Value.ToArray()
				};
				if (RegNotifyChangeKeyValue(registryKey.Handle, subtree: true, 268435461u, w.Signal.SafeWaitHandle.DangerousGetHandle(), asynchronous: true) != 0)
				{
					w.Dispose();
					continue;
				}
				w.Wait = ThreadPool.RegisterWaitForSingleObject(w.Signal, delegate
				{
					if (registryChangeWatch.disposed || w.Closed)
					{
						return;
					}
					try
					{
						if (RegNotifyChangeKeyValue(w.Key.Handle, subtree: true, 268435461u, w.Signal.SafeWaitHandle.DangerousGetHandle(), asynchronous: true) == 0)
						{
							changed(w.Ids);
						}
					}
					catch (ObjectDisposedException)
					{
					}
				}, null, -1, executeOnlyOnce: false);
				watches.Add(w);
			}
			catch
			{
			}
		}
	}

	public void Dispose()
	{
		disposed = true;
		foreach (Watch watch in watches)
		{
			watch.Dispose();
		}
		watches.Clear();
	}
}
