using System.Collections.Generic;
using System.Linq;

namespace Aziz;

internal static class ProfileLogic
{
	internal const string None = "";

	internal const string WindowsDefault = "windows-default";

	internal const string Recommended = "aziz-recommended";

	internal const string Ultra = "aziz-ultra";

	internal static bool BuiltIn(string key)
	{
		if (!(key == "windows-default") && !(key == "aziz-recommended"))
		{
			return key == "aziz-ultra";
		}
		return true;
	}

	internal static string BuiltInName(string key)
	{
		return key switch
		{
			"windows-default" => "Windows Default", 
			"aziz-recommended" => "Low Latency", 
			"aziz-ultra" => "Ultra Low Latency", 
			_ => null, 
		};
	}

	internal static bool Profileable(Tweak t)
	{
		if (t.Id == "cpu-boost-settings")
		{
			return true;
		}
		return !new string[6] { "Unavailable", "Shortcut", "Action", "GpuMsi", "SystemRestore", "PowerConfigure" }.Contains(t.Kind);
	}

	internal static string ServiceValue(TweakStatus value)
	{
		string text = value.Detail ?? "";
		if (text.Contains("Startup: Automatic"))
		{
			return "2";
		}
		if (text.Contains("Startup: Manual"))
		{
			return "3";
		}
		if (text.Contains("Startup: Disabled"))
		{
			return "4";
		}
		if (text.Contains("Startup: Boot"))
		{
			return "0";
		}
		if (text.Contains("Startup: System"))
		{
			return "1";
		}
		return null;
	}

	internal static string CurrentValue(Engine engine, Dictionary<string, TweakStatus> states, Tweak t)
	{
		if (!Profileable(t) || !states.TryGetValue(t.Id, out var value) || value == null || value.State == "Unavailable")
		{
			return null;
		}
		if (t.Id == "cpu-boost-settings")
		{
			try
			{
				PowerValue powerValue = PowerControls.Read(t.Id).Values.First((PowerValue x) => x.Key == "cpu-boost-policy");
				return "boost:" + powerValue.AC;
			}
			catch
			{
				return null;
			}
		}
		if (t.Kind == "Service")
		{
			return ServiceValue(value);
		}
		if (t.Choices != null && t.Choices.Count > 0)
		{
			try
			{
				return engine.ConfiguredChoice(t.Id);
			}
			catch
			{
				return null;
			}
		}
		if (!(value.State == "Enabled") && !(value.State == "Disabled"))
		{
			return null;
		}
		return value.State;
	}

	internal static bool ValueApplies(Tweak t, string value)
	{
		if (string.IsNullOrEmpty(value) || !Profileable(t))
		{
			return false;
		}
		if (t.Id == "cpu-boost-settings")
		{
			if (value.StartsWith("boost:") && uint.TryParse(value.Substring(6), out var result))
			{
				return result <= 100;
			}
			return false;
		}
		if (t.Kind == "Service")
		{
			if (value == "0" || value == "1")
			{
				if (t.Choices != null)
				{
					return t.Choices.Any((TweakChoice c) => c.Value == value);
				}
				return false;
			}
			if (!(value == "2") && !(value == "3"))
			{
				return value == "4";
			}
			return true;
		}
		if (t.Choices != null && t.Choices.Count > 0)
		{
			if (!t.Choices.Any((TweakChoice c) => c.Value == value && c.Value != "custom"))
			{
				if (t.CustomDecimal && int.TryParse(value, out var result2) && result2 >= 0)
				{
					return result2 <= 63;
				}
				return false;
			}
			return true;
		}
		if (!(value == "Enabled"))
		{
			return value == "Disabled";
		}
		return true;
	}

	internal static string SecurityValue(Tweak t)
	{
		if (t.Category != "Security" || !Profileable(t) || t.Kind == "SystemRestore")
		{
			return null;
		}
		if (t.Id == "bitlocker")
		{
			return "Disabled";
		}
		if (!AzizPresets.SecurityOn.Contains(t.Id))
		{
			return "Disabled";
		}
		return "Enabled";
	}

	internal static Dictionary<string, string> PresetValues(IEnumerable<Tweak> tweaks, bool ultra)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		Dictionary<string, string> dictionary2 = (ultra ? AzizPresets.Ultra : AzizPresets.Basic);
		foreach (Tweak tweak in tweaks)
		{
			if (!Profileable(tweak))
			{
				continue;
			}
			string value;
			if (tweak.Kind == "Service")
			{
				int? num = ServicePresets.Target("recommended", tweak.Service);
				if (num.HasValue)
				{
					dictionary[tweak.Id] = num.Value.ToString();
				}
			}
			else if (dictionary2.TryGetValue(tweak.Id, out value))
			{
				dictionary[tweak.Id] = value;
			}
			else if (tweak.Category == "Network" && AzizPresets.Network.TryGetValue(tweak.Id, out value))
			{
				dictionary[tweak.Id] = value;
			}
			else
			{
				string text = SecurityValue(tweak);
				if (text != null)
				{
					dictionary[tweak.Id] = text;
				}
			}
		}
		return dictionary;
	}

	// Saved profiles and references from older builds: "custom performance" (visual-best-performance, same meaning) and
	// "Animations & Visual Effects" (animations, opposite meaning) are now one option, Disable Animations.
	internal static void Upgrade(Dictionary<string, string> values)
	{
		if (values == null)
		{
			return;
		}
		if (values.TryGetValue("animations", out var value))
		{
			if (!values.ContainsKey("disable-animations") && (value == "Enabled" || value == "Disabled"))
			{
				values["disable-animations"] = ((value == "Enabled") ? "Disabled" : "Enabled");
			}
			values.Remove("animations");
		}
		if (values.TryGetValue("visual-best-performance", out var value2))
		{
			if (!values.ContainsKey("disable-animations") && (value2 == "Enabled" || value2 == "Disabled"))
			{
				values["disable-animations"] = value2;
			}
			values.Remove("visual-best-performance");
		}
	}

	internal static bool PresetSafe(Tweak t, string value)
	{
		if (t.Kind == "Service" && value == "4")
		{
			return !ServicePresets.RegisteredFilter(t.Service);
		}
		return true;
	}
}
