using System.Collections.Generic;

namespace Aziz;

internal class CompetitiveJournal
{
	public List<LauncherBackup> Launchers { get; set; }

	public string Ifeo { get; set; }

	public bool IfeoCreated { get; set; }

	public CompetitiveJournal()
	{
		Launchers = new List<LauncherBackup>();
	}
}
