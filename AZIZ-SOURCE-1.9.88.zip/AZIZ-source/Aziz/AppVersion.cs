namespace Aziz;

internal static class AppVersion
{
	public const string Text = "1.9.7";
}
