using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Aziz;

internal static class PortableArchives
{
	private static string Run(string args)
	{
		string text = Path.Combine(Program.Root, "helpers", "7zip", "7z.exe");
		if (!File.Exists(text))
		{
			throw new IOException("Portable archive helper is missing. Extract the complete AZIZ package.");
		}
		using Process process = new Process
		{
			StartInfo = new ProcessStartInfo(text, args)
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true
			}
		};
		process.Start();
		Task<string> task = process.StandardOutput.ReadToEndAsync();
		Task<string> task2 = process.StandardError.ReadToEndAsync();
		if (!process.WaitForExit(120000))
		{
			try
			{
				process.Kill();
			}
			catch
			{
			}
			throw new IOException("Archive preparation timed out.");
		}
		Task.WaitAll(task, task2);
		if (process.ExitCode != 0)
		{
			throw new IOException("Archive preparation failed: " + task2.Result);
		}
		return task.Result;
	}

	public static void Extract(string source, string destination)
	{
		source = Path.GetFullPath(source);
		destination = Path.GetFullPath(destination);
		DownloadLibrary.NoLinks(source);
		DownloadLibrary.NoLinks(destination);
		if (Directory.Exists(destination) || !DownloadLibrary.Within(destination, DownloadLibrary.Folder))
		{
			throw new IOException("Invalid portable extraction directory.");
		}
		string[] array = Run("l -slt -ba -- \"" + source + "\"").Replace("\r", "").Split(new string[1] { "\n\n" }, StringSplitOptions.RemoveEmptyEntries);
		long num = 0L;
		int num2 = 0;
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		string[] array2 = array;
		foreach (string obj in array2)
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string[] array3 = obj.Split('\n');
			foreach (string text in array3)
			{
				int num3 = text.IndexOf(" = ", StringComparison.Ordinal);
				if (num3 > 0)
				{
					dictionary[text.Substring(0, num3)] = text.Substring(num3 + 3);
				}
			}
			if (!dictionary.TryGetValue("Path", out var value))
			{
				continue;
			}
			if (++num2 > 50000 || Path.IsPathRooted(value) || value.Contains(':') || value.Split('\\', '/').Any((string x) => x == "..") || dictionary.ContainsKey("Symbolic Link") || dictionary.ContainsKey("Hard Link"))
			{
				throw new IOException("Unsafe archive entry");
			}
			string fullPath = Path.GetFullPath(Path.Combine(destination, value));
			if (!DownloadLibrary.Within(fullPath, destination) || !hashSet.Add(fullPath))
			{
				throw new IOException("Unsafe or duplicate archive path");
			}
			if (dictionary.TryGetValue("Size", out var value2))
			{
				if (!long.TryParse(value2, out var result) || result < 0)
				{
					throw new IOException("Invalid archive size");
				}
				num = checked(num + result);
				if (num > 8589934592L)
				{
					throw new IOException("Archive exceeds the size limit.");
				}
			}
		}
		if (num2 == 0)
		{
			throw new IOException("The archive contains no files.");
		}
		Directory.CreateDirectory(destination);
		Run("x -y -bd -o\"" + destination + "\" -- \"" + source + "\"");
	}
}
