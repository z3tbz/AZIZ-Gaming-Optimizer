using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

// The AZIZ registry set and the debloat values are applied by One Click outside the option catalog. Before a value is
// written for the first time, its original (or "missing") is kept here, so Windows Default puts every one of them back.
internal static class RegistryJournal
{
	public class Entry
	{
		public string Root { get; set; }

		public string Key { get; set; }

		public string Name { get; set; }

		public bool Existed { get; set; }

		public string Kind { get; set; }

		public string Text { get; set; }

		public long Number { get; set; }
	}

	private static readonly object Gate = new object();

	private static List<Entry> entries;

	private static string FilePath => Path.Combine(Program.Data, "registry-set-journal.json");

	private static List<Entry> Load()
	{
		if (entries == null)
		{
			try
			{
				entries = (File.Exists(FilePath) ? Program.Json.Deserialize<List<Entry>>(File.ReadAllText(FilePath)) : null) ?? new List<Entry>();
			}
			catch
			{
				// A damaged journal is kept aside (never overwritten by the next save), so its originals are not lost.
				try
				{
					File.Move(FilePath, FilePath + ".bad-" + DateTime.Now.ToString("yyyyMMddHHmmss"));
				}
				catch
				{
				}
				entries = new List<Entry>();
			}
		}
		return entries;
	}

	private static RegistryKey Root(string name)
	{
		return name switch
		{
			"HKLM" => Registry.LocalMachine, 
			"HKU" => Registry.Users, 
			_ => Registry.CurrentUser, 
		};
	}

	// Windows originals saved by the options (their snapshots), for every value an option also writes. One Click runs the
	// options first, so when the registry set then writes the same value, the live value is already AZIZ's: the journal
	// keeps the option's saved original instead, and Windows Default restores the true Windows value whatever the order.
	public static Dictionary<string, SavedValue> Originals;

	public static string KeyOf(string root, string key, string name)
	{
		return (root + "\\" + key.Trim('\\') + "\\" + name).ToLowerInvariant();
	}

	private static bool FromOriginal(Entry entry)
	{
		if (Originals == null || !Originals.TryGetValue(KeyOf(entry.Root, entry.Key, entry.Name), out var value))
		{
			return false;
		}
		if (!value.Exists)
		{
			entry.Existed = false;
			return true;
		}
		try
		{
			switch (value.Kind)
			{
			case "DWord":
			case "QWord":
				entry.Existed = true;
				entry.Kind = value.Kind;
				entry.Number = Convert.ToInt64(value.Value);
				return true;
			case "String":
			case "ExpandString":
				entry.Existed = true;
				entry.Kind = value.Kind;
				entry.Text = Convert.ToString(value.Value);
				return true;
			}
		}
		catch
		{
		}
		return false;
	}

	// Call before writing root\key\name.
	public static void Remember(string root, string key, string name)
	{
		lock (Gate)
		{
			List<Entry> list = Load();
			if (list.Any((Entry e) => e.Root == root && string.Equals(e.Key, key, StringComparison.OrdinalIgnoreCase) && string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase)))
			{
				return;
			}
			Entry entry = new Entry
			{
				Root = root,
				Key = key,
				Name = name
			};
			if (FromOriginal(entry))
			{
				list.Add(entry);
				return;
			}
			try
			{
				using RegistryKey registryKey = Root(root).OpenSubKey(key);
				object obj = registryKey?.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
				if (obj != null)
				{
					RegistryValueKind valueKind = registryKey.GetValueKind(name);
					if (valueKind != RegistryValueKind.DWord && valueKind != RegistryValueKind.QWord && valueKind != RegistryValueKind.String && valueKind != RegistryValueKind.ExpandString)
					{
						return;
					}
					entry.Existed = true;
					entry.Kind = valueKind.ToString();
					if (valueKind == RegistryValueKind.DWord || valueKind == RegistryValueKind.QWord)
					{
						entry.Number = Convert.ToInt64(obj);
					}
					else
					{
						entry.Text = Convert.ToString(obj);
					}
				}
			}
			catch
			{
				return;
			}
			list.Add(entry);
		}
	}

	public static void Save()
	{
		lock (Gate)
		{
			try
			{
				Directory.CreateDirectory(Program.Data);
				Utilities.AtomicWrite(FilePath, Program.Json.Serialize(Load()));
			}
			catch
			{
			}
		}
	}

	private static List<Tuple<string, Regex, string>> allowed;

	// Only values the AZIZ registry set or the debloat list write may be restored: the journal is a file in the user's
	// folder, and AZIZ restores with admin rights.
	private static bool Allowed(Entry e)
	{
		if (allowed == null)
		{
			List<Tuple<string, Regex, string>> list = new List<Tuple<string, Regex, string>>();
			Func<string, Regex> pattern = (string path) => new Regex("^" + Regex.Escape(path.Trim('\\')).Replace("\\*", "[^\\\\]+") + "$", RegexOptions.IgnoreCase);
			try
			{
				using Stream stream = typeof(RegistryJournal).Assembly.GetManifestResourceStream("Aziz.silent.reg");
				using StreamReader streamReader = new StreamReader(stream);
				string root = null;
				Regex regex = null;
				foreach (string item in streamReader.ReadToEnd().Replace("\r", "").Split('\n'))
				{
					Match match = Regex.Match(item.Trim(), "^\\[(HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER)\\\\(.+)\\]$");
					if (match.Success)
					{
						root = ((match.Groups[1].Value == "HKEY_LOCAL_MACHINE") ? "HKLM" : "HKCU");
						regex = pattern(match.Groups[2].Value);
						continue;
					}
					Match match2 = Regex.Match(item.Trim(), "^\"([^\"]+)\"=");
					if (match2.Success && root != null)
					{
						list.Add(Tuple.Create(root, regex, match2.Groups[1].Value));
					}
				}
			}
			catch
			{
			}
			try
			{
				DebloatList.Data data = Program.Json.Deserialize<DebloatList.Data>(DebloatList.Json());
				foreach (DebloatList.RegValue item2 in (data.Registry ?? new Dictionary<string, List<DebloatList.RegValue>>()).Values.Concat((data.Review ?? new Dictionary<string, List<DebloatList.RegValue>>()).Values).SelectMany((List<DebloatList.RegValue> x) => x))
				{
					string text = item2.P ?? "";
					string root2 = (text.StartsWith("HKLM:\\", StringComparison.OrdinalIgnoreCase) ? "HKLM" : (text.StartsWith("HKCU:\\", StringComparison.OrdinalIgnoreCase) ? "HKCU" : (text.StartsWith("Registry::HKEY_USERS\\", StringComparison.OrdinalIgnoreCase) ? "HKU" : null)));
					if (root2 != null && item2.N != null)
					{
						list.Add(Tuple.Create(root2, pattern(text.Substring((root2 == "HKU") ? 21 : 6)), item2.N));
					}
				}
			}
			catch
			{
			}
			allowed = list;
		}
		return allowed.Any((Tuple<string, Regex, string> x) => x.Item1 == e.Root && string.Equals(x.Item3, e.Name, StringComparison.OrdinalIgnoreCase) && x.Item2.IsMatch((e.Key ?? "").Trim('\\')));
	}

	public static List<string> RestoreAll()
	{
		List<string> list = new List<string>();
		lock (Gate)
		{
			List<Entry> list2 = Load();
			foreach (Entry item in list2.ToList())
			{
				if (!Allowed(item))
				{
					list2.Remove(item);
					continue;
				}
				try
				{
					if (item.Existed)
					{
						using RegistryKey registryKey = Root(item.Root).CreateSubKey(item.Key);
						RegistryValueKind registryValueKind = (RegistryValueKind)Enum.Parse(typeof(RegistryValueKind), item.Kind);
						object value = registryValueKind switch
						{
							RegistryValueKind.DWord => (int)item.Number, 
							RegistryValueKind.QWord => item.Number, 
							_ => item.Text ?? "", 
						};
						registryKey.SetValue(item.Name, value, registryValueKind);
					}
					else
					{
						using RegistryKey registryKey2 = Root(item.Root).OpenSubKey(item.Key, writable: true);
						registryKey2?.DeleteValue(item.Name, throwOnMissingValue: false);
					}
					list.Add(item.Root + "\\" + item.Key + " · " + item.Name);
					list2.Remove(item);
				}
				catch
				{
				}
			}
		}
		Save();
		return list;
	}
}
