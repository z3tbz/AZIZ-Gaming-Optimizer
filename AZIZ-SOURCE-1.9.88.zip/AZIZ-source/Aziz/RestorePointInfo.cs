using System;

namespace Aziz;

internal sealed class RestorePointInfo
{
	public uint Sequence;

	public string Description;

	public DateTime Created;

	public int Type;

	public string TypeName
	{
		get
		{
			if (Type != 0)
			{
				if (Type != 1)
				{
					if (Type != 10)
					{
						if (Type != 12)
						{
							if (Type != 13)
							{
								if (Type != 7)
								{
									return "Restore point";
								}
								return "Windows Update";
							}
							return "Cancelled";
						}
						return "Settings change";
					}
					return "Driver install";
				}
				return "App removal";
			}
			return "App install";
		}
	}
}
