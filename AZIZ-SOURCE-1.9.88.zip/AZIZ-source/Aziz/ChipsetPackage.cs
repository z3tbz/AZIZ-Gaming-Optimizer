using System;
using System.IO;
using Microsoft.Win32;

namespace Aziz;

internal static class ChipsetPackage
{
	public const string FileName = "AMD_Chipset_Software_8.08.12.551.exe";

	public const string Digest = "04192323117317d212119d66476fe518d62eab17a6250f0cf5ab1b6c43ae138c";

	public static DownloadItem Item()
	{
		return new DownloadItem
		{
			Id = "amd-chipset-package",
			Name = "AMD Chipset Software",
			Publisher = "AMD",
			FileName = "AMD_Chipset_Software_8.08.12.551.exe",
			DirectUrl = "https://drivers.amd.com/drivers/amd_chipset_software_8.08.12.551.exe",
			Referer = "https://www.amd.com/",
			Sha256 = "04192323117317d212119d66476fe518d62eab17a6250f0cf5ab1b6c43ae138c"
		};
	}

	public static bool ForThisPc()
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0");
			return registryKey == null || Convert.ToString(registryKey.GetValue("VendorIdentifier")).IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0;
		}
		catch
		{
			return true;
		}
	}

	public static string Find()
	{
		string[] array = new string[3]
		{
			DownloadLibrary.Folder,
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"),
			Program.Root
		};
		for (int i = 0; i < array.Length; i++)
		{
			string text = Path.Combine(array[i], "AMD_Chipset_Software_8.08.12.551.exe");
			if (File.Exists(text) && Utilities.Sha256File(text) == "04192323117317d212119d66476fe518d62eab17a6250f0cf5ab1b6c43ae138c")
			{
				return text;
			}
		}
		return null;
	}
}
