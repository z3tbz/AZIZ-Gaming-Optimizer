using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace Aziz;

internal static class CompetitiveLaunch
{
	private static string JournalPath => Path.Combine(Program.Data, "competitive-session.json");

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr OpenProcess(uint access, bool inherit, int id);

	[DllImport("kernel32.dll")]
	private static extern bool CloseHandle(IntPtr h);

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder name, ref int size);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool SetProcessAffinityMask(IntPtr h, UIntPtr mask);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool GetProcessAffinityMask(IntPtr h, out UIntPtr process, out UIntPtr system);

	public static string ImagePath(int pid)
	{
		IntPtr intPtr = OpenProcess(4096u, inherit: false, pid);
		if (intPtr == IntPtr.Zero)
		{
			return null;
		}
		try
		{
			StringBuilder stringBuilder = new StringBuilder(1024);
			int size = stringBuilder.Capacity;
			return QueryFullProcessImageName(intPtr, 0, stringBuilder, ref size) ? stringBuilder.ToString() : null;
		}
		finally
		{
			CloseHandle(intPtr);
		}
	}

	public static ulong Mask(uint[] cpuSets)
	{
		if (cpuSets == null || cpuSets.Length == 0)
		{
			return 0uL;
		}
		ulong num = 0uL;
		foreach (CpuUnit item in GameNative.CpuTopology())
		{
			if (item.Group == 0 && item.Index < 64 && cpuSets.Contains(item.Id))
			{
				num |= (ulong)(1L << item.Index);
			}
		}
		return num;
	}

	internal static string LibraryOf(GameRule r)
	{
		if (!string.IsNullOrEmpty(r.Library))
		{
			return r.Library;
		}
		string text = (r.Launch ?? "").ToLowerInvariant();
		if (!text.StartsWith("steam:"))
		{
			if (!text.StartsWith("com.epicgames.launcher:"))
			{
				if (!text.StartsWith("goggalaxy:"))
				{
					if (!text.StartsWith("uplay:"))
					{
						if (!text.StartsWith("origin") && !text.StartsWith("ea"))
						{
							if (!text.StartsWith("battlenet:"))
							{
								if (!text.Contains("riotclient"))
								{
									return "";
								}
								return "Riot";
							}
							return "Battle.net";
						}
						return "EA";
					}
					return "Ubisoft";
				}
				return "GOG";
			}
			return "Epic";
		}
		return "Steam";
	}

	internal static string[] LauncherNames(string library)
	{
		return library switch
		{
			"Steam" => new string[1] { "steam" }, 
			"Epic" => new string[1] { "EpicGamesLauncher" }, 
			"GOG" => new string[1] { "GalaxyClient" }, 
			"Ubisoft" => new string[2] { "upc", "UbisoftConnect" }, 
			"EA" => new string[1] { "EADesktop" }, 
			"Battle.net" => new string[1] { "Battle.net" }, 
			"Riot" => new string[1] { "RiotClientServices" }, 
			_ => new string[0], 
		};
	}

	internal static bool SetMask(int pid, ulong mask, out long previous)
	{
		previous = 0L;
		IntPtr intPtr = OpenProcess(1536u, inherit: false, pid);
		if (intPtr == IntPtr.Zero)
		{
			return false;
		}
		try
		{
			if (GetProcessAffinityMask(intPtr, out var process, out var _))
			{
				previous = (long)process.ToUInt64();
			}
			return SetProcessAffinityMask(intPtr, new UIntPtr(mask));
		}
		finally
		{
			CloseHandle(intPtr);
		}
	}

	private static void Save(CompetitiveJournal j)
	{
		Utilities.AtomicWrite(JournalPath, Program.Json.Serialize(j));
	}

	internal static int CpuClass(string cpu)
	{
		return cpu switch
		{
			"Idle" => 1, 
			"BelowNormal" => 5, 
			"AboveNormal" => 6, 
			"High" => 3, 
			_ => 2, 
		};
	}

	public static string Start(GameEntry game, GameRule rule, Action<string> report)
	{
		List<string> list = new List<string>();
		CompetitiveJournal competitiveJournal = new CompetitiveJournal();
		ulong num = Mask(rule.CpuSets);
		string fileName = Path.GetFileName(rule.Exe ?? game.Exe ?? "");
		if (rule.Boost && fileName.Length > 0 && (rule.Cpu != "Normal" || rule.Io != 2))
		{
			try
			{
				string text = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + fileName + "\\PerfOptions";
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(text))
				{
					competitiveJournal.IfeoCreated = registryKey == null;
				}
				competitiveJournal.Ifeo = fileName;
				Save(competitiveJournal);
				using (RegistryKey registryKey2 = Registry.LocalMachine.CreateSubKey(text))
				{
					registryKey2.SetValue("CpuPriorityClass", CpuClass(rule.Cpu), RegistryValueKind.DWord);
					registryKey2.SetValue("IoPriority", Math.Min(2, rule.Io), RegistryValueKind.DWord);
				}
				list.Add("priority set by Windows at game start (" + rule.Cpu + ")");
			}
			catch (Exception ex)
			{
				list.Add("priority: " + ex.Message);
			}
		}
		if (num != 0L)
		{
			string[] array = LauncherNames(game.Library);
			foreach (string text2 in array)
			{
				Process[] processesByName = Process.GetProcessesByName(text2);
				foreach (Process process in processesByName)
				{
					using (process)
					{
						if (SetMask(process.Id, num, out var previous))
						{
							competitiveJournal.Launchers.Add(new LauncherBackup
							{
								Pid = process.Id,
								Started = process.StartTime.ToUniversalTime().Ticks,
								Mask = previous
							});
							Save(competitiveJournal);
							list.Add("cores applied to " + text2);
						}
						else
						{
							list.Add(text2 + " refused core change");
						}
					}
				}
			}
		}
		report("Launching " + game.Name + "…");
		Process currentProcess = Process.GetCurrentProcess();
		IntPtr processorAffinity = currentProcess.ProcessorAffinity;
		try
		{
			if (num != 0L)
			{
				currentProcess.ProcessorAffinity = new IntPtr((long)num);
			}
			Process.Start(new ProcessStartInfo(game.Target)
			{
				UseShellExecute = true,
				WorkingDirectory = (File.Exists(game.Target) ? Path.GetDirectoryName(game.Target) : "")
			});
			Thread.Sleep(1500);
		}
		finally
		{
			try
			{
				currentProcess.ProcessorAffinity = processorAffinity;
			}
			catch
			{
			}
		}
		if (num != 0L && competitiveJournal.Launchers.Count == 0)
		{
			string[] array = LauncherNames(game.Library);
			for (int i = 0; i < array.Length; i++)
			{
				Process[] processesByName = Process.GetProcessesByName(array[i]);
				foreach (Process process3 in processesByName)
				{
					using (process3)
					{
						if (SetMask(process3.Id, num, out var previous2))
						{
							competitiveJournal.Launchers.Add(new LauncherBackup
							{
								Pid = process3.Id,
								Started = process3.StartTime.ToUniversalTime().Ticks,
								Mask = previous2
							});
							Save(competitiveJournal);
						}
					}
				}
			}
		}
		return string.Join(" · ", list);
	}

	public static string Watch(GameEntry game, GameRule rule, Action<string> report, CancellationToken token)
	{
		string text = rule.Exe ?? game.Exe;
		ulong num = Mask(rule.CpuSets);
		Stopwatch stopwatch = Stopwatch.StartNew();
		Process process = null;
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(text ?? "");
		while (process == null && stopwatch.Elapsed.TotalMinutes < 5.0 && !token.IsCancellationRequested)
		{
			Process[] processesByName = Process.GetProcessesByName(fileNameWithoutExtension);
			foreach (Process process2 in processesByName)
			{
				string text2 = ImagePath(process2.Id);
				if (text2 != null && string.Equals(Path.GetFullPath(text2), Path.GetFullPath(text), StringComparison.OrdinalIgnoreCase))
				{
					process = process2;
					break;
				}
				process2.Dispose();
			}
			if (process == null)
			{
				Thread.Sleep(1000);
			}
		}
		if (process == null)
		{
			Restore();
			return "The game process did not appear within 5 minutes; launcher cores restored.";
		}
		List<string> list = new List<string>();
		if (num != 0L && SetMask(process.Id, num, out var _))
		{
			list.Add("cores");
		}
		try
		{
			ProcessBackup saved = GameNative.Capture(process, gpu: true, io: true, sets: false);
			if (GameNative.Apply(process, saved, new GameRule
			{
				Cpu = rule.Cpu,
				Gpu = rule.Gpu,
				Io = rule.Io,
				CpuSets = null
			}).Count == 0)
			{
				list.Add("priorities");
			}
		}
		catch
		{
		}
		report(game.Name + " running · " + ((list.Count > 0) ? ("accepted directly: " + string.Join(", ", list)) : "protected by anti-cheat · using launcher cores + Windows priority"));
		try
		{
			while (!process.HasExited && !token.IsCancellationRequested)
			{
				Thread.Sleep(2000);
			}
		}
		catch
		{
		}
		process.Dispose();
		Restore();
		return game.Name + " closed · launcher cores and priority restored.";
	}

	public static void Restore()
	{
		try
		{
			if (!File.Exists(JournalPath))
			{
				return;
			}
			CompetitiveJournal competitiveJournal = Program.Json.Deserialize<CompetitiveJournal>(File.ReadAllText(JournalPath));
			foreach (LauncherBackup launcher in competitiveJournal.Launchers)
			{
				try
				{
					using Process process = Process.GetProcessById(launcher.Pid);
					if (process.StartTime.ToUniversalTime().Ticks == launcher.Started && launcher.Mask != 0L)
					{
						SetMask(launcher.Pid, (ulong)launcher.Mask, out var _);
					}
				}
				catch
				{
				}
			}
			if (!string.IsNullOrEmpty(competitiveJournal.Ifeo))
			{
				string name = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + competitiveJournal.Ifeo;
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(name, writable: true);
				if (registryKey != null && competitiveJournal.IfeoCreated)
				{
					registryKey.DeleteSubKeyTree("PerfOptions", throwOnMissingSubKey: false);
				}
			}
			File.Delete(JournalPath);
		}
		catch
		{
		}
	}
}
