namespace Aziz;

internal class InstalledApp
{
	public string AppUserModelId { get; set; }

	public string DisplayName { get; set; }

	public string Name { get; set; }

	public string Version { get; set; }

	public string PackageFullName { get; set; }

	public string PackageFamilyName { get; set; }

	public string Publisher { get; set; }

	public string InstallLocation { get; set; }

	public string IconPath { get; set; }
}
