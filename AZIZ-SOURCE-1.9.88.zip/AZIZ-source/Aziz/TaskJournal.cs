using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Aziz;

// Scheduled tasks One Click turned off that were on before, and the audit policy as it was: Windows Default and uninstall
// put both back (the registry set and startup apps have their own journals).
internal static class TaskJournal
{
	private static readonly object Gate = new object();

	private static string Path => System.IO.Path.Combine(Program.Data, "task-journal.json");

	public static string AuditBackup => System.IO.Path.Combine(Program.Data, "auditpol-before.csv");

	private static List<string> Load()
	{
		try
		{
			return File.Exists(Path) ? (Program.Json.Deserialize<List<string>>(File.ReadAllText(Path)) ?? new List<string>()) : new List<string>();
		}
		catch
		{
			return new List<string>();
		}
	}

	public static void Remember(IEnumerable<string> tasks)
	{
		lock (Gate)
		{
			List<string> list = Load();
			int count = list.Count;
			foreach (string task in tasks)
			{
				if (!list.Contains(task, StringComparer.OrdinalIgnoreCase))
				{
					list.Add(task);
				}
			}
			if (list.Count != count)
			{
				Directory.CreateDirectory(Program.Data);
				Utilities.AtomicWrite(Path, Program.Json.Serialize(list));
			}
		}
	}

	public static List<string> RestoreAll()
	{
		List<string> result = new List<string>();
		lock (Gate)
		{
			List<string> list = Load();
			if (list.Count > 0)
			{
				string script = "$ErrorActionPreference='Continue';$t=@(" + string.Join(",", list.Select((string v) => "'" + v.Replace("'", "''") + "'")) + ");$done=@();foreach($f in $t){try{& schtasks.exe /Change /TN $f /Enable 2>$null|Out-Null;if($LASTEXITCODE -eq 0){$done+=$f}}catch{}};$done -join \"`n\"";
				ActionResult actionResult = Utilities.RunRaw("powershell.exe", GameWatch.PsArgs(script), 300000);
				if (actionResult.Success)
				{
					result.AddRange(list.Select((string x) => x + " · on again"));
					try
					{
						File.Delete(Path);
					}
					catch
					{
					}
				}
			}
			if (File.Exists(AuditBackup) && Utilities.Run("auditpol.exe", "/restore /file:\"" + AuditBackup + "\"").Success)
			{
				result.Add("Audit policy · back as before");
				try
				{
					File.Delete(AuditBackup);
				}
				catch
				{
				}
			}
		}
		return result;
	}
}
