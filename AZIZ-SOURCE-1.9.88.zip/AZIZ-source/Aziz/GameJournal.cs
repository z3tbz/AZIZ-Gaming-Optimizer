using System.Collections.Generic;

namespace Aziz;

internal class GameJournal
{
	public List<ProcessBackup> Processes { get; set; }

	public List<string> Services { get; set; }

	public string Power { get; set; }

	public string AppliedPower { get; set; }

	public string Tcp { get; set; }

	public GameJournal()
	{
		Processes = new List<ProcessBackup>();
		Services = new List<string>();
	}
}
