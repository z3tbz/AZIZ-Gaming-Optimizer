using System.Windows;
using System.Windows.Media;

namespace Aziz;

internal static class BrandArt
{
	public const string Letter = "M8,76 L27,22 L41,22 L60,76 L46,76 L34,40 L22,76 Z M24,58 L44,58 L46,66 L22,66 Z";

	public const string Zed = "M56,22 L94,22 L94,32 L71,66 L94,66 L94,76 L54,76 L54,66 L77,32 L56,32 Z";

	public const string Badge = "M29,5 L71,5 Q95,5 95,29 L95,71 Q95,95 71,95 L29,95 Q5,95 5,71 L5,29 Q5,5 29,5 Z";

	public const string Plate = "M24,1 L76,1 Q99,1 99,24 L99,76 Q99,99 76,99 L24,99 Q1,99 1,76 L1,24 Q1,1 24,1 Z";

	public const string Cut = "M74,6 L40,50 L54,50 L26,94 L68,44 L54,44 L80,6 Z";

	public const string Bolt = "M71,12 L44,47 L57,47 L35,82 L63,47 L50,47 Z";

	private static DrawingGroup badge;

	private static DrawingGroup wordmark;

	private static Color C(byte r, byte g, byte b)
	{
		return Color.FromRgb(r, g, b);
	}

	private static LinearGradientBrush Diagonal(params Color[] colors)
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = new Point(0.0, 0.0),
			EndPoint = new Point(1.0, 1.0)
		};
		for (int i = 0; i < colors.Length; i++)
		{
			linearGradientBrush.GradientStops.Add(new GradientStop(colors[i], (colors.Length == 1) ? 0.0 : ((double)i / (double)(colors.Length - 1))));
		}
		return linearGradientBrush;
	}

	internal static LinearGradientBrush LetterBrush()
	{
		LinearGradientBrush linearGradientBrush = Diagonal(C(240, 249, byte.MaxValue), C(56, 189, 248), C(109, 40, 217));
		linearGradientBrush.GradientStops[1].Offset = 0.6;
		return linearGradientBrush;
	}

	internal static LinearGradientBrush ZedBrush()
	{
		LinearGradientBrush linearGradientBrush = Diagonal(C(124, 58, 237), C(37, 99, 235), C(6, 182, 212));
		linearGradientBrush.GradientStops[1].Offset = 0.55;
		return linearGradientBrush;
	}

	private static DrawingGroup Letters()
	{
		return Letters("M8,76 L27,22 L41,22 L60,76 L46,76 L34,40 L22,76 Z M24,58 L44,58 L46,66 L22,66 Z", "M56,22 L94,22 L94,32 L71,66 L94,66 L94,76 L54,76 L54,66 L77,32 L56,32 Z");
	}

	private static DrawingGroup Letters(string a, string z)
	{
		DrawingGroup drawingGroup = new DrawingGroup();
		PathGeometry pathGeometry = PathGeometry.CreateFromGeometry(Geometry.Parse(a));
		pathGeometry.FillRule = FillRule.Nonzero;
		drawingGroup.Children.Add(new GeometryDrawing(LetterBrush(), null, pathGeometry));
		drawingGroup.Children.Add(new GeometryDrawing(ZedBrush(), null, Geometry.Parse(z)));
		return drawingGroup;
	}

	internal static LinearGradientBrush BoltBrush()
	{
		return new LinearGradientBrush
		{
			StartPoint = new Point(0.0, 0.0),
			EndPoint = new Point(0.0, 1.0),
			GradientStops = 
			{
				new GradientStop(C(byte.MaxValue, 247, 200), 0.0),
				new GradientStop(C(byte.MaxValue, 200, 40), 0.5),
				new GradientStop(C(234, 120, 0), 1.0)
			}
		};
	}

	// The 1.9.7 mark (same as the wallpapers): slimmer A with side notches and a violet Z, split by a golden bolt.
	public const string MarkA = "M7,76 L25,22 L39,22 L55.5,76 L44.5,76 L32,37 L19,76 Z M22,60 L42,60 L44,67 L20,67 Z";

	public const string MarkNotches = "M47.8,48.5 L45.4,50 L48.3,51.5 Z";

	// Left side of the A: a small spike pointing outward (left).
	public const string MarkSpike = "M16.9,48.2 L13.2,50 L16.1,51.8 Z";

	public const string MarkZ = "M54,22 L91,22 L91,31 L69,67 L91,67 L91,76 L56,76 L56,67 L78,31 L54,31 Z";

	public const string MarkCut = "M77.52,6 L40,50 L54,50 L22.48,94 L68.48,44 L54.48,44 L83.52,6 Z";

	public const string MarkBolt = "M74.04,12 L44.24,47 L57.24,47 L32.44,82 L63.24,47 L50.24,47 Z";

	public const string RightOfCut = "M83.52,0 L83.52,6 L54.48,44 L68.48,44 L22.48,94 L22.48,100 L100,100 L100,0 Z";

	public const string LeftOfBolt = "M0,0 L84.25,0 L74.04,12 L44.24,47 L57.24,47 L32.44,82 L32.44,100 L0,100 Z";

	private static DrawingGroup mark;

	private static LinearGradientBrush Stops(Point start, Point end, params object[] stops)
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = start,
			EndPoint = end
		};
		for (int i = 0; i < stops.Length; i += 2)
		{
			linearGradientBrush.GradientStops.Add(new GradientStop((Color)stops[i + 1], (double)stops[i]));
		}
		return linearGradientBrush;
	}

	internal static Geometry MarkGeometryA()
	{
		Transform transform = new MatrixTransform(0.8, 0.0, 0.0, 0.8, 10.8, 10.8);
		Geometry geometry = Geometry.Parse(MarkA).Clone();
		geometry.Transform = transform;
		Geometry geometry2 = Geometry.Parse(MarkNotches).Clone();
		geometry2.Transform = transform;
		Geometry geometry4 = Geometry.Parse(MarkSpike).Clone();
		geometry4.Transform = transform;
		Geometry geometry5 = new CombinedGeometry(GeometryCombineMode.Union, PathGeometry.CreateFromGeometry(geometry), geometry4);
		Geometry geometry3 = new CombinedGeometry(GeometryCombineMode.Exclude, geometry5, geometry2);
		// Same as the wallpaper: the A is cut by the bolt and nothing of it shows right of the cut.
		Geometry cut = new CombinedGeometry(GeometryCombineMode.Exclude, geometry3, Geometry.Parse(MarkCut));
		return new CombinedGeometry(GeometryCombineMode.Exclude, cut, Geometry.Parse(RightOfCut));
	}

	internal static Geometry MarkGeometryZ()
	{
		Geometry geometry = Geometry.Parse(MarkZ).Clone();
		geometry.Transform = new MatrixTransform(0.8, 0.0, 0.0, 0.8, 10.8, 10.8);
		Geometry geometry2 = Geometry.Parse(MarkBolt);
		Geometry geometry3 = new CombinedGeometry(GeometryCombineMode.Union, geometry2, geometry2.GetWidenedPathGeometry(new Pen(Brushes.Black, 1.2)));
		Geometry geometry4 = new CombinedGeometry(GeometryCombineMode.Exclude, PathGeometry.CreateFromGeometry(geometry), geometry3);
		return new CombinedGeometry(GeometryCombineMode.Exclude, geometry4, Geometry.Parse(LeftOfBolt));
	}

	public static DrawingGroup Mark()
	{
		if (mark != null)
		{
			return mark;
		}
		DrawingGroup drawingGroup = new DrawingGroup();
		drawingGroup.Children.Add(new GeometryDrawing(Stops(new Point(0.0, 0.0), new Point(0.0, 1.0), 0.0, C(34, 92, 200), 0.4, C(62, 138, 236), 0.55, C(40, 104, 210), 1.0, C(24, 64, 170)), null, MarkGeometryA()));
		drawingGroup.Children.Add(new GeometryDrawing(Stops(new Point(0.0, 0.0), new Point(0.0, 1.0), 0.0, C(78, 30, 170), 0.4, C(116, 68, 214), 0.55, C(86, 36, 180), 1.0, C(56, 18, 132)), null, MarkGeometryZ()));
		drawingGroup.Children.Add(new GeometryDrawing(BoltBrush(), null, Geometry.Parse(MarkBolt)));
		drawingGroup.Children.Add(new GeometryDrawing(Brushes.Transparent, null, new RectangleGeometry(new Rect(0.0, 0.0, 100.0, 100.0))));
		drawingGroup.Freeze();
		mark = drawingGroup;
		return drawingGroup;
	}

	// Wallpaper letters (design G3): deep top to bottom with a soft glowing band across the middle.
	public static DrawingGroup WallpaperMark()
	{
		DrawingGroup drawingGroup = new DrawingGroup();
		drawingGroup.Children.Add(new GeometryDrawing(Stops(new Point(0.0, 0.0), new Point(0.0, 1.0), 0.0, C(34, 92, 200), 0.4, C(62, 138, 236), 0.55, C(40, 104, 210), 1.0, C(24, 64, 170)), null, MarkGeometryA()));
		drawingGroup.Children.Add(new GeometryDrawing(Stops(new Point(0.0, 0.0), new Point(0.0, 1.0), 0.0, C(78, 30, 170), 0.4, C(116, 68, 214), 0.55, C(86, 36, 180), 1.0, C(56, 18, 132)), null, MarkGeometryZ()));
		drawingGroup.Children.Add(new GeometryDrawing(BoltBrush(), null, Geometry.Parse(MarkBolt)));
		drawingGroup.Children.Add(new GeometryDrawing(Brushes.Transparent, null, new RectangleGeometry(new Rect(0.0, 0.0, 100.0, 100.0))));
		drawingGroup.Freeze();
		return drawingGroup;
	}

	public static DrawingGroup Wordmark()
	{
		return Mark();
	}

	public static DrawingGroup OldWordmark()
	{
		if (wordmark != null)
		{
			return wordmark;
		}
		wordmark = Wordmark("M8,76 L27,22 L41,22 L60,76 L46,76 L34,40 L22,76 Z M24,58 L44,58 L46,66 L22,66 Z", "M56,22 L94,22 L94,32 L71,66 L94,66 L94,76 L54,76 L54,66 L77,32 L56,32 Z");
		return wordmark;
	}

	public static DrawingGroup Wordmark(string a, string z)
	{
		DrawingGroup drawingGroup = new DrawingGroup();
		DrawingGroup drawingGroup2 = Letters(a, z);
		drawingGroup2.Transform = new MatrixTransform(0.74, 0.0, 0.0, 0.74, 12.259999999999998, 13.740000000000002);
		DrawingGroup drawingGroup3 = new DrawingGroup
		{
			ClipGeometry = new CombinedGeometry(GeometryCombineMode.Exclude, new RectangleGeometry(new Rect(0.0, 0.0, 100.0, 100.0)), Geometry.Parse("M74,6 L40,50 L54,50 L26,94 L68,44 L54,44 L80,6 Z"))
		};
		drawingGroup3.Children.Add(drawingGroup2);
		drawingGroup.Children.Add(drawingGroup3);
		drawingGroup.Children.Add(new GeometryDrawing(BoltBrush(), null, Geometry.Parse("M71,12 L44,47 L57,47 L35,82 L63,47 L50,47 Z")));
		drawingGroup.Freeze();
		return drawingGroup;
	}

	private static DrawingGroup blueBadge;

	public static DrawingGroup Drawing()
	{
		return Drawing(blue: false);
	}

	// blue: the Reflex limiter's tray icon. Same logo, letters, bolt and gradient; the background is deep blue throughout.
	public static DrawingGroup Drawing(bool blue)
	{
		if (!blue && badge != null)
		{
			return badge;
		}
		if (blue && blueBadge != null)
		{
			return blueBadge;
		}
		DrawingGroup drawingGroup = new DrawingGroup();
		// Same as the app icon: violet corner melting through deep ink into blue, rounded square, mark at 80%.
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = new Point(0.0, 0.0),
			EndPoint = new Point(1.0, 1.0),
			GradientStops =
			{
				new GradientStop(blue ? C(20, 50, 140) : C(46, 22, 104), 0.0),
				new GradientStop(blue ? C(5, 11, 34) : C(10, 8, 34), 0.45),
				new GradientStop(blue ? C(5, 11, 34) : C(10, 8, 34), 0.55),
				new GradientStop(blue ? C(12, 46, 128) : C(16, 40, 112), 1.0)
			}
		};
		drawingGroup.Children.Add(new GeometryDrawing(linearGradientBrush, null, new RectangleGeometry(new Rect(0.0, 0.0, 100.0, 100.0), 22.0, 22.0)));
		DrawingGroup drawingGroup2 = new DrawingGroup
		{
			Transform = new MatrixTransform(0.8, 0.0, 0.0, 0.8, 10.0, 10.0)
		};
		drawingGroup2.Children.Add(Mark());
		drawingGroup.Children.Add(drawingGroup2);
		drawingGroup.Freeze();
		if (blue)
		{
			blueBadge = drawingGroup;
		}
		else
		{
			badge = drawingGroup;
		}
		return drawingGroup;
	}
}
