using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Windows.Forms;

namespace Aziz;

// --reflex-tray: the AZIZ limiter by the clock, alive without AZIZ. Blue AZIZ logo (AZIZ itself is violet). Click it for a
// small blue panel: one row per Reflex game with its live frame rate (read only while the panel is open), a smooth
// limit slider 0-360 and the FPS counter switch.
internal static class ReflexTray
{
	private static readonly Color Back = Color.FromArgb(15, 20, 48);

	private static readonly Color Row = Color.FromArgb(22, 32, 74);

	private static readonly Color Edge = Color.FromArgb(35, 48, 94);

	private static readonly Color Soft = Color.FromArgb(143, 168, 216);

	private static readonly Color Blue = Color.FromArgb(47, 140, 255);

	private static readonly Color Light = Color.FromArgb(127, 208, 255);

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

	[DllImport("user32.dll")]
	private static extern IntPtr MonitorFromWindow(IntPtr hWnd, int flags);

	[StructLayout(LayoutKind.Sequential)]
	private struct Rect
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	[StructLayout(LayoutKind.Sequential)]
	private struct MonitorInfo
	{
		public int Size;

		public Rect Monitor;

		public Rect Work;

		public int Flags;
	}

	[DllImport("user32.dll")]
	private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);

	// Top-left of the monitor the game is on (fallback: the primary screen).
	private static System.Drawing.Point GameCorner(IntPtr window)
	{
		try
		{
			MonitorInfo info = new MonitorInfo
			{
				Size = Marshal.SizeOf(typeof(MonitorInfo))
			};
			if (GetMonitorInfo(MonitorFromWindow(window, 2), ref info))
			{
				return new System.Drawing.Point(info.Monitor.Left + 24, info.Monitor.Top + 24);
			}
		}
		catch
		{
		}
		Rectangle b = Screen.PrimaryScreen.Bounds;
		return new System.Drawing.Point(b.Left + 24, b.Top + 24);
	}

	public static int Run()
	{
		bool createdNew;
		using (new Mutex(initiallyOwned: true, "Local\\AZIZ-ReflexTray-" + WindowsIdentity.GetCurrent().User.Value, out createdNew))
		{
			if (!createdNew)
			{
				return 0;
			}
			try
			{
				ReflexFallback.KeepRunning(restart: false);
				ReflexFallback.HideTrayIcon();
			}
			catch
			{
			}
			System.Windows.Forms.Application.EnableVisualStyles();
			NotifyIcon icon = new NotifyIcon
			{
				Text = "AZIZ Limiter",
				Visible = true,
				Icon = BlueIcon()
			};
			Form panel = null;
			DateTime closedAt = DateTime.MinValue;
			icon.MouseClick += delegate(object s, MouseEventArgs e)
			{
				if (e.Button != MouseButtons.Left)
				{
					return;
				}
				if (panel != null && !panel.IsDisposed)
				{
					panel.Close();
					return;
				}
				// Clicking the icon first deactivates (closes) the open panel: that click only closes it.
				if ((DateTime.UtcNow - closedAt).TotalMilliseconds < 400.0)
				{
					return;
				}
				panel = Panel();
				panel.FormClosed += delegate
				{
					closedAt = DateTime.UtcNow;
				};
				Rectangle workingArea = Screen.PrimaryScreen.WorkingArea;
				panel.Location = new Point(workingArea.Right - panel.Width - 12, workingArea.Bottom - panel.Height - 12);
				panel.Show();
				panel.Activate();
			};
			// AZIZ signals this event when the last Reflex game is turned off: close without any polling thread.
			EventWaitHandle exit = new EventWaitHandle(initialState: false, EventResetMode.ManualReset, ReflexFallback.TrayExitEvent);
			SynchronizationContext ui = new WindowsFormsSynchronizationContext();
			ThreadPool.RegisterWaitForSingleObject(exit, delegate
			{
				ui.Post(delegate
				{
					icon.Visible = false;
					System.Windows.Forms.Application.Exit();
				}, null);
			}, null, -1, executeOnlyOnce: true);
			ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
			contextMenuStrip.Items.Add("Hide until next sign-in", null, delegate
			{
				icon.Visible = false;
				System.Windows.Forms.Application.Exit();
			});
			icon.ContextMenuStrip = contextMenuStrip;
			// RTSS starts with Windows by itself and may show its icon or window again (also after Explorer restarts):
			// keep it out of sight — every 3 s for the first two minutes after sign-in, then every 15 s.
			int ticks = 0;
			System.Threading.Timer conceal = null;
			conceal = new System.Threading.Timer(delegate
			{
				try
				{
					ReflexFallback.Conceal();
				}
				catch
				{
				}
				if (++ticks == 40)
				{
					conceal.Change(15000, 15000);
				}
			}, null, 1000, 3000);
			// AZIZ's own FPS counter overlay (no injection). Shows the frame rate of the foreground Reflex game when the
			// counter is on; hidden otherwise. RivaTuner provides the numbers and draws nothing.
			FpsOverlay overlay = new FpsOverlay();
			HashSet<string> gameSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			DateTime gameSetRead = DateTime.MinValue;
			System.Windows.Forms.Timer fpsTimer = new System.Windows.Forms.Timer
			{
				Interval = 250
			};
			fpsTimer.Tick += delegate
			{
				try
				{
					if (!ReflexFallback.Counter)
					{
						if (overlay.Visible)
						{
							overlay.Hide();
						}
						return;
					}
					if ((DateTime.UtcNow - gameSetRead).TotalSeconds > 2.0)
					{
						gameSet = new HashSet<string>(ReflexFallback.Games().Keys.Select(System.IO.Path.GetFileNameWithoutExtension), StringComparer.OrdinalIgnoreCase);
						gameSetRead = DateTime.UtcNow;
					}
					IntPtr fg = GetForegroundWindow();
					if (fg == IntPtr.Zero)
					{
						overlay.Hide();
						return;
					}
					GetWindowThreadProcessId(fg, out var pid);
					string name = null;
					try
					{
						using System.Diagnostics.Process process = System.Diagnostics.Process.GetProcessById((int)pid);
						name = process.ProcessName;
					}
					catch
					{
					}
					if (string.IsNullOrEmpty(name) || !gameSet.Contains(name))
					{
						overlay.Hide();
						return;
					}
					double fps = ReflexFallback.FpsOf(name + ".exe");
					if (fps < 1.0)
					{
						overlay.Hide();
						return;
					}
					overlay.SetText((int)Math.Round(fps) + " FPS", GameCorner(fg));
				}
				catch
				{
				}
			};
			fpsTimer.Start();
			// Turning the counter off in AZIZ hides the overlay without waiting for the next tick.
			EventWaitHandle counterEvent = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, ReflexFallback.CounterEvent);
			ThreadPool.RegisterWaitForSingleObject(counterEvent, delegate
			{
				ui.Post(delegate
				{
					if (!ReflexFallback.Counter && !overlay.IsDisposed)
					{
						overlay.Hide();
					}
				}, null);
			}, null, -1, executeOnlyOnce: false);
			System.Windows.Forms.Application.Run();
			fpsTimer.Dispose();
			overlay.Dispose();
			conceal.Dispose();
			icon.Visible = false;
		}
		return 0;
	}

	// The AZIZ logo with the deep blue background, drawn from the same vector art as the app icon.
	private static Icon BlueIcon()
	{
		try
		{
			System.Windows.Media.DrawingVisual drawingVisual = new System.Windows.Media.DrawingVisual();
			using (System.Windows.Media.DrawingContext drawingContext = drawingVisual.RenderOpen())
			{
				drawingContext.DrawDrawing(BrandArt.Drawing(blue: true));
			}
			int num = 64;
			System.Windows.Media.Imaging.RenderTargetBitmap renderTargetBitmap = new System.Windows.Media.Imaging.RenderTargetBitmap(num, num, 96.0, 96.0, System.Windows.Media.PixelFormats.Pbgra32);
			drawingVisual.Transform = new System.Windows.Media.ScaleTransform(num / 100.0, num / 100.0);
			System.Windows.Media.ContainerVisual containerVisual = new System.Windows.Media.ContainerVisual();
			containerVisual.Children.Add(drawingVisual);
			renderTargetBitmap.Render(containerVisual);
			System.Windows.Media.Imaging.PngBitmapEncoder pngBitmapEncoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
			pngBitmapEncoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(renderTargetBitmap));
			using MemoryStream memoryStream = new MemoryStream();
			pngBitmapEncoder.Save(memoryStream);
			memoryStream.Position = 0L;
			using Bitmap bitmap = new Bitmap(memoryStream);
			return Icon.FromHandle(bitmap.GetHicon());
		}
		catch
		{
			return SystemIcons.Application;
		}
	}

	private static GraphicsPath Round(Rectangle r, int radius)
	{
		GraphicsPath graphicsPath = new GraphicsPath();
		int num = radius * 2;
		graphicsPath.AddArc(r.X, r.Y, num, num, 180f, 90f);
		graphicsPath.AddArc(r.Right - num, r.Y, num, num, 270f, 90f);
		graphicsPath.AddArc(r.Right - num, r.Bottom - num, num, num, 0f, 90f);
		graphicsPath.AddArc(r.X, r.Bottom - num, num, num, 90f, 90f);
		graphicsPath.CloseFigure();
		return graphicsPath;
	}

	private sealed class Smooth : Panel
	{
		public Smooth()
		{
			DoubleBuffered = true;
			SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, value: true);
		}
	}

	// Blue slider: filled track, white thumb, moves with the mouse pixel by pixel; Changed fires when the hand lets go.
	private sealed class BlueSlider : Control
	{
		public int Maximum = 360;

		private int value;

		private bool dragging;

		public event Action<int> Moving;

		public event Action<int> Changed;

		public int Value
		{
			get
			{
				return value;
			}
			set
			{
				this.value = Math.Max(0, Math.Min(Maximum, value));
				Invalidate();
			}
		}

		public BlueSlider()
		{
			DoubleBuffered = true;
			SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer, value: true);
			BackColor = Row;
			Height = 22;
			Cursor = Cursors.Hand;
		}

		private void Track(int x)
		{
			Value = (int)Math.Round((double)(x - 9) / (double)Math.Max(1, Width - 18) * (double)Maximum);
			this.Moving?.Invoke(value);
		}

		protected override void OnMouseDown(MouseEventArgs e)
		{
			dragging = true;
			Capture = true;
			Track(e.X);
		}

		protected override void OnMouseMove(MouseEventArgs e)
		{
			if (dragging)
			{
				Track(e.X);
			}
		}

		protected override void OnMouseUp(MouseEventArgs e)
		{
			if (dragging)
			{
				dragging = false;
				Capture = false;
				this.Changed?.Invoke(value);
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			Graphics graphics = e.Graphics;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			int num = Height / 2;
			int num2 = 9 + (int)((double)(Width - 18) * (double)value / (double)Maximum);
			using (SolidBrush brush = new SolidBrush(Color.FromArgb(35, 38, 74)))
			{
				using GraphicsPath path = Round(new Rectangle(9, num - 3, Width - 18, 6), 3);
				graphics.FillPath(brush, path);
			}
			if (num2 > 12)
			{
				using LinearGradientBrush brush2 = new LinearGradientBrush(new Rectangle(9, num - 3, Math.Max(1, num2 - 9), 6), Color.FromArgb(27, 79, 214), Light, 0f);
				using GraphicsPath path2 = Round(new Rectangle(9, num - 3, num2 - 9, 6), 3);
				graphics.FillPath(brush2, path2);
			}
			using (SolidBrush brush3 = new SolidBrush(Color.FromArgb(70, Blue)))
			{
				graphics.FillEllipse(brush3, num2 - 11, num - 11, 22, 22);
			}
			graphics.FillEllipse(Brushes.White, num2 - 8, num - 8, 16, 16);
		}
	}

	private static Form Panel()
	{
		Font font = new Font("Segoe UI", 9.5f);
		Form form = new Form
		{
			Text = "AZIZ Limiter",
			FormBorderStyle = FormBorderStyle.None,
			StartPosition = FormStartPosition.Manual,
			BackColor = Back,
			ForeColor = Color.White,
			Font = font,
			ShowInTaskbar = false,
			TopMost = true,
			Width = 340
		};
		form.Paint += delegate(object s, PaintEventArgs e)
		{
			using Pen pen = new Pen(Edge);
			e.Graphics.DrawRectangle(pen, 0, 0, form.Width - 1, form.Height - 1);
		};
		Label title = new Label
		{
			Text = "AZIZ Limiter",
			Font = new Font("Segoe UI Semibold", 10.5f),
			ForeColor = Color.White,
			AutoSize = true,
			Location = new Point(16, 12)
		};
		Label subtitle = new Label
		{
			Text = "NVIDIA Reflex fallback",
			ForeColor = Soft,
			Font = new Font("Segoe UI", 8.25f),
			AutoSize = true,
			Location = new Point(16, 32)
		};
		Label close = new Label
		{
			Text = "✕",
			ForeColor = Soft,
			AutoSize = true,
			Cursor = Cursors.Hand,
			Location = new Point(312, 12)
		};
		close.Click += delegate
		{
			form.Close();
		};
		form.Controls.Add(title);
		form.Controls.Add(subtitle);
		form.Controls.Add(close);
		Dictionary<string, int> games = ReflexFallback.Games();
		Label status = new Label
		{
			ForeColor = Soft,
			Font = new Font("Segoe UI", 8.25f),
			AutoSize = false,
			Width = 308,
			Height = 18
		};
		int num = 58;
		Dictionary<string, Label> fps = new Dictionary<string, Label>(StringComparer.OrdinalIgnoreCase);
		if (games.Count == 0)
		{
			form.Controls.Add(new Label
			{
				Text = "No games yet. Turn Reflex on for a game in AZIZ ▸ Tools.",
				ForeColor = Soft,
				AutoSize = false,
				Width = 308,
				Height = 36,
				Location = new Point(16, num)
			});
			num += 40;
		}
		foreach (KeyValuePair<string, int> item in games.ToList())
		{
			string exe = item.Key;
			Smooth row = new Smooth
			{
				BackColor = Row,
				Location = new Point(12, num),
				Size = new Size(316, 66)
			};
			row.Controls.Add(new Label
			{
				Text = Path.GetFileNameWithoutExtension(exe),
				ForeColor = Color.White,
				AutoEllipsis = true,
				AutoSize = false,
				Width = 170,
				Height = 20,
				Location = new Point(10, 10)
			});
			Label live = new Label
			{
				Text = "—",
				ForeColor = Light,
				Font = new Font("Bahnschrift", 15f, FontStyle.Bold),
				TextAlign = ContentAlignment.MiddleRight,
				AutoSize = false,
				Width = 120,
				Height = 26,
				Location = new Point(186, 5)
			};
			fps[Path.GetFileName(exe)] = live;
			row.Controls.Add(live);
			BlueSlider slider = new BlueSlider
			{
				Value = Math.Max(0, Math.Min(360, item.Value)),
				Location = new Point(4, 36),
				Width = 250
			};
			// The limit can be dragged or typed straight in (0–360, Enter to apply).
			TextBox limit = new TextBox
			{
				Text = slider.Value.ToString(),
				ForeColor = Color.White,
				BackColor = Back,
				Font = new Font("Segoe UI Semibold", 10f),
				TextAlign = HorizontalAlignment.Center,
				BorderStyle = BorderStyle.FixedSingle,
				MaxLength = 3,
				Width = 48,
				Location = new Point(258, 38)
			};
			Func<int, System.Threading.Tasks.Task> applyLimit = async delegate(int v)
			{
				status.Text = "Applying…";
				ActionResult actionResult = await System.Threading.Tasks.Task.Run(() => ReflexFallback.Apply(exe, v));
				if (!form.IsDisposed)
				{
					status.Text = (actionResult.Success ? ("Limit " + ((v == 0) ? "off" : (Math.Max(20, v) + " FPS")) + " · applied") : actionResult.Message);
				}
			};
			slider.Moving += delegate(int v)
			{
				if (!limit.Focused)
				{
					limit.Text = ((v > 0 && v < 20) ? 20 : v).ToString();
				}
			};
			slider.Changed += async delegate(int v)
			{
				await applyLimit(v);
			};
			// Typing a number: digits only, Enter or leaving the box moves the slider and applies the limit.
			limit.KeyPress += delegate(object kts, KeyPressEventArgs kte)
			{
				if (!char.IsControl(kte.KeyChar) && !char.IsDigit(kte.KeyChar))
				{
					kte.Handled = true;
				}
			};
			Action commitTyped = delegate
			{
				int typed;
				if (!int.TryParse(limit.Text, out typed))
				{
					typed = slider.Value;
				}
				typed = Math.Max(0, Math.Min(360, typed));
				limit.Text = typed.ToString();
				bool moved = slider.Value != typed;
				slider.Value = typed;
				if (moved)
				{
					applyLimit(typed);
				}
			};
			limit.KeyDown += delegate(object kts, KeyEventArgs kte)
			{
				if (kte.KeyCode == Keys.Enter)
				{
					commitTyped();
					kte.Handled = true;
					kte.SuppressKeyPress = true;
				}
			};
			limit.Leave += delegate
			{
				commitTyped();
			};
			limit.Enter += delegate
			{
				limit.SelectAll();
			};
			row.Controls.Add(slider);
			row.Controls.Add(limit);
			form.Controls.Add(row);
			num += 72;
		}
		CheckBox counter = new CheckBox
		{
			Text = "FPS counter in the game (not on DirectX 11 games)",
			Checked = ReflexFallback.Counter,
			ForeColor = Soft,
			AutoSize = true,
			Location = new Point(16, num + 4),
			FlatStyle = FlatStyle.Flat
		};
		counter.CheckedChanged += delegate
		{
			ReflexFallback.SetCounter(counter.Checked);
			status.Text = (counter.Checked ? "FPS counter on · shows when the game starts or reloads its profile" : "FPS counter off");
		};
		form.Controls.Add(counter);
		status.Location = new Point(16, num + 30);
		form.Controls.Add(status);
		form.Height = num + 56;
		form.Region = new Region(Round(new Rectangle(0, 0, form.Width, form.Height), 14));
		// Live frame rate: only while this panel is open.
		System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer
		{
			Interval = 500
		};
		timer.Tick += delegate
		{
			Dictionary<string, double> dictionary = ReflexFallback.LiveFps();
			foreach (KeyValuePair<string, Label> item2 in fps)
			{
				item2.Value.Text = (dictionary.TryGetValue(item2.Key, out var value) ? (Math.Round(value) + " FPS") : "—");
			}
		};
		timer.Start();
		form.FormClosed += delegate
		{
			timer.Stop();
			timer.Dispose();
		};
		form.Deactivate += delegate
		{
			form.Close();
		};
		return form;
	}
}
