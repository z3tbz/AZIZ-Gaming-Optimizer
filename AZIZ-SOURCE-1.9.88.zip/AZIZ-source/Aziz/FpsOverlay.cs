using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Aziz;

// AZIZ's own FPS counter: a transparent, click-through, top-most window that draws the frame rate over the game. It never
// injects anything into the game (safe with anti-cheat) and does not touch the game's present chain. It appears for
// borderless and windowed games; a true exclusive-fullscreen game is drawn by the GPU itself and cannot be overlaid
// without injection, so the number then shows in the AZIZ panel instead. The frame numbers come from RivaTuner's shared
// memory (RivaTuner is the limiter only and draws nothing).
internal sealed class FpsOverlay : Form
{
	private string text = "";

	private readonly Font font = new Font("Consolas", 18f, FontStyle.Bold);

	public FpsOverlay()
	{
		base.FormBorderStyle = FormBorderStyle.None;
		base.ShowInTaskbar = false;
		base.TopMost = true;
		base.StartPosition = FormStartPosition.Manual;
		BackColor = Color.FromArgb(1, 2, 7);
		TransparencyKey = BackColor;
		base.Size = new Size(190, 44);
		base.Enabled = false;
		DoubleBuffered = true;
	}

	protected override bool ShowWithoutActivation => true;

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams p = base.CreateParams;
			// Layered + transparent + tool window + no-activate: the mouse and keyboard go straight through to the game,
			// and the window never steals focus or shows in Alt-Tab.
			p.ExStyle |= 0x80 | 0x20 | 0x80000 | 0x8000000;
			return p;
		}
	}

	public void SetText(string value, Point topLeft)
	{
		if (base.Location != topLeft)
		{
			base.Location = topLeft;
		}
		if (text != value)
		{
			text = value;
			Invalidate();
		}
		if (!base.Visible)
		{
			ShowNoActivate();
		}
	}

	[DllImport("user32.dll")]
	private static extern bool ShowWindow(IntPtr hWnd, int cmd);

	// SW_SHOWNOACTIVATE = 4.
	private void ShowNoActivate()
	{
		if (!base.IsHandleCreated)
		{
			base.CreateControl();
		}
		ShowWindow(base.Handle, 4);
		base.Visible = true;
		base.TopMost = true;
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		if (string.IsNullOrEmpty(text))
		{
			return;
		}
		Graphics g = e.Graphics;
		g.SmoothingMode = SmoothingMode.AntiAlias;
		g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
		using (GraphicsPath path = new GraphicsPath())
		{
			path.AddRoundedRectangle(new Rectangle(0, 0, base.Width - 1, base.Height - 1), 10);
			using SolidBrush back = new SolidBrush(Color.FromArgb(170, 8, 12, 32));
			g.FillPath(back, path);
		}
		// Shadow then the bright number, so it stays readable over any scene.
		using (SolidBrush shadow = new SolidBrush(Color.FromArgb(180, 0, 0, 0)))
		{
			g.DrawString(text, font, shadow, new PointF(11f, 10f));
		}
		using SolidBrush fore = new SolidBrush(Color.FromArgb(255, 127, 208, 255));
		g.DrawString(text, font, fore, new PointF(10f, 9f));
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing)
		{
			font.Dispose();
		}
		base.Dispose(disposing);
	}
}

internal static class RoundedPathExtensions
{
	public static void AddRoundedRectangle(this GraphicsPath path, Rectangle r, int radius)
	{
		int d = radius * 2;
		path.AddArc(r.X, r.Y, d, d, 180f, 90f);
		path.AddArc(r.Right - d, r.Y, d, d, 270f, 90f);
		path.AddArc(r.Right - d, r.Bottom - d, d, d, 0f, 90f);
		path.AddArc(r.X, r.Bottom - d, d, d, 90f, 90f);
		path.CloseFigure();
	}
}
