using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.IO;
using Microsoft.Win32;

namespace Aziz;

// Debloat apps: browser policies (telemetry off, no running in the background, hardware acceleration off).
// Policies apply on the next browser start; the browser shows "Managed by your organization".
internal static class AppDebloat
{
	private static readonly Dictionary<string, Tuple<string, string[]>> Browsers = new Dictionary<string, Tuple<string, string[]>>
	{
		{
			"Edge",
			Tuple.Create("SOFTWARE\\Policies\\Microsoft\\Edge", new string[8] { "MetricsReportingEnabled=0", "DiagnosticData=0", "PersonalizationReportingEnabled=0", "UserFeedbackAllowed=0", "BackgroundModeEnabled=0", "StartupBoostEnabled=0", "HardwareAccelerationModeEnabled=0", "EdgeShoppingAssistantEnabled=0" })
		},
		{
			"Chrome",
			Tuple.Create("SOFTWARE\\Policies\\Google\\Chrome", new string[6] { "MetricsReportingEnabled=0", "ChromeCleanupReportingEnabled=0", "UserFeedbackAllowed=0", "BackgroundModeEnabled=0", "HardwareAccelerationModeEnabled=0", "UrlKeyedAnonymizedDataCollectionEnabled=0" })
		},
		{
			"Brave",
			Tuple.Create("SOFTWARE\\Policies\\BraveSoftware\\Brave", new string[6] { "MetricsReportingEnabled=0", "BraveP3AEnabled=0", "BraveStatsPingEnabled=0", "BraveWebDiscoveryEnabled=0", "BackgroundModeEnabled=0", "HardwareAccelerationModeEnabled=0" })
		}
	};

	public static IEnumerable<string> Names => Browsers.Keys;

	public static bool Applied(string name)
	{
		Tuple<string, string[]> tuple = Browsers[name];
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(tuple.Item1);
		return registryKey != null && tuple.Item2.All((string v) => Convert.ToString(registryKey.GetValue(v.Split('=')[0])) == v.Split('=')[1]);
	}

	public static ActionResult Apply(string name, bool on)
	{
		try
		{
			Tuple<string, string[]> tuple = Browsers[name];
			using (RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(tuple.Item1))
			{
				foreach (string text in tuple.Item2)
				{
					string[] array = text.Split('=');
					if (on)
					{
						registryKey.SetValue(array[0], int.Parse(array[1]), RegistryValueKind.DWord);
					}
					else
					{
						registryKey.DeleteValue(array[0], throwOnMissingValue: false);
					}
				}
			}
			return new ActionResult
			{
				Success = true,
				Message = name + (on ? ": telemetry, background running and hardware acceleration off. Restart the browser." : ": AZIZ browser policies removed.")
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	// Discord: closes it, then turns hardware acceleration off in its settings.json. The overlays live inside Discord's own storage,
	// so the user switches them off in Discord (the guide shows where).
	public static ActionResult Discord()
	{
		try
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "discord", "settings.json");
			if (!File.Exists(text))
			{
				return new ActionResult
				{
					Message = "Discord is not installed for this Windows user."
				};
			}
			foreach (Process item in Process.GetProcesses().Where((Process x) => x.ProcessName.Equals("Discord", StringComparison.OrdinalIgnoreCase)))
			{
				try
				{
					item.Kill();
					item.WaitForExit(5000);
				}
				catch
				{
				}
			}
			Dictionary<string, object> dictionary = Program.Json.Deserialize<Dictionary<string, object>>(File.ReadAllText(text)) ?? new Dictionary<string, object>();
			dictionary["enableHardwareAcceleration"] = false;
			// Keep the very first backup: a second run must not overwrite the original settings.
			if (!File.Exists(text + ".aziz-backup"))
			{
				File.Copy(text, text + ".aziz-backup");
			}
			File.WriteAllText(text, Program.Json.Serialize(dictionary));
			long freed = TrimDiscord();
			return new ActionResult
			{
				Success = true,
				Message = "Discord: closed, hardware acceleration off, " + freed / 1048576 + " MB of old versions, update packages, extra languages and caches removed. In Discord ▸ User Settings ▸ Game Overlay, turn off Enable in-game overlay and the legacy overlay."
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	private static long Size(string path)
	{
		try
		{
			return Directory.Exists(path) ? Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories).Sum((string f) => new FileInfo(f).Length) : (File.Exists(path) ? new FileInfo(path).Length : 0);
		}
		catch
		{
			return 0L;
		}
	}

	private static long Delete(string path)
	{
		long num = Size(path);
		try
		{
			if (Directory.Exists(path))
			{
				Directory.Delete(path, recursive: true);
			}
			else if (File.Exists(path))
			{
				File.Delete(path);
			}
			return num;
		}
		catch
		{
			return 0L;
		}
	}

	// Safe trim: Update.exe and the newest app-x.y.z stay (Discord starts through them). Removed: old update packages,
	// older app versions, every language except English, caches and crash dumps (Discord rebuilds caches when needed).
	private static long TrimDiscord()
	{
		long num = 0L;
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Discord");
		if (Directory.Exists(text))
		{
			num += Delete(Path.Combine(text, "packages"));
			num += Delete(Path.Combine(text, "SquirrelSetup.log"));
			List<string> list = (from d in Directory.GetDirectories(text, "app-*")
				orderby (Version.TryParse(Path.GetFileName(d).Substring(4), out var v) ? v : new Version(0, 0)) descending
				select d).ToList();
			foreach (string item in list.Skip(1))
			{
				num += Delete(item);
			}
			if (list.Count > 0)
			{
				string path = Path.Combine(list[0], "locales");
				if (Directory.Exists(path))
				{
					foreach (string item2 in Directory.GetFiles(path, "*.pak").Where((string f) => !Path.GetFileName(f).StartsWith("en-US", StringComparison.OrdinalIgnoreCase)))
					{
						num += Delete(item2);
					}
				}
			}
		}
		string text2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "discord");
		foreach (string text3 in new string[6] { "Cache", "Code Cache", "GPUCache", "Crashpad", "DawnCache", "DawnGraphiteCache" })
		{
			num += Delete(Path.Combine(text2, text3));
		}
		return num;
	}
}
