namespace Aziz;

internal class CacheResult
{
	public long Bytes;

	public int Files;

	public int Skipped;

	public override string ToString()
	{
		return Files + " files · " + ((double)Bytes / 1048576.0).ToString("0.0") + " MB · " + Skipped + " locked/skipped";
	}
}
