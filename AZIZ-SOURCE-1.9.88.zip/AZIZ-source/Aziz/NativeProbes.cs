using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class NativeProbes
{
	private static readonly Regex RegistryProbe = new Regex("\\[Microsoft\\.Win32\\.Registry\\]::(LocalMachine|CurrentUser)\\.OpenSubKey\\('([^']+)'\\);\\$v=\\$null;if\\(\\$k\\)\\{try\\{\\$v=\\$k\\.GetValue\\('([^']+)',\\$null\\)\\}finally\\{\\$k\\.Dispose\\(\\)\\}\\};if\\(\\$null -eq \\$v\\)\\{\\$v=([^}]+)\\};@\\{State=\\$\\(if\\(\\$v -eq ([^)]+)\\)\\{'Enabled'\\}elseif\\(\\$v -eq ([^)]+)\\)\\{'Disabled'\\}else\\{'Unknown'\\}\\);Detail='([^']*)'\\}$");

	private static readonly Regex ServiceProbe = new Regex("^\\$a=@\\(Get-CimInstance Win32_Service \\| Where-Object \\{\\$_\\.Name -in @\\(([^)]*)\\)\\}\\);@\\{State=");

	private static readonly Regex PowerProbe = new Regex("/qh \\$scheme ([0-9a-fA-F-]{36}) ([0-9a-fA-F-]{36})");

	private static readonly Regex PowerMap = new Regex("@\\{State=\\$\\(if\\(\\$ac -(eq|gt) (\\d+)\\)\\{'Enabled'\\}elseif\\(\\$ac -eq (\\d+)\\)\\{'Disabled'\\}");

	private static readonly Regex NicProbe = new Regex("RegistryKeyword -in @\\(([^)]*)\\)");

	private static readonly Regex Quoted = new Regex("'([^']*)'");

	private const string NetClass = "SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}";

	private static readonly Dictionary<string, string[]> enumNames = new Dictionary<string, string[]>
	{
		{
			"MSFT_NetTCPSetting.AutoTuningLevelLocal",
			new string[5] { "Disabled", "HighlyRestricted", "Restricted", "Normal", "Experimental" }
		},
		{
			"MSFT_NetOffloadGlobalSetting.ReceiveSegmentCoalescing",
			new string[2] { "Disabled", "Enabled" }
		}
	};

	[DllImport("powrprof.dll")]
	private static extern uint PowerGetActiveScheme(IntPtr root, out IntPtr scheme);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadACValueIndex(IntPtr root, ref Guid scheme, ref Guid subgroup, ref Guid setting, out uint value);

	[DllImport("kernel32.dll")]
	private static extern IntPtr LocalFree(IntPtr mem);

	private static TweakStatus Status(string state, string detail)
	{
		return new TweakStatus
		{
			State = state,
			Detail = detail
		};
	}

	public static bool TryProbe(Tweak t, out TweakStatus status)
	{
		status = null;
		string text = t.ProbeScript ?? "";
		if (text.Length == 0)
		{
			return false;
		}
		try
		{
			status = Probe(t, text);
		}
		catch (Exception ex)
		{
			status = Status("Unknown", ex.Message);
		}
		return status != null;
	}

	private static TweakStatus Probe(Tweak t, string script)
	{
		switch (t.Id)
		{
		case "show-hidden-files":
		{
			int num5 = Dword(Registry.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "Hidden") ?? 2;
			int num6 = Dword(Registry.CurrentUser, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced", "HideFileExt") ?? 1;
			return Status((num5 == 1 && num6 == 0) ? "Enabled" : "Disabled", "Hidden=" + num5 + "; HideFileExt=" + num6);
		}
		case "ntfs-last-access":
		{
			int valueOrDefault = Dword(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\FileSystem", "NtfsDisableLastAccessUpdate").GetValueOrDefault();
			return Status(((valueOrDefault & 1) == 0) ? "Enabled" : "Disabled", "NTFS last access code: " + valueOrDefault);
		}
		case "hibernation":
			return Status((Dword(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\Power", "HibernateEnabled") == 1) ? "Enabled" : "Disabled", "Hibernation configuration; restart may be required.");
		case "no-lazy-mode":
			return Status((Dword(Registry.LocalMachine, "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile", "NoLazyMode") == 1) ? "Enabled" : "Disabled", "MMCSS idle policy; absent value is Windows default 0. MMCSS must be enabled.");
		case "search-indexing":
		{
			int? num9 = Dword(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\WSearch", "Start");
			bool flag = Dword(Registry.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search", "DisableWebSearch") != 1 || (Dword(Registry.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search", "ConnectedSearchUseWeb") ?? 1) != 0 || (Dword(Registry.LocalMachine, "SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search", "AllowCloudSearch") ?? 1) != 0;
			bool flag5 = num9.HasValue && num9.Value != 4;
			return Status((flag5 && flag) ? "Enabled" : ((flag5 || flag) ? "Mixed" : "Disabled"), ((flag5 != flag) ? ("Mixed · cause: " + (flag5 ? "indexing service still on" : "web search policies still on") + " · ") : "") + "Indexing service: " + (num9.HasValue ? ServicePresets.StartText(num9.Value) : "not installed") + " · web results: " + (flag ? "on" : "off"));
		}
		case "auto-defrag":
		{
			bool? flag2 = TaskEnabled("\\Microsoft\\Windows\\Defrag", "ScheduledDefrag");
			return Status((!flag2.HasValue) ? "Unavailable" : (flag2.Value ? "Enabled" : "Disabled"), "Live ScheduledDefrag task state");
		}
		case "nvidia-crash-reports":
		{
			List<bool> list3 = TasksLike("NvTmRep_CrashReport");
			int num4 = list3.Count((bool x) => x);
			return Status((list3.Count == 0) ? "Unavailable" : ((num4 == list3.Count) ? "Enabled" : ((num4 == 0) ? "Disabled" : "Mixed")), list3.Count + " installed NVIDIA tasks.");
		}
		case "tcp-autotuning":
		{
			string text4 = Cim("MSFT_NetTCPSetting", "SettingName='Internet'", "AutoTuningLevelLocal");
			if (text4 == null)
			{
				return null;
			}
			return Status(text4.Equals("Disabled", StringComparison.OrdinalIgnoreCase) ? "Disabled" : (text4.Equals("Normal", StringComparison.OrdinalIgnoreCase) ? "Enabled" : "Mixed"), "TCP auto-tuning: " + text4);
		}
		case "nvidia-dpc-queueing":
		{
			int num7 = 0;
			int num8 = 0;
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e968-e325-11ce-bfc1-08002be10318}"))
			{
				string[] array = registryKey?.GetSubKeyNames() ?? new string[0];
				foreach (string text3 in array)
				{
					if (!Regex.IsMatch(text3, "^\\d{4}$"))
					{
						continue;
					}
					try
					{
						using RegistryKey registryKey2 = registryKey.OpenSubKey(text3);
						if ((Convert.ToString(registryKey2?.GetValue("ProviderName")) + " " + Convert.ToString(registryKey2?.GetValue("DriverDesc"))).IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0)
						{
							num7++;
							if (Convert.ToInt32(registryKey2.GetValue("RMDisablePerIntrDPCQueueing", 0)) == 1)
							{
								num8++;
							}
						}
					}
					catch
					{
					}
				}
			}
			return Status((num7 == 0) ? "Unavailable" : ((num8 == num7) ? "Enabled" : "Disabled"), num7 + " NVIDIA adapter(s) · restart to apply");
		}
		case "tcp-rsc":
		{
			string text5 = Cim("MSFT_NetOffloadGlobalSetting", null, "ReceiveSegmentCoalescing");
			if (text5 == null)
			{
				return null;
			}
			return Status(text5.Equals("Enabled", StringComparison.OrdinalIgnoreCase) ? "Enabled" : "Disabled", "Live system probe");
		}
		case "cpu-minimum":
		{
			// Processor power management ▸ Minimum processor state (AC), read straight from the active plan.
			uint? num10 = PowerAc(new Guid("54533251-82be-4824-96c1-47b60b740d00"), new Guid("893dee8e-2bef-41e0-89c6-b55d0929964c"));
			if (!num10.HasValue)
			{
				return Status("Unavailable", "This power setting does not exist on this Windows or plan");
			}
			return Status((num10.Value == 100) ? "Enabled" : "Disabled", "CPU minimum state on AC: " + num10.Value + "%" + ((num10.Value != 100) ? " · On needs exactly 100%" : ""));
		}
		case "nvidia-telemetry-tasks":
		{
			// Same rule as before: Off = no NVIDIA telemetry/update task enabled, driver telemetry 0, Control Panel opt-in absent or 0.
			List<bool> list4 = TasksLikeAny("NvTm", "NvProfileUpdater", "NvDriverUpdateCheck", "NVIDIA GeForce Experience SelfUpdate");
			bool flag6;
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\nvlddmkm"))
			{
				flag6 = registryKey != null;
			}
			if (!flag6 && list4.Count == 0)
			{
				return Status("Unavailable", "No NVIDIA driver installed.");
			}
			int num11 = list4.Count((bool x) => x);
			int? num12 = Dword(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\nvlddmkm\\Global\\Startup", "SendTelemetryData");
			int? num13 = Dword(Registry.LocalMachine, "SOFTWARE\\NVIDIA Corporation\\NvControlPanel2\\Client", "OptInOrOutPreference");
			bool flag7 = num11 == 0 && num12 == 0 && (!num13.HasValue || num13 == 0);
			return Status(flag7 ? "Disabled" : "Enabled", num11 + " of " + list4.Count + " NVIDIA tasks enabled · driver telemetry " + ((num12 == 0) ? "off" : "on"));
		}
		case "fixed-pagefile":
		{
			// PagingFiles holds "C:\pagefile.sys <initial> <max>"; "?:\pagefile.sys" means Windows manages it automatically.
			string[] array = (Raw(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management", "PagingFiles") as string[]) ?? new string[0];
			string text5 = (Environment.GetEnvironmentVariable("SystemDrive") ?? "C:") + "\\pagefile.sys";
			bool flag5 = array.Any((string x) => x.Trim().StartsWith("?:", StringComparison.Ordinal));
			string text6 = array.FirstOrDefault((string x) => x.Trim().StartsWith(text5, StringComparison.OrdinalIgnoreCase));
			string[] array2 = (text6 ?? "").Trim().Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
			bool on = !flag5 && array2.Length >= 3 && array2[1] == "16192" && array2[2] == "16192";
			return Status(on ? "Enabled" : "Disabled", "Configured automatic: " + flag5 + "; Windows-drive initial/max: " + ((array2.Length >= 3) ? (array2[1] + "/" + array2[2]) : "not set") + " MB; restart activates allocation");
		}
		default:
		{
			Match match = RegistryProbe.Match(script);
			if (match.Success)
			{
				object obj = Raw((match.Groups[1].Value == "LocalMachine") ? Registry.LocalMachine : Registry.CurrentUser, match.Groups[2].Value, match.Groups[3].Value);
				string text = match.Groups[4].Value.Trim();
				string text2 = ((obj != null) ? Convert.ToString(obj, CultureInfo.InvariantCulture) : ((text == "$null") ? null : text));
				return Status((text2 != null && text2 == match.Groups[5].Value.Trim()) ? "Enabled" : ((text2 != null && text2 == match.Groups[6].Value.Trim()) ? "Disabled" : "Unknown"), match.Groups[7].Value);
			}
			match = ServiceProbe.Match(script);
			if (match.Success)
			{
				List<int> list = new List<int>();
				foreach (Match item in Quoted.Matches(match.Groups[1].Value))
				{
					string value = item.Groups[1].Value;
					int? num = Dword(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\" + value, "Start");
					if (num.HasValue && ((uint)Dword(Registry.LocalMachine, "SYSTEM\\CurrentControlSet\\Services\\" + value, "Type").GetValueOrDefault() & 0x30u) != 0)
					{
						list.Add(num.Value);
					}
				}
				return Status((list.Count == 0) ? "Unavailable" : (list.All((int x) => x == 4) ? "Disabled" : ((!list.Any((int x) => x == 4)) ? "Enabled" : "Mixed")), "Live service startup configuration; running status may differ.");
			}
			match = PowerProbe.Match(script);
			Match match2 = PowerMap.Match(script);
			if (match.Success && match2.Success)
			{
				uint? num2 = PowerAc(new Guid(match.Groups[1].Value), new Guid(match.Groups[2].Value));
				if (!num2.HasValue)
				{
					return Status("Unavailable", "This power setting does not exist on this Windows or plan");
				}
				uint value2 = num2.Value;
				uint num3 = uint.Parse(match2.Groups[2].Value);
				return Status(((match2.Groups[1].Value == "gt") ? (value2 > num3) : (value2 == num3)) ? "Enabled" : ((value2 == uint.Parse(match2.Groups[3].Value)) ? "Disabled" : "Mixed"), "AC " + value2);
			}
			match = NicProbe.Match(script);
			if (match.Success)
			{
				List<string> list2 = AdapterValues((from Match x in Quoted.Matches(match.Groups[1].Value)
					select x.Groups[1].Value).ToArray());
				return Status((list2.Count == 0) ? "Unavailable" : (list2.All((string x) => x == "1") ? "Enabled" : (list2.All((string x) => x == "0") ? "Disabled" : "Mixed")), list2.Count + " supported adapter properties detected");
			}
			return null;
		}
		}
	}

	private static object Raw(RegistryKey hive, string path, string name)
	{
		using RegistryKey registryKey = hive.OpenSubKey(path);
		return registryKey?.GetValue(name, null);
	}

	private static int? Dword(RegistryKey hive, string path, string name)
	{
		object obj = Raw(hive, path, name);
		if (obj == null)
		{
			return null;
		}
		try
		{
			return Convert.ToInt32(obj, CultureInfo.InvariantCulture);
		}
		catch
		{
			return null;
		}
	}

	private static uint? PowerAc(Guid subgroup, Guid setting)
	{
		if (PowerGetActiveScheme(IntPtr.Zero, out var scheme) != 0)
		{
			return null;
		}
		try
		{
			Guid scheme2 = (Guid)Marshal.PtrToStructure(scheme, typeof(Guid));
			if (PowerReadACValueIndex(IntPtr.Zero, ref scheme2, ref subgroup, ref setting, out var value) != 0)
			{
				return null;
			}
			return value;
		}
		finally
		{
			LocalFree(scheme);
		}
	}

	private static List<string> AdapterValues(string[] keywords)
	{
		List<string> list = new List<string>();
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Class\\{4d36e972-e325-11ce-bfc1-08002be10318}");
		if (registryKey == null)
		{
			return list;
		}
		string[] subKeyNames = registryKey.GetSubKeyNames();
		foreach (string text in subKeyNames)
		{
			if (!Regex.IsMatch(text, "^\\d{4}$"))
			{
				continue;
			}
			try
			{
				using RegistryKey registryKey2 = registryKey.OpenSubKey(text);
				string text2 = Convert.ToString(registryKey2?.GetValue("NetCfgInstanceId"));
				if (string.IsNullOrEmpty(text2) || ((uint)Convert.ToInt32(registryKey2.GetValue("Characteristics", 0)) & 8u) != 0)
				{
					continue;
				}
				using (RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Network\\{4D36E972-E325-11CE-BFC1-08002BE10318}\\" + text2 + "\\Connection"))
				{
					if (registryKey3 == null)
					{
						continue;
					}
				}
				foreach (string name in keywords)
				{
					object value = registryKey2.GetValue(name);
					if (value != null)
					{
						list.Add(Convert.ToString(value, CultureInfo.InvariantCulture).Trim());
					}
				}
			}
			catch
			{
			}
		}
		return list;
	}

	private static string Cim(string cls, string where, string property)
	{
		ManagementScope scope = new ManagementScope("\\\\.\\root\\StandardCimv2");
		using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT " + property + " FROM " + cls + ((where == null) ? "" : (" WHERE " + where))));
		using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
		using (ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectCollection.GetEnumerator())
		{
			if (managementObjectEnumerator.MoveNext())
			{
				ManagementObject managementObject = (ManagementObject)managementObjectEnumerator.Current;
				using (managementObject)
				{
					object obj = managementObject[property];
					if (obj == null)
					{
						return null;
					}
					return EnumName(scope, cls, property, Convert.ToString(obj, CultureInfo.InvariantCulture));
				}
			}
		}
		return null;
	}

	private static string EnumName(ManagementScope scope, string cls, string property, string raw)
	{
		if (enumNames.TryGetValue(cls + "." + property, out var value) && int.TryParse(raw, out var result) && result >= 0 && result < value.Length)
		{
			return value[result];
		}
		return null;
	}

	private static dynamic Scheduler()
	{
		dynamic val = Activator.CreateInstance(Type.GetTypeFromProgID("Schedule.Service"));
		val.Connect();
		return val;
	}

	private static bool? TaskEnabled(string folder, string name)
	{
		try
		{
			dynamic val = Scheduler();
			dynamic folder2 = val.GetFolder(folder);
			dynamic task = folder2.GetTask(name);
			return (bool)task.Enabled && (bool)task.Definition.Settings.Enabled;
		}
		catch
		{
			return null;
		}
	}

	private static List<bool> TasksLike(string prefix)
	{
		List<bool> list = new List<bool>();
		Walk((object)Scheduler().GetFolder("\\"), new string[1] { prefix }, list, 0);
		return list;
	}

	// One walk of the task tree for several name prefixes.
	private static List<bool> TasksLikeAny(params string[] prefixes)
	{
		List<bool> list = new List<bool>();
		Walk((object)Scheduler().GetFolder("\\"), prefixes, list, 0);
		return list;
	}

	// The folder goes in as object: a call with a dynamic argument is bound by method name at run time, and the obfuscated
	// build renames Walk (that broke both NVIDIA task options with "does not contain a definition for 'Walk'").
	private static void Walk(object folderObject, string[] prefixes, List<bool> found, int depth)
	{
		dynamic folder = folderObject;
		if (depth > 8)
		{
			return;
		}
		foreach (dynamic task in folder.GetTasks(1))
		{
			string name = (string)task.Name;
			if (prefixes.Any((string p) => name.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
			{
				found.Add((bool)task.Enabled && (bool)task.Definition.Settings.Enabled);
			}
		}
		foreach (dynamic folder2 in folder.GetFolders(0))
		{
			Walk((object)folder2, prefixes, found, depth + 1);
		}
	}
}
