using System;
using System.Collections.Generic;
using System.IO;

namespace Aziz;

internal static class WindowsBaseline
{
	private static Dictionary<string, string> cache;

	private static string FilePath => Path.Combine(Program.Data, "windows-baseline.json");

	internal static bool OriginalsCaptured => File.Exists(FilePath + ".originals");

	internal static Dictionary<string, string> Values()
	{
		if (cache == null)
		{
			try
			{
				cache = Program.Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(FilePath)) ?? new Dictionary<string, string>();
			}
			catch
			{
				cache = new Dictionary<string, string>();
			}
		}
		return cache;
	}

	internal static void Merge(Dictionary<string, string> current)
	{
		Dictionary<string, string> dictionary = Values();
		int num = 0;
		foreach (KeyValuePair<string, string> item in current)
		{
			if (!dictionary.ContainsKey(item.Key))
			{
				dictionary[item.Key] = item.Value;
				num++;
			}
		}
		if (num > 0)
		{
			Utilities.AtomicWrite(FilePath, Program.Json.Serialize(dictionary));
		}
	}

	internal static void MarkOriginals()
	{
		try
		{
			File.WriteAllText(FilePath + ".originals", DateTime.UtcNow.ToString("o"));
		}
		catch
		{
		}
	}
}
