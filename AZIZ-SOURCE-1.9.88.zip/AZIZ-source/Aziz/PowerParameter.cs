using System;

namespace Aziz;

internal class PowerParameter
{
	public string Key;

	public string Name;

	public string Units;

	public Guid Group;

	public Guid Id;

	public uint Maximum;

	public PowerParameter(string key, string name, string group, string id, uint max, string units)
	{
		Key = key;
		Name = name;
		Group = new Guid(group);
		Id = new Guid(id);
		Maximum = max;
		Units = units;
	}
}
