using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Aziz;

internal static class PackageRemoval
{
	public static string Script(InstalledApp app)
	{
		if (app == null || string.IsNullOrWhiteSpace(app.Name) || string.IsNullOrWhiteSpace(app.PackageFamilyName))
		{
			throw new InvalidDataException("Exact package identity is required.");
		}
		string text = "'" + app.Name.Replace("'", "''") + "'";
		string text2 = "'" + app.PackageFamilyName.Replace("'", "''") + "'";
		return "$name=" + text + "; $family=" + text2 + "; $publisher=($family -split '_')[-1]; $packages=@(Get-AppxPackage -AllUsers -PackageTypeFilter Bundle,Main | Where-Object { $_.Name -eq $name -and $_.PackageFamilyName -eq $family }); if(@($packages | Where-Object {$_.NonRemovable -or $_.IsFramework}).Count){throw 'Windows marks this package as protected. No system files or ownership will be changed.'}; foreach($p in ($packages | Sort-Object @{Expression={if($_.IsBundle){0}else{1}}})){if(Get-AppxPackage -AllUsers | Where-Object PackageFullName -eq $p.PackageFullName){Remove-AppxPackage -AllUsers -Package $p.PackageFullName -ErrorAction Stop}}; $provisioned=@(Get-AppxProvisionedPackage -Online | Where-Object {$_.DisplayName -eq $name -and $_.PackageName.EndsWith('_'+$publisher)}); foreach($p in $provisioned){Remove-AppxProvisionedPackage -Online -AllUsers -PackageName $p.PackageName -ErrorAction Stop | Out-Null}; if(Get-AppxPackage -AllUsers | Where-Object PackageFamilyName -eq $family){throw 'At least one user registration remains; removal may require a restart.'}; if(Get-AppxProvisionedPackage -Online | Where-Object {$_.DisplayName -eq $name -and $_.PackageName.EndsWith('_'+$publisher)}){throw 'The provisioned package remains.'}; 'Deep removal verified: all-user registrations and Windows provisioning removed. Windows manages shared dependencies and protected payload files.'";
	}

	public static ActionResult Deep(InstalledApp app)
	{
		if (!Program.IsAdmin)
		{
			return new ActionResult
			{
				Message = "Administrator rights are required for all-user removal."
			};
		}
		try
		{
			return Recovery.LongRun("powershell.exe", GameWatch.PsArgs(Script(app)));
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static string SafeResidual(DesktopApp app, IEnumerable<DesktopApp> others)
	{
		try
		{
			if (string.IsNullOrWhiteSpace(app.InstallLocation) || !Path.IsPathRooted(app.InstallLocation))
			{
				return null;
			}
			string path = Path.GetFullPath(Environment.ExpandEnvironmentVariables(app.InstallLocation)).TrimEnd('\\');
			if (path.StartsWith("\\\\") || !Directory.Exists(path))
			{
				return null;
			}
			string[] array = new string[3]
			{
				Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
				Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
				Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData)
			};
			if (!array.Any((string r) => !string.IsNullOrEmpty(r) && path.StartsWith(r + "\\", StringComparison.OrdinalIgnoreCase)))
			{
				return null;
			}
			string[] array2 = array;
			foreach (string value in array2)
			{
				if (path.Equals(value, StringComparison.OrdinalIgnoreCase))
				{
					return null;
				}
			}
			array2 = new string[9] { "Microsoft", "WindowsApps", "Common Files", "Packages", "Programs", "Windows", "Temp", "Microsoft OneDrive", "OneDrive" };
			foreach (string value2 in array2)
			{
				if (new DirectoryInfo(path).Name.Equals(value2, StringComparison.OrdinalIgnoreCase))
				{
					return null;
				}
			}
			for (DirectoryInfo directoryInfo = new DirectoryInfo(path); directoryInfo != null; directoryInfo = directoryInfo.Parent)
			{
				if ((directoryInfo.Attributes & FileAttributes.ReparsePoint) != 0)
				{
					return null;
				}
			}
			if (ContainsLink(path))
			{
				return null;
			}
			foreach (DesktopApp other in others)
			{
				if ((!(other.KeyPath == app.KeyPath) || !(other.Hive == app.Hive)) && !string.IsNullOrEmpty(other.InstallLocation))
				{
					string text = Path.GetFullPath(Environment.ExpandEnvironmentVariables(other.InstallLocation)).TrimEnd('\\');
					if (text.Equals(path, StringComparison.OrdinalIgnoreCase) || text.StartsWith(path + "\\", StringComparison.OrdinalIgnoreCase) || path.StartsWith(text + "\\", StringComparison.OrdinalIgnoreCase))
					{
						return null;
					}
				}
			}
			return path;
		}
		catch
		{
			return null;
		}
	}

	private static bool ContainsLink(string path)
	{
		string[] fileSystemEntries = Directory.GetFileSystemEntries(path);
		foreach (string path2 in fileSystemEntries)
		{
			FileAttributes attributes = File.GetAttributes(path2);
			if ((attributes & FileAttributes.ReparsePoint) != 0)
			{
				return true;
			}
			if ((attributes & FileAttributes.Directory) != 0 && ContainsLink(path2))
			{
				return true;
			}
		}
		return false;
	}

	public static ActionResult CleanResidual(DesktopApp app, List<DesktopApp> others, string reviewedPath)
	{
		try
		{
			string text = SafeResidual(app, others);
			if (text == null || !text.Equals(reviewedPath, StringComparison.OrdinalIgnoreCase))
			{
				throw new IOException("Residual path changed or overlaps another application.");
			}
			if (AppInventory.Read().Any((DesktopApp x) => x.KeyPath == app.KeyPath && x.Hive == app.Hive))
			{
				throw new IOException("The app registration still exists. Finish the vendor uninstaller first.");
			}
			Directory.Delete(text, recursive: true);
			return new ActionResult
			{
				Success = !Directory.Exists(text),
				Message = "Removed the reviewed residual installation folder: " + text
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
