using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Aziz;

internal static class ProfileFiles
{
	internal const string AzizDefault = "aziz-default";

	internal const string WindowsDefault = "windows-default";

	internal const string Extension = ".azizprofile";

	internal static string Folder => Path.Combine(Program.Data, "Profiles");

	internal static UserProfile Read(string path)
	{
		if (new FileInfo(path).Length > 1048576)
		{
			throw new InvalidDataException("Profile exceeds 1 MB.");
		}
		UserProfile userProfile = Program.Json.Deserialize<UserProfile>(File.ReadAllText(path));
		if (userProfile == null || (userProfile.Version != 1 && userProfile.Version != 2) || userProfile.Values == null || userProfile.Values.Count > 4000 || string.IsNullOrWhiteSpace(userProfile.Name) || userProfile.Name.Length > 120)
		{
			throw new InvalidDataException("This is not a valid AZIZ profile.");
		}
		ProfileLogic.Upgrade(userProfile.Values);
		return userProfile;
	}

	internal static void Write(string path, UserProfile p)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		p.Version = 2;
		p.SavedUtc = DateTime.UtcNow.ToString("o");
		Utilities.AtomicWrite(path, Program.Json.Serialize(p));
	}

	internal static string SafeName(string name)
	{
		string text = new string((from c in (name ?? "").Trim()
			where !Path.GetInvalidFileNameChars().Contains(c)
			select c).ToArray()).Trim();
		if (text.Length <= 80)
		{
			return text;
		}
		return text.Substring(0, 80);
	}

	internal static string NewPath(string name)
	{
		string text = SafeName(name);
		if (text.Length == 0)
		{
			text = "My profile";
		}
		string text2 = Path.Combine(Folder, text + ".azizprofile");
		int num = 2;
		while (File.Exists(text2))
		{
			text2 = Path.Combine(Folder, text + " (" + num + ").azizprofile");
			num++;
		}
		return text2;
	}

	internal static List<string> List()
	{
		try
		{
			return Directory.Exists(Folder) ? Directory.GetFiles(Folder, "*.azizprofile").OrderBy((string x) => x, StringComparer.OrdinalIgnoreCase).Take(200)
				.ToList() : new List<string>();
		}
		catch
		{
			return new List<string>();
		}
	}
}
