using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class GameDiscovery
{
	private static string FindSteamExe(string root, string text)
	{
		try
		{
			Match match = Regex.Match(text, "\"installdir\"\\s+\"([^\"]+)\"");
			if (!match.Success)
			{
				return null;
			}
			string text2 = Path.GetFullPath(Path.Combine(root, "steamapps", "common")) + Path.DirectorySeparatorChar;
			string fullPath = Path.GetFullPath(Path.Combine(text2, match.Groups[1].Value));
			if (!fullPath.StartsWith(text2, StringComparison.OrdinalIgnoreCase))
			{
				return null;
			}
			List<FileInfo> list = new List<FileInfo>();
			FindExe(fullPath, 0, list);
			// The real game: not a trial/demo/tool build, closest to the game's own folder, name like the folder, then the biggest.
			string folder = Regex.Replace(match.Groups[1].Value, "[^A-Za-z0-9]", "").ToLowerInvariant();
			return (from f in list
				let n = Path.GetFileNameWithoutExtension(f.Name).ToLowerInvariant()
				let flat = Regex.Replace(n, "[^a-z0-9]", "")
				orderby (folder.Length > 0 && (folder.Contains(flat) || flat.Contains(folder))) descending, f.DirectoryName.Length, f.Length descending
				select f.FullName).FirstOrDefault();
		}
		catch
		{
			return null;
		}
	}

	private static void FindExe(string path, int depth, List<FileInfo> found)
	{
		if (depth > 4 || found.Count > 200 || !Directory.Exists(path) || (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
		{
			return;
		}
		try
		{
			string[] files = Directory.GetFiles(path, "*.exe");
			foreach (string text in files)
			{
				string @object = Path.GetFileName(text).ToLowerInvariant();
				if (!new string[20] { "crash", "unins", "setup", "redist", "launcher", "anticheat", "easyanti", "battleye", "bootstrap", "helper", "trial", "demo", "benchmark", "server", "editor", "report", "installer", "touchup", "cleanup", "dxsetup" }.Any(@object.Contains))
				{
					found.Add(new FileInfo(text));
				}
			}
			files = Directory.GetDirectories(path);
			for (int i = 0; i < files.Length; i++)
			{
				FindExe(files[i], depth + 1, found);
			}
		}
		catch
		{
		}
	}

	public static List<GameEntry> Scan()
	{
		List<GameEntry> list = new List<GameEntry>();
		HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Valve\\Steam"))
		{
			if (registryKey != null)
			{
				string text = Convert.ToString(registryKey.GetValue("SteamPath"));
				if (Directory.Exists(text))
				{
					hashSet.Add(text);
				}
			}
		}
		string[] array = hashSet.ToArray();
		foreach (string path in array)
		{
			try
			{
				string path2 = Path.Combine(path, "steamapps", "libraryfolders.vdf");
				if (!File.Exists(path2))
				{
					continue;
				}
				foreach (Match item in Regex.Matches(File.ReadAllText(path2), "\"path\"\\s+\"([^\"]+)\""))
				{
					hashSet.Add(item.Groups[1].Value.Replace("\\\\", "\\"));
				}
			}
			catch
			{
			}
		}
		foreach (string item2 in hashSet)
		{
			try
			{
				string path3 = Path.Combine(item2, "steamapps");
				if (!Directory.Exists(path3))
				{
					continue;
				}
				array = Directory.GetFiles(path3, "appmanifest_*.acf");
				for (int i = 0; i < array.Length; i++)
				{
					string text2 = File.ReadAllText(array[i]);
					Match match2 = Regex.Match(text2, "\"appid\"\\s+\"(\\d+)\"");
					Match match3 = Regex.Match(text2, "\"name\"\\s+\"([^\"]+)\"");
					if (match2.Success && match3.Success)
					{
						list.Add(new GameEntry
						{
							Name = match3.Groups[1].Value,
							Target = "steam://rungameid/" + match2.Groups[1].Value,
							Exe = FindSteamExe(item2, text2),
							Library = "Steam"
						});
					}
				}
			}
			catch
			{
			}
		}
		string path4 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Epic\\EpicGamesLauncher\\Data\\Manifests");
		try
		{
			if (Directory.Exists(path4))
			{
				array = Directory.GetFiles(path4, "*.item");
				foreach (string path5 in array)
				{
					Dictionary<string, object> dictionary = Program.Json.Deserialize<Dictionary<string, object>>(File.ReadAllText(path5));
					if (dictionary.ContainsKey("DisplayName") && dictionary.ContainsKey("AppName"))
					{
						string stringToEscape = Convert.ToString(dictionary["AppName"]);
						list.Add(new GameEntry
						{
							Name = Convert.ToString(dictionary["DisplayName"]),
							Target = "com.epicgames.launcher://apps/" + Uri.EscapeDataString(stringToEscape) + "?action=launch&silent=true",
							Exe = ((dictionary.ContainsKey("InstallLocation") && dictionary.ContainsKey("LaunchExecutable")) ? Path.Combine(Convert.ToString(dictionary["InstallLocation"]), Convert.ToString(dictionary["LaunchExecutable"])) : null),
							Library = "Epic"
						});
					}
				}
			}
		}
		catch
		{
		}
		RegistryView[] array2 = new RegistryView[2]
		{
			RegistryView.Registry32,
			RegistryView.Registry64
		};
		foreach (RegistryView view in array2)
		{
			try
			{
				using RegistryKey registryKey2 = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view);
				using RegistryKey registryKey3 = registryKey2.OpenSubKey("SOFTWARE\\GOG.com\\Games");
				if (registryKey3 == null)
				{
					continue;
				}
				array = registryKey3.GetSubKeyNames();
				foreach (string name in array)
				{
					using RegistryKey registryKey4 = registryKey3.OpenSubKey(name);
					string text3 = Convert.ToString(registryKey4.GetValue("exe"));
					string text4 = Convert.ToString(registryKey4.GetValue("gameName"));
					if (!string.IsNullOrEmpty(text3) && File.Exists(text3) && !string.IsNullOrEmpty(text4))
					{
						list.Add(new GameEntry
						{
							Name = text4,
							Target = text3,
							Exe = text3,
							Library = "GOG"
						});
					}
				}
			}
			catch
			{
			}
		}
		return (from x in list
			group x by x.Target into g
			select g.First() into x
			orderby x.Name
			select x).ToList();
	}
}
