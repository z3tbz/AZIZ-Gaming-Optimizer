using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Media;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Shell;
using System.Windows.Threading;
using Microsoft.Win32;

namespace Aziz;

internal class MainWindow : Window
{
	[CompilerGenerated]
	internal sealed class _003C_003Ec__DisplayClass713
	{
		internal sealed class _003C_003Ec__DisplayClass717
		{
			public _003C_003Ec__DisplayClass713 CS_0024_003C_003E8__locals714;

			public int mode;
		}

		internal sealed class _003C_003Ec__DisplayClass71a
		{
			public _003C_003Ec__DisplayClass717 CS_0024_003C_003E8__locals718;

			public _003C_003Ec__DisplayClass713 CS_0024_003C_003E8__locals714;

			public InstalledApp app;

			public ActionResult _003CRenderUninstaller_003Eb__705()
			{
				if (CS_0024_003C_003E8__locals718.mode != 2)
				{
					return Utilities.RemoveApp(app);
				}
				return PackageRemoval.Deep(app);
			}
		}

		internal sealed class _003C_003Ec__DisplayClass71e
		{
			public _003C_003Ec__DisplayClass717 CS_0024_003C_003E8__locals718;

			public _003C_003Ec__DisplayClass713 CS_0024_003C_003E8__locals714;

			public DesktopApp app;

			public string _003CRenderUninstaller_003Eb__706()
			{
				return PackageRemoval.SafeResidual(app, CS_0024_003C_003E8__locals714.desktop);
			}

			public ActionResult _003CRenderUninstaller_003Eb__707()
			{
				return AppInventory.Remove(app);
			}
		}

		internal sealed class _003C_003Ec__DisplayClass721
		{
			public _003C_003Ec__DisplayClass71e CS_0024_003C_003E8__locals71f;

			public _003C_003Ec__DisplayClass717 CS_0024_003C_003E8__locals718;

			public _003C_003Ec__DisplayClass713 CS_0024_003C_003E8__locals714;

			public string path;

			public ActionResult _003CRenderUninstaller_003Eb__708()
			{
				return PackageRemoval.CleanResidual(CS_0024_003C_003E8__locals71f.app, CS_0024_003C_003E8__locals714.desktop, path);
			}
		}

		public List<DesktopApp> desktop;

		public HashSet<DesktopApp> selectedDesktop;

		public HashSet<InstalledApp> selectedStore;

		public List<System.Windows.Controls.CheckBox> checks;

		public System.Windows.Controls.Button remove;

		public TextBlock count;

		public System.Windows.Controls.TextBox filter;

		public Action update;

		public List<Tuple<string, Border>> cards;

		public MainWindow _003C_003E4__this;

		private static Func<DesktopApp, string> CS_0024_003C_003E9__CachedAnonymousMethodDelegate715;

		private static Func<InstalledApp, string> CS_0024_003C_003E9__CachedAnonymousMethodDelegate716;

		private static Func<System.Windows.Controls.CheckBox, bool> CS_0024_003C_003E9__CachedAnonymousMethodDelegate723;

		public async void _003CRenderUninstaller_003Eb__702()
		{
			_003C_003Ec__DisplayClass717 _003C_003Ec__DisplayClass = new _003C_003Ec__DisplayClass717();
			_003C_003Ec__DisplayClass.CS_0024_003C_003E8__locals714 = this;
			if (_003C_003E4__this.preview || _003C_003E4__this.applying)
			{
				return;
			}
			List<string> names = selectedDesktop.Select((DesktopApp x) => x.Name).Concat(selectedStore.Select((InstalledApp x) => FriendlyApp(x.Name))).ToList();
			if (names.Count == 0)
			{
				return;
			}
			_003C_003Ec__DisplayClass.mode = _003C_003E4__this.ReviewUninstall(names);
			if (_003C_003Ec__DisplayClass.mode == 0)
			{
				return;
			}
			if (_003C_003Ec__DisplayClass.mode == 2 && !Program.IsAdmin)
			{
				_003C_003E4__this.Elevate();
				return;
			}
			_003C_003E4__this.applying = true;
			int failures = 0;
			try
			{
				InstalledApp[] array = selectedStore.ToArray();
				for (int i = 0; i < array.Length; i++)
				{
					_003C_003Ec__DisplayClass717 _003C_003Ec__DisplayClass2 = _003C_003Ec__DisplayClass;
					InstalledApp app = array[i];
					_003C_003E4__this.notice.Text = "Removing " + FriendlyApp(app.Name);
					ActionResult actionResult = await Task.Run(() => (_003C_003Ec__DisplayClass2.mode == 2) ? PackageRemoval.Deep(app) : Utilities.RemoveApp(app));
					_003C_003E4__this.Record(FriendlyApp(app.Name), (_003C_003Ec__DisplayClass.mode == 2) ? "Deep uninstall" : "Uninstall", "Installed", actionResult.Success ? "Removed" : "Needs review", actionResult);
					if (!actionResult.Success)
					{
						failures++;
						Say(actionResult.Message, "Removal result");
					}
				}
				int num3 = 0;
				DesktopApp[] array2 = null;
				int num2 = 0;
				Func<ActionResult> func2 = null;
				_003C_003Ec__DisplayClass71e _003C_003Ec__DisplayClass71e = null;
				_003C_003Ec__DisplayClass721 _003C_003Ec__DisplayClass4 = null;
				Func<ActionResult> func3 = null;
				Func<string> func4 = null;
				_003C_003Ec__DisplayClass721 _003C_003Ec__DisplayClass3;
				object obj;
				switch (num3)
				{
				default:
					array2 = selectedDesktop.ToArray();
					num2 = 0;
					goto IL_0581;
				case 1:
				{
					_003C_003Ec__DisplayClass721 _003C_003Ec__DisplayClass5 = null;
					_003C_003Ec__DisplayClass3 = _003C_003Ec__DisplayClass5;
					goto IL_0715;
				}
				case 2:
				{
					ActionResult actionResult2 = await Task.Run(func2);
					_003C_003E4__this.Record(_003C_003Ec__DisplayClass71e.app.Name, "Vendor uninstall", "Installed", actionResult2.Success ? "Removed" : "Needs review", actionResult2);
					if (!actionResult2.Success)
					{
						failures++;
						Say(actionResult2.Message, "Removal result");
					}
					else if (_003C_003Ec__DisplayClass.mode == 2 && _003C_003Ec__DisplayClass4.path != null && Directory.Exists(_003C_003Ec__DisplayClass4.path) && System.Windows.MessageBox.Show("The vendor uninstaller left this folder:\n\n" + _003C_003Ec__DisplayClass4.path + "\n\nRemove its remaining files? Any saved app settings inside this exact folder will also be removed.", "Review residual folder", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
					{
						if (func3 == null)
						{
							func3 = _003C_003Ec__DisplayClass4._003CRenderUninstaller_003Eb__708;
						}
						goto case 3;
					}
					goto IL_0781;
				}
				case 3:
					{
						ActionResult actionResult3 = await Task.Run(func3);
						_003C_003E4__this.Record(_003C_003Ec__DisplayClass71e.app.Name, "Residual cleanup", _003C_003Ec__DisplayClass4.path, actionResult3.Success ? "Removed" : "Preserved", actionResult3);
						if (!actionResult3.Success)
						{
							failures++;
							Say(actionResult3.Message);
						}
						goto IL_0781;
					}
					IL_0581:
					if (num2 < array2.Length)
					{
						func4 = null;
						func2 = null;
						_003C_003Ec__DisplayClass71e = new _003C_003Ec__DisplayClass71e();
						_003C_003Ec__DisplayClass71e.CS_0024_003C_003E8__locals718 = _003C_003Ec__DisplayClass;
						_003C_003Ec__DisplayClass71e.CS_0024_003C_003E8__locals714 = this;
						_003C_003Ec__DisplayClass71e.app = array2[num2];
						func3 = null;
						_003C_003Ec__DisplayClass4 = new _003C_003Ec__DisplayClass721();
						_003C_003Ec__DisplayClass4.CS_0024_003C_003E8__locals71f = _003C_003Ec__DisplayClass71e;
						_003C_003Ec__DisplayClass4.CS_0024_003C_003E8__locals718 = _003C_003Ec__DisplayClass;
						_003C_003Ec__DisplayClass4.CS_0024_003C_003E8__locals714 = this;
						_003C_003Ec__DisplayClass3 = _003C_003Ec__DisplayClass4;
						if (_003C_003Ec__DisplayClass.mode != 2)
						{
							obj = null;
							goto IL_071e;
						}
						if (func4 == null)
						{
							func4 = _003C_003Ec__DisplayClass71e._003CRenderUninstaller_003Eb__706;
						}
						goto IL_0715;
					}
					await _003C_003E4__this.RefreshInventory();
					break;
					IL_071e:
					_003C_003Ec__DisplayClass3.path = (string)obj;
					_003C_003E4__this.notice.Text = "Opening uninstaller: " + _003C_003Ec__DisplayClass71e.app.Name;
					if (func2 == null)
					{
						func2 = _003C_003Ec__DisplayClass71e._003CRenderUninstaller_003Eb__707;
					}
					goto case 2;
					IL_0781:
					num2++;
					goto IL_0581;
					IL_0715:
					obj = await Task.Run(func4);
					goto IL_071e;
				}
			}
			finally
			{
				_003C_003E4__this.applying = false;
				_003C_003E4__this.notice.Text = names.Count + " requested · " + failures + " need review. Results saved in Home history.";
				if (_003C_003E4__this.current == "Uninstaller")
				{
					_003C_003E4__this.RenderUninstaller();
				}
				else
				{
					_003C_003E4__this.viewCache.Remove("Uninstaller");
				}
			}
		}

		public void _003CRenderUninstaller_003Eb__709(object s, RoutedEventArgs e)
		{
			foreach (System.Windows.Controls.CheckBox item in checks.Where((System.Windows.Controls.CheckBox c) => c.IsVisible))
			{
				item.IsChecked = true;
			}
		}

		public void _003CRenderUninstaller_003Eb__70b(object s, RoutedEventArgs e)
		{
			foreach (System.Windows.Controls.CheckBox check in checks)
			{
				check.IsChecked = false;
			}
		}

		public void _003CRenderUninstaller_003Eb__70c()
		{
			count.Text = selectedDesktop.Count + selectedStore.Count + " selected";
			remove.IsEnabled = selectedDesktop.Count + selectedStore.Count > 0;
		}

		public void _003CRenderUninstaller_003Eb__711(object s, TextChangedEventArgs e)
		{
			foreach (Tuple<string, Border> card in cards)
			{
				card.Item2.Visibility = (Visibility)((card.Item1.IndexOf(filter.Text, StringComparison.OrdinalIgnoreCase) < 0) ? 2u : 0u);
			}
		}

		private static string _003CRenderUninstaller_003Eb__703(DesktopApp x)
		{
			return x.Name;
		}

		private static string _003CRenderUninstaller_003Eb__704(InstalledApp x)
		{
			return FriendlyApp(x.Name);
		}

		private static bool _003CRenderUninstaller_003Eb__70a(System.Windows.Controls.CheckBox c)
		{
			return c.IsVisible;
		}
	}

	private readonly Dictionary<string, PendingChange> pendingChanges;

	private readonly List<string> pendingOrder;

	private readonly HashSet<string> inFlight;

	private int workers;

	private int batchDone;

	private bool batchRestart;

	private readonly List<string> batchFailed;

	private StartupBoost queueBoost;

	private DispatcherTimer adapterTimer;

	private readonly List<string> adapterReasons;

	private Task<BiosInfo> biosTask;

	private string selectedGame;

	private bool gameOptions;

	private bool competitiveRunning;

	private readonly HashSet<string> installingPackages;

	private string downloadCategory;

	private string downloadStatus;

	private string downloadQuery;

	private bool portableOnly;

	private bool preparingDownload;

	private bool refreshingApps;

	private AppSettings settings;

	private static System.Windows.Media.Brush Accent = B("#7654E8");

	private static bool Orange;

	private NotifyIcon tray;

	private bool exitRequested;

	private TimerLease timerLease;

	private List<GameEntry> games;

	private bool gameScanning;

	private List<DownloadJob> downloads;

	private DispatcherTimer downloadTimer;

	private Dictionary<DownloadJob, Action> downloadViews;

	private static readonly HashSet<string> GeneralIds = new HashSet<string>("disable-apps-telemetry legacy-context-menu wifi bluetooth printing location auto-driver-updates power-saving deep-sleep hotspot dynamic-lighting storagesense energyrecs bgapps consumer-features auto-defrag combine-taskbar-buttons small-desktop-icons disable-animations transparency show-hidden-files center-taskbar dark-theme end-task-right-click windows-update telemetry activity-history scrollbars-visible taskbar-search taskbar-task-view taskbar-battery window-snapping start-bing-search start-recommendations settings-home sticky-keys menu-delay explorer-launch-target desktop-context-menu".Split(' '));

	private int servicePage;

	private string serviceQuery;

	private readonly Dictionary<string, Dictionary<string, Border>> tweakHosts;

	private static readonly CultureInfo English = CultureInfo.GetCultureInfo("en-US");

	private DispatcherTimer liveStateTimer;

	private DateTime lastLiveRead;

	private Border memoryFill;

	private TextBlock memoryAmount;

	private bool openingProfile;

	private bool preparingInterface;

	private bool viewReady;

	private readonly Dictionary<string, ViewSnapshot> viewCache;

	private List<PowerPlan> cachedPowerPlans;

	private List<LaunchEntry> installedLaunchers;

	private List<HistoryEntry> cachedHistory;

	public Dictionary<string, double> StartupTimings;

	private RegistryChangeWatch registryWatch;

	private readonly HashSet<string> pendingRegistry;

	private DispatcherTimer changeDebounce;

	private DispatcherTimer prewarm;

	private static readonly string[] WarmPages = new string[9] { "Toggles", "Tweaks", "Services", "Downloads", "Network", "Security", "Tools", "Power plans", "Favorites" };

	private double wheelTarget;

	private bool wheelActive;

	private TimeSpan lastFrame;

	private static Dictionary<string, string> serviceRecommendations;

	private static readonly DateTime? previousSession = ReadPreviousSession();

	private static System.Windows.Media.Color Bg = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString("#090E19");

	private static System.Windows.Media.Brush Text = B("#F1F4FC");

	private static System.Windows.Media.Brush Muted = B("#8E9BB4");

	private static System.Windows.Media.Brush Purple = B("#A78BFA");

	private static System.Windows.Media.Brush Cyan = B("#44D9E8");

	private static System.Windows.Media.Brush Green = B("#56D6AA");

	private Engine engine;

	private Telemetry telemetry;

	private MachineInfo machine;

	private Dictionary<string, TweakStatus> states;

	private HashSet<string> favorites;

	private List<HistoryEntry> observations;

	private StackPanel nav;

	private StackPanel content;

	private TextBlock pageTitle;

	private TextBlock subtitle;

	private TextBlock scanLabel;

	private TextBlock notice;

	private TextBlock deviceLabel;

	private System.Windows.Controls.TextBox search;

	private ScrollViewer scroll;

	private Border stage;

	private Grid searchBox;

	private DispatcherTimer sampleTimer;

	private bool scanning;

	private bool applying;

	private bool sampling;

	private bool preview;

	private bool initialized;

	private bool closing;

	private string current;

	private Dictionary<string, TextBlock> metrics;

	private Dictionary<string, Polyline> traces;

	private Dictionary<string, List<double>> points;

	private Dictionary<string, System.Windows.Controls.Button> navButtons;

	private Sample lastSample;

	private static bool LightMode;

	private DateTime lastSampleRead;

	private List<DesktopApp> cachedDesktop;

	private List<InstalledApp> cachedStore;

	private bool inventoryScanning;

	private readonly HashSet<string> openingTools;

	private static readonly Dictionary<string, string[]> ToolArt = new Dictionary<string, string[]>
	{
		{
			"latencymon",
			new string[2] { "\uec4a", "#EF4444" }
		},
		{
			"gointerrupt",
			new string[2] { "\ue964", "#8B5CF6" }
		},
		{
			"rweverything",
			new string[2] { "\ue950", "#64748B" }
		},
		{
			"process-explorer",
			new string[2] { "\ue9d9", "#0EA5E9" }
		},
		{
			"autoruns",
			new string[2] { "\ue7e8", "#22C55E" }
		},
		{
			"cru",
			new string[2] { "\ue7f4", "#06B6D4" }
		},
		{
			"power-settings-explorer",
			new string[2] { "\ue945", "#F59E0B" }
		},
		{
			"driver-store-explorer",
			new string[2] { "\ue74d", "#A855F7" }
		},
		{
			"hidusbf",
			new string[2] { "\ue962", "#EC4899" }
		},
		{
			"windows-update-manager",
			new string[2] { "\ue895", "#3B82F6" }
		},
		{
			"logitech-omm",
			new string[2] { "\ue962", "#14B8A6" }
		},
		{
			"bloatynosy",
			new string[2] { "\ue916", "#F97316" }
		},
		{
			"msrt",
			new string[2] { "\ue83d", "#10B981" }
		},
		{
			"device-cleanup",
			new string[2] { "\ue772", "#6366F1" }
		},
		{
			"ddu",
			new string[2] { "\ue7f8", "#DC2626" }
		}
	};

	private static readonly string[] DebloatGroups = new string[10] { "Windows components", "Windows apps", "Xbox & gaming", "Protected Windows apps", "Background services", "Telemetry", "Scheduled tasks", "Privacy & telemetry settings", "Windows features", "Hardware you may not use" };

	private readonly HashSet<string> dirtyIds = new HashSet<string>();

	private System.Windows.Controls.Button profileButton;

	private bool showMoreServices;

	private readonly Dictionary<string, int> renderGeneration = new Dictionary<string, int>();

	private System.Windows.Controls.Button saveProfileButton;

	private double? cpuMhz;

	private Border optimizeHero;

	private OptimizeVisual optimizeVisual;

	private TextBlock optimizeStatus;

	private System.Windows.Controls.Button optimizeButton;

	private bool optimizing;

	// A profile switch (incl. Windows Default) or the uninstall is running: One Click, another profile, uninstall and Exit
	// wait, so a late registry set of one can never land on top of another.
	private bool profileBusy;

	private Grid optimizeOverlay;

	private UIElement optimizeRoot;

	private TextBlock overlayStatus;

	private string ActiveKey
	{
		get
		{
			string activeProfile = settings.ActiveProfile;
			if (string.IsNullOrEmpty(activeProfile))
			{
				return "";
			}
			if (ProfileLogic.BuiltIn(activeProfile))
			{
				return activeProfile;
			}
			if (!File.Exists(activeProfile))
			{
				return "";
			}
			return activeProfile;
		}
	}

	private bool UserProfileActive
	{
		get
		{
			if (ActiveKey.Length > 0)
			{
				return !ProfileLogic.BuiltIn(ActiveKey);
			}
			return false;
		}
	}

	private bool AnyProfileActive => ActiveKey.Length > 0;

	private string ReferencePath => System.IO.Path.Combine(Program.Data, "applied-reference.json");

	private bool WindowLive
	{
		get
		{
			if (!closing && base.IsVisible)
			{
				return base.WindowState != WindowState.Minimized;
			}
			return false;
		}
	}

	private event Action<string, bool> ChangeFinished;

	private void UpdateProfileBadge()
	{
		if (profileButton != null)
		{
			// Same AZIZ violet as Save; a gold dot marks the active profile, the label is the short name.
			StackPanel stackPanel = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal
			};
			if (AnyProfileActive)
			{
				stackPanel.Children.Add(new Ellipse
				{
					Width = 7.0,
					Height = 7.0,
					Fill = B("#F5B728"),
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
				});
			}
			TextBlock textBlock = new TextBlock
			{
				Text = "Profiles",
				FontWeight = FontWeights.SemiBold,
				Foreground = System.Windows.Media.Brushes.White,
				VerticalAlignment = VerticalAlignment.Center,
				MaxWidth = 140.0,
				TextTrimming = TextTrimming.CharacterEllipsis
			};
			stackPanel.Children.Add(textBlock);
			profileButton.Content = stackPanel;
			profileButton.Background = ProfileBrush();
			profileButton.ToolTip = (AnyProfileActive ? ("Active profile · " + ProfileName(ActiveKey) + "\n" + ProfileAbout(ActiveKey)) : "Open the profiles");
		}
		if (saveProfileButton != null)
		{
			saveProfileButton.Visibility = (Visibility)((!AnyProfileActive) ? 2u : 0u);
			saveProfileButton.Background = ProfileBrush();
			saveProfileButton.Foreground = System.Windows.Media.Brushes.White;
		}
	}

	private static System.Windows.Media.Brush ProfileBrush()
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(70, 36, 150), System.Windows.Media.Color.FromRgb(28, 42, 120), 0.0);
		linearGradientBrush.Freeze();
		return linearGradientBrush;
	}

	private string ShortProfileName(string key)
	{
		switch (key)
		{
		case "aziz-ultra":
			return "ULL";
		case "aziz-recommended":
			return "LL";
		case "windows-default":
			return "Default";
		default:
			return ProfileName(key);
		}
	}

	private Task Change(Tweak t, bool enabled)
	{
		if (preview)
		{
			return Task.FromResult(0);
		}
		Click(enabled);
		if (t.Kind == "GpuMsi")
		{
			return ConfigureGpuMsi(enabled);
		}
		if (!Program.IsAdmin)
		{
			Say("Use ‘Run as administrator’ before changing system settings.", "Administrator required");
			return Task.FromResult(0);
		}
		if (!EnsureProfile() || !EnsureEditable(t, enabled ? "Enabled" : "Disabled"))
		{
			RefreshTweak(t.Id);
			return Task.FromResult(0);
		}
		if (t.Kind == "Timer")
		{
			return SetTimer(enabled);
		}
		Enqueue(t, enabled, null);
		return Task.FromResult(0);
	}

	private Task ChangeChoice(Tweak t, TweakChoice choice)
	{
		if (preview || choice == null)
		{
			return Task.FromResult(0);
		}
		Click(choice.Value != "4");
		if (!Program.IsAdmin)
		{
			Say("Run as administrator before changing this setting.");
			RefreshTweak(t.Id);
			return Task.FromResult(0);
		}
		if (t.Kind == "Service" && choice.Value == "4")
		{
			string text = ServicePresets.Warning(t.Service);
			if (text != null && System.Windows.MessageBox.Show("Disable " + t.Name + "?\n\n⚠ " + text, "Important Windows service", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) != MessageBoxResult.OK)
			{
				RefreshTweak(t.Id);
				return Task.FromResult(0);
			}
		}
		if (!EnsureProfile() || !EnsureEditable(t, choice.Value))
		{
			RefreshTweak(t.Id);
			return Task.FromResult(0);
		}
		Enqueue(t, choice.Value != "4", choice.Value);
		return Task.FromResult(0);
	}

	private void Enqueue(Tweak t, bool enabled, string choice, bool restore = false)
	{
		if (pendingChanges.TryGetValue(t.Id, out var value))
		{
			value.Enabled = enabled;
			value.Choice = choice;
			value.Restore = restore;
			value.Version++;
		}
		else
		{
			pendingChanges[t.Id] = new PendingChange
			{
				T = t,
				Enabled = enabled,
				Choice = choice,
				Restore = restore
			};
			pendingOrder.Add(t.Id);
		}
		RefreshTweak(t.Id);
		Pump();
	}

	// Each finished change gets a serial number: a scan that started before it must not write its older reading back.
	private long applySerial;

	private readonly Dictionary<string, long> appliedAt = new Dictionary<string, long>();

	// Changes AZIZ makes outside the queue (GPU MSI): their rescan is not an "outside" change.
	private readonly HashSet<string> ownChanges = new HashSet<string>();

	private const double DefaultWidth = 1360.0;

	private const double DefaultHeight = 900.0;

	private Task backupFirst;

	// Before the very first change on this PC: the AZIZ Backup restore point (enabling System Restore if needed).
	private Task BackupFirst()
	{
		if (preview || settings.BackupPointCreated || !Program.IsAdmin)
		{
			return Task.FromResult(0);
		}
		if (backupFirst == null)
		{
			notice.Text = "Creating the AZIZ Backup restore point before the first change…";
			backupFirst = Task.Run(() => SystemRestore.EnsureBackupPoint()).ContinueWith(delegate(Task<ActionResult> t)
			{
				ActionResult r = (t.IsFaulted ? new ActionResult
				{
					Message = t.Exception.GetBaseException().Message
				} : t.Result);
				base.Dispatcher.BeginInvoke((Action)delegate
				{
					if (r.Success)
					{
						settings.BackupPointCreated = true;
						SaveSettings();
					}
					Record("System Restore", "AZIZ Backup", "", r.Success ? "Created" : "Not created", r);
				});
			});
		}
		return backupFirst;
	}

	private void Pump()
	{
		int num = Math.Max(3, Math.Min(8, Environment.ProcessorCount));
		while (workers < num && !closing)
		{
			string text = pendingOrder.FirstOrDefault((string x) => !inFlight.Contains(x));
			if (text == null)
			{
				break;
			}
			inFlight.Add(text);
			workers++;
			if (queueBoost == null)
			{
				queueBoost = new StartupBoost();
			}
			Work(text);
		}
		ShowQueue();
	}

	private void ShowQueue()
	{
		if (pendingOrder.Count > 0)
		{
			notice.Text = "Applying " + pendingOrder.Count + " change" + ((pendingOrder.Count == 1) ? "" : "s") + " in the background…";
		}
	}

	private async void Work(string id)
	{
		await BackupFirst();
		PendingChange p = pendingChanges[id];
		int version = p.Version;
		bool enabled = p.Enabled;
		bool restore = p.Restore;
		string choice = p.Choice;
		Tweak t = p.T;
		ActionResult result;
		try
		{
			result = await Task.Run(delegate
			{
				if (restore)
				{
					return engine.Restore(t.Id);
				}
				if (choice != "4" && enabled)
				{
					ActionResult actionResult = ComponentRecovery.BeforeEnable(t);
					if (!actionResult.Success)
					{
						return actionResult;
					}
				}
				return (choice != null) ? engine.ApplyChoice(t.Id, choice) : engine.Apply(t.Id, enabled);
			});
		}
		catch (Exception ex)
		{
			result = new ActionResult
			{
				Message = ex.Message
			};
		}
		Dictionary<string, TweakStatus> fresh = null;
		try
		{
			fresh = await Task.Run(() => engine.Scan(new string[1] { id }));
		}
		catch
		{
		}
		inFlight.Remove(id);
		workers--;
		if (p.Version != version)
		{
			// The user changed this option again while it was applying: the newer request runs next and reports the result.
			RefreshTweak(id);
			Pump();
			return;
		}
		pendingChanges.Remove(id);
		pendingOrder.Remove(id);
		appliedAt[id] = ++applySerial;
		if (fresh != null && !pendingChanges.ContainsKey(id))
		{
			foreach (KeyValuePair<string, TweakStatus> item in fresh)
			{
				states[item.Key] = item.Value;
			}
		}
		RefreshTweak(id);
		batchDone++;
		this.ChangeFinished?.Invoke(id, result.Success);
		if (result.Success)
		{
			AutoSaveChange(t);
			if (t.ApplyNow == "Adapter")
			{
				ScheduleAdapterRestart(t.Name);
			}
			if (t.RequiresRestart)
			{
				batchRestart = true;
			}
		}
		else
		{
			batchFailed.Add(t.Name);
		}
		if (pendingOrder.Count > 0 || workers > 0)
		{
			Pump();
			return;
		}
		if (queueBoost != null)
		{
			queueBoost.Dispose();
			queueBoost = null;
		}
		notice.Text = ((batchFailed.Count == 0) ? (((batchDone == 1) ? (t.Name + " · applied") : (batchDone + " changes applied")) + (batchRestart ? " · restart Windows to finish" : "")) : ("⚠ " + ((batchFailed.Count == 1) ? (batchFailed[0] + " did not apply") : (batchFailed.Count + " of " + batchDone + " changes did not apply (" + string.Join(", ", batchFailed.Take(3)) + ((batchFailed.Count > 3) ? "…" : "") + ")")) + " · details in History"));
		batchDone = 0;
		batchFailed.Clear();
		batchRestart = false;
		try
		{
			cachedHistory = await Task.Run(() => engine.History().Concat(GameWatch.History()).ToList());
			if (!preview)
			{
				Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "last-states.json"), Program.Json.Serialize(states));
			}
		}
		catch
		{
		}
	}

	private void ScheduleAdapterRestart(string reason)
	{
		if (!adapterReasons.Contains(reason))
		{
			adapterReasons.Add(reason);
		}
		if (adapterTimer == null)
		{
			DispatcherTimer dispatcherTimer = new DispatcherTimer();
			dispatcherTimer.Interval = TimeSpan.FromSeconds(1.5);
			adapterTimer = dispatcherTimer;
			adapterTimer.Tick += async delegate
			{
				adapterTimer.Stop();
				if (pendingChanges.Values.Any((PendingChange x) => x.T.ApplyNow == "Adapter"))
				{
					adapterTimer.Start();
				}
				else
				{
					string text = string.Join(", ", adapterReasons);
					adapterReasons.Clear();
					notice.Text = "Restarting the network adapter to apply " + text + " now (a few seconds offline)…";
					ActionResult actionResult = await Task.Run(() => NetworkApply.RestartAdapters());
					notice.Text = (actionResult.Success ? actionResult.Message.Replace("Completed. ", "") : ("Network restart: " + actionResult.Message));
				}
			};
		}
		adapterTimer.Stop();
		adapterTimer.Start();
	}

	private void StartBiosDetection()
	{
		if (biosTask == null && !preview)
		{
			biosTask = Task.Run(() => BiosDrivers.Read());
		}
	}

	private void AddBiosCard(System.Windows.Controls.Panel grid)
	{
		StartBiosDetection();
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(DriverTitle("BIOS Drivers", "\ue950", "#F59E0B"));
		TextBlock detail = Label("Reading this PC…", 12.0, Muted);
		detail.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		stackPanel.Children.Add(detail);
		TextBlock textBlock = Label("Click to open your BIOS, chipset and driver downloads", 11.0, Muted);
		textBlock.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
		stackPanel.Children.Add(textBlock);
		Border border = Card(stackPanel);
		border.Margin = new Thickness(0.0, 0.0, 10.0, 12.0);
		border.Cursor = System.Windows.Input.Cursors.Hand;
		border.ToolTip = "Opens the manufacturer's download page for this exact PC";
		if (biosTask != null)
		{
			biosTask.ContinueWith((Task<BiosInfo> t) => base.Dispatcher.BeginInvoke((Action)delegate
			{
				if (t.IsFaulted || t.Result == null)
				{
					detail.Text = "Manufacturer not detected";
				}
				else
				{
					detail.Text = t.Result.Vendor + " · " + t.Result.Model + "\nBIOS " + t.Result.Version;
				}
			}));
		}
		border.MouseLeftButtonUp += async delegate
		{
			if (preview)
			{
				return;
			}
			try
			{
				StartBiosDetection();
				BiosInfo biosInfo = await biosTask;
				if (!biosInfo.Exact && !string.IsNullOrWhiteSpace(biosInfo.Model))
				{
					try
					{
						System.Windows.Clipboard.SetText(biosInfo.Model);
					}
					catch
					{
					}
				}
				OpenUri(biosInfo.Url);
				notice.Text = "Opened the support page for " + biosInfo.Vendor + " " + biosInfo.Model + (biosInfo.Exact ? "" : " · model copied to clipboard for the search box");
			}
			catch (Exception ex)
			{
				Say(ex.Message, "BIOS Drivers");
			}
		};
		grid.Children.Add(border);
	}

	private void ApplyBrandIcon()
	{
		base.Icon = BrandLogo.ExternalImage();
		if (preview)
		{
			return;
		}
		try
		{
			string text = System.IO.Path.Combine(Program.Root, "aziz.ico");
			if (!File.Exists(text))
			{
				return;
			}
			if (tray != null)
			{
				Icon icon = tray.Icon;
				tray.Icon = new Icon(text);
				icon?.Dispose();
			}
			string location = Program.ExePath;
			string[] array = new string[3]
			{
				Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
				Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory),
				System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Microsoft", "Internet Explorer", "Quick Launch", "User Pinned", "TaskBar")
			};
			foreach (string path in array)
			{
				if (!Directory.Exists(path))
				{
					continue;
				}
				string[] files = Directory.GetFiles(path, "*.lnk");
				foreach (string text2 in files)
				{
					object obj = null;
					object obj2 = null;
					try
					{
						Type typeFromProgID = Type.GetTypeFromProgID("WScript.Shell");
						obj = Activator.CreateInstance(typeFromProgID);
						obj2 = typeFromProgID.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, obj, new object[1] { text2 });
						Type type = obj2.GetType();
						if (string.Equals(System.IO.Path.GetFullPath(Convert.ToString(type.InvokeMember("TargetPath", BindingFlags.GetProperty, null, obj2, null))), System.IO.Path.GetFullPath(location), StringComparison.OrdinalIgnoreCase))
						{
							type.InvokeMember("IconLocation", BindingFlags.SetProperty, null, obj2, new object[1] { text + ",0" });
							type.InvokeMember("Save", BindingFlags.InvokeMethod, null, obj2, null);
						}
					}
					catch
					{
					}
					finally
					{
						if (obj2 != null)
						{
							Marshal.FinalReleaseComObject(obj2);
						}
						if (obj != null)
						{
							Marshal.FinalReleaseComObject(obj);
						}
					}
				}
			}
		}
		catch (Exception ex)
		{
			if (notice != null)
			{
				notice.Text = "Shortcut icon could not be refreshed: " + ex.Message;
			}
		}
	}

	private static string[] BrowserCacheRoots()
	{
		List<string> list = new List<string>();
		string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
		string[] array = new string[4] { "Google\\Chrome", "Microsoft\\Edge", "BraveSoftware\\Brave-Browser", "Vivaldi" };
		foreach (string path in array)
		{
			string path2 = System.IO.Path.Combine(folderPath, path, "User Data");
			try
			{
				if (!Directory.Exists(path2) || (File.GetAttributes(path2) & FileAttributes.ReparsePoint) != 0)
				{
					continue;
				}
				foreach (string item in (from x in Directory.GetDirectories(path2)
					where System.IO.Path.GetFileName(x) == "Default" || System.IO.Path.GetFileName(x).StartsWith("Profile ")
					select x).Take(30))
				{
					string[] array2 = new string[3] { "Cache", "Code Cache", "GPUCache" };
					foreach (string path4 in array2)
					{
						list.Add(System.IO.Path.Combine(item, path4));
					}
				}
			}
			catch
			{
			}
		}
		return list.ToArray();
	}

	public void PreviewCompetitive()
	{
		if (preview)
		{
			gameOptions = true;
			content.Children.Clear();
			AddCompetitivePanel();
		}
	}

	private void AddCompetitivePanel()
	{
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("Competitive Mode", 19.0, Text));
		stackPanel.Children.Add(Spacer(12));
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		System.Windows.Controls.ComboBox comboBox = new System.Windows.Controls.ComboBox();
		comboBox.ItemsSource = games;
		comboBox.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
		System.Windows.Controls.ComboBox list = comboBox;
		list.SelectedItem = games.FirstOrDefault((GameEntry x) => x.Target == selectedGame) ?? games.FirstOrDefault();
		grid.Children.Add(list);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		stackPanel2.Children.Add(Btn("Browse…", delegate
		{
			if (!preview)
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
				{
					Filter = "Game executable (*.exe)|*.exe"
				};
				if (openFileDialog.ShowDialog() == true)
				{
					GameEntry gameEntry2 = new GameEntry
					{
						Name = System.IO.Path.GetFileNameWithoutExtension(openFileDialog.FileName),
						Target = openFileDialog.FileName,
						Exe = openFileDialog.FileName,
						Library = "Manual"
					};
					games.Add(gameEntry2);
					selectedGame = gameEntry2.Target;
					SaveManualGames();
					RenderOverview();
				}
			}
		}));
		stackPanel2.Children.Add(BrandBtn("Start Competitive Mode", async delegate
		{
			if (list.SelectedItem is GameEntry game2)
			{
				await LaunchCompetitive(game2);
			}
		}, primary: true));
		Grid.SetColumn(stackPanel2, 1);
		grid.Children.Add(stackPanel2);
		stackPanel.Children.Add(grid);
		stackPanel.Children.Add(Spacer(10));
		WrapPanel wrapPanel = new WrapPanel();
		wrapPanel.Children.Add(Btn(gameOptions ? "Hide options" : "Show options", delegate
		{
			selectedGame = ((list.SelectedItem == null) ? null : ((GameEntry)list.SelectedItem).Target);
			gameOptions = !gameOptions;
			RenderOverview();
		}));
		wrapPanel.Children.Add(Btn("Rescan games", async delegate
		{
			await RefreshGames();
		}));
		wrapPanel.Children.Add(Btn("Create shortcut", delegate
		{
			if (list.SelectedItem is GameEntry game)
			{
				CreateGameShortcut(game);
			}
		}));
		GameConfig gameConfig = GameWatch.Load();
		if (gameConfig.Enabled)
		{
			wrapPanel.Children.Add(Btn("Disable auto profiles", async delegate
			{
				if (!preview)
				{
					if (!Program.IsAdmin)
					{
						Elevate();
					}
					else
					{
						ActionResult actionResult;
						try
						{
							actionResult = await Task.Run(() => GameWatch.Disable());
						}
						catch (Exception ex)
						{
							actionResult = new ActionResult
							{
								Message = ex.Message
							};
						}
						notice.Text = (actionResult.Success ? "Automatic profiles are off · changes made for a running game are restored." : ("Automatic profiles: " + Utilities.Short(actionResult.Message)));
						InvalidateViews();
						RenderOverview();
					}
				}
			}));
		}
		stackPanel.Children.Add(wrapPanel);
		stackPanel.Children.Add(Spacer(10));
		stackPanel.Children.Add(Label(games.Count + " games · " + (gameConfig.Enabled ? "Independent profiles enabled" : "Auto profiles are off") + " · game library loaded at startup · manual rescan available", 11.0, Muted));
		stackPanel.Children.Add(Label("Saved profiles run whenever the selected game executable starts, even with AZIZ closed. Some anti-cheats block priority changes; skipped changes are recorded.", 11.0, Muted));
		list.SelectionChanged += delegate
		{
			if (list.SelectedItem != null)
			{
				selectedGame = ((GameEntry)list.SelectedItem).Target;
				if (gameOptions)
				{
					RenderOverview();
				}
			}
		};
		GameEntry gameEntry = list.SelectedItem as GameEntry;
		if (gameOptions && gameEntry != null)
		{
			stackPanel.Children.Add(Spacer(18));
			FillGameOptions(stackPanel, gameEntry, gameConfig);
		}
		content.Children.Add(Card(stackPanel));
	}

	private void FillGameOptions(StackPanel panel, GameEntry game, GameConfig cfg)
	{
		GameRule gameRule = cfg.Rules.FirstOrDefault((GameRule x) => x.Launch == game.Target);
		GameRule rule = ((gameRule == null) ? new GameRule
		{
			Name = game.Name,
			Exe = game.Exe,
			Launch = game.Target,
			Library = game.Library
		} : Program.Json.Deserialize<GameRule>(Program.Json.Serialize(gameRule)));
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 2
		};
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(0.0, 0.0, 20.0, 0.0);
		stackPanel.Children.Add(Label("GAME PROCESS", 11.0, Purple));
		AddGameCheck(stackPanel, "Boost game priority", rule.Boost, delegate(bool v)
		{
			rule.Boost = v;
		});
		AddGameChoice(stackPanel, "CPU priority", new string[5] { "Idle", "BelowNormal", "Normal", "AboveNormal", "High" }, rule.Cpu, delegate(string v)
		{
			rule.Cpu = v;
		});
		AddGameChoice(stackPanel, "GPU priority", new string[5] { "Idle", "Below normal", "Normal", "Above normal", "High" }, (new string[5] { "Idle", "Below normal", "Normal", "Above normal", "High" })[rule.Gpu], delegate(string v)
		{
			rule.Gpu = Array.IndexOf(new string[5] { "Idle", "Below normal", "Normal", "Above normal", "High" }, v);
		});
		AddGameChoice(stackPanel, "I/O priority", new string[4] { "Very low", "Low", "Normal", "High" }, (new string[4] { "Very low", "Low", "Normal", "High" })[rule.Io], delegate(string v)
		{
			rule.Io = Array.IndexOf(new string[4] { "Very low", "Low", "Normal", "High" }, v);
		});
		stackPanel.Children.Add(Spacer(12));
		stackPanel.Children.Add(Label("Manual cores · applied to the launcher before the game starts, so anti-cheat games inherit them. Empty = Windows decides.", 11.0, Muted));
		List<CpuUnit> cores = GameNative.CpuTopology();
		Dictionary<uint, System.Windows.Controls.CheckBox> checks = new Dictionary<uint, System.Windows.Controls.CheckBox>();
		WrapPanel wrapPanel = new WrapPanel
		{
			Margin = new Thickness(0.0, 8.0, 0.0, 8.0)
		};
		Action<Func<CpuUnit, bool>> choose = delegate(Func<CpuUnit, bool> predicate)
		{
			foreach (CpuUnit item in cores)
			{
				checks[item.Id].IsChecked = predicate(item);
			}
		};
		wrapPanel.Children.Add(Btn("All", delegate
		{
			choose((CpuUnit x) => true);
		}));
		wrapPanel.Children.Add(Btn("None", delegate
		{
			choose((CpuUnit x) => false);
		}));
		wrapPanel.Children.Add(Btn("SMT on", delegate
		{
			choose((CpuUnit x) => true);
		}));
		wrapPanel.Children.Add(Btn("SMT off", delegate
		{
			choose((CpuUnit x) => !x.Smt);
		}));
		stackPanel.Children.Add(wrapPanel);
		UniformGrid uniformGrid2 = new UniformGrid
		{
			Columns = 4
		};
		foreach (CpuUnit item2 in cores)
		{
			System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
			{
				Content = item2.ToString(),
				IsChecked = rule.CpuSets.Contains(item2.Id),
				Foreground = Text,
				Margin = new Thickness(0.0, 5.0, 6.0, 5.0),
				FontSize = 11.0
			};
			checks[item2.Id] = checkBox;
			uniformGrid2.Children.Add(checkBox);
		}
		stackPanel.Children.Add(uniformGrid2);
		uniformGrid.Children.Add(stackPanel);
		StackPanel stackPanel2 = Stack();
		stackPanel2.Children.Add(Label("BACKGROUND ACTIVITY", 11.0, Purple));
		AddGameCheck(stackPanel2, "Game focus · lower browser / Discord priority", rule.Focus, delegate(bool v)
		{
			rule.Focus = v;
		});
		AddGameCheck(stackPanel2, "Pause SysMain, error reporting and telemetry", rule.PauseServices, delegate(bool v)
		{
			rule.PauseServices = v;
		});
		WrapPanel wrapPanel2 = new WrapPanel
		{
			Margin = new Thickness(0.0, 8.0, 0.0, 0.0)
		};
		TextBlock helperStatus = Label((SteamHelper.SteamFolder() == null) ? "Steam not found" : (SteamHelper.Installed() ? "NoSteamWebHelper is installed and starts with Windows" : ""), 10.0, Muted);
		System.Windows.Controls.Button helper = Btn(SteamHelper.Installed() ? "Remove NoSteamWebHelper" : "Install NoSteamWebHelper", delegate
		{
		});
		helper.IsEnabled = SteamHelper.SteamFolder() != null;
		helper.Click += async delegate
		{
			if (!preview)
			{
				if (!Program.IsAdmin)
				{
					Elevate();
				}
				else
				{
					bool remove = SteamHelper.Installed();
					string target = SteamHelper.SteamFolder();
					helper.IsEnabled = false;
					helperStatus.Text = (remove ? "Removing…" : "Installing NoSteamWebHelper (Steam closes and reopens)…");
					await BackupFirst();
					ActionResult actionResult2 = await Task.Run(() => remove ? SteamHelper.Remove() : SteamHelper.Install(target));
					helperStatus.Text = actionResult2.Message;
					Record("NoSteamWebHelper", remove ? "Remove" : "Install", "", actionResult2.Success ? "Done" : "Failed", actionResult2);
					helper.Content = (SteamHelper.Installed() ? "Remove NoSteamWebHelper" : "Install NoSteamWebHelper");
					helper.IsEnabled = true;
				}
			}
		};
		wrapPanel2.Children.Add(helper);
		stackPanel2.Children.Add(wrapPanel2);
		stackPanel2.Children.Add(helperStatus);
		AddGameCheck(stackPanel2, "Pause Windows Search indexing", rule.Search, delegate(bool v)
		{
			rule.Search = v;
		});
		AddGameCheck(stackPanel2, "Close AZIZ after game launch", rule.CloseApp, delegate(bool v)
		{
			rule.CloseApp = v;
		});
		stackPanel2.Children.Add(Spacer(18));
		stackPanel2.Children.Add(Label("SYSTEM & NETWORK", 11.0, Purple));
		AddGameCheck(stackPanel2, "Load latency reduction · disable TCP auto-tuning", rule.Network, delegate(bool v)
		{
			rule.Network = v;
		});
		stackPanel2.Children.Add(Label("Experimental; can reduce TCP throughput. Original value restores after play.", 10.0, Muted));
		AddGameCheck(stackPanel2, "Consistent performance · High Performance plan", rule.Performance, delegate(bool v)
		{
			rule.Performance = v;
		});
		AddGameCheck(stackPanel2, "Clear standby memory once at launch", rule.Standby, delegate(bool v)
		{
			rule.Standby = v;
			if (preview)
			{
				return;
			}
			// Takes effect at once: a saved or automatic profile picks it up on its next check, and switching it on clears standby now.
			try
			{
				GameConfig gameConfig2 = GameWatch.Load();
				GameRule gameRule2 = gameConfig2.Rules.FirstOrDefault((GameRule x) => x.Launch == game.Target || (!string.IsNullOrEmpty(rule.Exe) && string.Equals(x.Exe, rule.Exe, StringComparison.OrdinalIgnoreCase)));
				if (gameRule2 != null)
				{
					gameRule2.Standby = v;
					GameWatch.Save(gameConfig2);
				}
			}
			catch
			{
			}
			if (v && Program.IsAdmin)
			{
				Task.Run(delegate
				{
					try
					{
						GameNative.ClearStandby();
						base.Dispatcher.BeginInvoke((Action)delegate
						{
							notice.Text = "Standby memory cleared now · it is cleared again every time " + game.Name + " starts.";
						});
					}
					catch (Exception ex4)
					{
						base.Dispatcher.BeginInvoke((Action)delegate
						{
							notice.Text = "Standby: " + ex4.Message;
						});
					}
				});
			}
		});
		stackPanel2.Children.Add(Label("Cached memory refills naturally; clearing it can increase loading time.", 10.0, Muted));
		uniformGrid.Children.Add(stackPanel2);
		panel.Children.Add(uniformGrid);
		panel.Children.Add(Spacer(14));
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Text = rule.Exe ?? "";
		textBox.ToolTip = "Actual game process executable, not the launcher";
		textBox.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
		System.Windows.Controls.TextBox exe = textBox;
		panel.Children.Add(Label("Game executable to monitor", 12.0, Muted));
		panel.Children.Add(exe);
		WrapPanel wrapPanel3 = new WrapPanel();
		wrapPanel3.Children.Add(Btn("Choose game EXE", delegate
		{
			if (!preview)
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
				{
					Filter = "Game executable (*.exe)|*.exe"
				};
				if (openFileDialog.ShowDialog() == true)
				{
					exe.Text = openFileDialog.FileName;
				}
			}
		}));
		wrapPanel3.Children.Add(Btn("Save profile", delegate
		{
			if (preview)
			{
				return;
			}
			try
			{
				rule.Library = game.Library;
				rule.Exe = exe.Text.Trim();
				rule.CpuSets = checks.Where(delegate(KeyValuePair<uint, System.Windows.Controls.CheckBox> x)
				{
					KeyValuePair<uint, System.Windows.Controls.CheckBox> keyValuePair4 = x;
					return keyValuePair4.Value.IsChecked == true;
				}).Select(delegate(KeyValuePair<uint, System.Windows.Controls.CheckBox> x)
				{
					KeyValuePair<uint, System.Windows.Controls.CheckBox> keyValuePair3 = x;
					return keyValuePair3.Key;
				}).ToArray();
				GameWatch.Validate(rule);
				GameConfig gameConfig = GameWatch.Load();
				gameConfig.Rules.RemoveAll((GameRule x) => x.Launch == game.Target || x.Exe.Equals(rule.Exe, StringComparison.OrdinalIgnoreCase));
				gameConfig.Rules.Add(rule);
				GameWatch.Save(gameConfig);
				notice.Text = "Profile saved for " + game.Name + " · press Start Competitive Mode.";
			}
			catch (Exception ex2)
			{
				Say(ex2.Message);
			}
		}, primary: true));
		wrapPanel3.Children.Add(Btn("Save & run automatically", async delegate
		{
			if (!preview && !applying)
			{
				if (Program.IsAdmin)
				{
					try
					{
						rule.Library = game.Library;
						rule.Exe = exe.Text.Trim();
						rule.CpuSets = checks.Where(delegate(KeyValuePair<uint, System.Windows.Controls.CheckBox> x)
						{
							KeyValuePair<uint, System.Windows.Controls.CheckBox> keyValuePair2 = x;
							return keyValuePair2.Value.IsChecked == true;
						}).Select(delegate(KeyValuePair<uint, System.Windows.Controls.CheckBox> x)
						{
							KeyValuePair<uint, System.Windows.Controls.CheckBox> keyValuePair = x;
							return keyValuePair.Key;
						}).ToArray();
						GameWatch.Validate(rule);
						if (!File.Exists(rule.Exe))
						{
							throw new FileNotFoundException("Choose the actual installed game executable.");
						}
						if (System.Windows.MessageBox.Show("Enable this profile whenever " + game.Name + " starts?\n\nA small AZIZ helper will run independently at sign-in. It restores changed priorities, services and system settings when the last monitored game exits.\n\n" + rule.Exe, "Automatic game profile", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
						{
							applying = true;
							GameConfig currentCfg = GameWatch.Load();
							currentCfg.Rules.RemoveAll((GameRule x) => x.Launch == game.Target || x.Exe.Equals(rule.Exe, StringComparison.OrdinalIgnoreCase));
							currentCfg.Rules.Add(rule);
							currentCfg.Enabled = true;
							GameWatch.Save(currentCfg);
							ActionResult actionResult = await Task.Run(() => GameWatch.Install());
							Record(game.Name, "Save automatic profile", "Previous profile", rule.Exe, actionResult);
							if (!actionResult.Success)
							{
								currentCfg.Enabled = false;
								GameWatch.Save(currentCfg);
							}
							notice.Text = (actionResult.Success ? ("Automatic profile on · every option you ticked is applied whenever " + game.Name + " starts, from AZIZ or anywhere else, even with AZIZ closed.") : ("The automatic profile could not start: " + Utilities.Short(actionResult.Message)));
							InvalidateViews();
							RenderOverview();
						}
						return;
					}
					catch (Exception ex)
					{
						notice.Text = "Automatic profile: " + Utilities.Short(ex.Message);
						return;
					}
					finally
					{
						applying = false;
					}
				}
				Elevate();
			}
		}, primary: true));
		panel.Children.Add(wrapPanel3);
	}

	private void AddGameCheck(StackPanel p, string title, bool value, Action<bool> changed)
	{
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			Content = title,
			IsChecked = value,
			Foreground = Text,
			Margin = new Thickness(0.0, 12.0, 0.0, 0.0),
			FontSize = 12.0
		};
		checkBox.Checked += delegate
		{
			changed(obj: true);
		};
		checkBox.Unchecked += delegate
		{
			changed(obj: false);
		};
		p.Children.Add(checkBox);
	}

	private void AddGameChoice(StackPanel p, string title, string[] values, string value, Action<string> changed)
	{
		Grid grid = new Grid
		{
			Margin = new Thickness(0.0, 8.0, 0.0, 0.0)
		};
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(105.0)
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		TextBlock textBlock = Label(title, 12.0, Muted);
		textBlock.VerticalAlignment = VerticalAlignment.Center;
		grid.Children.Add(textBlock);
		System.Windows.Controls.ComboBox comboBox = new System.Windows.Controls.ComboBox();
		comboBox.ItemsSource = values;
		comboBox.SelectedItem = value;
		System.Windows.Controls.ComboBox box = comboBox;
		box.SelectionChanged += delegate
		{
			changed(Convert.ToString(box.SelectedItem));
		};
		Grid.SetColumn(box, 1);
		grid.Children.Add(box);
		p.Children.Add(grid);
	}

	private async Task LaunchCompetitive(GameEntry game)
	{
		if (preview || applying || competitiveRunning)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		GameConfig gameConfig = GameWatch.Load();
		GameRule rule = gameConfig.Rules.FirstOrDefault((GameRule x) => x.Launch == game.Target && x.Enabled);
		if (rule == null && !string.IsNullOrEmpty(game.Exe) && File.Exists(game.Exe))
		{
			rule = new GameRule
			{
				Name = game.Name,
				Exe = game.Exe,
				Launch = game.Target,
				Library = game.Library,
				Cpu = "High",
				Gpu = 4,
				Io = 2,
				Focus = true,
				Steam = true,
				PauseServices = true
			};
			try
			{
				GameWatch.Validate(rule);
				gameConfig.Rules.RemoveAll((GameRule x) => x.Launch == game.Target);
				gameConfig.Rules.Add(rule);
				GameWatch.Save(gameConfig);
			}
			catch
			{
				rule = null;
			}
		}
		if (rule == null || string.IsNullOrEmpty(rule.Exe))
		{
			selectedGame = game.Target;
			notice.Text = "AZIZ could not find the game executable for " + game.Name + ". Open Show options, press Choose game EXE, then Save profile.";
			return;
		}
		competitiveRunning = true;
		competitiveExe = (gameConfig.Enabled ? null : rule.Exe);
		Action<string> report = delegate(string m)
		{
			base.Dispatcher.BeginInvoke((Action)delegate
			{
				notice.Text = "Competitive · " + m;
			});
		};
		try
		{
			bool watcher = gameConfig.Enabled;
			GameJournal journal = new GameJournal();
			string text = await Task.Run(delegate
			{
				if (!watcher)
				{
					GameWatch.ApplyGlobals(rule, journal);
				}
				return CompetitiveLaunch.Start(game, rule, report);
			});
			report(game.Name + " starting · " + text);
			if (rule.CloseApp)
			{
				if (!watcher)
				{
					try
					{
						GameWatch.StartSession(rule.Exe);
					}
					catch
					{
					}
				}
				exitRequested = true;
				Close();
				return;
			}
			string text2 = await Task.Run(delegate
			{
				string result = CompetitiveLaunch.Watch(game, rule, report, CancellationToken.None);
				if (!watcher)
				{
					GameWatch.RestoreGlobals(journal);
				}
				return result;
			});
			report(text2);
			GameWatch.Log(game.Name, "Competitive session", text2);
		}
		catch (Exception ex)
		{
			notice.Text = "Competitive Mode: " + Utilities.Short(ex.Message);
			CompetitiveLaunch.Restore();
		}
		finally
		{
			competitiveRunning = false;
		}
	}

	private void CreateGameShortcut(GameEntry game)
	{
		if (preview)
		{
			return;
		}
		try
		{
			string text = string.Concat(game.Name.Where((char x) => !System.IO.Path.GetInvalidFileNameChars().Contains(x)));
			string path = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), text + " - AZIZ.url");
			if (File.Exists(path))
			{
				notice.Text = "This shortcut already exists.";
				return;
			}
			string text2 = game.Target;
			if (File.Exists(text2))
			{
				text2 = new Uri(text2).AbsoluteUri;
			}
			File.WriteAllText(path, "[InternetShortcut]\r\nURL=" + text2.Replace("\r", "").Replace("\n", "") + "\r\n");
			notice.Text = "Desktop shortcut created. Saved auto profile applies on game detection.";
		}
		catch (Exception ex)
		{
			notice.Text = ex.Message;
		}
	}

	private IEnumerable<GameEntry> ReadManualGames()
	{
		try
		{
			return Program.Json.Deserialize<List<GameEntry>>(File.ReadAllText(System.IO.Path.Combine(Program.Data, "manual-games.json")));
		}
		catch
		{
			return new GameEntry[0];
		}
	}

	private void SaveManualGames()
	{
		if (!preview)
		{
			Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "manual-games.json"), Program.Json.Serialize(games.Where((GameEntry x) => x.Library == "Manual").ToArray()));
		}
	}

	private void SpecialDownload(DownloadItem item, WrapPanel actions, System.Windows.Controls.Button action, TextBlock detail)
	{
		if (item.Builtin != null)
		{
			string path = BuiltinPath(item);
			bool flag = File.Exists(path);
			action.Content = (flag ? "Open" : "Not in this Windows");
			action.IsEnabled = flag;
			action.Background = (flag ? BrandBrush() : BrandBrush());
			detail.Visibility = Visibility.Visible;
			detail.Text = (flag ? "Built into Windows · opens locally" : ("This Windows build has no " + item.Name));
			action.Click += delegate
			{
				if (!preview)
				{
					try
					{
						Process.Start(new ProcessStartInfo(path)
						{
							UseShellExecute = true
						});
					}
					catch (Exception ex4)
					{
						Say(ex4.Message, item.Name);
					}
				}
			};
			// The card already has Shortcut when Windows lists the app as installed: never show it twice.
			if (!flag || actions.Children.OfType<System.Windows.Controls.Button>().Any((System.Windows.Controls.Button x) => (x.Content as string) == "Shortcut"))
			{
				return;
			}
			LaunchEntry entry = new LaunchEntry
			{
				Name = item.Name,
				Target = path,
				Icon = path,
				Directory = System.IO.Path.GetDirectoryName(path)
			};
			actions.Children.Add(Btn("Shortcut", delegate
			{
				if (!preview)
				{
					try
					{
						AppLauncher.Shortcut(entry);
						notice.Text = "Desktop shortcut created for " + item.Name;
					}
					catch (Exception ex3)
					{
						Say(ex3.Message);
					}
				}
			}));
			return;
		}
		LaunchEntry installed = Installed(item);
		Action paint = delegate
		{
			bool flag2 = installingPackages.Contains(item.Id);
			installed = Installed(item);
			action.Content = (flag2 ? "Installing…" : ((installed != null) ? "Open" : "Install"));
			action.IsEnabled = !flag2;
			action.Background = ((installed != null) ? BrandBrush() : BrandBrush());
			detail.Visibility = Visibility.Visible;
			detail.Text = (flag2 ? "Installing with the Windows package manager…" : ((installed != null) ? "Installed in Windows" : "Installs directly · no Store app needed"));
		};
		paint();
		if (installed != null && !actions.Children.OfType<System.Windows.Controls.Button>().Any((System.Windows.Controls.Button x) => (x.Content as string) == "Shortcut"))
		{
			actions.Children.Add(Btn("Shortcut", delegate
			{
				if (!preview)
				{
					try
					{
						AppLauncher.Shortcut(Installed(item));
					}
					catch (Exception ex2)
					{
						Say(ex2.Message);
					}
				}
			}));
		}
		action.Click += async delegate
		{
			if (!preview && !installingPackages.Contains(item.Id))
			{
				LaunchEntry launchEntry = Installed(item);
				if (launchEntry != null)
				{
					try
					{
						AppLauncher.Open(launchEntry);
						return;
					}
					catch (Exception ex)
					{
						Say(ex.Message);
						return;
					}
				}
				installingPackages.Add(item.Id);
				paint();
				ActionResult actionResult = await Task.Run(() => Recovery.InstallStorePackage(item.Winget));
				installingPackages.Remove(item.Id);
				Record(item.Name, "Install", "Not installed", actionResult.Success ? "Installed" : "Failed", actionResult);
				notice.Text = (actionResult.Success ? (item.Name + " installed.") : (item.Name + ": " + ((actionResult.Message.Length > 300) ? actionResult.Message.Substring(actionResult.Message.Length - 300) : actionResult.Message)));
				await RefreshLaunchers();
				if (current == "Downloads")
				{
					RenderDownloads();
				}
			}
		};
	}

	private LaunchEntry Installed(DownloadItem item)
	{
		return installedLaunchers.FirstOrDefault((LaunchEntry x) => x.CatalogId == item.Id && (x.Target.StartsWith("shell:AppsFolder\\", StringComparison.Ordinal) || AppLauncher.ValidExe(x.Target)));
	}

	private static string BuiltinPath(DownloadItem item)
	{
		if (!string.IsNullOrEmpty(item.Builtin))
		{
			return Environment.ExpandEnvironmentVariables(item.Builtin);
		}
		return null;
	}

	private bool Available(DownloadItem item)
	{
		if (Installed(item) == null && (item.Builtin == null || !File.Exists(BuiltinPath(item))))
		{
			return downloads.Any((DownloadJob j) => j.Item.Id == item.Id && j.State == "Completed" && File.Exists(j.FilePath));
		}
		return true;
	}

	private void RenderDownloads()
	{
		content.Children.Clear();
		downloadViews.Clear();
		if (downloadTimer == null)
		{
			DispatcherTimer dispatcherTimer = new DispatcherTimer();
			dispatcherTimer.Interval = TimeSpan.FromMilliseconds(400.0);
			downloadTimer = dispatcherTimer;
			downloadTimer.Tick += delegate
			{
				if (current == "Downloads")
				{
					Action[] array = downloadViews.Values.ToArray();
					for (int i = 0; i < array.Length; i++)
					{
						array[i]();
					}
				}
			};
		}
		DockPanel dockPanel = new DockPanel
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		};
		System.Windows.Controls.Button button = Btn("Downloads folder", delegate
		{
			if (!preview)
			{
				Directory.CreateDirectory(DownloadLibrary.Folder);
				Process.Start(Utilities.Explorer, "\"" + DownloadLibrary.Folder + "\"");
			}
		}, primary: true);
		DockPanel.SetDock(button, Dock.Right);
		dockPanel.Children.Add(button);
		System.Windows.Controls.Button button2 = Btn("↻", async delegate
		{
			if (preview)
			{
				return;
			}
			refreshingApps = true;
			try
			{
				await RefreshLaunchers();
				RenderDownloads();
			}
			finally
			{
				refreshingApps = false;
			}
		});
		button2.IsEnabled = !refreshingApps;
		button2.ToolTip = "Refresh installed apps";
		DockPanel.SetDock(button2, Dock.Right);
		dockPanel.Children.Add(button2);
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Width = 250.0;
		textBox.Text = downloadQuery;
		textBox.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		textBox.Margin = new Thickness(0.0, 0.0, 14.0, 0.0);
		System.Windows.Controls.TextBox filter = textBox;
		Grid grid = WithPlaceholder(filter, "Search for an app…");
		DockPanel.SetDock(grid, Dock.Left);
		dockPanel.Children.Add(grid);
		string[] itemsSource = new string[1] { "All categories" }.Concat(from x in (from x in DownloadManager.Catalog()
				where !x.Tool
				select x.Category).Distinct()
			orderby x
			select x).ToArray();
		System.Windows.Controls.ComboBox comboBox = new System.Windows.Controls.ComboBox();
		comboBox.Width = 165.0;
		comboBox.ItemsSource = itemsSource;
		comboBox.SelectedItem = downloadCategory;
		comboBox.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
		System.Windows.Controls.ComboBox category = comboBox;
		DockPanel.SetDock(category, Dock.Left);
		dockPanel.Children.Add(category);
		System.Windows.Controls.ComboBox comboBox2 = new System.Windows.Controls.ComboBox();
		comboBox2.Width = 165.0;
		comboBox2.ItemsSource = new string[3] { "All downloads", "Downloaded", "Not downloaded" };
		comboBox2.SelectedItem = downloadStatus;
		comboBox2.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		System.Windows.Controls.ComboBox status = comboBox2;
		dockPanel.Children.Add(status);
		content.Children.Add(dockPanel);
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			Content = "Portable only",
			IsChecked = portableOnly,
			Foreground = Text,
			Margin = new Thickness(0.0, 0.0, 0.0, 10.0)
		};
		WrapPanel wrapPanel = new WrapPanel();
		wrapPanel.Children.Add(checkBox);
		System.Windows.Controls.CheckBox checkBox2 = new System.Windows.Controls.CheckBox
		{
			Content = "Hide apps already on this PC",
			IsChecked = settings.HideAvailableDownloads,
			Foreground = Text,
			Margin = new Thickness(22.0, 0.0, 0.0, 10.0),
			ToolTip = "Off by default. Hides apps that are already downloaded or installed so the page only lists what you can still get."
		};
		wrapPanel.Children.Add(checkBox2);
		content.Children.Add(wrapPanel);
		content.Children.Add(Label("Files are saved in Downloads beside AZIZ · no shortcut is created unless you press Shortcut.", 11.0, Muted));
		content.Children.Add(Spacer(12));
		StackPanel gallery = Stack();
		content.Children.Add(gallery);
		Action draw = delegate
		{
			gallery.Children.Clear();
			downloadViews.Clear();
			List<DownloadItem> list = (from x in DownloadManager.Catalog()
				where !x.Tool && string.IsNullOrEmpty(x.BundledPath) && (downloadCategory == "All categories" || x.Category == downloadCategory) && (!portableOnly || x.Portable) && (x.Name + " " + x.Description).IndexOf(downloadQuery, StringComparison.OrdinalIgnoreCase) >= 0
				select x).ToList();
			Func<DownloadItem, bool> complete = Available;
			if (settings.HideAvailableDownloads)
			{
				list = list.Where((DownloadItem x) => !complete(x)).ToList();
			}
			if (downloadStatus == "Downloaded")
			{
				list = list.Where(complete).ToList();
			}
			if (downloadStatus == "Not downloaded")
			{
				list = list.Where((DownloadItem x) => !complete(x)).ToList();
			}
			List<DownloadItem> list2 = (from x in list.Where(complete)
				orderby x.Name
				select x).ToList();
			if (list2.Count > 0)
			{
				AddDownloadGroup(gallery, "Available · " + list2.Count, list2);
			}
			foreach (IGrouping<string, DownloadItem> item in from x in list
				where !complete(x)
				group x by x.Category)
			{
				AddDownloadGroup(gallery, item.Key, item.ToList());
			}
			if (list.Count == 0)
			{
				gallery.Children.Add(Card(Label("No apps match these filters.", 14.0, Muted)));
			}
		};
		checkBox2.Checked += delegate
		{
			settings.HideAvailableDownloads = true;
			SaveSettings();
			draw();
		};
		checkBox2.Unchecked += delegate
		{
			settings.HideAvailableDownloads = false;
			SaveSettings();
			draw();
		};
		category.SelectionChanged += delegate
		{
			downloadCategory = Convert.ToString(category.SelectedItem);
			draw();
		};
		status.SelectionChanged += delegate
		{
			downloadStatus = Convert.ToString(status.SelectedItem);
			draw();
		};
		filter.TextChanged += delegate
		{
			downloadQuery = filter.Text;
			draw();
		};
		checkBox.Checked += delegate
		{
			portableOnly = true;
			draw();
		};
		checkBox.Unchecked += delegate
		{
			portableOnly = false;
			draw();
		};
		draw();
	}

	private void AddDownloadGroup(StackPanel gallery, string title, List<DownloadItem> items)
	{
		TextBlock textBlock = Label(title, 14.0, Purple);
		textBlock.Margin = new Thickness(0.0, 12.0, 0.0, 10.0);
		gallery.Children.Add(textBlock);
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 3
		};
		foreach (DownloadItem item in items)
		{
			StackPanel stackPanel = Stack();
			Grid grid = new Grid
			{
				Height = 62.0
			};
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = new GridLength(39.0)
			});
			grid.ColumnDefinitions.Add(new ColumnDefinition());
			grid.Children.Add(new Border
			{
				Width = 30.0,
				Height = 34.0,
				VerticalAlignment = VerticalAlignment.Top,
				CornerRadius = new CornerRadius(7.0),
				Background = B("#233149"),
				Child = new TextBlock
				{
					Text = (item.Portable ? "◈" : "↓"),
					Foreground = Cyan,
					FontSize = 23.0,
					HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center
				}
			});
			StackPanel stackPanel2 = Stack();
			TextBlock textBlock2 = Label(item.Name.Replace(" · Portable", "").Replace(" · Installer", ""), 13.0, Text);
			textBlock2.FontWeight = FontWeights.SemiBold;
			textBlock2.TextWrapping = TextWrapping.NoWrap;
			textBlock2.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock2.ToolTip = item.Name;
			stackPanel2.Children.Add(textBlock2);
			stackPanel2.Children.Add(Label((item.Builtin != null) ? "Built into Windows" : ((item.Winget != null) ? "Windows package · no Store" : (item.Portable ? "Portable" : "Installer")), 10.0, Purple));
			TextBlock textBlock3 = Label(item.Description, 10.0, Muted);
			textBlock3.MaxHeight = 28.0;
			textBlock3.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
			textBlock3.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock3.ToolTip = item.Description + "\nPublisher: " + item.Publisher;
			stackPanel2.Children.Add(textBlock3);
			Grid.SetColumn(stackPanel2, 1);
			grid.Children.Add(stackPanel2);
			stackPanel.Children.Add(grid);
			System.Windows.Controls.ProgressBar progress = new System.Windows.Controls.ProgressBar
			{
				Minimum = 0.0,
				Maximum = 100.0,
				Height = 4.0,
				Margin = new Thickness(0.0, 8.0, 0.0, 0.0),
				Foreground = Accent,
				Visibility = Visibility.Collapsed
			};
			stackPanel.Children.Add(progress);
			TextBlock detail = Label("", 10.0, Muted);
			detail.Visibility = Visibility.Collapsed;
			detail.Margin = new Thickness(0.0, 7.0, 0.0, 0.0);
			stackPanel.Children.Add(detail);
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
			};
			System.Windows.Controls.Button action = Btn("Download", delegate
			{
			});
			action.Padding = new Thickness(10.0, 5.0, 10.0, 5.0);
			action.FontSize = 11.0;
			wrapPanel.Children.Add(action);
			System.Windows.Controls.Button show = Btn("↗", delegate
			{
			});
			show.ToolTip = "Show downloaded file";
			show.Padding = new Thickness(8.0, 5.0, 8.0, 5.0);
			show.Visibility = Visibility.Collapsed;
			wrapPanel.Children.Add(show);
			System.Windows.Controls.Button again = Btn("↓", delegate
			{
			});
			again.ToolTip = "Download again";
			again.Padding = new Thickness(8.0, 5.0, 8.0, 5.0);
			again.Visibility = Visibility.Collapsed;
			wrapPanel.Children.Add(again);
			if (installedLaunchers.Any((LaunchEntry x) => x.CatalogId == item.Id))
			{
				wrapPanel.Children.Add(Btn("Shortcut", delegate
				{
					if (!preview)
					{
						try
						{
							AppLauncher.Shortcut(Installed(item));
						}
						catch (Exception ex6)
						{
							Say(ex6.Message);
						}
					}
				}));
			}
			if (item.Id == "cru")
			{
				wrapPanel.Children.Add(Btn("restart64", delegate
				{
					RestartCru();
				}));
			}
			stackPanel.Children.Add(wrapPanel);
			Border border = Card(stackPanel);
			border.Padding = new Thickness(14.0);
			border.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
			border.CornerRadius = new CornerRadius(10.0);
			uniformGrid.Children.Add(border);
			DownloadJob job = downloads.LastOrDefault((DownloadJob x) => x.Item.Id == item.Id && x.Running) ?? downloads.LastOrDefault((DownloadJob x) => x.Item.Id == item.Id && x.State == "Completed" && File.Exists(x.FilePath)) ?? downloads.LastOrDefault((DownloadJob x) => x.Item.Id == item.Id);
			if (item.Builtin != null || item.Winget != null)
			{
				SpecialDownload(item, wrapPanel, action, detail);
				continue;
			}
			LaunchEntry installed = Installed(item);
			Action update = delegate
			{
				if (job == null)
				{
					action.Content = ((installed != null) ? "Open" : "Download");
					action.Background = ((installed != null) ? BrandBrush() : BrandBrush());
					detail.Visibility = (Visibility)((installed == null) ? 2u : 0u);
					detail.Text = ((installed != null) ? "Installed in Windows" : "");
				}
				else
				{
					bool flag = job.State == "Completed" && File.Exists(job.FilePath);
					action.Content = (job.Running ? "Cancel" : ((installed != null || flag) ? "Open" : "Download"));
					action.Background = ((installed != null || flag) ? BrandBrush() : BrandBrush());
					progress.Visibility = (Visibility)((!job.Running) ? 2u : 0u);
					detail.Visibility = Visibility.Visible;
					progress.IsIndeterminate = job.Running && !job.Total.HasValue;
					progress.Value = ((job.Total.HasValue && job.Total > 0) ? ((double)job.Bytes * 100.0 / (double)job.Total.Value) : ((double)(flag ? 100 : 0)));
					detail.Text = (flag ? ("Downloaded · " + ((double)job.Bytes / 1048576.0).ToString("0.0") + " MB") : (job.State + ((job.State == "Downloading") ? (" · " + ((job.Total > 0) ? (progress.Value.ToString("0") + "% · ") : "") + ((double)job.Bytes / 1048576.0).ToString("0.0") + " MB · " + (job.Speed / 1048576.0).ToString("0.00") + " MB/s") : "") + ((job.Error == null) ? "" : (" · " + job.Error))));
					detail.ToolTip = ((job.Hash == null) ? job.Error : ("SHA-256: " + job.Hash));
					System.Windows.Controls.Button button = show;
					System.Windows.Controls.Button button2 = again;
					int num = ((!flag) ? 2 : 0);
					Visibility visibility = (Visibility)num;
					button2.Visibility = (Visibility)num;
					button.Visibility = visibility;
				}
			};
			if (job != null)
			{
				downloadViews[job] = update;
			}
			update();
			Func<Task> start = async delegate
			{
				if (!preview)
				{
					if (job != null)
					{
						downloadViews.Remove(job);
					}
					job = new DownloadJob
					{
						Item = item
					};
					downloads.Add(job);
					downloadViews[job] = update;
					downloadTimer.Start();
					await DownloadManager.Run(job, delegate
					{
					});
					if (job.State == "Completed")
					{
						DownloadLibrary.Remember(job);
						if (item.Portable)
						{
							try
							{
								string text2 = await Task.Run(() => DownloadLibrary.Prepare(job));
								if (AppLauncher.ValidExe(text2))
								{
									LaunchEntry entry = AppLauncher.Portable(job, text2);
									await Task.Run(delegate
									{
										AppLauncher.RememberManual(entry);
									});
									installedLaunchers.RemoveAll((LaunchEntry x) => x.CatalogId == item.Id);
									installedLaunchers.Add(entry);
								}
							}
							catch (Exception ex3)
							{
								job.Error = "Downloaded; portable preparation: " + ex3.Message;
							}
						}
						else if (File.Exists(job.FilePath))
						{
							detail.Visibility = Visibility.Visible;
							detail.Text = "Installing " + item.Name.Replace(" · Installer", "") + "…";
							string setup = job.FilePath;
							bool archived = InstallerRun.IsArchive(setup);
							if (archived)
							{
								detail.Text = "Extracting the installer…";
								try
								{
									setup = await Task.Run(delegate
									{
										string text4 = DownloadLibrary.Prepare(job);
										if (Directory.Exists(text4))
										{
											text4 = (from x in Directory.GetFiles(text4, "*.exe", SearchOption.AllDirectories).Concat(Directory.GetFiles(text4, "*.msi", SearchOption.AllDirectories))
												orderby (System.IO.Path.GetFileName(x).IndexOf("setup", StringComparison.OrdinalIgnoreCase) < 0 && System.IO.Path.GetFileName(x).IndexOf("install", StringComparison.OrdinalIgnoreCase) < 0) ? 1 : 0, x.Length
												select x).FirstOrDefault() ?? text4;
										}
										return text4;
									});
								}
								catch (Exception ex4)
								{
									job.Error = "Extract: " + ex4.Message;
								}
								detail.Text = "Opening the installer · follow its steps (Agree, Next…)";
							}
							string setupFile = setup;
							ActionResult actionResult = ((File.Exists(setupFile) && (setupFile.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) || setupFile.EndsWith(".msi", StringComparison.OrdinalIgnoreCase))) ? (await Task.Run(() => InstallerRun.Run(setupFile, archived))) : new ActionResult
							{
								Message = "No installer was found in the download."
							});
							ActionResult installedResult = actionResult;
							await RefreshLaunchers();
							installed = Installed(item);
							string text3 = ((installed == null) ? AppLauncher.FindInstalled(item) : null);
							try
							{
								if (installed != null)
								{
									AppLauncher.Open(installed);
								}
								else if (text3 != null)
								{
									Process.Start(new ProcessStartInfo(text3)
									{
										UseShellExecute = true,
										WorkingDirectory = System.IO.Path.GetDirectoryName(text3)
									});
								}
								else if (!installedResult.Success)
								{
									job.Error = installedResult.Message;
								}
								else
								{
									job.Error = installedResult.Message + " Open it from Start.";
								}
							}
							catch (Exception ex5)
							{
								job.Error = ex5.Message;
							}
						}
					}
					if (!downloads.Any((DownloadJob x) => x.Running))
					{
						downloadTimer.Stop();
					}
					update();
					Record(item.Name, "Download", "Requested", job.State, new ActionResult
					{
						Success = (job.State == "Completed"),
						Message = (job.Error ?? ("Saved: " + job.FilePath + " SHA256: " + job.Hash))
					});
					if (current == "Downloads")
					{
						RenderDownloads();
					}
				}
			};
			action.Click += async delegate
			{
				if (!preview)
				{
					if (job != null && job.Running)
					{
						job.Cancel.Cancel();
					}
					else
					{
						if (installed != null)
						{
							try
							{
								AppLauncher.Open(installed);
								return;
							}
							catch (Exception ex)
							{
								Say(ex.Message);
								return;
							}
						}
						if (job == null || !(job.State == "Completed") || !File.Exists(job.FilePath))
						{
							await start();
						}
						else if (!preparingDownload)
						{
							preparingDownload = true;
							action.Content = "Preparing…";
							try
							{
								_ = 1;
								try
								{
									string text = await Task.Run(() => DownloadLibrary.Prepare(job));
									if (!job.Item.Portable && File.Exists(text) && Program.IsAdmin && SilentSetup.Arguments(text) != null && SilentSetup.Signed(text))
									{
										// A real install: silent, no terms, no folder, no Next.
										action.Content = "Installing…";
										ActionResult installed2 = await Task.Run(() => SilentSetup.Run(text));
										Record(job.Item.Name, "Install", "Downloaded setup", installed2.Success ? "Installed" : "Failed", installed2);
										notice.Text = job.Item.Name + ": " + installed2.Message;
										await RefreshLaunchers();
										return;
									}
									string arguments = ((job.Item.Portable && (job.Item.Id == "brave" || job.Item.Id == "helium") && File.Exists(text)) ? ("--user-data-dir=\"" + System.IO.Path.Combine(System.IO.Path.GetDirectoryName(text), "UserData") + "\"") : "");
									if (arguments.Length == 0 && File.Exists(text))
									{
										// Unsigned or unknown setups open with normal user rights; Windows asks if they need more.
										Process.Start(Utilities.Explorer, "\"" + text + "\"");
									}
									else
									{
										Process.Start(new ProcessStartInfo(text, arguments)
										{
											UseShellExecute = true,
											WorkingDirectory = (Directory.Exists(text) ? text : System.IO.Path.GetDirectoryName(text))
										});
									}
								}
								catch (Exception ex2)
								{
									Say(ex2.Message, "Open download");
								}
							}
							finally
							{
								preparingDownload = false;
								update();
							}
						}
					}
				}
			};
			again.Click += async delegate
			{
				await start();
			};
			show.Click += delegate
			{
				if (!preview && job != null && File.Exists(job.FilePath))
				{
					Process.Start(Utilities.Explorer, "/select,\"" + job.FilePath + "\"");
				}
			};
		}
		gallery.Children.Add(uniformGrid);
	}

	private static bool InsideButton(DependencyObject child)
	{
		while (child != null)
		{
			if (child is System.Windows.Controls.Primitives.ButtonBase)
			{
				return true;
			}
			child = ((child is Visual) ? VisualTreeHelper.GetParent(child) : LogicalTreeHelper.GetParent(child));
		}
		return false;
	}

	private FrameworkElement DriverTitle(string title, string glyph, string color)
	{
		StackPanel obj = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			Children = { (UIElement)ToolBadge(glyph, color, 34.0) }
		};
		TextBlock textBlock = Label(title, 19.0, Text);
		textBlock.FontWeight = FontWeights.SemiBold;
		textBlock.VerticalAlignment = VerticalAlignment.Center;
		textBlock.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
		obj.Children.Add(textBlock);
		return obj;
	}

	private static Border ToolBadge(string glyph, string color, double size)
	{
		System.Windows.Media.Color color2 = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(color);
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush(System.Windows.Media.Color.FromArgb(byte.MaxValue, color2.R, color2.G, color2.B), System.Windows.Media.Color.FromArgb(byte.MaxValue, (byte)((double)(int)color2.R * 0.55), (byte)((double)(int)color2.G * 0.55), (byte)((double)(int)color2.B * 0.55)), 45.0);
		linearGradientBrush.Freeze();
		return new Border
		{
			Width = size,
			Height = size,
			CornerRadius = new CornerRadius(size * 0.26),
			Background = linearGradientBrush,
			Child = new TextBlock
			{
				Text = glyph,
				FontFamily = new System.Windows.Media.FontFamily("Segoe Fluent Icons, Segoe MDL2 Assets"),
				FontSize = size * 0.5,
				Foreground = System.Windows.Media.Brushes.White,
				HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center
			}
		};
	}

	// AMD's driver page for this exact card (Radeon RX 5000 / 6000 / 7000 / 9000), else AMD's driver search page.
	internal static string AmdDriverPage(string name)
	{
		const string fallback = "https://www.amd.com/en/support/download/drivers.html";
		if (string.IsNullOrEmpty(name))
		{
			return fallback;
		}
		Match match = Regex.Match(name, "RX\\s*(\\d)(\\d{3})\\s*(XTX|XT|GRE)?", RegexOptions.IgnoreCase);
		if (!match.Success)
		{
			return fallback;
		}
		string series = match.Groups[1].Value + "000";
		string model = match.Groups[1].Value + match.Groups[2].Value + (match.Groups[3].Success ? ("-" + match.Groups[3].Value.ToLowerInvariant()) : "");
		return "https://www.amd.com/en/support/downloads/drivers.html/graphics/radeon-rx/radeon-rx-" + series + "-series/amd-radeon-rx-" + model + ".html";
	}

	private void AddReflexCard()
	{
		DockPanel dockPanel = new DockPanel();
		System.Windows.Controls.Button button = BrandBtn("Reflex Fallback", ShowReflexFallback, primary: true);
		button.VerticalAlignment = VerticalAlignment.Center;
		DockPanel.SetDock(button, Dock.Right);
		dockPanel.Children.Add(button);
		StackPanel stackPanel = Stack();
		TextBlock textBlock = Label("NVIDIA Reflex Fallback", 17.0, Text);
		textBlock.FontWeight = FontWeights.SemiBold;
		stackPanel.Children.Add(textBlock);
		stackPanel.Children.Add(Label("NVIDIA Reflex low latency and a smooth FPS limiter for older games without Reflex. Turn it on per game; the limiter icon by the clock changes the limit even with AZIZ closed.", 11.0, Muted));
		dockPanel.Children.Add(stackPanel);
		Border border = Card(dockPanel);
		border.Padding = new Thickness(16.0);
		border.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		content.Children.Add(border);
	}

	private static Task<ActionResult> reflexReady;

	// Blue slider for the Reflex limiter: filled part blue, round thumb, moves pixel by pixel (no snapping).
	private static System.Windows.Controls.Slider BlueSlider(double max)
	{
		System.Windows.Controls.Slider slider = new System.Windows.Controls.Slider
		{
			Minimum = 0.0,
			Maximum = max,
			SmallChange = 1.0,
			LargeChange = 10.0,
			IsMoveToPointEnabled = true,
			IsSnapToTickEnabled = false,
			VerticalAlignment = VerticalAlignment.Center,
			Cursor = System.Windows.Input.Cursors.Hand
		};
		slider.Style = (Style)XamlReader.Parse("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='Slider'><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Slider'><Grid Height='22' Background='Transparent'><Border Height='6' CornerRadius='3' Background='#23264A' VerticalAlignment='Center'/><Track x:Name='PART_Track' VerticalAlignment='Center'><Track.DecreaseRepeatButton><RepeatButton Command='Slider.DecreaseLarge' Focusable='False'><RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Height='6' CornerRadius='3'><Border.Background><LinearGradientBrush StartPoint='0,0' EndPoint='1,0'><GradientStop Color='#1B4FD6' Offset='0'/><GradientStop Color='#2F8CFF' Offset='0.7'/><GradientStop Color='#7FD0FF' Offset='1'/></LinearGradientBrush></Border.Background></Border></ControlTemplate></RepeatButton.Template></RepeatButton></Track.DecreaseRepeatButton><Track.IncreaseRepeatButton><RepeatButton Command='Slider.IncreaseLarge' Focusable='False'><RepeatButton.Template><ControlTemplate TargetType='RepeatButton'><Border Background='Transparent'/></ControlTemplate></RepeatButton.Template></RepeatButton></Track.IncreaseRepeatButton><Track.Thumb><Thumb Width='18' Height='18'><Thumb.Template><ControlTemplate TargetType='Thumb'><Ellipse Fill='White'><Ellipse.Effect><DropShadowEffect Color='#2F8CFF' BlurRadius='12' ShadowDepth='0' Opacity='0.9'/></Ellipse.Effect></Ellipse></ControlTemplate></Thumb.Template></Thumb></Track.Thumb></Track></Grid></ControlTemplate></Setter.Value></Setter></Style>");
		return slider;
	}

	private static System.Windows.Media.Brush ReflexOnBrush()
	{
		return new LinearGradientBrush(System.Windows.Media.Color.FromRgb(47, 140, 255), System.Windows.Media.Color.FromRgb(27, 79, 214), 90.0);
	}

	// Opening the page gets the limiter engine ready in the background (silent, hidden), so ON is instant.
	private static Task<ActionResult> ReflexReady()
	{
		if (reflexReady == null || (reflexReady.IsCompleted && !reflexReady.Result.Success))
		{
			reflexReady = Task.Run(() => ReflexFallback.InstallRtss());
		}
		return reflexReady;
	}

	private void ShowReflexFallback()
	{
		if (preview)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		// RivaTuner is prepared silently while the page is open, but never by closing a running MSI Afterburner just for
		// looking: then it waits for the first ON.
		if (System.Diagnostics.Process.GetProcessesByName("MSIAfterburner").Length == 0)
		{
			ReflexReady();
		}
		ShowSheet(delegate(StackPanel p, Action close)
		{
			TextBlock title = Label("Reflex Fallback", 24.0, System.Windows.Media.Brushes.White);
			title.FontWeight = FontWeights.SemiBold;
			p.Children.Add(title);
			p.Children.Add(Label("NVIDIA Reflex low latency and a smooth FPS limiter for games without Reflex. Turn it on per game; it works right away, even while the game is running. Games that already have NVIDIA Reflex are marked. 0 = no FPS cap.", 12.0, Muted));
			// FPS counter: off unless the user turns it on (same switch as in the limiter panel by the clock).
			System.Windows.Controls.CheckBox counter = new System.Windows.Controls.CheckBox
			{
				Content = "FPS counter in the game (never on DirectX 11 games)",
				IsChecked = ReflexFallback.Counter,
				Foreground = Muted,
				Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
			};
			p.Children.Add(counter);
			TextBlock status = Label("", 11.0, Muted);
			status.Margin = new Thickness(0.0, 8.0, 0.0, 8.0);
			p.Children.Add(status);
			counter.Click += async delegate
			{
				bool want = counter.IsChecked == true;
				await Task.Run(delegate
				{
					ReflexFallback.SetCounter(want);
				});
				status.Text = (want ? "FPS counter on." : "FPS counter off.");
			};
			Dictionary<string, int> saved = ReflexFallback.Games();
			List<GameEntry> list = (games ?? new List<GameEntry>()).Where((GameEntry g) => AppLauncher.ValidExe(g.Exe)).GroupBy((GameEntry g) => g.Exe, StringComparer.OrdinalIgnoreCase).Select((IGrouping<string, GameEntry> g) => g.First()).OrderBy((GameEntry g) => g.Name).ToList();
			if (list.Count == 0)
			{
				p.Children.Add(Label("No games found yet. Open Home once so AZIZ can scan your launchers, then come back.", 12.0, Muted));
			}
			foreach (GameEntry g in list)
			{
				string exe = g.Exe;
				bool on = saved.ContainsKey(exe);
				int start = (saved.TryGetValue(exe, out var value) ? Math.Max(0, Math.Min(360, value)) : 237);
				Grid row = new Grid();
				row.ColumnDefinitions.Add(new ColumnDefinition());
				row.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(250.0)
				});
				row.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(54.0)
				});
				row.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = GridLength.Auto
				});
				StackPanel name = Stack();
				name.VerticalAlignment = VerticalAlignment.Center;
				name.Children.Add(Label(g.Name, 13.0, Text));
				TextBlock detail = Label(on ? ("Reflex on · " + start + " FPS") : g.Library, 10.0, Muted);
				name.Children.Add(detail);
				row.Children.Add(name);
				System.Windows.Controls.Slider slider = BlueSlider(360.0);
				slider.Value = start;
				slider.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
				Grid.SetColumn(slider, 1);
				row.Children.Add(slider);
				// The limit can be dragged or typed: this box takes a number straight (0–360, Enter to apply).
				System.Windows.Controls.TextBox number = new System.Windows.Controls.TextBox
				{
					Text = start.ToString(),
					FontSize = 15.0,
					FontWeight = FontWeights.SemiBold,
					Foreground = System.Windows.Media.Brushes.White,
					Background = B("#141A30"),
					CaretBrush = System.Windows.Media.Brushes.White,
					BorderThickness = new Thickness(1.0),
					BorderBrush = B("#2A3152"),
					TextAlignment = TextAlignment.Center,
					VerticalContentAlignment = VerticalAlignment.Center,
					VerticalAlignment = VerticalAlignment.Center,
					MaxLength = 3,
					Padding = new Thickness(0.0, 3.0, 0.0, 3.0),
					Margin = new Thickness(0.0, 0.0, 10.0, 0.0),
					ToolTip = "Type an FPS limit from 0 to 360, then press Enter. 0 = no cap."
				};
				Grid.SetColumn(number, 2);
				row.Children.Add(number);
				// Digits only, so the box never holds anything that is not a number.
				number.PreviewTextInput += delegate(object nts, System.Windows.Input.TextCompositionEventArgs nte)
				{
					foreach (char c in nte.Text)
					{
						if (!char.IsDigit(c))
						{
							nte.Handled = true;
							break;
						}
					}
				};
				System.Windows.DataObject.AddPastingHandler(number, delegate(object pts, System.Windows.DataObjectPastingEventArgs pte)
				{
					if (!pte.DataObject.GetDataPresent(typeof(string)))
					{
						pte.CancelCommand();
						return;
					}
					foreach (char c in (string)pte.DataObject.GetData(typeof(string)))
					{
						if (!char.IsDigit(c))
						{
							pte.CancelCommand();
							break;
						}
					}
				});
				System.Windows.Controls.Button toggle = Btn("", delegate
				{
				});
				toggle.MinWidth = 150.0;
				Grid.SetColumn(toggle, 3);
				row.Children.Add(toggle);
				int applied = start;
				Action paint = delegate
				{
					toggle.Content = (on ? "NVIDIA Reflex ON" : "NVIDIA Reflex OFF");
					toggle.Background = (on ? ReflexOnBrush() : B("#1D2236"));
					toggle.Foreground = (on ? System.Windows.Media.Brushes.White : B("#6C7390"));
					toggle.FontWeight = (on ? FontWeights.SemiBold : FontWeights.Normal);
					slider.Opacity = (on ? 1.0 : 0.45);
					number.Opacity = slider.Opacity;
				};
				paint();
				// The limit follows the slider live; it is written once the hand stops moving (no flood of writes while dragging).
				DispatcherTimer settle = new DispatcherTimer
				{
					Interval = TimeSpan.FromMilliseconds(350.0)
				};
				settle.Tick += async delegate
				{
					settle.Stop();
					int fps = (int)Math.Round(slider.Value);
					if (!on || fps == applied)
					{
						return;
					}
					applied = fps;
					ActionResult r = await Task.Run(() => ReflexFallback.Apply(exe, fps));
					Record("Reflex Fallback · " + g.Name, "Limit", "", r.Success ? (fps + " FPS") : "Failed", r);
					status.Text = r.Message;
					if (r.Success)
					{
						detail.Text = "Reflex on · " + fps + " FPS";
					}
				};
				slider.ValueChanged += delegate
				{
					int shown = (int)Math.Round(slider.Value);
					string want = ((shown > 0 && shown < 20) ? 20 : shown).ToString();
					// Leave the box alone while the user is typing in it; just mirror the slider otherwise.
					if (!number.IsKeyboardFocused && number.Text != want)
					{
						number.Text = want;
					}
					settle.Stop();
					settle.Start();
				};
				// A typed number drives the same slider: clamp to 0–360, snap the slider, and the limit follows.
				Action commitTyped = delegate
				{
					int typed;
					if (!int.TryParse(number.Text, out typed))
					{
						typed = (int)Math.Round(slider.Value);
					}
					typed = Math.Max(0, Math.Min(360, typed));
					number.Text = typed.ToString();
					if (Math.Abs(slider.Value - typed) >= 0.5)
					{
						slider.Value = typed;
					}
					else
					{
						settle.Stop();
						settle.Start();
					}
				};
				number.KeyDown += delegate(object kts, System.Windows.Input.KeyEventArgs kte)
				{
					if (kte.Key == System.Windows.Input.Key.Enter)
					{
						commitTyped();
						Keyboard.ClearFocus();
						kte.Handled = true;
					}
				};
				number.LostKeyboardFocus += delegate
				{
					commitTyped();
				};
				number.GotKeyboardFocus += delegate
				{
					number.SelectAll();
				};
				toggle.Click += async delegate
				{
					toggle.IsEnabled = false;
					try
					{
						int fps = (int)Math.Round(slider.Value);
						if (!on)
						{
							status.Text = "Turning NVIDIA Reflex on for " + g.Name + "…";
							await BackupFirst();
							ActionResult ready = await ReflexReady();
							ActionResult r = ready.Success ? (await Task.Run(() => ReflexFallback.Apply(exe, fps))) : ready;
							if (r.Success && !ReflexFallback.TrayRunning())
							{
								await Task.Run(() => ReflexFallback.InstallTray());
							}
							Record("Reflex Fallback · " + g.Name, "On", "", r.Success ? (fps + " FPS") : "Failed", r);
							status.Text = r.Message;
							on = r.Success;
							applied = fps;
						}
						else
						{
							ActionResult r = await Task.Run(() => ReflexFallback.Remove(exe));
							Record("Reflex Fallback · " + g.Name, "Off", "", r.Success ? "Removed" : "Failed", r);
							status.Text = r.Message;
							on = !r.Success;
						}
						detail.Text = (on ? ("Reflex on · " + fps + " FPS") : g.Library);
						paint();
					}
					finally
					{
						toggle.IsEnabled = true;
					}
				};
				// Looking for Reflex DLLs walks the game folder: off the UI thread, the row updates when it is done.
				if (!on)
				{
					Task.Run(() => ReflexFallback.HasReflex(exe)).ContinueWith(delegate(Task<bool> t)
					{
						if (t.Result && !on)
						{
							detail.Text = "Has NVIDIA Reflex · not needed";
							detail.Foreground = B("#7EE2A8");
							toggle.Visibility = Visibility.Collapsed;
							slider.Visibility = Visibility.Collapsed;
							number.Visibility = Visibility.Collapsed;
						}
					}, TaskScheduler.FromCurrentSynchronizationContext());
				}
				p.Children.Add(new Border
				{
					Background = B("#141A30"),
					CornerRadius = new CornerRadius(10.0),
					Padding = new Thickness(12.0, 10.0, 12.0, 10.0),
					Margin = new Thickness(0.0, 0.0, 0.0, 6.0),
					Child = row
				});
			}
			System.Windows.Controls.Button done = Btn("Done", close);
			done.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
			done.Margin = new Thickness(0.0, 10.0, 0.0, 0.0);
			p.Children.Add(done);
		}, 860.0);
	}

	private void AddDriverHeader()
	{
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 3
		};
		StackPanel stackPanel = Stack();
		DockPanel dockPanel = new DockPanel();
		stackPanel.Children.Add(dockPanel);
		stackPanel.Children.Add(Label("Click the card for current and archived Game Ready drivers for your GPU", 11.0, Muted));
		TextBlock status = Label("", 11.0, Muted);
		// One row: Clean Install · Profile · Per game (compact, never wraps under each other).
		StackPanel wrapPanel = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			Margin = new Thickness(0.0, 10.0, 0.0, 4.0)
		};
		System.Windows.Controls.Button clean = Btn("Clean Install", delegate
		{
		});
		clean.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
		clean.Padding = new Thickness(9.0, 5.0, 9.0, 5.0);
		clean.FontSize = 12.0;
		clean.ToolTip = "NVCleanstall · build a clean driver without telemetry. No shortcut is created.";
		clean.Click += async delegate
		{
			await OpenTool(DownloadManager.Catalog().First((DownloadItem x) => x.Id == "nvcleanstall"), clean, status);
		};
		wrapPanel.Children.Add(clean);
		System.Windows.Controls.Button button = Btn("Profile", ShowNvidiaProfile);
		button.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
		button.Padding = new Thickness(9.0, 5.0, 9.0, 5.0);
		button.FontSize = 12.0;
		button.ToolTip = "Profile Inspector · first open imports AZIZ Ultra Low Latency";
		wrapPanel.Children.Add(button);
		System.Windows.Controls.Button button2 = Btn("Per game", ShowProfilePerGame);
		button2.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
		button2.Padding = new Thickness(9.0, 5.0, 9.0, 5.0);
		button2.FontSize = 12.0;
		button2.ToolTip = "Open the NVIDIA profile of a game found on this PC";
		wrapPanel.Children.Add(button2);
		System.Windows.Controls.Button p0 = Btn("P0", delegate
		{
		});
		p0.Padding = new Thickness(12.0, 5.0, 12.0, 5.0);
		p0.Margin = new Thickness(0.0, 0.0, 8.0, 6.0);
		p0.VerticalAlignment = VerticalAlignment.Center;
		p0.BorderThickness = new Thickness(1.0);
		Action paintP0 = delegate
		{
			TweakStatus tweakStatus = NvidiaP0.State();
			bool flag = tweakStatus.State == "Enabled";
			TextBlock textBlock = new TextBlock
			{
				VerticalAlignment = VerticalAlignment.Center
			};
			InlineCollection inlines = textBlock.Inlines;
			Run run = new Run("● ")
			{
				Foreground = (flag ? B("#FCA5A5") : B("#64748B"))
			};
			((TextElementCollection<Inline>)inlines).Add(run);
			InlineCollection inlines2 = textBlock.Inlines;
			Run run2 = new Run("P0")
			{
				FontWeight = FontWeights.Bold
			};
			((TextElementCollection<Inline>)inlines2).Add(run2);
			InlineCollection inlines3 = textBlock.Inlines;
			Run run3 = new Run(flag ? "  ON" : "  OFF")
			{
				FontSize = 10.0,
				Foreground = (flag ? System.Windows.Media.Brushes.White : Muted)
			};
			((TextElementCollection<Inline>)inlines3).Add(run3);
			p0.Content = textBlock;
			p0.Background = ((!flag) ? B("#1A2436") : new LinearGradientBrush(System.Windows.Media.Color.FromRgb(239, 68, 68), System.Windows.Media.Color.FromRgb(153, 27, 27), 45.0));
			p0.BorderBrush = (flag ? B("#F87171") : B("#334155"));
			p0.Foreground = (flag ? System.Windows.Media.Brushes.White : Text);
			p0.ToolTip = (flag ? "P0 on · maximum performance locked · " : "P0 off · click to lock maximum performance · ") + tweakStatus.Detail;
			p0.IsEnabled = tweakStatus.State != "Unavailable";
		};
		paintP0();
		p0.Click += async delegate
		{
			if (!preview)
			{
				if (!Program.IsAdmin)
				{
					Say("Run AZIZ as administrator first.");
				}
				else
				{
					bool target = NvidiaP0.State().State != "Enabled";
					p0.IsEnabled = false;
					status.Text = (target ? "Locking maximum performance (P0)…" : "Returning to dynamic P-states…");
					ActionResult actionResult = await Task.Run(() => NvidiaP0.Set(target));
					Record("NVIDIA P0", target ? "Enable" : "Disable", "", target ? "P0" : "Dynamic", actionResult);
					status.Text = actionResult.Message;
					paintP0();
				}
			}
		};
		DockPanel.SetDock(p0, Dock.Right);
		dockPanel.Children.Add(p0);
		dockPanel.Children.Add(DriverTitle("NVIDIA Driver", "\ue7f8", "#76B900"));
		stackPanel.Children.Add(wrapPanel);
		stackPanel.Children.Add(status);
		Border border = Card(stackPanel);
		border.Margin = new Thickness(0.0, 0.0, 10.0, 12.0);
		border.Cursor = System.Windows.Input.Cursors.Hand;
		border.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
		{
			object originalSource = e.OriginalSource;
			if (!InsideButton((DependencyObject)((originalSource is DependencyObject) ? originalSource : null)))
			{
				ShowNvidiaDrivers();
			}
		};
		uniformGrid.Children.Add(border);
		AddBiosCard(uniformGrid);
		// AMD graphics card driver (the chipset comes from the BIOS drivers card now).
		string amdGpu = GpuInterrupt.Devices.Select((GpuDevice d) => d.Name).FirstOrDefault((string n) => n != null && (n.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0 || n.IndexOf("Radeon", StringComparison.OrdinalIgnoreCase) >= 0));
		StackPanel stackPanel2 = Stack();
		stackPanel2.Children.Add(DriverTitle("AMD GPU Driver", "\ue964", "#ED1C24"));
		TextBlock amdStatus = Label((amdGpu != null) ? (amdGpu + " · click for AMD Software: Adrenalin Edition") : "No AMD graphics card found · click for AMD drivers", 11.0, Muted);
		amdStatus.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		stackPanel2.Children.Add(amdStatus);
		Border border2 = Card(stackPanel2);
		border2.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		border2.Cursor = System.Windows.Input.Cursors.Hand;
		border2.ToolTip = "AMD's official driver page for your Radeon card";
		border2.MouseLeftButtonUp += delegate
		{
			try
			{
				Process.Start(new ProcessStartInfo(AmdDriverPage(amdGpu))
				{
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				amdStatus.Text = ex.Message;
			}
		};
		uniformGrid.Children.Add(border2);
		content.Children.Add(uniformGrid);
	}

	private void AddDriverRelease(System.Windows.Controls.Panel rows, NvidiaRelease release)
	{
		DownloadItem item = new DownloadItem
		{
			Id = "nvidia-driver-" + release.Id,
			Name = "Game Ready " + release.Version,
			Publisher = "NVIDIA",
			Category = "Drivers",
			DirectUrl = release.Url,
			FileName = System.IO.Path.GetFileName(new Uri(release.Url).AbsolutePath),
			Parallel = true
		};
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("GeForce Game Ready " + release.Version, 16.0, Text));
		TextBlock status = Label(release.Date + " · " + release.Size, 11.0, Muted);
		stackPanel.Children.Add(status);
		WrapPanel wrapPanel = new WrapPanel();
		// Download: you pick the folder and run it yourself. Install now: AZIZ downloads, checks, extracts and installs
		// silently (no terms, no Next, no restart prompt); the screen may blink once.
		System.Windows.Controls.Button download = Btn("Download…", delegate
		{
		});
		download.Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(118, 185, 0), System.Windows.Media.Color.FromRgb(70, 128, 0), 90.0);
		download.Foreground = System.Windows.Media.Brushes.White;
		download.FontWeight = FontWeights.SemiBold;
		download.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
		System.Windows.Controls.Button install = Btn("Install now", delegate
		{
		}, primary: true);
		System.Windows.Controls.Button cancel = Btn("Cancel download", delegate
		{
		});
		cancel.Visibility = Visibility.Collapsed;
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox();
		checkBox.Content = "Clean installation";
		checkBox.Foreground = Text;
		checkBox.VerticalAlignment = VerticalAlignment.Center;
		checkBox.Margin = new Thickness(8.0);
		System.Windows.Controls.CheckBox clean = checkBox;
		wrapPanel.Children.Add(download);
		wrapPanel.Children.Add(install);
		wrapPanel.Children.Add(clean);
		wrapPanel.Children.Add(cancel);
		stackPanel.Children.Add(wrapPanel);
		DownloadJob job = null;
		bool busy = false;
		cancel.Click += delegate
		{
			if (job != null && job.Running)
			{
				job.Cancel.Cancel();
			}
		};
		Func<bool, Task> run = async delegate(bool immediate)
		{
			if (busy || applying)
			{
				return;
			}
			string destination = null;
			if (immediate)
			{
				if (!Program.IsAdmin)
				{
					Say("Run AZIZ as administrator to install the selected driver.");
					return;
				}
			}
			else
			{
				Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
				{
					Filter = "NVIDIA installer|*.exe",
					FileName = item.FileName,
					InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
					OverwritePrompt = true
				};
				if (saveFileDialog.ShowDialog() != true)
				{
					return;
				}
				destination = saveFileDialog.FileName;
			}
			busy = true;
			System.Windows.Controls.Button button = download;
			System.Windows.Controls.Button button2 = install;
			bool flag2 = (clean.IsEnabled = false);
			bool flag3 = flag2;
			flag2 = (button2.IsEnabled = flag3);
			bool isEnabled = flag2;
			button.IsEnabled = isEnabled;
			try
			{
				if (job == null || job.State != "Completed")
				{
					job = new DownloadJob
					{
						Item = item
					};
					downloads.Add(job);
					cancel.Visibility = Visibility.Visible;
					await DownloadManager.Run(job, delegate
					{
						base.Dispatcher.BeginInvoke((Action)delegate
						{
							status.Text = job.State + " · " + ((job.Total > 0) ? (((double)job.Bytes * 100.0 / (double)job.Total.Value).ToString("0") + "% · ") : "") + (job.Speed / 1048576.0).ToString("0.0") + " MB/s";
						});
					});
					cancel.Visibility = Visibility.Collapsed;
					if (job.State != "Completed")
					{
						throw new IOException(job.Error ?? job.State);
					}
				}
				if (immediate)
				{
					applying = true;
					status.Text = "Verifying, extracting and installing…";
					bool fresh = clean.IsChecked == true;
					await BackupFirst();
					ActionResult actionResult = await Task.Run(() => DriverInstaller.Install(job, fresh));
					Record(item.Name, "Install driver", "Selected package", actionResult.Success ? "Installer completed" : "Failed", actionResult);
					status.Text = actionResult.Message;
					DisplayHardware.Invalidate();
				}
				else
				{
					await Task.Run(delegate
					{
						DownloadLibrary.Verify(job);
						DriverInstaller.VerifyPublisher(job.FilePath, "NVIDIA");
						File.Copy(job.FilePath, destination, overwrite: true);
					});
					status.Text = "Saved: " + destination;
				}
			}
			catch (Exception ex)
			{
				status.Text = ex.Message;
			}
			finally
			{
				busy = false;
				applying = false;
				System.Windows.Controls.Button button3 = download;
				System.Windows.Controls.Button button4 = install;
				flag2 = (clean.IsEnabled = true);
				bool flag6 = flag2;
				flag2 = (button4.IsEnabled = flag6);
				bool isEnabled2 = flag2;
				button3.IsEnabled = isEnabled2;
				cancel.Visibility = Visibility.Collapsed;
			}
		};
		download.Click += async delegate
		{
			await run(arg: false);
		};
		install.Click += async delegate
		{
			await run(arg: true);
		};
		rows.Children.Add(Card(stackPanel));
	}

	private async Task OpenAmdChipset(TextBlock status)
	{
		if (preview || openingTools.Contains("amd-chipset-package"))
		{
			return;
		}
		openingTools.Add("amd-chipset-package");
		try
		{
			status.Text = "Checking for the local package…";
			string file = await Task.Run(() => ChipsetPackage.Find());
			if (file == null)
			{
				DownloadJob job = new DownloadJob
				{
					Item = ChipsetPackage.Item()
				};
				downloads.Add(job);
				await DownloadManager.Run(job, delegate
				{
					base.Dispatcher.BeginInvoke((Action)delegate
					{
						status.Text = "Downloading from AMD · " + ((job.Total > 0) ? (((double)job.Bytes * 100.0 / (double)job.Total.Value).ToString("0") + "% · ") : "") + (job.Speed / 1048576.0).ToString("0.0") + " MB/s";
					});
				});
				if (job.State != "Completed")
				{
					throw new IOException(job.Error ?? job.State);
				}
				DownloadLibrary.Remember(job);
				file = job.FilePath;
			}
			string ready = file;
			status.Text = "Verifying AMD signature…";
			// Checked and started from a copy in AZIZ's admin-only folder (Downloads can be changed by any program).
			ready = await Task.Run(delegate
			{
				string copy = SilentSetup.SecureCopy(ready);
				if (copy == null || Utilities.Sha256File(copy) != "04192323117317d212119d66476fe518d62eab17a6250f0cf5ab1b6c43ae138c")
				{
					throw new IOException("AMD package verification failed.");
				}
				DriverInstaller.VerifyPublisher(copy, "Advanced Micro Devices");
				return copy;
			});
			Process.Start(new ProcessStartInfo(ready)
			{
				UseShellExecute = true,
				Verb = "runas",
				WorkingDirectory = System.IO.Path.GetDirectoryName(ready)
			});
			status.Text = "AMD Chipset Software installer is open · no shortcut created";
			Record("AMD Chipset Driver", "Install", "Local package", "Installer opened", new ActionResult
			{
				Success = true,
				Message = file
			});
		}
		catch (Win32Exception)
		{
			status.Text = "Installation was cancelled";
		}
		catch (Exception ex2)
		{
			status.Text = "Could not install: " + ex2.Message;
		}
		finally
		{
			openingTools.Remove("amd-chipset-package");
		}
	}

	private void AddInstalledGallery(StackPanel gallery)
	{
		if (settings.HideAvailableDownloads || downloadStatus == "Not downloaded" || portableOnly)
		{
			return;
		}
		List<LaunchEntry> list = installedLaunchers.Where((LaunchEntry x) => x.CatalogId == null && (downloadCategory == "All categories" || downloadCategory == x.Category) && (x.Name + " " + x.Category).IndexOf(downloadQuery, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
		if (list.Count == 0)
		{
			return;
		}
		gallery.Children.Add(Label("Installed in Windows · " + list.Count, 14.0, Purple));
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 3
		};
		foreach (LaunchEntry app in list)
		{
			StackPanel stackPanel = Stack();
			DockPanel dockPanel = new DockPanel();
			ImageSource imageSource = AppIcons.Load(app.Icon);
			if (imageSource != null)
			{
				dockPanel.Children.Add(new System.Windows.Controls.Image
				{
					Source = imageSource,
					Width = 28.0,
					Height = 28.0,
					Margin = new Thickness(0.0, 0.0, 10.0, 0.0)
				});
			}
			TextBlock textBlock = Label(app.Name, 13.0, Text);
			textBlock.TextWrapping = TextWrapping.NoWrap;
			textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock.ToolTip = app.Target;
			dockPanel.Children.Add(textBlock);
			stackPanel.Children.Add(dockPanel);
			stackPanel.Children.Add(Label(app.Source, 10.0, Muted));
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
			};
			System.Windows.Controls.Button button = BrandBtn("Open", delegate
			{
				if (!preview)
				{
					try
					{
						AppLauncher.Open(app);
					}
					catch (Exception ex2)
					{
						Say(ex2.Message);
					}
				}
			});
			button.Background = BrandBrush();
			wrapPanel.Children.Add(button);
			wrapPanel.Children.Add(Btn("Shortcut", delegate
			{
				if (!preview)
				{
					try
					{
						AppLauncher.Shortcut(app);
					}
					catch (Exception ex)
					{
						Say(ex.Message);
					}
				}
			}));
			stackPanel.Children.Add(wrapPanel);
			Border border = Card(stackPanel);
			border.Padding = new Thickness(14.0);
			border.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
			uniformGrid.Children.Add(border);
		}
		gallery.Children.Add(uniformGrid);
	}

	private void RestartCru()
	{
		if (preview)
		{
			return;
		}
		LaunchEntry launchEntry = installedLaunchers.FirstOrDefault((LaunchEntry x) => x.CatalogId == "cru");
		if (launchEntry == null)
		{
			Say("Download and extract CRU first, or add its executable to your Windows shortcuts and refresh.");
			return;
		}
		string text = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(launchEntry.Target), "restart64.exe");
		if (!File.Exists(text))
		{
			Say("restart64.exe is missing from this CRU folder.");
		}
		else if (System.Windows.MessageBox.Show("Restart the graphics driver now? The display will go black briefly. Save your work first.", "CRU restart64", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
		{
			Process.Start(new ProcessStartInfo(text)
			{
				UseShellExecute = true,
				WorkingDirectory = System.IO.Path.GetDirectoryName(text)
			});
		}
	}

	private void CustomPriority(Tweak t)
	{
		Window window = new Window();
		window.Owner = this;
		window.Title = "Win32PrioritySeparation · decimal";
		window.Width = 460.0;
		window.Height = 230.0;
		window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window.Background = new SolidColorBrush(Bg);
		window.Foreground = Text;
		Window w = window;
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(22.0);
		stackPanel.Children.Add(Label("Decimal value (0–63)", 17.0, Text));
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Text = "40";
		textBox.Margin = new Thickness(0.0, 12.0, 0.0, 12.0);
		System.Windows.Controls.TextBox input = textBox;
		stackPanel.Children.Add(input);
		stackPanel.Children.Add(Btn("Apply decimal value", async delegate
		{
			if (!int.TryParse(input.Text, out var result) || result < 0 || result > 63)
			{
				Say("Enter a decimal integer from 0 to 63.");
			}
			else
			{
				w.Close();
				await ChangeChoice(t, new TweakChoice
				{
					Value = result.ToString(),
					Label = result + " (decimal)"
				});
			}
		}, primary: true));
		w.Content = stackPanel;
		DarkDialog(w);
		w.ShowDialog();
	}

	private void ClearAllHistory()
	{
		if (preview || applying)
		{
			return;
		}
		try
		{
			string[] array = new string[3] { "history.jsonl", "observations.json", "game-history.jsonl" };
			foreach (string path in array)
			{
				string path2 = System.IO.Path.Combine(Program.Data, path);
				if (File.Exists(path2))
				{
					File.WriteAllText(path2, "");
				}
			}
			observations.Clear();
			cachedHistory.Clear();
			SaveObservations();
			InvalidateViews();
			if (current == "Home")
			{
				RenderOverview();
			}
		}
		catch (Exception ex)
		{
			Say(ex.Message);
		}
	}

	private string ControlTechnicalDetails(Tweak t)
	{
		List<string> list = new List<string> { RecommendationLabel(t) };
		if (t.Kind == "Service")
		{
			list.Add("Registry: HKLM\\SYSTEM\\CurrentControlSet\\Services\\" + t.Service + "\\Start\n2 = Automatic; 3 = Manual; 4 = Disabled. Runtime changes can require restart.");
		}
		string[] array = new string[2] { "Enable", "Disable" };
		foreach (string text in array)
		{
			List<RegistryOperation> list2 = ((text == "Enable") ? t.Enable : t.Disable);
			if (list2 == null)
			{
				continue;
			}
			foreach (RegistryOperation item in list2)
			{
				list.Add(text + ": " + item.Hive + "\\" + item.Path + "\n" + item.Name + (string.IsNullOrEmpty(item.Token) ? "" : (" · token " + item.Token)) + " = " + ((item.Value == null) ? "Delete value (Windows fallback)" : Program.Json.Serialize(item.Value)) + " [" + item.Kind + "]");
			}
		}
		if (t.Kind == "Bcd")
		{
			list.Add("Boot option: " + t.BcdKey + "\nOn: bcdedit /set {current} " + t.BcdKey + " " + t.BcdOnValue + "\nOff: bcdedit /deletevalue {current} " + t.BcdKey);
		}
		if (t.Kind == "Native")
		{
			list.Add("Native configuration (no invented registry equivalent):\nEnable:\n" + t.EnableScript + "\nDisable:\n" + t.DisableScript);
		}
		return string.Join("\n\n", list);
	}

	// Crescent moon (night) or soft sun (day), drawn so it stays sharp.
	private Grid ThemeGlyph(bool night)
	{
		Grid grid = new Grid
		{
			Width = 22.0,
			Height = 22.0,
			Background = System.Windows.Media.Brushes.Transparent,
			Cursor = System.Windows.Input.Cursors.Hand,
			VerticalAlignment = VerticalAlignment.Center,
			ToolTip = (night ? "Switch to day mode" : "Switch to night mode")
		};
		if (night)
		{
			Geometry moon = new CombinedGeometry(GeometryCombineMode.Exclude, new EllipseGeometry(new System.Windows.Point(10.0, 11.0), 8.0, 8.0), new EllipseGeometry(new System.Windows.Point(14.5, 7.5), 7.0, 7.0));
			grid.Children.Add(new System.Windows.Shapes.Path
			{
				Data = moon,
				Fill = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(214, 204, 255), System.Windows.Media.Color.FromRgb(150, 120, 255), 45.0)
			});
		}
		else
		{
			grid.Children.Add(new Ellipse
			{
				Width = 10.0,
				Height = 10.0,
				Fill = B("#E8B04A")
			});
			for (int i = 0; i < 8; i++)
			{
				grid.Children.Add(new System.Windows.Shapes.Rectangle
				{
					Width = 2.0,
					Height = 4.0,
					RadiusX = 1.0,
					RadiusY = 1.0,
					Fill = B("#E8B04A"),
					RenderTransformOrigin = new System.Windows.Point(0.5, 0.5),
					RenderTransform = new TransformGroup
					{
						Children =
						{
							(Transform)new TranslateTransform(0.0, -9.0),
							(Transform)new RotateTransform(i * 45)
						}
					}
				});
			}
		}
		return grid;
	}

	private void ToggleDayNight()
	{
		settings.Light = !settings.Light;
		SaveSettings();
		SetPalette();
		ApplyInputStyles();
		RebuildShell();
	}

	private void ShowDiskCleanup()
	{
		if (preview)
		{
			return;
		}
		ShowPanel("Disk cleanup", delegate(StackPanel p)
		{
			p.Children.Add(Label("Choose caches to clean", 23.0, Text));
			p.Children.Add(Label("Close games and installers first. Only files under the selected cache directories are considered; locked files and directory links are skipped. Downloads, documents, restore points, installer packages and Windows component files are kept.", 12.0, Muted));
			string folderPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
			Dictionary<string, string[]> dictionary = new Dictionary<string, string[]>
			{
				{
					"DirectX / NVIDIA / AMD shader caches",
					ShaderCache.Roots()
				},
				{
					"Current user temporary files",
					new string[1] { System.IO.Path.GetTempPath() }
				},
				{
					"Windows temporary files",
					new string[1] { System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Temp") }
				},
				{
					"Windows crash reports",
					new string[3]
					{
						System.IO.Path.Combine(folderPath, "CrashDumps"),
						System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Microsoft", "Windows", "WER", "ReportArchive"),
						System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Microsoft", "Windows", "WER", "ReportQueue")
					}
				}
			};
			dictionary["User error reports and diagnostics"] = new string[3]
			{
				System.IO.Path.Combine(folderPath, "Microsoft", "Windows", "WER", "ReportArchive"),
				System.IO.Path.Combine(folderPath, "Microsoft", "Windows", "WER", "ReportQueue"),
				System.IO.Path.Combine(folderPath, "Diagnostics")
			};
			dictionary["NVIDIA installer cache"] = new string[1] { System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "NVIDIA Corporation", "Downloader") };
			dictionary["Chromium browser caches (keep profiles, passwords and cookies)"] = BrowserCacheRoots();
			dictionary["Windows font cache"] = new string[1] { System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "ServiceProfiles", "LocalService", "AppData", "Local", "FontCache") };
			List<System.Windows.Controls.CheckBox> selected = new List<System.Windows.Controls.CheckBox>();
			foreach (KeyValuePair<string, string[]> item in dictionary)
			{
				System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
				{
					Content = item.Key,
					Tag = item.Value,
					IsChecked = false,
					Margin = new Thickness(0.0, 12.0, 0.0, 8.0),
					Foreground = Text
				};
				selected.Add(checkBox);
				p.Children.Add(checkBox);
			}
			TextBlock result = Label("Select categories, then analyze.", 13.0, Cyan);
			p.Children.Add(result);
			System.Windows.Controls.Button analyze = Btn("Analyze", delegate
			{
			});
			System.Windows.Controls.Button clean = Btn("Clean selected", delegate
			{
			}, primary: true);
			clean.IsEnabled = false;
			bool busy = false;
			analyze.Click += async delegate
			{
				if (busy)
				{
					return;
				}
				busy = true;
				System.Windows.Controls.Button button2 = analyze;
				bool flag4 = (clean.IsEnabled = false);
				bool isEnabled2 = flag4;
				button2.IsEnabled = isEnabled2;
				try
				{
					string[] roots2 = selected.Where((System.Windows.Controls.CheckBox x) => x.IsChecked == true).SelectMany((System.Windows.Controls.CheckBox x) => (string[])x.Tag).Distinct()
						.ToArray();
					CacheResult cacheResult2 = await Task.Run(() => ShaderCache.ProcessRoots(roots2, remove: false));
					result.Text = "Can clean " + ((double)cacheResult2.Bytes / 1073741824.0).ToString("0.000") + " GB · " + cacheResult2.Files + " files";
					clean.IsEnabled = cacheResult2.Files > 0;
				}
				finally
				{
					busy = false;
					analyze.IsEnabled = true;
				}
			};
			clean.Click += async delegate
			{
				if (!busy)
				{
					string[] roots = selected.Where((System.Windows.Controls.CheckBox x) => x.IsChecked == true).SelectMany((System.Windows.Controls.CheckBox x) => (string[])x.Tag).Distinct()
						.ToArray();
					if (System.Windows.MessageBox.Show("Delete files in the selected cache categories?", "Disk cleanup", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
					{
						busy = true;
						System.Windows.Controls.Button button = clean;
						bool flag2 = (analyze.IsEnabled = false);
						bool isEnabled = flag2;
						button.IsEnabled = isEnabled;
						try
						{
							CacheResult cacheResult = await Task.Run(() => ShaderCache.ProcessRoots(roots, remove: true));
							result.Text = "Cleaned " + ((double)cacheResult.Bytes / 1073741824.0).ToString("0.000") + " GB · " + cacheResult.Files + " files · " + cacheResult.Skipped + " skipped";
							Record("Disk cleanup", "Clean", "Cache files", "Removed", new ActionResult
							{
								Success = true,
								Message = result.Text
							});
						}
						finally
						{
							busy = false;
							analyze.IsEnabled = true;
						}
					}
				}
			};
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 20.0, 0.0, 0.0)
			};
			wrapPanel.Children.Add(analyze);
			wrapPanel.Children.Add(clean);
			System.Windows.Controls.Button dism = Btn("Dism++ x64", delegate
			{
			});
			dism.Click += async delegate
			{
				await OpenTool(DownloadManager.Catalog().First((DownloadItem x) => x.Id == "dismpp"), dism, result);
			};
			wrapPanel.Children.Add(dism);
			p.Children.Add(wrapPanel);
		}, 780.0, 610.0);
	}

	private void SetPalette()
	{
		LightMode = settings.Light;
		Text = B(settings.Light ? "#2A2742" : "#E9EDF7");
		Muted = B(settings.Light ? "#68647F" : "#929DB3");
		Orange = settings.Theme == "Sunset";
		Bg = (System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(settings.Light ? "#E3E1EA" : (Orange ? "#151014" : "#080917"));
		Accent = B(Orange ? "#D96637" : "#7654E8");
		Purple = B(settings.Light ? "#6F43B5" : (Orange ? "#FDBA74" : "#A78BFA"));
		Cyan = B(settings.Light ? "#087582" : (Orange ? "#FF949F" : "#44D9E8"));
	}

	private string L(string en)
	{
		if (settings.Language != "العربية")
		{
			return en;
		}
		Dictionary<string, string> dictionary = new Dictionary<string, string>
		{
			{ "Manual all", "الكل يدوي" },
			{ "Home", "الرئيسية" },
			{ "Favorites", "المفضلة" },
			{ "Toggles", "التوقلز" },
			{ "Shortcuts", "الاختصارات" },
			{ "Power plans", "خطط الطاقة" },
			{ "Network", "الشبكة" },
			{ "Tweaks", "التويكات" },
			{ "Security", "الحماية" },
			{ "Services", "الخدمات" },
			{ "Restoration", "الاستعادة" },
			{ "Uninstaller", "إزالة التطبيقات" },
			{ "Downloads", "التنزيلات" },
			{ "Tools", "الأدوات" },
			{ "History", "السجل" },
			{ "System", "مواصفات الجهاز" },
			{ "Settings", "الإعدادات" },
			{ "About", "عن التطبيق" },
			{ "Enable all", "تفعيل الكل" },
			{ "Disable all", "تعطيل الكل" },
			{ "Enable", "تفعيل" },
			{ "Disable", "تعطيل" },
			{ "Configure", "ضبط" },
			{ "Download", "تحميل" },
			{ "Cancel", "إلغاء" },
			{ "Restore", "استعادة" }
		};
		if (!dictionary.ContainsKey(en))
		{
			return en;
		}
		return dictionary[en];
	}

	private void SetupTray()
	{
		if (preview)
		{
			return;
		}
		NotifyIcon notifyIcon = new NotifyIcon();
		notifyIcon.Text = "AZIZ Gaming Optimizer";
		notifyIcon.Icon = System.Drawing.Icon.ExtractAssociatedIcon(Program.ExePath);
		// Only shown while AZIZ is hidden to the tray, so it is never mixed up with the Reflex limiter icon.
		notifyIcon.Visible = false;
		tray = notifyIcon;
		ContextMenuStrip contextMenuStrip = new ContextMenuStrip();
		contextMenuStrip.Items.Add("Open AZIZ", null, delegate
		{
			base.Dispatcher.BeginInvoke(new Action(ShowFromTray));
		});
		contextMenuStrip.Items.Add("Exit", null, delegate
		{
			base.Dispatcher.BeginInvoke((Action)delegate
			{
				exitRequested = true;
				Close();
			});
		});
		tray.ContextMenuStrip = contextMenuStrip;
		tray.DoubleClick += delegate
		{
			base.Dispatcher.BeginInvoke(new Action(ShowFromTray));
		};
		base.Closing += delegate(object s, CancelEventArgs e)
		{
			if (!preview && base.WindowState == WindowState.Normal && base.ActualWidth >= 1080.0 && base.ActualHeight >= 720.0)
			{
				settings.WindowWidth = base.ActualWidth;
				settings.WindowHeight = base.ActualHeight;
				try
				{
					SaveSettings();
				}
				catch
				{
				}
			}
			if (!exitRequested && settings.CloseToTray)
			{
				e.Cancel = true;
				HideToTray();
			}
			else if (applying || optimizing || profileBusy || workers > 0 || pendingOrder.Count > 0)
			{
				// Closing in the middle would leave changes half done (and their way back unsaved).
				e.Cancel = true;
				exitRequested = false;
				Say("Wait for the current changes to finish before exiting.");
			}
			else
			{
				if (downloads.Any((DownloadJob x) => x.Running))
				{
					if (System.Windows.MessageBox.Show("Downloads are running. Cancel them and exit?", "AZIZ", MessageBoxButton.OKCancel) != MessageBoxResult.OK)
					{
						e.Cancel = true;
						exitRequested = false;
						return;
					}
					foreach (DownloadJob item in downloads.Where((DownloadJob x) => x.Running))
					{
						item.Cancel.Cancel();
					}
				}
				// Competitive Mode still running without the game watcher: hand the restore over to a small session helper,
				// so services, power plan and network go back when the game closes even though AZIZ exits now.
				if (competitiveRunning && competitiveExe != null)
				{
					try
					{
						GameWatch.StartSession(competitiveExe);
					}
					catch
					{
					}
					competitiveExe = null;
				}
				PlayCue("close", wait: true);
			}
		};
	}

	private string competitiveExe;

	private void HideToTray()
	{
		if (tray != null)
		{
			tray.Visible = true;
		}
		Hide();
		if (sampleTimer != null)
		{
			sampleTimer.Stop();
		}
		ReleaseMemorySoon();
	}

	[DllImport("psapi.dll")]
	private static extern bool EmptyWorkingSet(IntPtr process);

	// In the tray AZIZ only waits: a few seconds after hiding it hands its memory back to Windows (and the game), and pages
	// what it needs back in when the window opens again (measured: ~145 MB kept while hidden before).
	private async void ReleaseMemorySoon(int delay = 3000)
	{
		await Task.Delay(delay);
		if (base.IsVisible || closing)
		{
			return;
		}
		try
		{
			GC.Collect();
			GC.WaitForPendingFinalizers();
			using System.Diagnostics.Process process = System.Diagnostics.Process.GetCurrentProcess();
			EmptyWorkingSet(process.Handle);
		}
		catch
		{
		}
	}

	// Started with Windows: the window is never shown; only the tray icon. The first open behaves normally.
	private bool shownOnce;

	private bool startedInTray;

	public void StartInTray()
	{
		startedInTray = true;
		if (tray != null)
		{
			tray.Visible = true;
		}
		// Started with Windows into the tray: once the start-up work is done, the memory goes back too.
		ReleaseMemorySoon(30000);
	}

	private bool ready;

	// A second start while this one is still loading waits: the window comes forward once it is complete.
	public void BringForward()
	{
		if (ready)
		{
			ShowFromTray();
		}
		else
		{
			bringForwardPending = true;
		}
	}

	private bool bringForwardPending;

	public void RequestUninstall()
	{
		if (!base.IsVisible)
		{
			ShowFromTray();
		}
		UninstallSelf();
	}

	private void ShowFromTray()
	{
		if (tray != null)
		{
			tray.Visible = false;
		}
		Show();
		base.WindowState = WindowState.Normal;
		Activate();
		if (sampleTimer != null && current == "Home")
		{
			sampleTimer.Start();
		}
	}

	private bool CategoryMatch(Tweak t)
	{
		if (current == "Favorites")
		{
			return favorites.Contains(t.Id);
		}
		if (current == "Toggles")
		{
			return GeneralIds.Contains(t.Id);
		}
		if (GeneralIds.Contains(t.Id))
		{
			return false;
		}
		return string.Equals(t.Category, current, StringComparison.OrdinalIgnoreCase);
	}

	private int ControlOrder(Tweak t)
	{
		string[][] array = new string[9][]
		{
			new string[2] { "hyper-v", "virtualization-stack" },
			new string[5] { "system-restore", "windows-update", "telemetry", "disable-apps-telemetry", "activity-history" },
			new string[3] { "wifi", "bluetooth", "hotspot" },
			new string[2] { "power-saving", "deep-sleep" },
			new string[6] { "center-taskbar", "combine-taskbar-buttons", "taskbar-search", "taskbar-task-view", "taskbar-battery", "end-task-right-click" },
			new string[5] { "show-file-extensions", "show-hidden-files", "small-desktop-icons", "legacy-context-menu", "explorer-launch-target" },
			new string[3] { "dark-theme", "transparency", "disable-animations" },
			new string[7] { "gpu-msi", "hags", "mpo", "windowed-optimizations", "nvidia-hdcp", "nvidia-memory-compression", "nvidia-primary-latency" },
			new string[4] { "disable-timer-coalescing", "distribute-timers", "global-timer-resolution", "timer-resolution" }
		};
		for (int i = 0; i < array.Length; i++)
		{
			int num = Array.IndexOf(array[i], t.Id);
			if (num >= 0)
			{
				return i * 100 + num;
			}
		}
		return 1000;
	}

	private string GroupFor(Tweak t)
	{
		if (t.Kind == "Service" && !string.IsNullOrEmpty(t.Group) && t.Group != "Windows services" && t.Group != "Multimedia")
		{
			return t.Group;
		}
		if (t.Kind == "Service")
		{
			if (t.Id.Contains("xbl") || t.Id.Contains("xbox") || t.Id.Contains("bcast"))
			{
				return "Xbox & game services";
			}
			if (t.Id.Contains("diag") || t.Id.Contains("wer") || t.Id.Contains("inventory") || t.Id.Contains("pcasvc"))
			{
				return "Diagnostics & reporting";
			}
			return "Windows services";
		}
		if (!string.IsNullOrEmpty(t.Group))
		{
			return t.Group;
		}
		if (t.Category == "Appearance")
		{
			return "Appearance";
		}
		if (GeneralIds.Contains(t.Id))
		{
			if (!(t.Category == "Devices"))
			{
				return "Windows";
			}
			return "Devices & connectivity";
		}
		if (t.Id.Contains("mouse") || t.Id.Contains("keyboard") || t.Id.Contains("input") || t.Id.Contains("sticky"))
		{
			return "Input";
		}
		if (new string[6] { "hags", "variable-refresh-rate", "fullscreen-optimizations", "mpo", "windowed-optimizations", "tdr-delay" }.Contains(t.Id))
		{
			if (!(t.Id == "hags") && !(t.Id == "tdr-delay"))
			{
				return "Display";
			}
			return "GPU";
		}
		if (!(t.Category == "Tweaks"))
		{
			return t.Category;
		}
		return "System & latency";
	}

	private void RenderTweaks()
	{
		double verticalOffset = scroll.VerticalOffset;
		content.Children.Clear();
		Dictionary<string, Border> dictionary = new Dictionary<string, Border>();
		tweakHosts[current] = dictionary;
		string query = (search.Text ?? "").Trim();
		List<Tweak> list = (from t in engine.Tweaks.Where(CategoryMatch)
			where query.Length == 0 || (t.Name + " " + t.Description).IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0
			select t).ToList();
		DockPanel dockPanel = new DockPanel
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
		};
		StackPanel stackPanel = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		string page = current;
		foreach (Tuple<string, string, string> preset in PagePresets(page))
		{
			// Rounded pill buttons matching the new identity: Low Latency blue, Ultra Low Latency and each page's
			// recommended set violet with a glow, the rest (Minimal, Default) a quiet outline pill.
			Tuple<string, string, string> captured = preset;
			bool low = preset.Item2 == "Low Latency";
			bool strong = low || preset.Item1 == "low-latency" || preset.Item1 == "recommended";
			TextBlock pillText = Label(preset.Item2, 12.5, strong ? System.Windows.Media.Brushes.White : B("#C4CBE4"));
			pillText.FontWeight = FontWeights.SemiBold;
			pillText.VerticalAlignment = VerticalAlignment.Center;
			System.Windows.Media.Brush idle = (low ? new LinearGradientBrush(System.Windows.Media.Color.FromRgb(43, 95, 217), System.Windows.Media.Color.FromRgb(28, 42, 120), 0.0) : (strong ? new LinearGradientBrush(System.Windows.Media.Color.FromRgb(122, 60, 240), System.Windows.Media.Color.FromRgb(70, 36, 150), 0.0) : B("#141A30")));
			System.Windows.Media.Brush hot = (low ? new LinearGradientBrush(System.Windows.Media.Color.FromRgb(58, 112, 238), System.Windows.Media.Color.FromRgb(36, 54, 150), 0.0) : (strong ? new LinearGradientBrush(System.Windows.Media.Color.FromRgb(140, 78, 255), System.Windows.Media.Color.FromRgb(86, 48, 180), 0.0) : B("#1C2440")));
			Border pill = new Border
			{
				Child = pillText,
				CornerRadius = new CornerRadius(20.0),
				Padding = new Thickness(18.0, 8.0, 18.0, 8.0),
				Margin = new Thickness(8.0, 0.0, 0.0, 0.0),
				Background = idle,
				BorderThickness = new Thickness(strong ? 0.0 : 1.0),
				BorderBrush = (strong ? System.Windows.Media.Brushes.Transparent : B("#39436A")),
				Cursor = System.Windows.Input.Cursors.Hand,
				VerticalAlignment = VerticalAlignment.Center,
				ToolTip = preset.Item3
			};
			if (strong && !low)
			{
				pill.Effect = new DropShadowEffect
				{
					Color = System.Windows.Media.Color.FromRgb(122, 60, 240),
					BlurRadius = 16.0,
					ShadowDepth = 0.0,
					Opacity = 0.5
				};
			}
			pill.MouseEnter += delegate
			{
				pill.Background = hot;
			};
			pill.MouseLeave += delegate
			{
				pill.Background = idle;
			};
			pill.MouseLeftButtonUp += async delegate
			{
				await ApplyPagePreset(captured.Item1, engine.Tweaks.Where(CategoryMatch).ToList());
			};
			stackPanel.Children.Add(pill);
		}
		DockPanel.SetDock(stackPanel, Dock.Right);
		dockPanel.Children.Add(stackPanel);
		int num = list.Count;
		dockPanel.Children.Add(Label(num + " controls · changes run in the background", 12.0, Muted));
		content.Children.Add(dockPanel);
		if (current == "Tweaks")
		{
			content.Children.Add(DxButton());
		}
		if (list.Count == 0)
		{
			content.Children.Add(Card(Label((current == "Favorites") ? "Use the star beside any control to save it here." : "No matching controls.", 16.0, Muted)));
			return;
		}
		bool flag = settings.CompactControls && (current == "Tweaks" || current == "Toggles");
		if (current == "Tweaks" || current == "Toggles")
		{
			System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
			{
				Content = "Compact cards",
				IsChecked = flag,
				Foreground = Text,
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			};
			checkBox.Checked += delegate
			{
				settings.CompactControls = true;
				SaveSettings();
				InvalidateViews();
				RenderTweaks();
			};
			checkBox.Unchecked += delegate
			{
				settings.CompactControls = false;
				SaveSettings();
				InvalidateViews();
				RenderTweaks();
			};
			content.Children.Add(checkBox);
		}
		if (current == "Services")
		{
			content.Children.Add(Label("Services and drivers covered by the AZIZ Minimal, Recommended and Default lists, read live from Windows. Each card shows the value of every list. Disabling an important Windows service asks first and says what stops working. The main services are open below; every other category opens with a click on its name.", 12.0, Muted));
		}
		bool grouped = current == "Tweaks" || current == "Toggles" || current == "Services" || current == "Network" || current == "Security";
		bool searching = query.Length > 0;
		renderGeneration.TryGetValue(page, out var generation);
		generation++;
		renderGeneration[page] = generation;
		Dictionary<string, Border> hosts = dictionary;
		List<Tuple<System.Windows.Controls.Panel, Tweak, string>> cards = new List<Tuple<System.Windows.Controls.Panel, Tweak, string>>();
		foreach (IGrouping<string, Tweak> item2 in (from t in list
			group t by grouped ? PageGroup(t, searching) : current into g
			orderby GroupRank(g.Key)
			select g).ThenBy((IGrouping<string, Tweak> g) => g.Key, StringComparer.OrdinalIgnoreCase))
		{
			string orderKey = page + "|" + item2.Key;
			object obj = (flag ? ((System.Windows.Controls.Panel)new UniformGrid
			{
				Columns = 3
			}) : ((System.Windows.Controls.Panel)Stack()));
			System.Windows.Controls.Panel panel = (System.Windows.Controls.Panel)obj;
			List<Tweak> ordered = OrderCards(orderKey, item2);
			bool collapsed = grouped && !searching && GroupCollapsed(page, item2.Key);
			if (grouped)
			{
				bool filled = !collapsed;
				content.Children.Add(GroupHeader(item2.Key, ordered.Count, collapsed, delegate(bool fold)
				{
					SetGroupCollapsed(page, item2.Key, fold);
					panel.Visibility = (fold ? Visibility.Collapsed : Visibility.Visible);
					if (!fold)
					{
						if (!filled)
						{
							filled = true;
							FillCards(page, generation, ordered.Select((Tweak x) => Tuple.Create(panel, x, orderKey)).ToList(), 0, flag, hosts);
						}
						panel.Opacity = 0.0;
						panel.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(180.0)));
					}
				}));
			}
			if (collapsed)
			{
				panel.Visibility = Visibility.Collapsed;
			}
			content.Children.Add(panel);
			if (!collapsed)
			{
				foreach (Tweak item3 in ordered)
				{
					cards.Add(Tuple.Create(panel, item3, orderKey));
				}
			}
		}
		FillCards(page, generation, cards, 24, flag, hosts);
		scroll.ScrollToVerticalOffset(verticalOffset);
	}

	private void FillCards(string page, int generation, List<Tuple<System.Windows.Controls.Panel, Tweak, string>> cards, int now, bool compact, Dictionary<string, Border> hosts)
	{
		int next = 0;
		Action<int> add = delegate(int upTo)
		{
			for (; next < upTo; next++)
			{
				Border card = TweakCard(cards[next].Item2, compact, hosts);
				card.Uid = cards[next].Item2.Id;
				cards[next].Item1.Children.Add(card);
				EnableReorder(card, cards[next].Item1, cards[next].Item3, !compact);
			}
		};
		add(Math.Min(cards.Count, now));
		Action batch = null;
		batch = delegate
		{
			if (!closing && renderGeneration[page] == generation)
			{
				add(Math.Min(cards.Count, next + 20));
				if (next < cards.Count)
				{
					base.Dispatcher.BeginInvoke(batch, DispatcherPriority.Background);
				}
			}
		};
		if (next < cards.Count)
		{
			base.Dispatcher.BeginInvoke(batch, DispatcherPriority.Background);
		}
	}

	private string PageGroup(Tweak t, bool searching)
	{
		if (current == "Services" && !searching && t.Kind == "Service" && ServicePresets.Main.Contains(ServicePresets.BaseName(t.Service)))
		{
			return "Main services";
		}
		if (current == "Network")
		{
			switch (t.Id)
			{
			case "nic-interrupt-moderation":
			case "nic-eee":
			case "nic-lso":
			case "tcpip-task-offload":
			case "tcp-rsc":
				return "Network adapter";
			case "llmnr":
			case "netbios":
			case "ndu-service":
			case "delivery-optimization-p2p":
				return "Background & sharing";
			default:
				return "TCP & latency";
			}
		}
		if (current == "Security")
		{
			switch (t.Id)
			{
			case "hyper-v":
			case "virtualization-stack":
			case "core-isolation":
			case "vbs":
				return "Virtualization";
			case "cpu-mitigations":
			case "control-flow-guard":
			case "other-security-mitigations":
			case "allowed-in-memory-settings":
				return "Exploit mitigations";
			default:
				return "Windows protection";
			}
		}
		return GroupFor(t);
	}

	private List<Tweak> OrderCards(string orderKey, IEnumerable<Tweak> items)
	{
		Dictionary<string, int> saved = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		if (settings.CardOrder != null && settings.CardOrder.TryGetValue(orderKey, out var value) && !string.IsNullOrEmpty(value))
		{
			string[] array = value.Split(',');
			for (int i = 0; i < array.Length; i++)
			{
				if (!saved.ContainsKey(array[i]))
				{
					saved[array[i]] = i;
				}
			}
		}
		return items.OrderBy((Tweak x) => saved.TryGetValue(x.Id, out var value2) ? value2 : int.MaxValue).ThenBy((Tweak x) => ControlOrder(x)).ThenBy((Tweak x) => x.Name, StringComparer.OrdinalIgnoreCase).ToList();
	}

	private bool GroupCollapsed(string page, string group)
	{
		string item = page + "|" + group;
		if (settings.CollapsedGroups != null && settings.CollapsedGroups.Contains(item))
		{
			return true;
		}
		// Services: only Main services is open; the other groups stay folded until opened (not remembered between starts).
		if (page == "Services" && group != "Main services")
		{
			return !openServiceGroups.Contains(item);
		}
		return false;
	}

	private readonly HashSet<string> openServiceGroups = new HashSet<string>();

	private void SetGroupCollapsed(string page, string group, bool fold)
	{
		string item = page + "|" + group;
		if (settings.CollapsedGroups == null)
		{
			settings.CollapsedGroups = new List<string>();
		}
		if (settings.ExpandedGroups == null)
		{
			settings.ExpandedGroups = new List<string>();
		}
		if (page == "Services" && group != "Main services")
		{
			if (fold)
			{
				openServiceGroups.Remove(item);
			}
			else
			{
				openServiceGroups.Add(item);
			}
			return;
		}
		settings.CollapsedGroups.Remove(item);
		settings.ExpandedGroups.Remove(item);
		if (fold)
		{
			settings.CollapsedGroups.Add(item);
		}
		else if (page == "Services")
		{
			settings.ExpandedGroups.Add(item);
		}
		SaveSettings();
	}

	private FrameworkElement GroupHeader(string title, int count, bool collapsed, Action<bool> toggled)
	{
		bool folded = collapsed;
		StackPanel row = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			Background = System.Windows.Media.Brushes.Transparent,
			Cursor = System.Windows.Input.Cursors.Hand,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
			Margin = new Thickness(2.0, 16.0, 0.0, 10.0),
			ToolTip = "Click to fold or open this category"
		};
		TextBlock name = Label(title, 13.0, Purple);
		name.FontWeight = FontWeights.SemiBold;
		name.VerticalAlignment = VerticalAlignment.Center;
		row.Children.Add(name);
		TextBlock amount = Label(count.ToString(), 11.0, Muted);
		amount.VerticalAlignment = VerticalAlignment.Center;
		amount.Margin = new Thickness(8.0, 1.0, 0.0, 0.0);
		row.Children.Add(amount);
		RotateTransform turn = new RotateTransform(folded ? (-90.0) : 0.0);
		TextBlock chevron = new TextBlock
		{
			Text = "▾",
			FontSize = 13.0,
			Foreground = Purple,
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(8.0, 0.0, 0.0, 0.0),
			RenderTransformOrigin = new System.Windows.Point(0.5, 0.5),
			RenderTransform = turn,
			Opacity = (folded ? 0.45 : 0.0)
		};
		row.Children.Add(chevron);
		Action<double> fade = delegate(double to)
		{
			chevron.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(to, TimeSpan.FromMilliseconds(140.0)));
		};
		row.MouseEnter += delegate
		{
			fade(1.0);
		};
		row.MouseLeave += delegate
		{
			fade(folded ? 0.45 : 0.0);
		};
		row.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
		{
			folded = !folded;
			turn.BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation(folded ? (-90.0) : 0.0, TimeSpan.FromMilliseconds(160.0))
			{
				EasingFunction = new QuadraticEase()
			});
			toggled(folded);
			e.Handled = true;
		};
		return row;
	}

	private void EnableReorder(Border card, System.Windows.Controls.Panel panel, string orderKey, bool vertical)
	{
		ScaleTransform scale = new ScaleTransform(1.0, 1.0);
		TranslateTransform shift = new TranslateTransform();
		card.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
		card.RenderTransform = new TransformGroup
		{
			Children = { (Transform)scale, (Transform)shift }
		};
		DispatcherTimer hold = null;
		bool dragging = false;
		System.Windows.Point start = default(System.Windows.Point);
		System.Windows.Point grab = default(System.Windows.Point);
		Action cancel = delegate
		{
			if (hold != null)
			{
				hold.Stop();
				hold = null;
			}
		};
		Action<double> grow = delegate(double to)
		{
			DoubleAnimation animation = new DoubleAnimation(to, TimeSpan.FromMilliseconds(140.0));
			scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
			scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
		};
		Action finish = delegate
		{
			if (!dragging)
			{
				return;
			}
			dragging = false;
			if (card.IsMouseCaptured)
			{
				card.ReleaseMouseCapture();
			}
			grow(1.0);
			shift.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(shift.X, 0.0, TimeSpan.FromMilliseconds(160.0))
			{
				EasingFunction = new QuadraticEase()
			});
			shift.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(shift.Y, 0.0, TimeSpan.FromMilliseconds(160.0))
			{
				EasingFunction = new QuadraticEase()
			});
			card.Effect = null;
			card.Opacity = 1.0;
			System.Windows.Controls.Panel.SetZIndex(card, 0);
			List<string> ids = (from FrameworkElement x in panel.Children
				where !string.IsNullOrEmpty(x.Uid)
				select x.Uid).ToList();
			if (settings.CardOrder == null)
			{
				settings.CardOrder = new Dictionary<string, string>();
			}
			settings.CardOrder[orderKey] = string.Join(",", ids);
			SaveSettings();
		};
		card.PreviewMouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
		{
			if (dragging)
			{
				return;
			}
			start = e.GetPosition(panel);
			cancel();
			hold = new DispatcherTimer
			{
				Interval = TimeSpan.FromMilliseconds(420.0)
			};
			hold.Tick += delegate
			{
				cancel();
				if (Mouse.LeftButton != MouseButtonState.Pressed || !card.IsVisible)
				{
					return;
				}
				dragging = true;
				Vector offset = VisualTreeHelper.GetOffset(card);
				grab = new System.Windows.Point(start.X - offset.X, start.Y - offset.Y);
				shift.BeginAnimation(TranslateTransform.XProperty, null);
				shift.BeginAnimation(TranslateTransform.YProperty, null);
				System.Windows.Controls.Panel.SetZIndex(card, 100);
				card.Opacity = 0.94;
				card.Effect = new DropShadowEffect
				{
					Color = System.Windows.Media.Color.FromRgb(118, 84, 232),
					BlurRadius = 26.0,
					ShadowDepth = 0.0,
					Opacity = 0.55
				};
				grow(1.025);
				card.CaptureMouse();
			};
			hold.Start();
		};
		card.PreviewMouseMove += delegate(object s, System.Windows.Input.MouseEventArgs e)
		{
			System.Windows.Point position = e.GetPosition(panel);
			if (!dragging)
			{
				if (hold != null && (position - start).Length > 6.0)
				{
					cancel();
				}
				return;
			}
			e.Handled = true;
			foreach (UIElement child in panel.Children)
			{
				FrameworkElement other = child as FrameworkElement;
				if (other == null || other == card || string.IsNullOrEmpty(other.Uid))
				{
					continue;
				}
				Vector at = VisualTreeHelper.GetOffset(other);
				if (!(position.X >= at.X) || !(position.X <= at.X + other.ActualWidth) || !(position.Y >= at.Y) || !(position.Y <= at.Y + other.ActualHeight))
				{
					continue;
				}
				int to = panel.Children.IndexOf(other);
				Dictionary<FrameworkElement, Vector> before = panel.Children.OfType<FrameworkElement>().ToDictionary((FrameworkElement x) => x, (FrameworkElement x) => VisualTreeHelper.GetOffset(x));
				while (panel.Children.IndexOf(card) < to)
				{
					int num = panel.Children.IndexOf(card);
					UIElement element = panel.Children[num + 1];
					panel.Children.RemoveAt(num + 1);
					panel.Children.Insert(num, element);
				}
				while (panel.Children.IndexOf(card) > to)
				{
					int num2 = panel.Children.IndexOf(card);
					UIElement element2 = panel.Children[num2 - 1];
					panel.Children.RemoveAt(num2 - 1);
					panel.Children.Insert(num2, element2);
				}
				panel.UpdateLayout();
				foreach (KeyValuePair<FrameworkElement, Vector> item in before)
				{
					if (item.Key == card || !(item.Key.RenderTransform is TransformGroup transformGroup) || transformGroup.Children.Count < 2 || !(transformGroup.Children[1] is TranslateTransform translateTransform))
					{
						continue;
					}
					Vector vector = item.Value - VisualTreeHelper.GetOffset(item.Key);
					if (vector.Length > 0.5)
					{
						translateTransform.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(vector.X, 0.0, TimeSpan.FromMilliseconds(170.0))
						{
							EasingFunction = new QuadraticEase()
						});
						translateTransform.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(vector.Y, 0.0, TimeSpan.FromMilliseconds(170.0))
						{
							EasingFunction = new QuadraticEase()
						});
					}
				}
				break;
			}
			Vector offset2 = VisualTreeHelper.GetOffset(card);
			shift.X = (vertical ? 0.0 : (position.X - grab.X - offset2.X));
			shift.Y = position.Y - grab.Y - offset2.Y;
			if (scroll != null)
			{
				double y = e.GetPosition(scroll).Y;
				if (y < 48.0)
				{
					scroll.ScrollToVerticalOffset(scroll.VerticalOffset - 14.0);
				}
				else if (y > scroll.ActualHeight - 48.0)
				{
					scroll.ScrollToVerticalOffset(scroll.VerticalOffset + 14.0);
				}
				wheelTarget = scroll.VerticalOffset;
			}
		};
		card.PreviewMouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
		{
			cancel();
			if (dragging)
			{
				finish();
				e.Handled = true;
			}
		};
		card.LostMouseCapture += delegate
		{
			finish();
		};
	}

	private static int GroupRank(string g)
	{
		if (g == "Main services")
		{
			return -1;
		}
		int num = Array.IndexOf(new string[28]
		{
			"TCP & latency", "Network adapter", "Background & sharing", "Windows", "Security", "Devices & connectivity", "Appearance", "CPU & Power", "CPU & Scheduling", "GPU", "Display", "Gaming", "Memory & Storage",
			"Input & USB", "Timers & Boot", "System & Latency", "Privacy & Background", "Explorer & Shell", "Essential · kept running", "Gaming, launchers & drivers", "Xbox & game services", "Installed apps", "Windows services",
			"Diagnostics & reporting", "Not needed for gaming", "Virtualization", "Exploit mitigations", "Windows protection"
		}, g);
		if (num >= 0)
		{
			return num;
		}
		return 100;
	}

	private TweakStatus StateOf(Tweak t)
	{
		if (!states.TryGetValue(t.Id, out var value))
		{
			return new TweakStatus
			{
				State = "Unknown",
				Detail = "Reading Windows settings…"
			};
		}
		return value;
	}

	private Border TweakCard(Tweak t, bool compact, Dictionary<string, Border> hosts)
	{
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(t.Name, 14.0, Text));
		TextBlock textBlock = Label(t.Description, 11.0, Muted);
		textBlock.Margin = new Thickness(0.0, 4.0, 22.0, 0.0);
		if (t.Kind == "Service")
		{
			int? num = ServicePresets.Target("minimal", t.Service);
			int? num2 = ServicePresets.Target("recommended", t.Service);
			int? num3 = ServicePresets.Target("default", t.Service);
			if (num.HasValue || num2.HasValue || num3.HasValue)
			{
				textBlock.Text = "Minimal: " + (num.HasValue ? ServicePresets.StartText(num.Value) : "—") + "  ·  Recommended: " + (num2.HasValue ? ServicePresets.StartText(num2.Value) : "—") + "  ·  Default: " + (num3.HasValue ? ServicePresets.StartText(num3.Value) : "—");
			}
			string text = ServicePresets.Warning(t.Service);
			if (text != null)
			{
				textBlock.Text = textBlock.Text + "\n⚠ Important: " + text;
			}
			textBlock.ToolTip = t.Description;
		}
		if (compact)
		{
			textBlock.MaxHeight = 46.0;
			textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock.ToolTip = t.Description;
		}
		stackPanel.Children.Add(textBlock);
		grid.Children.Add(stackPanel);
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			VerticalAlignment = VerticalAlignment.Center
		};
		System.Windows.Controls.Button button = Btn("ⓘ", delegate
		{
			ShowControlDetails(t);
		});
		button.Padding = new Thickness(6.0);
		button.Background = System.Windows.Media.Brushes.Transparent;
		button.Foreground = Muted;
		stackPanel2.Children.Add(button);
		System.Windows.Controls.Button button2 = Btn(favorites.Contains(t.Id) ? "★" : "☆", delegate
		{
			if (!favorites.Add(t.Id))
			{
				favorites.Remove(t.Id);
			}
			SaveFavorites();
			viewCache.Remove("Favorites");
			RenderTweaks();
		});
		button2.Background = System.Windows.Media.Brushes.Transparent;
		button2.Foreground = Purple;
		button2.Padding = new Thickness(6.0);
		stackPanel2.Children.Add(button2);
		Border border = new Border
		{
			Tag = compact,
			VerticalAlignment = VerticalAlignment.Center
		};
		border.Child = TweakControl(t, StateOf(t), compact);
		hosts[t.Id] = border;
		stackPanel2.Children.Add(border);
		if (compact)
		{
			grid.RowDefinitions.Add(new RowDefinition());
			grid.RowDefinitions.Add(new RowDefinition
			{
				Height = GridLength.Auto
			});
			Grid.SetColumnSpan(stackPanel, 2);
			Grid.SetRow(stackPanel2, 1);
			stackPanel2.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
			stackPanel2.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
			Grid.SetColumnSpan(stackPanel2, 2);
		}
		else
		{
			Grid.SetColumn(stackPanel2, 1);
		}
		grid.Children.Add(stackPanel2);
		Border val12 = Card(grid);
		val12.Padding = (compact ? new Thickness(16.0, 14.0, 14.0, 12.0) : new Thickness(18.0, 13.0, 14.0, 13.0));
		val12.CornerRadius = new CornerRadius(12.0);
		if (compact)
		{
			val12.Height = 156.0;
		}
		val12.Margin = new Thickness(0.0, 0.0, compact ? 10 : 0, compact ? 10.0 : 8.0);
		System.Windows.Media.Brush rest = val12.BorderBrush;
		val12.MouseEnter += delegate
		{
			val12.BorderBrush = B("#5A44B8");
		};
		val12.MouseLeave += delegate
		{
			val12.BorderBrush = rest;
		};
		return val12;
	}

	private FrameworkElement TweakControl(Tweak t, TweakStatus state, bool compact)
	{
		PendingChange value;
		bool flag = pendingChanges.TryGetValue(t.Id, out value);
		StackPanel stackPanel = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			VerticalAlignment = VerticalAlignment.Center
		};
		if (t.Kind == "SystemRestore")
		{
			TextBlock textBlock = Label(state.Detail ?? "", 10.0, Muted);
			textBlock.MaxWidth = (compact ? 150 : 260);
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
			if (!compact)
			{
				stackPanel.Children.Add(textBlock);
			}
			System.Windows.Controls.Button button = Btn("Restore points", OpenSystemRestore, primary: true);
			button.Margin = new Thickness(0.0);
			button.ToolTip = "Create a restore point or restore Windows to one.";
			stackPanel.Children.Add(button);
			return stackPanel;
		}
		if (t.Kind == "PowerConfigure")
		{
			System.Windows.Controls.Button button2 = Btn("Configure", delegate
			{
				ConfigurePower(t);
			});
			button2.IsEnabled = state.State != "Unavailable";
			button2.ToolTip = state.Detail;
			stackPanel.Children.Add(button2);
			return stackPanel;
		}
		if (t.Kind == "GpuMsi")
		{
			stackPanel.Children.Add(Btn("Configure", async delegate
			{
				await ConfigureGpuMsi(state.State != "Enabled");
			}));
			return stackPanel;
		}
		if (t.Kind == "Action")
		{
			stackPanel.Children.Add(Btn("Open Recovery", delegate
			{
				OpenUri("ms-settings:recovery");
			}));
			return stackPanel;
		}
		if (t.Kind == "Shortcut")
		{
			stackPanel.Children.Add(Btn(L("Configure"), delegate
			{
				OpenUri("SystemPropertiesProtection.exe");
			}));
			return stackPanel;
		}
		if (t.Kind == "Service" && t.Choices != null && t.Choices.Count > 0)
		{
			string text = (flag ? value.Choice : ProfileLogic.ServiceValue(state));
			TweakChoice tweakChoice = t.Choices.FirstOrDefault((TweakChoice c) => c.Value == text);
			System.Windows.Controls.Button pick = Btn(((tweakChoice == null) ? "Choose…" : tweakChoice.Label) + "  ▾", delegate
			{
			});
			pick.Width = (compact ? 150 : 150);
			pick.Padding = new Thickness(12.0, 7.0, 12.0, 7.0);
			pick.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left;
			pick.Background = B("#233149");
			pick.ToolTip = (flag ? "Windows is being updated in the background." : state.Detail);
			pick.IsEnabled = !flag;
			pick.Click += delegate
			{
				StackPanel stackPanel2 = new StackPanel();
				Popup popup = new Popup();
				foreach (TweakChoice c2 in t.Choices)
				{
					System.Windows.Controls.Button button4 = Btn(c2.Label + ((c2.Value == text) ? "  ✓" : ""), delegate
					{
					});
					button4.Background = System.Windows.Media.Brushes.Transparent;
					button4.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left;
					button4.Padding = new Thickness(14.0, 8.0, 14.0, 8.0);
					button4.MinWidth = 150.0;
					button4.Foreground = ((c2.Value == text) ? B("#F5B700") : Text);
					button4.Click += async delegate
					{
						popup.IsOpen = false;
						if (c2.Value != text)
						{
							await ChangeChoice(t, c2);
						}
					};
					stackPanel2.Children.Add(button4);
				}
				Border border = new Border
				{
					Background = B("#141B2B"),
					BorderBrush = B("#35405A"),
					BorderThickness = new Thickness(1.0),
					CornerRadius = new CornerRadius(8.0),
					Padding = new Thickness(4.0),
					Child = stackPanel2
				};
				popup.Child = border;
				popup.PlacementTarget = pick;
				popup.Placement = PlacementMode.Bottom;
				popup.StaysOpen = false;
				popup.AllowsTransparency = true;
				popup.IsOpen = true;
			};
			stackPanel.Children.Add(pick);
			return stackPanel;
		}
		if (t.Choices != null && t.Choices.Count > 0)
		{
			System.Windows.Controls.ComboBox comboBox = new System.Windows.Controls.ComboBox();
			comboBox.Width = (compact ? 170 : 200);
			comboBox.DisplayMemberPath = "Label";
			comboBox.Background = B("#233149");
			comboBox.Foreground = Text;
			System.Windows.Controls.ComboBox choice = comboBox;
			List<TweakChoice> list = new List<TweakChoice>();
			TweakChoice tweakChoice2 = null;
			foreach (TweakChoice choice2 in t.Choices)
			{
				if (flag && value.Choice == choice2.Value)
				{
					tweakChoice2 = choice2;
				}
				else if (!flag && (state.Detail ?? "").Contains((t.Kind == "Service") ? ("Startup: " + choice2.Label) : ("(" + choice2.Value + ")")))
				{
					tweakChoice2 = choice2;
				}
			}
			if (tweakChoice2 == null)
			{
				list.Add(new TweakChoice
				{
					Label = "Choose a value…",
					Value = ""
				});
			}
			list.AddRange(t.Choices);
			choice.ItemsSource = list;
			choice.SelectedItem = tweakChoice2 ?? list[0];
			choice.ToolTip = state.Detail;
			choice.SelectionChanged += async delegate
			{
				if (choice.SelectedItem is TweakChoice tweakChoice4 && !string.IsNullOrEmpty(tweakChoice4.Value))
				{
					if (tweakChoice4.Value == "custom")
					{
						CustomPriority(t);
						RefreshTweak(t.Id);
					}
					else
					{
						await ChangeChoice(t, tweakChoice4);
					}
				}
			};
			stackPanel.Children.Add(choice);
			return stackPanel;
		}
		bool on = (flag ? value.Enabled : ShownOn(t, state));
		bool flag2 = !flag && state.State == "Unavailable";
		TranslateTransform slide = new TranslateTransform(on ? 20.0 : 0.0, 0.0);
		Border knob = new Border
		{
			Width = 18.0,
			Height = 18.0,
			CornerRadius = new CornerRadius(9.0),
			Background = System.Windows.Media.Brushes.White,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(2.0, 0.0, 0.0, 0.0),
			RenderTransform = slide
		};
		System.Windows.Media.Brush onTrack = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(108, 58, 220), System.Windows.Media.Color.FromRgb(80, 46, 190), 0.0);
		Border button3 = new Border
		{
			Width = 44.0,
			Height = 24.0,
			CornerRadius = new CornerRadius(12.0),
			BorderThickness = new Thickness(1.0),
			Background = (on ? onTrack : B("#252C42")),
			BorderBrush = (on ? B("#AA8CFF") : B("#3A4360")),
			Cursor = System.Windows.Input.Cursors.Hand,
			Opacity = (flag2 ? 0.45 : 1.0),
			VerticalAlignment = VerticalAlignment.Center,
			Child = knob,
			ToolTip = ((state.State == "Mixed" && !flag) ? (on ? "Mixed · shown as On until every part is off" : "Mixed · shown as Off until every part is on") : (on ? "Enabled" : "Disabled")) + " · " + (flag ? "Windows is being updated in the background." : state.Detail) + (t.RequiresRestart ? " · Restart may be required." : "")
		};
		button3.MouseEnter += delegate
		{
			knob.Width = 20.0;
		};
		button3.MouseLeave += delegate
		{
			knob.Width = 18.0;
		};
		button3.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
		{
			e.Handled = true;
		};
		button3.MouseLeftButtonUp += async delegate(object s, MouseButtonEventArgs e)
		{
			e.Handled = true;
			slide.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(on ? 0.0 : 20.0, TimeSpan.FromMilliseconds(160.0))
			{
				EasingFunction = new QuadraticEase()
			});
			button3.Background = (on ? B("#252C42") : onTrack);
			button3.BorderBrush = (on ? B("#3A4360") : B("#AA8CFF"));
			await Change(t, !on);
		};
		stackPanel.Children.Add(button3);
		return stackPanel;
	}

	private void RefreshTweak(string id)
	{
		Tweak tweak = engine.Tweaks.FirstOrDefault((Tweak x) => x.Id == id);
		if (tweak == null)
		{
			return;
		}
		foreach (Dictionary<string, Border> value2 in tweakHosts.Values)
		{
			if (value2.TryGetValue(id, out var value))
			{
				value.Child = TweakControl(tweak, StateOf(tweak), value.Tag is bool && (bool)value.Tag);
			}
		}
	}

	private async Task Bulk(List<Tweak> list, bool on)
	{
		if (preview || applying)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		List<Tweak> list2 = (from t in list
			where t.Kind != "Unavailable" && t.Kind != "Shortcut" && t.Kind != "GpuMsi" && t.Kind != "Timer" && t.Kind != "Action" && t.Kind != "NvidiaScaling" && t.Kind != "PowerConfigure" && t.Kind != "SystemRestore" && (t.Choices == null || t.Kind == "Service")
			where StateOf(t).State != "Unavailable"
			select t).ToList();
		List<Tuple<Tweak, string, string>> list3 = new List<Tuple<Tweak, string, string>>();
		foreach (Tweak item in list2)
		{
			string text = CurrentValue(item);
			if (item.Kind == "Service")
			{
				if (int.TryParse(text, out var result))
				{
					int num = ServiceBatch.Target(item.Service, on, result, item.Name);
					if (num != result)
					{
						list3.Add(Tuple.Create(item, text, num.ToString()));
					}
				}
			}
			else
			{
				string text2 = (on ? "Enabled" : "Disabled");
				if (text != text2)
				{
					list3.Add(Tuple.Create(item, text, text2));
				}
			}
		}
		if (list3.Count == 0)
		{
			notice.Text = "Nothing to change · this page already matches.";
			return;
		}
		string title = L((!on) ? "Disable all" : ((current == "Services") ? "Manual all" : "Enable all"));
		string intro = ((current == "Services") ? ((on ? "Essentials and gaming services stay as they are; services a gaming PC never needs are disabled; the rest become Manual." : "Only essential and gaming services keep running (sign-in, desktop, input, audio, display, network, launchers and anti-cheat).") + " Untick anything you want to keep.") : "Untick anything you want to keep.");
		// Same rule as single changes and page presets: a static profile is never edited silently.
		if (!ReviewChanges(title, intro, list3, out var chosen) || !EnsureEditable(null, null))
		{
			return;
		}
		foreach (Tweak t2 in chosen)
		{
			Func<Tuple<Tweak, string, string>, bool> predicate = (Tuple<Tweak, string, string> x) => x.Item1 == t2;
			Tuple<Tweak, string, string> tuple = list3.First(predicate);
			if (t2.Kind == "Service")
			{
				Enqueue(t2, tuple.Item3 != "4", tuple.Item3);
			}
			else
			{
				Enqueue(t2, on, null);
			}
		}
	}

	private void RenderSettings()
	{
		content.Children.Clear();
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("PERSONALIZE YOUR SPACE", 11.0, Purple));
		stackPanel.Children.Add(Spacer(14));
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		stackPanel2.Children.Add(Btn((settings.Language == "العربية") ? "●  بنفسجي" : "●  Purple", delegate
		{
			ChangeTheme("Purple");
		}, primary: true));
		System.Windows.Controls.Button button = Btn((settings.Language == "العربية") ? "●  برتقالي" : "●  Orange", delegate
		{
			ChangeTheme("Sunset");
		});
		button.Background = B("#B95032");
		stackPanel2.Children.Add(button);
		stackPanel.Children.Add(stackPanel2);
		stackPanel.Children.Add(Spacer(20));
		System.Windows.Controls.ComboBox comboBox = new System.Windows.Controls.ComboBox();
		comboBox.ItemsSource = new string[2] { "English", "العربية" };
		comboBox.SelectedItem = settings.Language;
		comboBox.Width = 210.0;
		comboBox.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		System.Windows.Controls.ComboBox lang = comboBox;
		lang.SelectionChanged += delegate
		{
			settings.Language = Convert.ToString(lang.SelectedItem);
			SaveSettings();
			RebuildShell();
		};
		stackPanel.Children.Add(Label("Language / اللغة · navigation & common actions", 13.0, Text));
		stackPanel.Children.Add(Spacer(8));
		stackPanel.Children.Add(lang);
		content.Children.Add(Card(stackPanel));
		AddSetting("Opening and closing sounds", "Short AZIZ sound cues.", settings.Sounds, delegate(bool v)
		{
			settings.Sounds = v;
		});
		AddSetting("Start with Windows", "AZIZ starts in the tray when you sign in (no admin prompt).", settings.StartWithWindows, delegate(bool v)
		{
			settings.StartWithWindows = v;
			settings.StartupPath = null;
			Task.Run(() => AppInstall.StartWithWindows(v));
			if (v)
			{
				settings.StartupPath = System.IO.Path.Combine(Program.Root, "AZIZGamingOptimizer.exe");
			}
		});
		AddSetting("Automatic memory cleaner", "Cleans RAM at 80% use and every hour, even with AZIZ closed (never touches the memory of a running game). Turned on by the first RAM clean.", settings.AutoMemoryClean, delegate(bool v)
		{
			settings.AutoMemoryClean = v;
			if (!v)
			{
				Task.Run(() => MemoryCleaner.Remove());
			}
		});
		AddSetting("Start minimized", "Start in the tray when you open AZIZ.", settings.StartMinimized, delegate(bool v)
		{
			settings.StartMinimized = v;
		});
		AddSetting("Keep running when closed", "Close hides the window. Use the tray menu to exit.", settings.CloseToTray, delegate(bool v)
		{
			settings.CloseToTray = v;
		});
		AddSetting("CPU and GPU temperatures on Home", "Show the temperature sensors next to CPU, GPU, RAM and CPU clock.", settings.ShowTemperatures, delegate(bool v)
		{
			settings.ShowTemperatures = v;
			viewCache.Remove("Home");
		});
		StackPanel stackPanel3 = Stack();
		stackPanel3.Children.Add(Label("AZIZ wallpaper", 15.0, Text));
		stackPanel3.Children.Add(Label("Dark violet and blue AZIZ backgrounds with the AZ mark, drawn at your screen's real resolution and shape (1080p, 1440p, 4K, ultrawide…), so it stays sharp. Optimize sets the official Horizon for you (or the one you picked here); use these buttons to put it back or switch.", 12.0, Muted));
		WrapPanel wallButtons = new WrapPanel
		{
			Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
		};
		for (int wallStyle = 0; wallStyle < Wallpaper.Styles.Length; wallStyle++)
		{
			int style = wallStyle;
			wallButtons.Children.Add(Btn("Set wallpaper · " + Wallpaper.Styles[style], delegate
			{
				settings.WallpaperPicked = true;
				ApplyWallpaper(style);
			}, style == (settings.WallpaperPicked ? settings.WallpaperStyle : 0)));
		}
		stackPanel3.Children.Add(wallButtons);
		content.Children.Add(Card(stackPanel3));
		StackPanel stackPanel4 = Stack();
		stackPanel4.Children.Add(Label("Home live readings · seconds", 15.0, Text));
		stackPanel4.Children.Add(Label("CPU, GPU and RAM update live only while Home is open and the window is not minimized. Other pages stop sampling. Controls refresh from Windows change notifications; only the page you are viewing is re-checked.", 12.0, Muted));
		System.Windows.Controls.ComboBox comboBox2 = new System.Windows.Controls.ComboBox();
		comboBox2.ItemsSource = new int[4] { 1, 2, 5, 10 };
		comboBox2.SelectedItem = settings.MonitorSeconds;
		comboBox2.Width = 150.0;
		comboBox2.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		comboBox2.Margin = new Thickness(0.0, 12.0, 0.0, 0.0);
		System.Windows.Controls.ComboBox intervals = comboBox2;
		intervals.SelectionChanged += delegate
		{
			settings.MonitorSeconds = (int)intervals.SelectedItem;
			SaveSettings();
			if (sampleTimer != null)
			{
				sampleTimer.Interval = TimeSpan.FromSeconds(settings.MonitorSeconds);
			}
		};
		stackPanel4.Children.Add(intervals);
		content.Children.Add(Card(stackPanel4));
		StackPanel stackPanel5 = Stack();
		stackPanel5.Children.Add(Label("Application maintenance", 16.0, Text));
		stackPanel5.Children.Add(Spacer(14));
		stackPanel5.Children.Add(Btn("Open local history & backups", delegate
		{
			OpenUri(Program.Data);
		}));
		stackPanel5.Children.Add(Spacer(10));
		stackPanel5.Children.Add(Btn("Uninstall AZIZ", UninstallSelf));
		stackPanel5.Children.Add(Spacer(10));
		stackPanel5.Children.Add(Label("Portable copy: close AZIZ and remove its folder. Playbook installation: removes only this app and its shortcuts; Windows tweaks and recovery snapshots stay in place.", 12.0, Muted));
		content.Children.Add(Card(stackPanel5));
	}

	private void AddSetting(string name, string desc, bool value, Action<bool> setter)
	{
		DockPanel dockPanel = new DockPanel();
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			IsChecked = value,
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(20.0, 0.0, 5.0, 0.0)
		};
		checkBox.Checked += delegate
		{
			setter(obj: true);
			SaveSettings();
		};
		checkBox.Unchecked += delegate
		{
			setter(obj: false);
			SaveSettings();
		};
		DockPanel.SetDock(checkBox, Dock.Right);
		dockPanel.Children.Add(checkBox);
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(name, 15.0, Text));
		stackPanel.Children.Add(Label(desc, 12.0, Muted));
		dockPanel.Children.Add(stackPanel);
		content.Children.Add(Card(dockPanel));
	}

	private void SaveSettings()
	{
		if (!preview)
		{
			settings.Save();
		}
	}

	private void ChangeTheme(string theme)
	{
		settings.Theme = theme;
		SaveSettings();
		SetPalette();
		RebuildShell();
	}

	private void RebuildShell()
	{
		ApplyBrandIcon();
		InvalidateViews();
		if (!optimizing)
		{
			optimizeHero = null;
		}
		viewReady = false;
		navButtons.Clear();
		BuildShell();
		Go(current);
	}

	private string WelcomeBackPath => System.IO.Path.Combine(Program.Data, "welcome-back.json");

	// Uninstall for both the installed and the portable copy. Optionally puts Windows back first (Windows Default).
	// Profiles, history and downloads stay; a later copy applies nothing by itself and asks "Welcome back" instead.
	private async void UninstallSelf()
	{
		if (preview || applying || optimizing || profileBusy)
		{
			if (optimizing || profileBusy)
			{
				Say("Wait until the current One Click or profile change has finished, then uninstall.");
			}
			return;
		}
		if (downloads.Any((DownloadJob x) => x.Running))
		{
			Say("Finish or cancel downloads before uninstalling AZIZ.");
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Uninstall AZIZ Gaming Optimizer?\n\nYes: put your Windows back first (Windows Default), then remove AZIZ.\nNo: remove AZIZ only; Windows keeps its current settings.\n\nYour profiles, history and downloads (Downloads\\AZIZ) are kept. Every AZIZ helper (Reflex limiter, memory cleaner, game watch, timer) is stopped and removed.", "Uninstall AZIZ", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
		if (messageBoxResult == MessageBoxResult.Cancel)
		{
			return;
		}
		string previousProfile = settings.ActiveProfile ?? "";
		SetActiveProfile(null);
		if (messageBoxResult == MessageBoxResult.Yes)
		{
			notice.Text = "Putting your Windows back…";
			Dictionary<string, string> values = ProfileValues("windows-default");
			// Registry set and startup apps first, then the options on top (same order as Windows Default).
			await Task.Run(() => StartupApps.RestoreAll());
			await Task.Run(() => RegistryJournal.RestoreAll());
			await Task.Run(() => TaskJournal.RestoreAll());
			foreach (Tweak item in engine.Tweaks.Where(Profileable).ToList())
			{
				if ((!states.TryGetValue(item.Id, out var value) || value.State != "Unavailable") && (RestoresOriginal("windows-default", item) || (values.TryGetValue(item.Id, out var value2) && ValueApplies(item, value2) && CurrentValue(item) != value2)))
				{
					values.TryGetValue(item.Id, out var value3);
					await QueueProfileValue("windows-default", item, value3);
				}
			}
			Stopwatch stopwatch = Stopwatch.StartNew();
			while ((pendingOrder.Count > 0 || workers > 0) && stopwatch.Elapsed.TotalMinutes < 10.0)
			{
				await Task.Delay(500);
			}
		}
		try
		{
			Utilities.AtomicWrite(WelcomeBackPath, Program.Json.Serialize(new Dictionary<string, string> { 
			{
				"Profile",
				previousProfile
			} }));
			if (File.Exists(ReferencePath))
			{
				File.Delete(ReferencePath);
			}
		}
		catch
		{
		}
		await Task.Run(delegate
		{
			AppInstall.Uninstall();
		});
		exitRequested = true;
		applying = false;
		System.Windows.Application.Current.Shutdown();
	}

	// After a reinstall: nothing was applied by itself; offer the profile the user had before.
	private bool WelcomeBack()
	{
		if (!File.Exists(WelcomeBackPath))
		{
			return false;
		}
		string key = null;
		try
		{
			Program.Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(WelcomeBackPath)).TryGetValue("Profile", out key);
			File.Delete(WelcomeBackPath);
		}
		catch
		{
		}
		if (string.IsNullOrEmpty(key) || (!ProfileLogic.BuiltIn(key) && !File.Exists(key)))
		{
			return true;
		}
		string name = ProfileName(key);
		ShowSheet(delegate(StackPanel panel, Action close)
		{
			TextBlock textBlock = Label("WELCOME BACK", 11.0, B("#5FD3F3"));
			textBlock.FontWeight = FontWeights.SemiBold;
			textBlock.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			panel.Children.Add(textBlock);
			TextBlock textBlock2 = Label("Welcome back to AZIZ", 26.0, System.Windows.Media.Brushes.White);
			textBlock2.FontWeight = FontWeights.SemiBold;
			textBlock2.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock2.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
			panel.Children.Add(textBlock2);
			TextBlock textBlock3 = Label("Nothing was changed on this PC. Last time you used " + name + ". Do you want to go back to your profile?", 13.0, B("#B7AEE6"));
			textBlock3.TextAlignment = TextAlignment.Center;
			textBlock3.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock3.MaxWidth = 560.0;
			panel.Children.Add(textBlock3);
			StackPanel stackPanel = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal,
				HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
				Margin = new Thickness(0.0, 20.0, 0.0, 4.0)
			};
			System.Windows.Controls.Button button = Btn("Use " + name, async delegate
			{
				close();
				await UseProfile(key);
			}, primary: true);
			button.Background = ProfileBrush();
			button.Foreground = System.Windows.Media.Brushes.White;
			button.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
			stackPanel.Children.Add(button);
			stackPanel.Children.Add(Btn("Not now", close));
			panel.Children.Add(stackPanel);
		}, 640.0);
		return true;
	}

	// Once per start, in the background: a newer AZIZ is offered; profiles, history and downloads are kept.
	private async void CheckForUpdate()
	{
		if (preview)
		{
			return;
		}
		await Task.Delay(15000);
		AppInstall.UpdateInfo info = await Task.Run(() => AppInstall.Check());
		if (info == null || closing)
		{
			return;
		}
		while (applying || pendingOrder.Count > 0 || workers > 0)
		{
			await Task.Delay(2000);
		}
		if (System.Windows.MessageBox.Show("AZIZ " + info.Version + " is available (you have " + AppVersion.Text + ")." + (string.IsNullOrEmpty(info.Notes) ? "" : ("\n\n" + info.Notes)) + "\n\nUpdate now? Your profiles, history and downloads stay.", "AZIZ update", MessageBoxButton.YesNo, MessageBoxImage.Information) != MessageBoxResult.Yes)
		{
			return;
		}
		ActionResult r = await Task.Run(() => AppInstall.Update(info, delegate(int pct)
		{
			base.Dispatcher.BeginInvoke((Action)delegate
			{
				notice.Text = "Downloading AZIZ " + info.Version + " · " + pct + "%";
			});
		}));
		notice.Text = r.Message;
		if (r.Success)
		{
			exitRequested = true;
			System.Windows.Application.Current.Shutdown();
		}
	}

	// First start: AZIZ starts with Windows (in the tray), a desktop shortcut is made, and close keeps it in the tray.
	private void FirstRunDefaults()
	{
		if (preview || !Program.IsAdmin)
		{
			return;
		}
		AppInstall.RegisterUninstall();
		string exe = System.IO.Path.Combine(Program.Root, "AZIZGamingOptimizer.exe");
		if (!settings.FirstRunDone)
		{
			settings.FirstRunDone = true;
			settings.StartWithWindows = true;
			settings.CloseToTray = true;
			SaveSettings();
			AppInstall.DesktopShortcut();
		}
		if (settings.StartWithWindows && !string.Equals(settings.StartupPath, exe, StringComparison.OrdinalIgnoreCase))
		{
			Task.Run(delegate
			{
				if (AppInstall.StartWithWindows(on: true).Success)
				{
					base.Dispatcher.BeginInvoke((Action)delegate
					{
						settings.StartupPath = exe;
						SaveSettings();
					});
				}
			});
		}
	}

	private static string PsQuote(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	private void RenderAbout()
	{
		content.Children.Clear();
		StackPanel stackPanel = Stack();
		TextBlock textBlock = Label("AZIZ GAMING OPTIMIZER", 30.0, Text);
		textBlock.FontWeight = FontWeights.Black;
		stackPanel.Children.Add(textBlock);
		stackPanel.Children.Add(Label("1.9.7 · Windows 10 / 11 x64", 14.0, B("#F5B700")));
		stackPanel.Children.Add(Spacer(14));
		stackPanel.Children.Add(Label("A light, careful optimizer for gamers: it reads your PC first, changes only what you choose, and always keeps a way back. Under 100 MB of RAM, idle when you are not looking at it.", 15.0, Muted));
		content.Children.Add(Card(stackPanel));
		UniformGrid uniformGrid = new UniformGrid();
		uniformGrid.Columns = 2;
		StackPanel stackPanel2 = Stack();
		TextBlock textBlock2 = Label("One app for the whole PC", 17.0, Text);
		textBlock2.FontWeight = FontWeights.SemiBold;
		stackPanel2.Children.Add(textBlock2);
		stackPanel2.Children.Add(Spacer(6));
		stackPanel2.Children.Add(Label("AZIZ Gaming Optimizer brings Windows tuning, services, network, security, power plans, drivers, debloating, downloads and live hardware readings into one place. Gamers get lower latency and steadier frame times; everyday users get a lighter, quieter and more private Windows; creators and engineers get a responsive system that stays out of the way. It replaces a folder full of separate scripts and tools.", 12.0, Muted));
		Border border = Card(stackPanel2);
		border.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border);
		StackPanel stackPanel3 = Stack();
		TextBlock textBlock3 = Label("It reads before it changes", 17.0, Text);
		textBlock3.FontWeight = FontWeights.SemiBold;
		stackPanel3.Children.Add(textBlock3);
		stackPanel3.Children.Add(Spacer(6));
		stackPanel3.Children.Add(Label("Every control reads its real state from Windows (registry, services, power plan, network adapters, boot options, drivers) before showing a switch, so what you see is what your PC is actually doing. Reads are direct and light: no background scripts, and only the page in front of you is re-checked. When AZIZ is hidden or minimized it goes idle.", 12.0, Muted));
		Border border2 = Card(stackPanel3);
		border2.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border2);
		StackPanel stackPanel4 = Stack();
		TextBlock textBlock4 = Label("Smart about your hardware", 17.0, Text);
		textBlock4.FontWeight = FontWeights.SemiBold;
		stackPanel4.Children.Add(textBlock4);
		stackPanel4.Children.Add(Spacer(6));
		stackPanel4.Children.Add(Label("AZIZ detects your CPU, graphics card, storage and Windows build and only offers what applies: AMD-only and NVIDIA-only settings, MSI mode for the main GPU, NVIDIA Profile Inspector presets, BIOS and chipset drivers for your board. Drivers this PC loads as disk or volume filters are never switched off by a preset, and important Windows services warn you with what would stop working.", 12.0, Muted));
		Border border3 = Card(stackPanel4);
		border3.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border3);
		StackPanel stackPanel5 = Stack();
		TextBlock textBlock5 = Label("Always a way back", 17.0, Text);
		textBlock5.FontWeight = FontWeights.SemiBold;
		stackPanel5.Children.Add(textBlock5);
		stackPanel5.Children.Add(Spacer(6));
		stackPanel5.Children.Add(Label("AZIZ never changes Windows by itself: nothing is applied until you press One Click or a control. The first time it opens it only saves your own Windows values as the Windows Default profile; the AZIZ Backup restore point is made right before your first change. Every change keeps its original value, every action is listed in History, and any profile can be restored, exported or shared.", 12.0, Muted));
		Border border4 = Card(stackPanel5);
		border4.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border4);
		StackPanel stackPanel6 = Stack();
		TextBlock textBlock6 = Label("Profiles for every user", 17.0, Text);
		textBlock6.FontWeight = FontWeights.SemiBold;
		stackPanel6.Children.Add(textBlock6);
		stackPanel6.Children.Add(Spacer(6));
		stackPanel6.Children.Add(Label("One Click gives Low Latency for everyday gaming or Ultra Low Latency for competitive play. Windows Default is your PC before AZIZ. Your own profile saves every change at once; the next start asks Keep or Restore for what changed, and Export asks the same.", 12.0, Muted));
		Border border5 = Card(stackPanel6);
		border5.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border5);
		StackPanel stackPanel7 = Stack();
		TextBlock textBlock7 = Label("One click, or full control", 17.0, Text);
		textBlock7.FontWeight = FontWeights.SemiBold;
		stackPanel7.Children.Add(textBlock7);
		stackPanel7.Children.Add(Spacer(6));
		stackPanel7.Children.Add(Label("Optimize your PC for Gaming applies a complete setup in one go: Windows, services, network, startup apps (only Process Lasso, RivaTuner, MSI Afterburner and AZIZ keep starting with Windows) and animations off. Toggles, Tweaks, Network, Services and Security change any single setting with its details. Scan & Debloat and Debloat Apps (Discord, Steam, browsers) remove what you do not need.", 12.0, Muted));
		Border border6 = Card(stackPanel7);
		border6.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border6);
		StackPanel stackPanel8 = Stack();
		TextBlock textBlock8 = Label("Built for games", 17.0, Text);
		textBlock8.FontWeight = FontWeights.SemiBold;
		stackPanel8.Children.Add(textBlock8);
		stackPanel8.Children.Add(Spacer(6));
		stackPanel8.Children.Add(Label("Reflex Fallback brings NVIDIA Reflex low latency and a smooth FPS limiter to older games without Reflex, applied live even while the game runs, with a small limiter by the clock and an optional FPS counter. Plus Competitive Mode, per-game profiles, timer resolution, NVIDIA drivers installed silently, power plans and curated downloads that install themselves.", 12.0, Muted));
		Border border7 = Card(stackPanel8);
		border7.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		uniformGrid.Children.Add(border7);
		content.Children.Add(uniformGrid);
		StackPanel stackPanel9 = Stack();
		stackPanel9.Children.Add(Label("Third-party software keeps its own ownership, licenses and notices. Results can vary by game, driver and device; settings that need a restart are marked in their details.", 12.0, Muted));
		stackPanel9.Children.Add(Btn("Third-party notices", delegate
		{
			OpenUri(System.IO.Path.Combine(Program.Root, "ThirdPartyNotices"));
		}));
		content.Children.Add(Card(stackPanel9));
	}

	private async Task EnsureGpuMsi()
	{
		try
		{
			GpuDevice d = await Task.Run(() => GpuInterrupt.Primary());
			// AMD processors: main GPU (NVIDIA or AMD) gets MSI, High priority and one specific processor (CPU 1, the second thread of core 0).
			bool amd = Engine.CpuVendor() == "AuthenticAMD" && Environment.ProcessorCount > 1 && Environment.ProcessorCount <= 64;
			bool msiOn = d != null && GpuInterrupt.Read(d, "MessageSignaledInterruptProperties", "MSISupported", 0) == 1;
			bool amdDone = d != null && GpuInterrupt.Read(d, "Affinity Policy", "DevicePriority", 0) == 3 && GpuInterrupt.Read(d, "Affinity Policy", "DevicePolicy", 0) == 4;
			if (d != null && (!msiOn || (amd && !amdDone)))
			{
				Tweak tweak = (amd ? GpuInterrupt.Profile(d, on: true, 3, 4, GpuInterrupt.Mask(new int[1] { 1 }, Environment.ProcessorCount)) : GpuInterrupt.MsiOnly(d));
				ActionResult actionResult = await Task.Run(() => engine.ApplyScoped(tweak, restore: false));
				Record("MSI mode for GPU", "Enable", d.Name, actionResult.Success ? (amd ? "MSI on · High priority · CPU 1 · restart to activate" : "MSI on · restart to activate") : "Unchanged", actionResult);
				DisplayHardware.Invalidate();
				ownChanges.Add("gpu-msi");
				await ScanAsync(new string[1] { "gpu-msi" });
				ownChanges.Remove("gpu-msi");
			}
		}
		catch (Exception ex)
		{
			Record("MSI mode for GPU", "Enable", "", "Unchanged", new ActionResult
			{
				Message = ex.Message
			});
		}
	}

	private async Task ConfigureGpuMsi(bool enable)
	{
		await BackupFirst();
		if (preview || applying)
		{
			return;
		}
		List<GpuDevice> list = await Task.Run(() => GpuInterrupt.Devices);
		if (list.Count == 0)
		{
			Say("No PCI GPU exposes a driver-provided MSISupported value. AZIZ does not invent MSI support for an unsupported device.");
			return;
		}
		Window window2 = new Window();
		window2.Owner = this;
		window2.Title = "GPU MSI · interrupt policy";
		window2.Width = 730.0;
		window2.Height = 650.0;
		window2.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window2.Background = new SolidColorBrush(Bg);
		Window window = window2;
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(24.0);
		stackPanel.Children.Add(Label("GPU MSI and interrupt policy", 22.0, Text));
		stackPanel.Children.Add(Label("A restart is required. Defaults leave routing to Windows. Unsupported driver changes can affect display stability; restore the saved values if needed.", 12.0, Muted));
		System.Windows.Controls.ComboBox comboBox = new System.Windows.Controls.ComboBox();
		comboBox.ItemsSource = list;
		comboBox.SelectedIndex = 0;
		comboBox.Margin = new Thickness(0.0, 18.0, 0.0, 14.0);
		System.Windows.Controls.ComboBox gpu = comboBox;
		stackPanel.Children.Add(gpu);
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox();
		checkBox.Content = "Enable MSI on selected GPU";
		checkBox.Foreground = Text;
		checkBox.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		System.Windows.Controls.CheckBox msi = checkBox;
		stackPanel.Children.Add(msi);
		System.Windows.Controls.ComboBox comboBox2 = new System.Windows.Controls.ComboBox();
		comboBox2.ItemsSource = new string[4] { "Default (Windows)", "Low", "Normal", "High" };
		comboBox2.SelectedIndex = 0;
		comboBox2.Margin = new Thickness(0.0, 7.0, 0.0, 15.0);
		System.Windows.Controls.ComboBox priority = comboBox2;
		stackPanel.Children.Add(Label("Device priority", 13.0, Text));
		stackPanel.Children.Add(priority);
		System.Windows.Controls.ComboBox comboBox3 = new System.Windows.Controls.ComboBox();
		comboBox3.ItemsSource = new string[6] { "Default (Windows)", "All close processors", "One close processor", "All processors", "Specific processors", "Spread messages" };
		comboBox3.SelectedIndex = 0;
		comboBox3.Margin = new Thickness(0.0, 7.0, 0.0, 15.0);
		System.Windows.Controls.ComboBox policy = comboBox3;
		stackPanel.Children.Add(Label("Interrupt affinity policy", 13.0, Text));
		stackPanel.Children.Add(policy);
		List<CpuUnit> topology = GameNative.CpuTopology();
		bool single = topology.All((CpuUnit x) => x.Group == 0) && topology.Count > 0 && topology.Max((CpuUnit x) => x.Index) < 64;
		UniformGrid uniformGrid = new UniformGrid();
		uniformGrid.Columns = 4;
		uniformGrid.Visibility = Visibility.Collapsed;
		UniformGrid coreGrid = uniformGrid;
		Dictionary<int, System.Windows.Controls.CheckBox> checks = new Dictionary<int, System.Windows.Controls.CheckBox>();
		foreach (CpuUnit item in topology.Where((CpuUnit x) => x.Group == 0))
		{
			System.Windows.Controls.CheckBox checkBox2 = new System.Windows.Controls.CheckBox
			{
				Content = item.ToString(),
				Foreground = Text,
				Margin = new Thickness(0.0, 5.0, 8.0, 5.0)
			};
			checks[item.Index] = checkBox2;
			coreGrid.Children.Add(checkBox2);
		}
		stackPanel.Children.Add(coreGrid);
		TextBlock detail = Label("", 11.0, Muted);
		stackPanel.Children.Add(detail);
		Action read = delegate
		{
			GpuDevice gpuDevice = (GpuDevice)gpu.SelectedItem;
			msi.IsChecked = GpuInterrupt.Read(gpuDevice, "MessageSignaledInterruptProperties", "MSISupported", 0) != 0;
			priority.SelectedIndex = Math.Max(0, Math.Min(3, GpuInterrupt.Read(gpuDevice, "Affinity Policy", "DevicePriority", 0)));
			policy.SelectedIndex = Math.Max(0, Math.Min(5, GpuInterrupt.Read(gpuDevice, "Affinity Policy", "DevicePolicy", 0)));
			detail.Text = "HKLM\\" + gpuDevice.BasePath + "\nMSISupported=" + GpuInterrupt.Read(gpuDevice, "MessageSignaledInterruptProperties", "MSISupported", 0);
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(gpuDevice.BasePath + "\\Affinity Policy");
			object obj = registryKey?.GetValue("AssignmentSetOverride");
			ulong num = ((obj is byte[]) ? BitConverter.ToUInt64(((byte[])obj).Concat(new byte[8]).Take(8).ToArray(), 0) : ((ulong)((obj is int) ? ((uint)(int)obj) : ((obj is long) ? ((long)obj) : 0))));
			foreach (KeyValuePair<int, System.Windows.Controls.CheckBox> item2 in checks)
			{
				item2.Value.IsChecked = (num & (ulong)(1L << item2.Key)) != 0;
			}
		};
		policy.SelectionChanged += delegate
		{
			coreGrid.Visibility = (Visibility)((policy.SelectedIndex != 4 || !single) ? 2u : 0u);
		};
		gpu.SelectionChanged += delegate
		{
			read();
		};
		read();
		msi.Checked += delegate
		{
			enable = true;
			System.Windows.Controls.ComboBox comboBox6 = priority;
			bool flag6 = (policy.IsEnabled = true);
			bool isEnabled3 = flag6;
			comboBox6.IsEnabled = isEnabled3;
		};
		msi.Unchecked += delegate
		{
			enable = false;
			System.Windows.Controls.ComboBox comboBox5 = priority;
			bool flag4 = (policy.IsEnabled = false);
			bool isEnabled2 = flag4;
			comboBox5.IsEnabled = isEnabled2;
		};
		enable = msi.IsChecked == true;
		System.Windows.Controls.ComboBox comboBox4 = priority;
		bool flag2 = (policy.IsEnabled = enable);
		bool isEnabled = flag2;
		comboBox4.IsEnabled = isEnabled;
		WrapPanel wrapPanel = new WrapPanel
		{
			Margin = new Thickness(0.0, 22.0, 0.0, 0.0)
		};
		Func<bool, Task> apply = async delegate(bool restore)
		{
			if (!applying)
			{
				try
				{
					if (!Program.IsAdmin)
					{
						Say("Run as administrator first.");
						return;
					}
					if (!restore && enable && policy.SelectedIndex == 4 && !single)
					{
						throw new InvalidOperationException("Specific affinity is not offered on multiple processor groups. Choose Windows default.");
					}
					byte[] mask = ((!restore && enable && policy.SelectedIndex == 4) ? GpuInterrupt.Mask(checks.Where(delegate(KeyValuePair<int, System.Windows.Controls.CheckBox> x)
					{
						KeyValuePair<int, System.Windows.Controls.CheckBox> keyValuePair2 = x;
						return keyValuePair2.Value.IsChecked == true;
					}).Select(delegate(KeyValuePair<int, System.Windows.Controls.CheckBox> x)
					{
						KeyValuePair<int, System.Windows.Controls.CheckBox> keyValuePair = x;
						return keyValuePair.Key;
					}), topology.Max((CpuUnit x) => x.Index) + 1) : null);
					GpuDevice d = (GpuDevice)gpu.SelectedItem;
					Tweak t = GpuInterrupt.Profile(d, enable, (!restore) ? priority.SelectedIndex : 0, (!restore) ? policy.SelectedIndex : 0, mask);
					applying = true;
					ActionResult actionResult = await Task.Run(() => engine.ApplyScoped(t, restore));
					read();
					TextBlock textBlock = detail;
					textBlock.Text = textBlock.Text + "\n" + actionResult.Message;
					Say(actionResult.Message);
					if (actionResult.Success)
					{
						DisplayHardware.Invalidate();
					}
				}
				catch (Exception ex)
				{
					Say(ex.Message);
				}
				finally
				{
					applying = false;
				}
				List<HistoryEntry> list2 = await Task.Run(() => engine.History().Concat(GameWatch.History()).ToList());
				cachedHistory = list2;
				ownChanges.Add("gpu-msi");
				await ScanAsync(new string[1] { "gpu-msi" });
				ownChanges.Remove("gpu-msi");
			}
		};
		wrapPanel.Children.Add(Btn("Apply selected GPU", async delegate
		{
			await apply(arg: false);
		}, primary: true));
		wrapPanel.Children.Add(Btn("Restore original", async delegate
		{
			await apply(arg: true);
		}));
		wrapPanel.Children.Add(Btn("Cancel", delegate
		{
			window.Close();
		}));
		stackPanel.Children.Add(wrapPanel);
		window.Content = new ScrollViewer
		{
			Content = stackPanel,
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto
		};
		DarkDialog(window);
		window.ShowDialog();
	}

	internal static string Clock(DateTime t)
	{
		DateTime today = DateTime.Today;
		return ((t.Date == today) ? "Today" : ((t.Date == today.AddDays(-1.0)) ? "Yesterday" : t.ToString("d MMM yyyy", English))) + " · " + t.ToString("h:mm tt", English);
	}

	private static DateTime? ParseTime(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		if (!DateTime.TryParseExact((text.Length > 19) ? text.Substring(0, 19) : text, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out var result) && !DateTime.TryParse(text, out result))
		{
			return null;
		}
		return result;
	}

	private static bool Meaningful(HistoryEntry h)
	{
		if (h.Action == "Observed change" || h.Action == "Startup comparison")
		{
			return h.Before != h.After;
		}
		return true;
	}

	private HashSet<string> historyNames;

	// History shows only switching an option of Toggles, Tweaks, Network, Security or Services on or off — no "Pending"
	// start lines, observed changes, scripts or other AZIZ work.
	private bool Shown(HistoryEntry h)
	{
		if (historyNames == null)
		{
			historyNames = new HashSet<string>(engine.Tweaks.Select((Tweak t) => t.Name), StringComparer.OrdinalIgnoreCase);
		}
		string action = h.Action ?? "";
		return historyNames.Contains(h.Name ?? "") && h.After != "Pending" && (action == "Enable" || action == "Disable" || action == "Restore original" || action.StartsWith("Set "));
	}

	private IEnumerable<HistoryEntry> HomeHistory()
	{
		return (from x in cachedHistory.Concat(observations).Where(Meaningful).Where(Shown)
			orderby ParseTime(x.Time) ?? DateTime.MinValue descending
			select x).Take(400);
	}

	private string HistoryText(HistoryEntry h)
	{
		DateTime? dateTime = ParseTime(h.Time);
		return (dateTime.HasValue ? Clock(dateTime.Value) : h.Time) + " · " + h.Name + "\n" + h.Action + (string.IsNullOrEmpty(h.After) ? "" : (" → " + h.After)) + (string.IsNullOrEmpty(h.Profile) ? "" : (" · profile " + h.Profile));
	}

	private System.Windows.Media.Brush ResultColor(HistoryEntry h)
	{
		string text = h.Result + " " + h.After;
		if (!text.StartsWith("Failed") && !text.Contains("Failed:") && !(h.After == "Failed") && !(h.After == "Kept") && !(h.After == "Unchanged"))
		{
			return Green;
		}
		return B("#F87171");
	}

	private FrameworkElement HistoryCard(HistoryEntry h, bool compact)
	{
		DateTime? dateTime = ParseTime(h.Time);
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		StackPanel stackPanel = Stack();
		TextBlock textBlock = Label(h.Name, compact ? 13 : 14, Text);
		textBlock.FontWeight = FontWeights.SemiBold;
		stackPanel.Children.Add(textBlock);
		WrapPanel wrapPanel = new WrapPanel
		{
			Margin = new Thickness(0.0, 4.0, 0.0, 0.0)
		};
		wrapPanel.Children.Add(Label(h.Action ?? "", 11.0, Purple));
		if (!string.IsNullOrEmpty(h.Before) || !string.IsNullOrEmpty(h.After))
		{
			wrapPanel.Children.Add(Label("   ·   ", 11.0, Muted));
			if (!string.IsNullOrEmpty(h.Before))
			{
				wrapPanel.Children.Add(Label(h.Before, 11.0, Muted));
				wrapPanel.Children.Add(Label("  →  ", 11.0, Muted));
			}
			wrapPanel.Children.Add(Label(h.After ?? "", 11.0, ResultColor(h)));
		}
		stackPanel.Children.Add(wrapPanel);
		string text = Utilities.CleanMessage(h.Result ?? "");
		if (text.StartsWith("Detected from Windows") || text.StartsWith("Read from Windows"))
		{
			text = "Changed outside AZIZ";
		}
		if (!compact && text.Length > 0)
		{
			TextBlock textBlock2 = Label((text.Length > 220) ? (text.Substring(0, 220) + "…") : text, 11.0, Muted);
			textBlock2.Margin = new Thickness(0.0, 4.0, 0.0, 0.0);
			textBlock2.ToolTip = text;
			stackPanel.Children.Add(textBlock2);
		}
		grid.Children.Add(stackPanel);
		StackPanel stackPanel2 = new StackPanel
		{
			HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
			Margin = new Thickness(12.0, 0.0, 0.0, 0.0)
		};
		TextBlock textBlock3 = Label(dateTime.HasValue ? Clock(dateTime.Value) : h.Time, 11.0, Muted);
		textBlock3.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
		textBlock3.TextWrapping = TextWrapping.NoWrap;
		stackPanel2.Children.Add(textBlock3);
		if (!string.IsNullOrEmpty(h.Profile))
		{
			Border border = new Border
			{
				Background = B("#252440"),
				CornerRadius = new CornerRadius(9.0),
				Padding = new Thickness(8.0, 2.0, 8.0, 2.0),
				Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
				HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
				Child = Label(h.Profile, 10.0, Cyan)
			};
			border.ToolTip = "Active profile at that moment";
			stackPanel2.Children.Add(border);
		}
		Grid.SetColumn(stackPanel2, 1);
		grid.Children.Add(stackPanel2);
		return new Border
		{
			Background = B("#111B2C"),
			BorderBrush = B("#233049"),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(9.0),
			Padding = new Thickness(14.0, 10.0, 14.0, 10.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 6.0),
			Child = grid
		};
	}

	private void FillHistory(StackPanel panel, IEnumerable<HistoryEntry> entries)
	{
		List<HistoryEntry> list = entries.ToList();
		if (list.Count == 0)
		{
			panel.Children.Add(Label("Your timeline starts with your first change.", 13.0, Muted));
			return;
		}
		foreach (IGrouping<DateTime, HistoryEntry> item in list.GroupBy(delegate(HistoryEntry h)
		{
			DateTime? dateTime = ParseTime(h.Time);
			return dateTime.HasValue ? dateTime.Value.Date : DateTime.MinValue;
		}))
		{
			TextBlock textBlock = Label((item.Key == DateTime.MinValue) ? "Earlier" : ((item.Key == DateTime.Today) ? "Today" : ((item.Key == DateTime.Today.AddDays(-1.0)) ? "Yesterday" : item.Key.ToString("dddd, d MMMM yyyy", English))), 12.0, Purple);
			textBlock.Margin = new Thickness(2.0, 12.0, 0.0, 8.0);
			panel.Children.Add(textBlock);
			foreach (HistoryEntry item2 in item)
			{
				panel.Children.Add(HistoryCard(item2, compact: false));
			}
		}
	}

	private void ShowHistory()
	{
		ShowPanel("History", delegate(StackPanel panel)
		{
			DockPanel dockPanel = new DockPanel
			{
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			};
			System.Windows.Controls.Button button = Btn("Export", delegate
			{
				Export("AZIZ-history.json", Program.Json.Serialize(HomeHistory().ToList()));
			});
			DockPanel.SetDock(button, Dock.Right);
			dockPanel.Children.Add(button);
			StackPanel stackPanel = Stack();
			stackPanel.Children.Add(Label("History", 22.0, Text));
			stackPanel.Children.Add(Label("Every change with its time, what it changed and the profile that was active.", 12.0, Muted));
			dockPanel.Children.Add(stackPanel);
			panel.Children.Add(dockPanel);
			FillHistory(panel, HomeHistory().Take(300));
		}, 900.0, 700.0);
	}

	private async Task RefreshGames()
	{
		if (gameScanning || closing)
		{
			return;
		}
		gameScanning = true;
		try
		{
			games = (from x in (await Task.Run(() => GameDiscovery.Scan())).Concat(ReadManualGames()).Concat(games.Where((GameEntry x) => x.Library == "Manual"))
				group x by x.Target into g
				select g.First()).ToList();
			InvalidateViews();
			if (current == "Home" && !gameOptions && !preparingInterface)
			{
				RenderOverview();
			}
		}
		catch (Exception ex)
		{
			notice.Text = "Game library scan: " + ex.Message;
		}
		finally
		{
			gameScanning = false;
		}
	}

	private void AddGamingPanel()
	{
		AddCompetitivePanel();
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("Shader cache cleaner", 17.0, Text));
		stackPanel.Children.Add(Label("DirectX · NVIDIA · AMD. Removes cached shaders only; locked files are skipped. Games rebuild shaders on their next launch.", 12.0, Muted));
		stackPanel.Children.Add(Spacer(12));
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		stackPanel2.Children.Add(Btn("Clean shader cache", CleanCache, primary: true));
		stackPanel2.Children.Add(Btn("Disk cleanup", ShowDiskCleanup));
		stackPanel2.Children.Add(Btn("Timer Resolution Test", ToggleTimer));
		stackPanel.Children.Add(stackPanel2);
		stackPanel.Children.Add(Spacer(8));
		stackPanel.Children.Add(Label("The 0.5 ms request lasts while AZIZ is running. The five-second test measures this process only; other games can use a different effective resolution.", 11.0, Muted));
		content.Children.Add(Card(stackPanel));
	}

	private async void CleanCache()
	{
		if (preview || applying)
		{
			return;
		}
		CacheResult scan = await Task.Run(() => ShaderCache.ProcessRoots(ShaderCache.Roots(), remove: false));
		if (System.Windows.MessageBox.Show(string.Concat("Clean ", scan, "?\n\nClose games first. The next game launch can stutter while shaders rebuild. Personal files and game installations are not included."), "Shader cache", MessageBoxButton.OKCancel) != MessageBoxResult.OK)
		{
			return;
		}
		applying = true;
		try
		{
			CacheResult cacheResult = await Task.Run(() => ShaderCache.ProcessRoots(ShaderCache.Roots(), remove: true));
			notice.Text = cacheResult.ToString();
			Record("Shader cache", "Clean", scan.ToString(), cacheResult.ToString(), new ActionResult
			{
				Success = true,
				Message = cacheResult.ToString()
			});
		}
		finally
		{
			applying = false;
		}
	}

	private void RenderShortcuts()
	{
		content.Children.Clear();
		foreach (IGrouping<string, ShortcutItem> item2 in from x in Utilities.Catalog<ShortcutItem>("shortcuts.json")
			group x by x.Category)
		{
			TextBlock textBlock = Label(item2.Key, 14.0, Purple);
			textBlock.Margin = new Thickness(0.0, 12.0, 0.0, 12.0);
			content.Children.Add(textBlock);
			UniformGrid uniformGrid = new UniformGrid
			{
				Columns = 3
			};
			foreach (ShortcutItem item in item2)
			{
				Grid grid = new Grid();
				grid.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = new GridLength(36.0)
				});
				grid.ColumnDefinitions.Add(new ColumnDefinition());
				grid.Children.Add(Label((item.Kind == "Uri") ? "▣" : "⚙", 22.0, Cyan));
				StackPanel stackPanel = Stack();
				stackPanel.Children.Add(Label(item.Name, 14.0, Text));
				TextBlock textBlock2 = Label(item.Description, 11.0, Muted);
				textBlock2.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
				stackPanel.Children.Add(textBlock2);
				Grid.SetColumn(stackPanel, 1);
				grid.Children.Add(stackPanel);
				System.Windows.Controls.Button button = Btn("", delegate
				{
					LaunchShortcut(item);
				});
				button.Content = grid;
				button.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Stretch;
				button.Background = B("#111B2C");
				button.MinHeight = 90.0;
				button.Margin = new Thickness(0.0, 0.0, 12.0, 12.0);
				button.Padding = new Thickness(16.0);
				uniformGrid.Children.Add(button);
			}
			content.Children.Add(uniformGrid);
		}
	}

	private void LaunchShortcut(ShortcutItem item)
	{
		if (preview)
		{
			return;
		}
		try
		{
			string text = Environment.ExpandEnvironmentVariables(item.Target);
			string arguments = item.Arguments ?? "";
			if (item.Kind == "Mmc")
			{
				arguments = "\"" + text + "\"";
				text = "mmc.exe";
			}
			else if (item.Kind == "ControlPanel")
			{
				arguments = text;
				text = "control.exe";
			}
			else if (item.Kind == "Folder")
			{
				arguments = "\"" + text + "\"";
				text = "explorer.exe";
			}
			else if (item.Kind == "ElevatedNotepad")
			{
				arguments = "\"" + text + "\"";
				text = "notepad.exe";
			}
			Process.Start(new ProcessStartInfo(text, arguments)
			{
				UseShellExecute = true,
				Verb = ((item.Elevate || item.Kind == "ElevatedNotepad") ? "runas" : "")
			});
		}
		catch (Exception ex)
		{
			notice.Text = ex.Message;
		}
	}

	private void AddRestoreApps()
	{
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("Restore Windows components", 21.0, Text));
		stackPanel.Children.Add(Label("Recover apps through Microsoft's package manager. Core components use DISM and Windows Update. Repair may need a matching Windows installation source if files were removed from the component store.", 12.0, Muted));
		stackPanel.Children.Add(Spacer(12));
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		stackPanel2.Children.Add(Btn("Repair component store (DISM)", async delegate
		{
			await RunRecovery("Repair the Windows component store", () => Recovery.Repair(null));
		}, primary: true));
		stackPanel2.Children.Add(Btn("Restore OneDrive", async delegate
		{
			await RunRecovery("Reinstall OneDrive", () => Recovery.InstallDesktop("Microsoft.OneDrive"));
		}));
		stackPanel2.Children.Add(Btn("Restore Edge", async delegate
		{
			await RunRecovery("Reinstall Edge", () => Recovery.InstallDesktop("Microsoft.Edge"));
		}));
		stackPanel2.Children.Add(Btn("Windows recovery options", delegate
		{
			OpenUri("ms-settings:recovery");
		}));
		stackPanel.Children.Add(stackPanel2);
		content.Children.Add(Card(stackPanel));
		AddServiceRecovery();
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 3
		};
		RestoreApp[] apps = Recovery.Apps;
		foreach (RestoreApp item in apps)
		{
			StackPanel stackPanel3 = Stack();
			stackPanel3.Children.Add(Label(item.Name, 15.0, Text));
			stackPanel3.Children.Add(Label("Microsoft Store package", 11.0, Muted));
			stackPanel3.Children.Add(Spacer(12));
			UIElementCollection children = stackPanel3.Children;
			string title = L("Restore");
			Action action = async delegate
			{
				await RunRecovery("Restore " + item.Name, () => Recovery.Install(item));
			};
			children.Add(Btn(title, action));
			Border border = Card(stackPanel3);
			border.Padding = new Thickness(16.0);
			border.Margin = new Thickness(0.0, 0.0, 12.0, 12.0);
			uniformGrid.Children.Add(border);
		}
		content.Children.Add(uniformGrid);
		content.Children.Add(Spacer(18));
	}

	private void AddServiceRecovery()
	{
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("Restore removed services", 18.0, Text));
		string path = System.IO.Path.Combine(Program.Data, "UltraLite");
		List<string> files = new List<string>();
		try
		{
			if (Directory.Exists(path))
			{
				files = (from g in Directory.GetFiles(path, "*.reg", SearchOption.AllDirectories).GroupBy((string f) => System.IO.Path.GetFileNameWithoutExtension(f), StringComparer.OrdinalIgnoreCase)
					select g.OrderByDescending(File.GetLastWriteTime).First() into f
					orderby System.IO.Path.GetFileNameWithoutExtension(f)
					select f).ToList();
			}
		}
		catch
		{
		}
		stackPanel.Children.Add(Label((files.Count == 0) ? "No service was removed by Deep Debloat on this PC." : (files.Count + " services were removed by Deep Debloat. Each one comes back from the registry backup saved before removal; restart Windows afterwards."), 12.0, Muted));
		Func<string, ActionResult> import = delegate(string file)
		{
			// The backups sit in the user's folder and reg.exe imports with admin rights: a file is only imported when every
			// key in it belongs to the one service it is named after.
			if (!ServiceBackupOnly(file))
			{
				return new ActionResult
				{
					Message = "This backup contains keys outside its service and was not imported."
				};
			}
			ActionResult actionResult = Utilities.Run("reg.exe", "import \"" + file + "\"");
			return new ActionResult
			{
				Success = actionResult.Success,
				Message = (actionResult.Success ? "Restored from backup · restart Windows to start it." : actionResult.Message)
			};
		};
		if (files.Count > 0)
		{
			System.Windows.Controls.Button button = Btn("Restore all " + files.Count, async delegate
			{
				await RunRecovery("Restore " + files.Count + " removed services", delegate
				{
					List<string> list2 = (from f in files
						select new
						{
							f = f,
							r = import(f)
						} into x
						where !x.r.Success
						select System.IO.Path.GetFileNameWithoutExtension(x.f)).ToList();
					return new ActionResult
					{
						Success = (list2.Count == 0),
						Message = ((list2.Count == 0) ? "All services restored · restart Windows." : ("Not restored: " + string.Join(", ", list2)))
					};
				});
			}, primary: true);
			button.Margin = new Thickness(0.0, 12.0, 0.0, 8.0);
			button.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
			stackPanel.Children.Add(button);
			WrapPanel wrapPanel = new WrapPanel();
			foreach (string item in files)
			{
				string f2 = item;
				string name = System.IO.Path.GetFileNameWithoutExtension(item);
				System.Windows.Controls.Button button2 = Btn(name, async delegate
				{
					await RunRecovery("Restore service " + name, () => import(f2));
				});
				button2.Margin = new Thickness(0.0, 0.0, 6.0, 6.0);
				button2.ToolTip = "Restore " + name + " from " + f2;
				wrapPanel.Children.Add(button2);
			}
			stackPanel.Children.Add(wrapPanel);
		}
		WrapPanel wrapPanel2 = new WrapPanel
		{
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
		};
		Tweak update = engine.Tweaks.FirstOrDefault((Tweak x) => x.Id == "windows-update");
		if (update != null)
		{
			wrapPanel2.Children.Add(Btn("Turn Windows Update back on", delegate
			{
				Enqueue(update, enabled: true, null);
			}));
		}
		Tweak search = engine.Tweaks.FirstOrDefault((Tweak x) => x.Id == "search-indexing");
		if (search != null)
		{
			wrapPanel2.Children.Add(Btn("Turn Search indexing back on", delegate
			{
				Enqueue(search, enabled: true, null);
			}));
		}
		wrapPanel2.Children.Add(Btn("Services: Windows Default", async delegate
		{
			List<Tweak> list = engine.Tweaks.Where((Tweak t) => t.Kind == "Service" && engine.CanRestore(t.Id) && engine.MatchesOriginal(t.Id) == false).ToList();
			if (list.Count == 0)
			{
				notice.Text = "Every service already has its original start type.";
			}
			else if (System.Windows.MessageBox.Show("Put " + list.Count + " services back to how this PC had them before AZIZ?", "Services", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
			{
				foreach (Tweak item2 in list)
				{
					Enqueue(item2, enabled: true, null, restore: true);
				}
				await Task.FromResult(0);
			}
		}));
		stackPanel.Children.Add(wrapPanel2);
		content.Children.Add(Card(stackPanel));
	}

	private async Task RunRecovery(string name, Func<ActionResult> action)
	{
		if (preview || applying)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
		}
		else if (System.Windows.MessageBox.Show(name + "?\n\nThis may download files from Microsoft and can take several minutes. An internet connection and available Windows sources are required.", "Component recovery", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
		{
			applying = true;
			notice.Text = name + "…";
			try
			{
				ActionResult actionResult = await Task.Run(action);
				Record(name, "Recovery", "Requested", actionResult.Success ? "Completed" : "Failed", actionResult);
				notice.Text = (actionResult.Success ? "Recovery completed. Rescanning Windows…" : "Recovery did not complete. See History.");
				Say((actionResult.Message.Length > 2400) ? actionResult.Message.Substring(actionResult.Message.Length - 2400) : actionResult.Message, "Recovery result");
			}
			finally
			{
				applying = false;
			}
			await ScanAsync();
		}
	}

	private void StartLiveState()
	{
		DispatcherTimer dispatcherTimer = new DispatcherTimer(DispatcherPriority.Background);
		dispatcherTimer.Interval = TimeSpan.FromSeconds(30.0);
		liveStateTimer = dispatcherTimer;
		liveStateTimer.Tick += async delegate
		{
			await RefreshLiveState();
		};
		liveStateTimer.Start();
		base.Activated += async delegate
		{
			// Options that changed while another window was in front are read now.
			CatchUpPage();
			await RefreshLiveState();
		};
		base.Closed += delegate
		{
			liveStateTimer.Stop();
		};
	}

	private async Task RefreshLiveState()
	{
		if (preview || closing || applying || scanning || preparingInterface || !WindowLive || !base.IsActive || !IsTweakPage(current) || (DateTime.UtcNow - lastLiveRead).TotalSeconds < 20.0)
		{
			return;
		}
		lastLiveRead = DateTime.UtcNow;
		try
		{
			List<string> visible = (tweakHosts.ContainsKey(current) ? tweakHosts[current].Keys.ToList() : (from t in engine.Tweaks.Where(CategoryMatch)
				select t.Id).ToList());
			string[] array = (from t in engine.Tweaks
				where visible.Contains(t.Id) && !pendingChanges.ContainsKey(t.Id) && (t.Kind == "Timer" || t.Kind == "PowerSwitch" || t.Kind == "PowerConfigure" || t.Kind == "Service" || t.Kind == "GpuMsi" || t.Kind == "SystemRestore" || t.Kind.StartsWith("Nvidia") || !string.IsNullOrEmpty(t.ProbeScript))
				select t.Id).ToArray();
			if (array.Length != 0)
			{
				// The display device list is kept: the values themselves are read live, and a manual Refresh re-enumerates.
				await ScanAsync(array, freshRead: false);
			}
		}
		catch (Exception ex)
		{
			notice.Text = "Windows state refresh: " + ex.Message;
		}
	}

	private void AddMemoryCup(System.Windows.Controls.Panel parent)
	{
		StackPanel stackPanel = Stack();
		// No caption: the flask sits a little higher and near the middle of the card.
		Grid grid = new Grid
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 6.0),
			HorizontalAlignment = System.Windows.HorizontalAlignment.Center
		};
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(50.0)
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		// Glass flask: violet-to-cyan liquid with a soft highlight; click it to clean RAM.
		Grid grid2 = new Grid
		{
			Width = 30.0,
			Height = 54.0,
			VerticalAlignment = VerticalAlignment.Center
		};
		Border border2 = new Border
		{
			CornerRadius = new CornerRadius(8.0, 8.0, 14.0, 14.0),
			Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(40, 160, 140, 255)),
			ClipToBounds = true
		};
		Grid grid3 = new Grid
		{
			ClipToBounds = true
		};
		memoryFill = new Border
		{
			Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(150, 110, 255), System.Windows.Media.Color.FromRgb(60, 190, 235), 90.0),
			VerticalAlignment = VerticalAlignment.Bottom,
			Height = 0.0,
			CornerRadius = new CornerRadius(3.0, 3.0, 12.0, 12.0),
			Margin = new Thickness(3.0)
		};
		grid3.Children.Add(memoryFill);
		grid3.Children.Add(new Border
		{
			Width = 6.0,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
			Margin = new Thickness(6.0, 8.0, 0.0, 12.0),
			CornerRadius = new CornerRadius(3.0),
			Background = new LinearGradientBrush(System.Windows.Media.Color.FromArgb(110, byte.MaxValue, byte.MaxValue, byte.MaxValue), System.Windows.Media.Color.FromArgb(0, byte.MaxValue, byte.MaxValue, byte.MaxValue), 90.0)
		});
		border2.Child = grid3;
		grid2.Children.Add(border2);
		grid2.Children.Add(new Border
		{
			CornerRadius = new CornerRadius(8.0, 8.0, 14.0, 14.0),
			BorderThickness = new Thickness(2.0),
			BorderBrush = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(190, 170, byte.MaxValue), System.Windows.Media.Color.FromRgb(90, 70, 200), 90.0)
		});
		grid.Children.Add(grid2);
		StackPanel stackPanel2 = Stack();
		Grid.SetColumn(stackPanel2, 1);
		stackPanel2.VerticalAlignment = VerticalAlignment.Center;
		TextBlock textBlock = Label("—", 22.0, B("#B9A6FF"));
		metrics["RAM"] = textBlock;
		stackPanel2.Children.Add(textBlock);
		memoryAmount = Label("—", 11.0, Muted);
		metrics["memory"] = memoryAmount;
		stackPanel2.Children.Add(memoryAmount);
		grid.Children.Add(stackPanel2);
		stackPanel.Children.Add(grid);
		TextBlock hint = Label(MemoryCleaner.KnownInstalled ? "Click to clean · auto clean on" : "Click to clean memory", 10.0, Muted);
		hint.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		stackPanel.Children.Add(hint);
		Border border = Card(stackPanel);
		border.Padding = new Thickness(12.0, 9.0, 12.0, 9.0);
		border.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		border.Cursor = System.Windows.Input.Cursors.Hand;
		border.ToolTip = "Clean RAM: every app gives back unused memory and the standby list is cleared (no defrag). Your installed games are never touched, even while they run. The first clean also turns on the automatic cleaner: at 80% RAM and every hour, even with AZIZ closed or a game running.";
		bool busy = false;
		border.MouseLeftButtonUp += async delegate
		{
			if (busy || preview)
			{
				return;
			}
			if (!Program.IsAdmin)
			{
				Elevate();
				return;
			}
			busy = true;
			hint.Text = "Cleaning…";
			ActionResult actionResult = await Task.Run(() => MemoryCleaner.Clean(full: true));
			string text = actionResult.Message;
			if (actionResult.Success && settings.AutoMemoryClean && !(await Task.Run(() => MemoryCleaner.Installed())))
			{
				ActionResult actionResult2 = await Task.Run(() => MemoryCleaner.Install());
				Record("Memory cleaner", "Automatic cleaner", "", actionResult2.Success ? "On" : "Failed", actionResult2);
				text = text + (actionResult2.Success ? " · auto clean on (80% RAM and hourly)" : "");
			}
			Record("Memory cleaner", "Clean RAM", "", text, actionResult);
			hint.Text = text;
			busy = false;
		};
		parent.Children.Add(border);
		UpdateMemoryCup();
	}

	private void UpdateMemoryCup()
	{
		if (lastSample != null)
		{
			if (metrics.TryGetValue("memory", out var value))
			{
				value.Text = lastSample.MemoryText;
			}
			if (memoryFill != null && lastSample.Ram.HasValue)
			{
				double toValue = Math.Max(0.0, Math.Min(100.0, lastSample.Ram.Value)) * 46.0 / 100.0;
				// RAM moves a fraction of a pixel most seconds: animate (a layout pass per frame) only for a visible change.
				if (Math.Abs(toValue - memoryFill.ActualHeight) >= 1.0)
				{
					memoryFill.BeginAnimation(FrameworkElement.HeightProperty, new DoubleAnimation(toValue, new Duration(TimeSpan.FromMilliseconds(240.0))));
				}
			}
			if (metrics.TryGetValue("RAM", out var value2))
			{
				value2.Text = (lastSample.Ram.HasValue ? (lastSample.Ram.Value.ToString("0") + "%") : "—");
			}
		}
	}

	private void ShowNvidiaDrivers()
	{
		if (preview)
		{
			return;
		}
		ShowPanel("NVIDIA · Game Ready drivers", delegate(StackPanel p)
		{
			p.Children.Add(Label("NVIDIA Graphics Driver", 24.0, Text));
			p.Children.Add(Label("Game Ready drivers from NVIDIA for your GPU (566.36 and newer), found even on a fresh Windows without a driver. Install now does everything by itself, silently; Download saves the installer where you choose. The screen can blink once while installing.", 12.0, Muted));
			TextBlock info = Label("Detecting GPU…", 13.0, Cyan);
			p.Children.Add(info);
			System.Windows.Controls.ComboBox series = new System.Windows.Controls.ComboBox
			{
				DisplayMemberPath = "Name",
				Margin = new Thickness(0.0, 14.0, 0.0, 8.0)
			};
			System.Windows.Controls.ComboBox products = new System.Windows.Controls.ComboBox
			{
				DisplayMemberPath = "Name",
				Margin = new Thickness(0.0, 0.0, 0.0, 10.0)
			};
			p.Children.Add(series);
			p.Children.Add(products);
			System.Windows.Controls.Button search = Btn("Find matching drivers", delegate
			{
			}, primary: true);
			p.Children.Add(search);
			StackPanel rows = Stack();
			p.Children.Add(rows);
			CancellationTokenSource cancellation = new CancellationTokenSource();
			p.Unloaded += delegate
			{
				cancellation.Cancel();
			};
			bool selecting = false;
			bool found = false;
			Func<Task> find = null;
			int selectionVersion = 0;
			series.SelectionChanged += async delegate
			{
				if (selecting || series.SelectedItem == null)
				{
					return;
				}
				int version = ++selectionVersion;
				try
				{
					products.ItemsSource = null;
					List<DriverOption> itemsSource = await NvidiaDrivers.Options(3, ((DriverOption)series.SelectedItem).Id, cancellation.Token);
					if (version == selectionVersion)
					{
						products.ItemsSource = itemsSource;
					}
				}
				catch (OperationCanceledException)
				{
				}
				catch (Exception ex6)
				{
					info.Text = ex6.Message;
				}
			};
			Func<Task> obj = async delegate
			{
				search.IsEnabled = false;
				try
				{
					// The GPU name and the official series list are read at the same time, not one after the other.
					Task<List<DriverOption>> allTask = NvidiaDrivers.Options(2, "1", cancellation.Token);
					string gpuName = await Task.Run(() => DisplayHardware.NvidiaName());
					if (gpuName == null)
					{
						info.Text = "No NVIDIA GPU was detected.";
					}
					else
					{
						info.Text = gpuName + " · reading official product lists…";
						// Same GPU as last time: the releases, the series list and the product list are read together, at once.
						string[] known = NvidiaDrivers.Remembered(gpuName);
						if (known != null)
						{
							NvidiaDrivers.Search(known[0], known[1], cancellation.Token);
						}
						Task<List<DriverOption>> knownProducts = ((known != null) ? NvidiaDrivers.Options(3, known[0], cancellation.Token) : null);
						List<DriverOption> all = await allTask;
						series.ItemsSource = all;
						Tuple<DriverOption, List<DriverOption>> detected = null;
						if (known != null && all.Any((DriverOption x) => x.Id == known[0]))
						{
							try
							{
								List<DriverOption> list3 = await knownProducts;
								DriverOption driverOption2 = list3.FirstOrDefault((DriverOption x) => x.Id == known[1]);
								if (driverOption2 != null)
								{
									driverOption2.Parent = known[0];
									detected = Tuple.Create(driverOption2, list3);
								}
							}
							catch (OperationCanceledException)
							{
								throw;
							}
							catch
							{
							}
						}
						if (detected == null)
						{
							detected = await NvidiaDrivers.Detect(gpuName, all, cancellation.Token);
						}
						if (detected == null)
						{
							info.Text = "Choose the exact product; an automatic match was not found for " + gpuName;
						}
						else
						{
							selecting = true;
							series.SelectedItem = all.First((DriverOption x) => x.Id == detected.Item1.Parent);
							products.ItemsSource = detected.Item2;
							products.SelectedItem = detected.Item1;
							info.Text = "Detected: " + gpuName + " · Windows x64";
							NvidiaDrivers.Remember(gpuName, detected.Item1.Parent, detected.Item1.Id);
							found = true;
						}
					}
				}
				catch (OperationCanceledException)
				{
				}
				catch (Exception ex4)
				{
					info.Text = ex4.Message;
				}
				finally
				{
					selecting = false;
					search.IsEnabled = true;
				}
				// Detected: the driver list opens by itself (before, it waited for "Find matching drivers").
				if (found)
				{
					await find();
				}
			};
			search.Click += async delegate
			{
				await find();
			};
			find = async delegate
			{
				DriverOption driverOption = series.SelectedItem as DriverOption;
				DriverOption pf = products.SelectedItem as DriverOption;
				if (driverOption == null || pf == null)
				{
					info.Text = "Select the exact product series and GPU.";
					return;
				}
				search.IsEnabled = false;
				rows.Children.Clear();
				try
				{
					info.Text = "Reading current and archived Game Ready releases…";
					List<NvidiaRelease> list = await NvidiaDrivers.Search(driverOption.Id, pf.Id, cancellation.Token);
					info.Text = list.Count + " matching Game Ready releases · " + pf.Name;
					foreach (NvidiaRelease item in list)
					{
						AddDriverRelease(rows, item);
					}
				}
				catch (OperationCanceledException)
				{
				}
				catch (Exception ex2)
				{
					info.Text = ex2.Message;
				}
				finally
				{
					search.IsEnabled = true;
				}
			};
			obj();
		}, 920.0, 690.0);
	}

	private static DownloadItem InspectorItem(bool newest)
	{
		return new DownloadItem
		{
			Id = (newest ? "nvidia-profile-latest" : "nvidia-profile-24031"),
			Name = "NVIDIA Profile Inspector",
			Publisher = "Orbmu2k",
			FileName = (newest ? "NVIDIA-Profile-Inspector-Latest.zip" : "NVIDIA-Profile-Inspector-2.4.0.31.zip"),
			Portable = true,
			Archive = "zip",
			EntryExe = "nvidiaProfileInspector.exe",
			Repo = (newest ? "Orbmu2k/nvidiaProfileInspector" : null),
			Pattern = "^nvidiaProfileInspector\\.zip$",
			DirectUrl = (newest ? null : "https://github.com/Orbmu2k/nvidiaProfileInspector/releases/download/2.4.0.31/nvidiaProfileInspector.zip")
		};
	}

	private async Task<string> PrepareInspector(bool newest, TextBlock status)
	{
		DownloadItem item = InspectorItem(newest);
		DownloadJob job = downloads.LastOrDefault((DownloadJob x) => x.Item.Id == item.Id && x.State == "Completed" && File.Exists(x.FilePath)) ?? DownloadLibrary.LoadJob(item);
		if (job == null)
		{
			job = new DownloadJob
			{
				Item = item
			};
			downloads.Add(job);
			await DownloadManager.Run(job, delegate
			{
				base.Dispatcher.BeginInvoke((Action)delegate
				{
					status.Text = "Downloading Profile Inspector · " + ((job.Total > 0) ? (((double)job.Bytes * 100.0 / (double)job.Total.Value).ToString("0") + "%") : job.State);
				});
			});
			if (job.State != "Completed")
			{
				throw new IOException(job.Error ?? job.State);
			}
			DownloadLibrary.Remember(job);
		}
		DownloadJob ready = job;
		return await Task.Run(() => DownloadLibrary.Prepare(ready));
	}

	private async Task<string> FirstImport(TextBlock status)
	{
		if (NvidiaProfilePreset.Imported)
		{
			return null;
		}
		status.Text = "First use · importing AZIZ Ultra Low Latency into the global NVIDIA profile…";
		try
		{
			string text = await Task.Run(() => NvidiaProfilePreset.Import());
			Record("NVIDIA profile", "Import AZIZ Ultra Low Latency", "Driver defaults", "Imported", new ActionResult
			{
				Success = true,
				Message = text
			});
			return text;
		}
		catch (Exception ex)
		{
			return "Import failed, nothing was changed: " + ex.Message;
		}
	}

	private WrapPanel VersionChoice(out Func<bool> newest)
	{
		WrapPanel obj = new WrapPanel
		{
			Margin = new Thickness(0.0, 10.0, 0.0, 6.0)
		};
		System.Windows.Controls.RadioButton latest = new System.Windows.Controls.RadioButton
		{
			Content = "Latest version",
			GroupName = "inspector",
			Foreground = Text,
			Margin = new Thickness(0.0, 0.0, 18.0, 0.0),
			IsChecked = (settings.InspectorVersion != "2.4.0.31")
		};
		System.Windows.Controls.RadioButton radioButton = new System.Windows.Controls.RadioButton
		{
			Content = "NVIDIA Profile Inspector 2.4.0.31",
			GroupName = "inspector",
			Foreground = Text,
			IsChecked = (settings.InspectorVersion == "2.4.0.31")
		};
		obj.Children.Add(latest);
		obj.Children.Add(radioButton);
		newest = delegate
		{
			settings.InspectorVersion = ((latest.IsChecked == true) ? "latest" : "2.4.0.31");
			SaveSettings();
			return latest.IsChecked == true;
		};
		return obj;
	}

	private void ShowNvidiaProfile()
	{
		if (preview)
		{
			return;
		}
		ShowPanel("NVIDIA Profile", delegate(StackPanel p)
		{
			p.Children.Add(Label("NVIDIA Profile", 22.0, Text));
			p.Children.Add(Label(NvidiaProfilePreset.Imported ? "The AZIZ Ultra Low Latency profile is already imported. Open just opens the inspector so you can keep tuning; Import again is separate." : "Choose a version. The first Open imports AZIZ Ultra Low Latency into the global NVIDIA profile, verifies it, then opens the inspector. Later opens never import again. No shortcut is created.", 12.0, Muted));
			p.Children.Add(VersionChoice(out var newest));
			TextBlock status = Label("", 12.0, Cyan);
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 8.0, 0.0, 8.0)
			};
			System.Windows.Controls.Button open = BrandBtn("Open", delegate
			{
			}, primary: true);
			wrapPanel.Children.Add(open);
			wrapPanel.Children.Add(Btn("Import again", async delegate
			{
				if (openingProfile || System.Windows.MessageBox.Show("Re-apply AZIZ Ultra Low Latency to the global NVIDIA profile? Your later edits to the same settings are overwritten.", "NVIDIA profile", MessageBoxButton.OKCancel) != MessageBoxResult.OK)
				{
					return;
				}
				openingProfile = true;
				try
				{
					TextBlock obj = status;
					obj.Text = await Task.Run(() => NvidiaProfilePreset.Import());
				}
				catch (Exception ex2)
				{
					status.Text = ex2.Message;
				}
				finally
				{
					openingProfile = false;
				}
			}));
			p.Children.Add(wrapPanel);
			p.Children.Add(status);
			open.Click += async delegate
			{
				if (openingProfile)
				{
					return;
				}
				openingProfile = true;
				open.IsEnabled = false;
				try
				{
					bool newest2 = newest();
					string exe = await PrepareInspector(newest2, status);
					string text = await FirstImport(status);
					Process.Start(new ProcessStartInfo(exe)
					{
						UseShellExecute = true,
						WorkingDirectory = System.IO.Path.GetDirectoryName(exe)
					});
					status.Text = "Profile Inspector opened · no shortcut created." + ((text != null) ? ("\n" + text) : "");
				}
				catch (Exception ex)
				{
					status.Text = ex.Message;
				}
				finally
				{
					openingProfile = false;
					open.IsEnabled = true;
				}
			};
		}, 720.0, 400.0);
	}

	private void ShowProfilePerGame()
	{
		if (preview)
		{
			return;
		}
		ShowPanel("Profile per game", delegate(StackPanel p)
		{
			p.Children.Add(Label("Profile per game", 22.0, Text));
			p.Children.Add(Label("Pick a game found on this PC. AZIZ finds its NVIDIA driver profile, creates one from the game's EXE when NVIDIA has none, then opens Profile Inspector on that game. The first time also imports AZIZ Ultra Low Latency into the global profile.", 12.0, Muted));
			p.Children.Add(VersionChoice(out var newest));
			System.Windows.Controls.TextBox filter = new System.Windows.Controls.TextBox
			{
				Width = 320.0,
				HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
				Margin = new Thickness(0.0, 8.0, 0.0, 8.0)
			};
			p.Children.Add(WithPlaceholder(filter, "Find a game…"));
			TextBlock status = Label("", 12.0, Cyan);
			p.Children.Add(status);
			StackPanel list = Stack();
			p.Children.Add(list);
			Action draw = delegate
			{
				list.Children.Clear();
				List<GameEntry> list2 = (from g in games
					where !string.IsNullOrEmpty(g.Exe) && File.Exists(g.Exe) && g.Name.IndexOf(filter.Text, StringComparison.OrdinalIgnoreCase) >= 0
					orderby g.Name
					select g).ToList();
				if (list2.Count == 0)
				{
					list.Children.Add(Label((games.Count == 0) ? "No games detected yet. Use Rescan games on Home or add a game EXE there." : "No game matches.", 12.0, Muted));
				}
				foreach (GameEntry item in list2)
				{
					GameEntry g2 = item;
					DockPanel dockPanel = new DockPanel();
					System.Windows.Controls.Button go = Btn("Open profile", delegate
					{
					}, primary: true);
					DockPanel.SetDock(go, Dock.Right);
					dockPanel.Children.Add(go);
					StackPanel stackPanel = Stack();
					stackPanel.Children.Add(Label(g2.Name, 14.0, Text));
					stackPanel.Children.Add(Label(g2.Library + " · " + System.IO.Path.GetFileName(g2.Exe), 11.0, Muted));
					dockPanel.Children.Add(stackPanel);
					Border border = Card(dockPanel);
					border.Padding = new Thickness(12.0);
					border.Margin = new Thickness(0.0, 0.0, 0.0, 6.0);
					list.Children.Add(border);
					go.Click += async delegate
					{
						if (openingProfile)
						{
							return;
						}
						openingProfile = true;
						go.IsEnabled = false;
						try
						{
							bool latest = newest();
							string exe = await PrepareInspector(latest, status);
							string text = await FirstImport(status);
							if (text != null)
							{
								notice.Text = "NVIDIA profile: " + text;
							}
							status.Text = "Finding the NVIDIA profile for " + g2.Name + "…";
							string profile = await Task.Run(() => NvidiaProfilePreset.EnsureGameProfile(g2.Name, g2.Exe));
							Process.Start(new ProcessStartInfo(exe)
							{
								UseShellExecute = true,
								WorkingDirectory = System.IO.Path.GetDirectoryName(exe)
							});
							status.Text = "Opening Profile Inspector on " + profile + "…";
							bool flag = await Task.Run(delegate
							{
								IntPtr intPtr = InspectorWindow.WaitForWindow(exe, 25);
								if (intPtr == IntPtr.Zero)
								{
									return false;
								}
								Thread.Sleep(latest ? 2500 : 1500);
								return InspectorWindow.DropFile(intPtr, g2.Exe);
							});
							status.Text = (flag ? ("Profile Inspector is showing “" + profile + "”.") : ("Profile “" + profile + "” is ready · choose it in Profile Inspector's profile list."));
						}
						catch (Exception ex)
						{
							status.Text = ex.Message;
						}
						finally
						{
							openingProfile = false;
							go.IsEnabled = true;
						}
					};
				}
			};
			filter.TextChanged += delegate
			{
				draw();
			};
			draw();
		}, 760.0, 640.0);
	}

	// "DX11 Fullscreen": violet outline pill (design A2), opens the per-game fullscreen settings.
	private Border DxButton()
	{
		SolidColorBrush rest = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0, 150, 120, 255));
		SolidColorBrush hover = new SolidColorBrush(System.Windows.Media.Color.FromArgb(34, 150, 120, 255));
		Border border = new Border
		{
			Height = 46.0,
			Width = 240.0,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
			Margin = new Thickness(0.0, 4.0, 0.0, 14.0),
			CornerRadius = new CornerRadius(23.0),
			BorderThickness = new Thickness(2.0),
			BorderBrush = new SolidColorBrush(System.Windows.Media.Color.FromRgb(150, 120, 255)),
			Background = rest,
			Cursor = System.Windows.Input.Cursors.Hand,
			ToolTip = "DirectX 11 and earlier · per-game fullscreen settings",
			Child = new TextBlock
			{
				Text = "DX11 True Fullscreen Exclusive",
				FontSize = 14.0,
				FontWeight = FontWeights.SemiBold,
				Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(205, 190, 255)),
				HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
				VerticalAlignment = VerticalAlignment.Center
			}
		};
		border.MouseEnter += delegate
		{
			border.Background = hover;
		};
		border.MouseLeave += delegate
		{
			border.Background = rest;
		};
		border.MouseLeftButtonUp += delegate
		{
			ShowOlderGames();
		};
		return border;
	}

	private void ShowOlderGames()
	{
		if (preview)
		{
			return;
		}
		ShowPanel("DX11 True Fullscreen Exclusive", delegate(StackPanel p)
		{
			p.Children.Add(Label("Disable fullscreen optimizations · per game", 22.0, Text));
			p.Children.Add(Label("For DirectX 11 and earlier / legacy presentation games, select the actual game EXE. This compatibility flag cannot force an unsupported exclusive presentation mode. On adds DISABLEDXMAXIMIZEDWINDOWEDMODE; Off removes only that flag. Existing compatibility flags are preserved. Windows default has no override. Restart the game after changing it.", 12.0, Muted));
			HashSet<string> paths = new HashSet<string>(games.Select((GameEntry x) => x.Exe).Where(AppLauncher.ValidExe), StringComparer.OrdinalIgnoreCase);
			try
			{
				foreach (string item in Program.Json.Deserialize<List<string>>(File.ReadAllText(System.IO.Path.Combine(Program.Data, "older-games.json"))))
				{
					if (AppLauncher.ValidExe(item))
					{
						paths.Add(item);
					}
				}
			}
			catch
			{
			}
			StackPanel rows = Stack();
			Action draw = null;
			draw = delegate
			{
				rows.Children.Clear();
				foreach (string exe in paths)
				{
					bool on = (OlderGameCompatibility.Read(exe) ?? "").Split(' ').Any((string x) => x.Equals("DISABLEDXMAXIMIZEDWINDOWEDMODE", StringComparison.OrdinalIgnoreCase));
					DockPanel dockPanel = new DockPanel();
					WrapPanel wrapPanel = new WrapPanel();
					System.Windows.Controls.Button button = Btn(on ? "ON · Disable FSO" : "OFF · Windows default", delegate
					{
					});
					button.Background = (on ? Accent : B("#526075"));
					button.Foreground = System.Windows.Media.Brushes.White;
					button.Click += async delegate
					{
						if (!applying)
						{
							if (Program.IsAdmin)
							{
								applying = true;
								try
								{
									Tweak profile2 = OlderGameCompatibility.Profile(exe, !on);
									ActionResult actionResult = await Task.Run(() => engine.ApplyScoped(profile2, restore: false));
									if (!actionResult.Success)
									{
										Say(actionResult.Message);
									}
									List<HistoryEntry> list = await Task.Run(() => engine.History().Concat(GameWatch.History()).ToList());
									cachedHistory = list;
									draw();
									InvalidateViews();
									return;
								}
								finally
								{
									applying = false;
								}
							}
							Say("Run AZIZ as administrator.");
						}
					};
					wrapPanel.Children.Add(button);
					System.Windows.Controls.Button button2 = Btn("Restore original", delegate
					{
					});
					button2.Click += async delegate
					{
						if (applying)
						{
							return;
						}
						applying = true;
						try
						{
							Tweak profile = OlderGameCompatibility.Profile(exe, on);
							Say((await Task.Run(() => engine.ApplyScoped(profile, restore: true))).Message);
							draw();
							InvalidateViews();
						}
						finally
						{
							applying = false;
						}
					};
					wrapPanel.Children.Add(button2);
					DockPanel.SetDock(wrapPanel, Dock.Right);
					dockPanel.Children.Add(wrapPanel);
					dockPanel.Children.Add(Label(System.IO.Path.GetFileName(exe) + "\n" + exe, 12.0, Text));
					rows.Children.Add(Card(dockPanel));
				}
			};
			p.Children.Add(Btn("Choose game EXE", delegate
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
				{
					Filter = "Game executable|*.exe"
				};
				if (openFileDialog.ShowDialog() == true)
				{
					paths.Add(openFileDialog.FileName);
					Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "older-games.json"), Program.Json.Serialize(paths.ToList()));
					draw();
				}
			}));
			p.Children.Add(Spacer(14));
			p.Children.Add(rows);
			draw();
		}, 950.0, 600.0);
	}

	public async Task InitializeAsync(Action<string, int> progress = null)
	{
		if (initialized)
		{
			return;
		}
		initialized = true;
		preparingInterface = true;
		Stopwatch total = Stopwatch.StartNew();
		Action<string, int> report = delegate(string s, int p)
		{
			if (progress != null)
			{
				progress(s, p);
			}
		};
		report("Reading Windows settings and installed apps…", 8);
		Engine.ActiveProfileName = ProfileName(ActiveKey);
		try
		{
			if (!preview)
			{
				try
				{
					states = Program.Json.Deserialize<Dictionary<string, TweakStatus>>(File.ReadAllText(System.IO.Path.Combine(Program.Data, "last-states.json")));
				}
				catch
				{
				}
			}
			StartBiosDetection();
			if (!preview)
			{
				Task.Run(delegate
				{
					CompetitiveLaunch.Restore();
					GameWatch.RestoreLeftover();
				});
				Task.Run(delegate
				{
					TimerService.EnsureRunning();
					GameWatch.EnsureRunning();
				});
			}
			Task<MachineInfo> systemTask = Task.Run(() => telemetry.Inspect());
			Task<Dictionary<string, TweakStatus>> scanTask = Task.Run(delegate
			{
				ServiceInventory.Merge(engine.Tweaks);
				return engine.Scan();
			});
			Task task = RefreshInventory();
			Task<List<GameEntry>> gamesTask = Task.Run(() => GameDiscovery.Scan());
			Task assetsTask = Task.Run(delegate
			{
				cachedPowerPlans = Utilities.PowerPlans();
				DownloadLibrary.Migrate();
				MemoryCleaner.Installed();
				downloads = DownloadLibrary.LoadJobs();
				Utilities.Catalog<ShortcutItem>("shortcuts.json");
				Utilities.Catalog<BundledPlan>("power-plans.json");
				cachedHistory = engine.History().Concat(GameWatch.History()).ToList();
			});
			await task;
			report("Installed applications read · preparing launch targets…", 28);
			Task<List<LaunchEntry>> launchTask = Task.Run(() => AppLauncher.Discover(cachedDesktop, cachedStore));
			await Task.WhenAll(systemTask, scanTask, gamesTask, assetsTask, launchTask);
			machine = systemTask.Result;
			games = (from x in gamesTask.Result.Concat(ReadManualGames())
				group x by x.Target into g
				select g.First()).ToList();
			installedLaunchers = launchTask.Result;
			ApplyObserved(scanTask.Result, "Startup comparison");
			StartupTimings["readWindowsAppsGamesMs"] = total.Elapsed.TotalMilliseconds;
			report("Reading hardware sensors…", 60);
			await ReadSample();
			report("Preparing interface and controls…", 70);
			Stopwatch layout = Stopwatch.StartNew();
			viewReady = false;
			viewCache.Clear();
			string[] pages = new string[14]
			{
				"Home", "Toggles", "Tweaks", "Network", "Power plans", "Services", "Security", "Tools", "Downloads", "Uninstaller",
				"Shortcuts", "Favorites", "About", "Settings"
			};
			for (int i = 0; i < pages.Length; i++)
			{
				Go(pages[i]);
				FrameworkElement obj2 = (FrameworkElement)base.Content;
				obj2.Measure(new System.Windows.Size(base.Width, base.Height));
				obj2.Arrange(new Rect(0.0, 0.0, base.Width, base.Height));
				obj2.UpdateLayout();
				report("Preparing interface · " + pages[i], 70 + (i + 1) * 27 / pages.Length);
				await base.Dispatcher.BeginInvoke(DispatcherPriority.Background, (Action)delegate
				{
				});
			}
			Go("Home");
			StartupTimings["prepareInterfaceMs"] = layout.Elapsed.TotalMilliseconds;
			sampleTimer = new DispatcherTimer(DispatcherPriority.Normal)
			{
				Interval = TimeSpan.FromSeconds(Math.Max(1, settings.MonitorSeconds))
			};
			sampleTimer.Tick += async delegate
			{
				await ReadSample();
			};
			if (base.IsVisible)
			{
				sampleTimer.Start();
			}
			if (!preview)
			{
				StartRegistryWatch();
				StartLiveState();
				StartPrewarm();
			}
			report("Ready to open", 100);
		}
		finally
		{
			preparingInterface = false;
			StartupTimings["totalMs"] = total.Elapsed.TotalMilliseconds;
		}
		if (preview)
		{
			return;
		}
		try
		{
			await Task.Run(delegate
			{
				Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "startup-performance.json"), Program.Json.Serialize(StartupTimings));
			});
		}
		catch
		{
		}
	}

	private void ApplyObserved(Dictionary<string, TweakStatus> fresh, string source)
	{
		foreach (KeyValuePair<string, TweakStatus> item in fresh)
		{
			Dictionary<string, TweakStatus> dictionary = states;
			KeyValuePair<string, TweakStatus> keyValuePair = item;
			if (dictionary.TryGetValue(keyValuePair.Key, out var value))
			{
				string state = value.State;
				KeyValuePair<string, TweakStatus> keyValuePair2 = item;
				if (state != keyValuePair2.Value.State && value.State != "Unknown")
				{
					KeyValuePair<string, TweakStatus> keyValuePair3 = item;
					if (keyValuePair3.Value.State != "Unknown")
					{
						Tweak tweak = engine.Tweaks.FirstOrDefault(delegate(Tweak x)
						{
							string id = x.Id;
							KeyValuePair<string, TweakStatus> keyValuePair8 = item;
							return id == keyValuePair8.Key;
						});
						List<HistoryEntry> list = observations;
						HistoryEntry historyEntry = new HistoryEntry
						{
							Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
						};
						string name;
						if (tweak != null)
						{
							name = tweak.Name;
						}
						else
						{
							KeyValuePair<string, TweakStatus> keyValuePair4 = item;
							name = keyValuePair4.Key;
						}
						historyEntry.Name = name;
						historyEntry.Action = source;
						historyEntry.Before = value.State;
						KeyValuePair<string, TweakStatus> keyValuePair5 = item;
						historyEntry.After = keyValuePair5.Value.State;
						historyEntry.Result = "Changed while AZIZ was closed";
						historyEntry.Profile = ProfileName(ActiveKey);
						list.Insert(0, historyEntry);
					}
				}
			}
			Dictionary<string, TweakStatus> dictionary2 = states;
			KeyValuePair<string, TweakStatus> keyValuePair6 = item;
			string key = keyValuePair6.Key;
			KeyValuePair<string, TweakStatus> keyValuePair7 = item;
			dictionary2[key] = keyValuePair7.Value;
		}
		if (!preview)
		{
			SaveObservations();
			Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "last-states.json"), Program.Json.Serialize(states));
		}
		scanLabel.Text = "Read · " + DateTime.Now.ToString("h:mm tt", English);
	}

	private void SaveView()
	{
		if (viewReady)
		{
			viewCache[current] = new ViewSnapshot
			{
				Panel = content,
				Metrics = new Dictionary<string, TextBlock>(metrics),
				Traces = new Dictionary<string, Polyline>(traces)
			};
		}
	}

	private bool RestoreView(string page)
	{
		if ((!IsTweakPage(page) || string.IsNullOrEmpty(search.Text)) && viewCache.TryGetValue(page, out var value))
		{
			scroll.Content = null;
			content = value.Panel;
			scroll.Content = content;
			metrics = new Dictionary<string, TextBlock>(value.Metrics);
			traces = new Dictionary<string, Polyline>(value.Traces);
			viewReady = true;
			return true;
		}
		content = Stack();
		scroll.Content = content;
		viewReady = true;
		return false;
	}

	private void InvalidateViews()
	{
		viewCache.Clear();
	}

	private void StartPrewarm()
	{
		if (!preview && prewarm == null)
		{
			DispatcherTimer dispatcherTimer = new DispatcherTimer(DispatcherPriority.ApplicationIdle);
			dispatcherTimer.Interval = TimeSpan.FromMilliseconds(600.0);
			prewarm = dispatcherTimer;
			prewarm.Tick += delegate
			{
				Prewarm();
			};
			prewarm.Start();
		}
	}

	private void Prewarm()
	{
		if (closing || !viewReady || !string.IsNullOrEmpty(search.Text) || base.WindowState == WindowState.Minimized || !base.IsVisible)
		{
			return;
		}
		string text = WarmPages.FirstOrDefault((string p) => p != current && !viewCache.ContainsKey(p));
		// Every page ready: look again only every few seconds (a page is rebuilt after its cache is dropped).
		prewarm.Interval = TimeSpan.FromMilliseconds((text == null) ? 5000.0 : 600.0);
		if (text == null)
		{
			return;
		}
		StackPanel stackPanel = content;
		string text2 = current;
		Dictionary<string, TextBlock> dictionary = metrics;
		Dictionary<string, Polyline> dictionary2 = traces;
		double verticalOffset = scroll.VerticalOffset;
		try
		{
			content = Stack();
			current = text;
			metrics = new Dictionary<string, TextBlock>();
			traces = new Dictionary<string, Polyline>();
			if (IsTweakPage(text))
			{
				RenderTweaks();
			}
			else
			{
				switch (text)
				{
				case "Downloads":
					RenderDownloads();
					break;
				case "Tools":
					RenderTools();
					break;
				case "Power plans":
					RenderPower();
					break;
				}
			}
			viewCache[text] = new ViewSnapshot
			{
				Panel = content,
				Metrics = metrics,
				Traces = traces
			};
		}
		catch
		{
		}
		finally
		{
			content = stackPanel;
			current = text2;
			metrics = dictionary;
			traces = dictionary2;
			scroll.ScrollToVerticalOffset(verticalOffset);
		}
	}

	private async Task RefreshPowerPlans()
	{
		cachedPowerPlans = await Task.Run(() => Utilities.PowerPlans());
		viewCache.Remove("Power plans");
	}

	private async Task RefreshLaunchers()
	{
		await RefreshInventory();
		installedLaunchers = await Task.Run(() => AppLauncher.Discover(cachedDesktop, cachedStore));
		viewCache.Remove("Downloads");
	}

	private void SmoothWheel(object sender, MouseWheelEventArgs e)
	{
		if (!(scroll.ScrollableHeight <= 0.0))
		{
			e.Handled = true;
			if (!wheelActive)
			{
				wheelTarget = scroll.VerticalOffset;
				lastFrame = TimeSpan.Zero;
				CompositionTarget.Rendering += AnimateWheel;
				wheelActive = true;
			}
			if (Math.Sign(wheelTarget - scroll.VerticalOffset) == Math.Sign(e.Delta))
			{
				wheelTarget = scroll.VerticalOffset;
			}
			wheelTarget = Math.Max(0.0, Math.Min(scroll.ScrollableHeight, wheelTarget - (double)e.Delta * 0.85));
		}
	}

	private void AnimateWheel(object sender, EventArgs e)
	{
		RenderingEventArgs renderingEventArgs = (RenderingEventArgs)e;
		if (!(lastFrame == renderingEventArgs.RenderingTime))
		{
			double seconds = ((lastFrame == TimeSpan.Zero) ? (1.0 / 60.0) : (renderingEventArgs.RenderingTime - lastFrame).TotalSeconds);
			lastFrame = renderingEventArgs.RenderingTime;
			wheelTarget = Math.Max(0.0, Math.Min(scroll.ScrollableHeight, wheelTarget));
			scroll.ScrollToVerticalOffset(ScrollMotion.Next(scroll.VerticalOffset, wheelTarget, seconds));
			if (Math.Abs(wheelTarget - scroll.VerticalOffset) < 0.6)
			{
				StopWheel();
			}
		}
	}

	private void StopWheel()
	{
		if (wheelActive)
		{
			CompositionTarget.Rendering -= AnimateWheel;
			wheelActive = false;
		}
		wheelTarget = ((scroll == null) ? 0.0 : scroll.VerticalOffset);
		lastFrame = TimeSpan.Zero;
	}

	private void StartRegistryWatch()
	{
		registryWatch = new RegistryChangeWatch(engine.Tweaks, delegate(string[] ids)
		{
			base.Dispatcher.BeginInvoke((Action)delegate
			{
				string[] array = ids;
				foreach (string item in array)
				{
					pendingRegistry.Add(item);
				}
				if (changeDebounce == null)
				{
					changeDebounce = new DispatcherTimer(DispatcherPriority.Background)
					{
						Interval = TimeSpan.FromMilliseconds(850.0)
					};
					changeDebounce.Tick += async delegate
					{
						if (!applying && !scanning)
						{
							changeDebounce.Stop();
							string[] changed = pendingRegistry.ToArray();
							pendingRegistry.Clear();
							if (!WindowLive)
							{
								dirtyIds.UnionWith(changed);
							}
							else
							{
								if (changed.Contains("@apps"))
								{
									if (current == "Downloads" || current == "Uninstaller")
									{
										await RefreshLaunchers();
										if (current == "Downloads")
										{
											RenderDownloads();
										}
									}
									else
									{
										dirtyIds.Add("@apps");
									}
								}
								if (changed.Contains("nvidia-hdcp") || changed.Contains("gpu-msi"))
								{
									DisplayHardware.Invalidate();
								}
								HashSet<string> onPage = VisibleControlIds();
								// While another window is in front, options read through PowerShell wait until AZIZ is used again:
								// service and device writes happen all the time and would start PowerShell again and again.
								bool active = base.IsActive;
								Func<string, bool> heavy = delegate(string x)
								{
									Tweak tweak = engine.Tweaks.FirstOrDefault((Tweak t) => t.Id == x);
									return tweak != null && !string.IsNullOrWhiteSpace(tweak.ProbeScript);
								};
								string[] array2 = changed.Where((string x) => x != "@apps" && onPage.Contains(x) && (active || !heavy(x))).ToArray();
								dirtyIds.UnionWith(changed.Where((string x) => x != "@apps" && (!onPage.Contains(x) || (!active && heavy(x)))));
								if (array2.Length != 0)
								{
									await ScanAsync(array2, freshRead: false);
								}
							}
						}
					};
				}
				changeDebounce.Stop();
				changeDebounce.Start();
			});
		});
	}

	private HashSet<string> VisibleControlIds()
	{
		if (!IsTweakPage(current) || !tweakHosts.ContainsKey(current))
		{
			return new HashSet<string>();
		}
		return new HashSet<string>(tweakHosts[current].Keys);
	}

	private async void CatchUpPage()
	{
		if (!preview && WindowLive && dirtyIds.Count != 0)
		{
			if (dirtyIds.Remove("@apps") && (current == "Downloads" || current == "Uninstaller"))
			{
				await RefreshLaunchers();
			}
			HashSet<string> hashSet = VisibleControlIds();
			string[] array = dirtyIds.Where(hashSet.Contains).ToArray();
			if (array.Length != 0)
			{
				dirtyIds.ExceptWith(array);
				await ScanAsync(array, freshRead: false);
			}
		}
	}

	private void ConfigurePower(Tweak tweak)
	{
		if (preview)
		{
			return;
		}
		ShowPanel(tweak.Name, delegate(StackPanel p)
		{
			p.Children.Add(Label(tweak.Name, 23.0, Text));
			p.Children.Add(Label("Values for the active power plan. AC = plugged in; DC = battery. Maximum frequency 0 removes the frequency cap. Windows and firmware still control thermal and power limits.", 12.0, Muted));
			TextBlock status = Label("Reading Windows…", 12.0, Cyan);
			p.Children.Add(status);
			StackPanel rows = Stack();
			p.Children.Add(rows);
			PowerSnapshot loaded = null;
			Dictionary<string, Func<PowerValue>> inputs = new Dictionary<string, Func<PowerValue>>();
			WrapPanel actions = new WrapPanel();
			p.Children.Add(actions);
			Action<PowerSnapshot> show = delegate(PowerSnapshot snapshot)
			{
				loaded = snapshot;
				rows.Children.Clear();
				inputs.Clear();
				foreach (PowerValue value in snapshot.Values)
				{
					PowerParameter parameter = PowerControls.Parameter(value.Key);
					StackPanel stackPanel = Stack();
					stackPanel.Children.Add(Label(parameter.Name + " " + parameter.Units, 15.0, Text));
					WrapPanel pair = new WrapPanel
					{
						Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
					};
					Func<uint, Func<uint>> func = delegate(uint current)
					{
						pair.Children.Add(Label((pair.Children.Count == 0) ? "AC" : "DC", 12.0, Muted));
						if (value.Key == "cpu-boost-mode" || value.Key == "usb3-link-power")
						{
							string[] labels = ((!(value.Key == "cpu-boost-mode")) ? new string[4] { "Off", "Minimum power savings", "Moderate power savings", "Maximum power savings" } : new string[7] { "Disabled", "Enabled", "Aggressive", "Efficient Enabled", "Efficient Aggressive", "Aggressive At Guaranteed", "Efficient Aggressive At Guaranteed" });
							List<TweakChoice> list = ((value.Key == "cpu-boost-mode") ? CpuBoostCapabilities.Modes() : new uint[4] { 0u, 1u, 2u, 3u }).Select((uint n) => new TweakChoice
							{
								Value = n.ToString(),
								Label = labels[n]
							}).ToList();
							System.Windows.Controls.ComboBox combo = new System.Windows.Controls.ComboBox
							{
								Width = 260.0,
								Margin = new Thickness(10.0, 0.0, 18.0, 0.0),
								ItemsSource = list,
								DisplayMemberPath = "Label",
								SelectedItem = list.FirstOrDefault((TweakChoice c) => c.Value == current.ToString())
							};
							combo.ToolTip = "Current Windows index: " + current;
							pair.Children.Add(combo);
							return () => (combo.SelectedItem == null) ? current : uint.Parse(((TweakChoice)combo.SelectedItem).Value);
						}
						System.Windows.Controls.TextBox input = new System.Windows.Controls.TextBox
						{
							Text = current.ToString(),
							Width = 140.0,
							Margin = new Thickness(10.0, 0.0, 18.0, 0.0)
						};
						pair.Children.Add(input);
						return delegate
						{
							if (!uint.TryParse(input.Text, out var result) || result > parameter.Maximum)
							{
								throw new ArgumentException(parameter.Name + ": enter 0–" + parameter.Maximum + ".");
							}
							return result;
						};
					};
					Func<uint> ac = func(value.AC);
					Func<uint> dc = func(value.DC);
					inputs[value.Key] = () => new PowerValue
					{
						Key = value.Key,
						AC = ac(),
						DC = dc()
					};
					stackPanel.Children.Add(pair);
					rows.Children.Add(Card(stackPanel));
				}
				status.Text = "Read from Windows · " + snapshot.Scheme.ToString("D");
			};
			if (tweak.Id == "cpu-boost-settings")
			{
				p.Children.Add(Label("Efficient modes are offered only when EPB hardware support is confirmed and Windows lists them. Windows may treat some boost modes alike; a higher setting does not guarantee higher clock speed.", 11.0, Muted));
			}
			Action reload = delegate
			{
				try
				{
					show(PowerControls.Read(tweak.Id));
				}
				catch (Exception ex3)
				{
					status.Text = ex3.Message;
					loaded = null;
					rows.Children.Clear();
					inputs.Clear();
				}
			};
			Func<bool, Task> apply = async delegate(bool restore)
			{
				if (!applying && loaded != null)
				{
					if (!Program.IsAdmin)
					{
						Say("Run AZIZ as administrator to change power settings.");
					}
					else
					{
						try
						{
							if (loaded.Scheme != PowerControls.Store.Active())
							{
								throw new InvalidOperationException("The active power plan changed. Click Refresh before applying.");
							}
							PowerSnapshot target = new PowerSnapshot
							{
								Scheme = loaded.Scheme,
								Values = inputs.Values.Select((Func<PowerValue> read) => read()).ToList()
							};
							applying = true;
							actions.IsEnabled = false;
							ActionResult actionResult = await Task.Run(() => restore ? PowerControls.Restore(tweak.Id, engine.DataPath) : PowerControls.Apply(tweak.Id, target, engine.DataPath));
							Record(tweak.Name, restore ? "Restore original" : "Configure", "Previous power values", actionResult.Success ? "Verified" : "Failed", actionResult);
							reload();
							status.Text = actionResult.Message;
							if (!actionResult.Success)
							{
								Say(actionResult.Message);
							}
						}
						catch (Exception ex2)
						{
							Say(ex2.Message);
						}
						finally
						{
							applying = false;
							actions.IsEnabled = true;
						}
						await ScanAsync(new string[1] { tweak.Id });
					}
				}
			};
			actions.Children.Add(Btn("Apply", async delegate
			{
				await apply(arg: false);
			}, primary: true));
			actions.Children.Add(Btn("Windows defaults", delegate
			{
				try
				{
					if (loaded != null)
					{
						show(PowerControls.Defaults(tweak.Id, loaded.Scheme));
					}
					status.Text = "Defaults loaded for review. Click Apply to save.";
				}
				catch (Exception ex)
				{
					status.Text = ex.Message;
				}
			}));
			actions.Children.Add(Btn("Restore original", async delegate
			{
				await apply(arg: true);
			}));
			actions.Children.Add(Btn("Refresh", reload));
			reload();
		}, 850.0, 640.0);
	}

	private async Task ImportBundledPower(BundledPlan plan, bool activate)
	{
		await BackupFirst();
		if (preview || applying)
		{
			return;
		}
		applying = true;
		try
		{
			ActionResult actionResult = await Task.Run(() => Utilities.ImportPlan(plan, activate));
			Record(plan.Name, activate ? "Import & activate" : "Import only", "Power plans", plan.Name, actionResult);
			notice.Text = actionResult.Message;
			if (!actionResult.Success)
			{
				Say(actionResult.Message);
			}
		}
		finally
		{
			applying = false;
		}
		await RefreshPowerPlans();
		RenderPower();
	}

	private void ChoosePowerImport(string file)
	{
		if (preview)
		{
			return;
		}
		if (file == null)
		{
			Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
			{
				Filter = "Windows power plan|*.pow"
			};
			if (openFileDialog.ShowDialog() != true)
			{
				return;
			}
			file = openFileDialog.FileName;
		}
		string path = file;
		ShowPanel("Import power plan", delegate(StackPanel p)
		{
			p.Children.Add(Label(System.IO.Path.GetFileName(path), 18.0, Text));
			TextBlock status = Label("Choose whether to activate this plan after importing.", 12.0, Muted);
			p.Children.Add(status);
			WrapPanel row = new WrapPanel();
			bool busy = false;
			Func<bool, Task> run = async delegate(bool activate)
			{
				if (busy || applying)
				{
					return;
				}
				busy = (applying = true);
				row.IsEnabled = false;
				try
				{
					string id = Guid.NewGuid().ToString();
					ActionResult actionResult = await Task.Run(delegate
					{
						ActionResult actionResult2 = Utilities.Run("powercfg.exe", "/import \"" + path + "\" " + id);
						return (actionResult2.Success && activate) ? Utilities.ActivatePlan(id) : actionResult2;
					});
					status.Text = ((!actionResult.Success) ? actionResult.Message : (activate ? "Imported and activated." : "Imported; active plan unchanged."));
					Record("Power plan", activate ? "Import & activate" : "Import only", path, id, actionResult);
					await RefreshPowerPlans();
					InvalidateViews();
				}
				finally
				{
					busy = (applying = false);
					row.IsEnabled = true;
				}
			};
			row.Children.Add(Btn("Import only", async delegate
			{
				await run(arg: false);
			}));
			row.Children.Add(Btn("Import & activate", async delegate
			{
				await run(arg: true);
			}, primary: true));
			p.Children.Add(row);
		}, 620.0, 280.0);
	}

	private Dictionary<string, string> ServiceReference()
	{
		if (serviceRecommendations == null)
		{
			try
			{
				serviceRecommendations = Program.Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(System.IO.Path.Combine(Program.Root, "services-reference.json"))) ?? new Dictionary<string, string>();
			}
			catch
			{
				serviceRecommendations = new Dictionary<string, string>();
			}
		}
		return serviceRecommendations;
	}

	private string Recommendation(string id)
	{
		Tweak tweak = engine.Tweaks.FirstOrDefault((Tweak x) => x.Id == id);
		if (tweak == null)
		{
			return "Not specified";
		}
		string value;
		if (tweak.Kind == "Service")
		{
			if (ServiceBatch.Hidden(tweak.Service))
			{
				return "Not specified";
			}
			string text = tweak.Service ?? "";
			Match match = Regex.Match(text, "^(.+)_[0-9a-fA-F]{4,8}$");
			if (!ServiceReference().TryGetValue(text, out value) && (!match.Success || !ServiceReference().TryGetValue(match.Groups[1].Value, out value)))
			{
				return "Not specified";
			}
			return value;
		}
		if (AzizPresets.Basic.TryGetValue(id, out value))
		{
			return value;
		}
		if (tweak.Category == "Network")
		{
			if (!AzizPresets.Network.TryGetValue(id, out value))
			{
				return "Not specified";
			}
			return value;
		}
		if (tweak.Category == "Security" && Profileable(tweak) && tweak.Kind != "SystemRestore")
		{
			if (!AzizPresets.SecurityOn.Contains(id))
			{
				return "Disabled";
			}
			return "Enabled";
		}
		return "Not specified";
	}

	private string RecommendationLabel(Tweak t)
	{
		if (AzizPresets.Basic.TryGetValue(t.Id, out var value))
		{
			string text = AzizPresets.Ultra[t.Id];
			if (!(value == text))
			{
				return "Low Latency: " + ValueText(t, value) + " · Ultra Low Latency: " + ValueText(t, text);
			}
			return "AZIZ recommended: " + ValueText(t, value);
		}
		string text2 = Recommendation(t.Id);
		if (!(text2 == "Not specified"))
		{
			return "AZIZ recommended: " + ValueText(t, text2);
		}
		return "";
	}

	internal static bool Profileable(Tweak t)
	{
		return ProfileLogic.Profileable(t);
	}

	// A partial state counts as the opposite of what AZIZ sets: a switch AZIZ turns off reads On until every part is off,
	// a tweak AZIZ turns on reads Off until every part is on. The details still say Mixed and list the parts.
	// Mixed shows the opposite of the AZIZ target, for every page: Toggles/Tweaks, Network and Security.
	internal static bool MixedShowsOn(Tweak t)
	{
		if (AzizPresets.Ultra.TryGetValue(t.Id, out var value) || AzizPresets.Basic.TryGetValue(t.Id, out value) || (t.Category == "Network" && AzizPresets.Network.TryGetValue(t.Id, out value)) || (value = ProfileLogic.SecurityValue(t)) != null)
		{
			if (value == "Disabled")
			{
				return true;
			}
			if (value == "Enabled")
			{
				return false;
			}
		}
		string category = t.Category ?? "";
		return category == "Devices" || category == "Windows" || category == "Appearance" || category == "Security";
	}

	internal static bool ShownOn(Tweak t, TweakStatus state)
	{
		if (state == null)
		{
			return false;
		}
		if (state.State == "Mixed")
		{
			return MixedShowsOn(t);
		}
		return state.State == "Enabled";
	}

	private string CurrentValue(Tweak t)
	{
		return ProfileLogic.CurrentValue(engine, states, t);
	}

	private bool ValueApplies(Tweak t, string value)
	{
		return ProfileLogic.ValueApplies(t, value);
	}

	private string ValueText(Tweak t, string value)
	{
		if (value == null)
		{
			return "Unknown";
		}
		if (value.StartsWith("boost:"))
		{
			return "Boost policy " + value.Substring(6) + "% (AC)";
		}
		if (t != null && t.Kind == "Service" && (value == "0" || value == "1"))
		{
			if (!(value == "0"))
			{
				return "System";
			}
			return "Boot";
		}
		if (t != null && t.Kind == "Service")
		{
			if (!(value == "2"))
			{
				if (!(value == "3"))
				{
					if (!(value == "4"))
					{
						return value;
					}
					return "Disabled";
				}
				return "Manual";
			}
			return "Automatic";
		}
		if (t != null && t.Choices != null)
		{
			TweakChoice tweakChoice = t.Choices.FirstOrDefault((TweakChoice x) => x.Value == value);
			if (tweakChoice != null)
			{
				return tweakChoice.Label;
			}
		}
		if (!(value == "Enabled"))
		{
			if (!(value == "Disabled"))
			{
				return value;
			}
			return "Off";
		}
		return "On";
	}

	private async Task QueueValue(Tweak t, string value)
	{
		if (t.Id == "cpu-boost-settings")
		{
			uint i = uint.Parse(value.Substring(6));
			ActionResult actionResult = await Task.Run(() => PowerControls.SetAc(t.Id, "cpu-boost-policy", i, engine.DataPath));
			Record(t.Name, "Set boost policy " + i + "% (AC)", "Previous power values", actionResult.Success ? "Verified" : "Failed", actionResult);
		}
		else if (t.Kind == "Timer")
		{
			await SetTimer(value == "Enabled", report: false);
		}
		else if (t.Kind == "Service")
		{
			Enqueue(t, value != "4", value);
		}
		else if (t.Choices != null && t.Choices.Count > 0)
		{
			Enqueue(t, enabled: true, value);
		}
		else
		{
			Enqueue(t, value == "Enabled", null);
		}
	}

	private async Task ApplyValues(Dictionary<string, string> values, IEnumerable<Tweak> scope)
	{
		foreach (Tweak item in scope)
		{
			if (values.TryGetValue(item.Id, out var value) && ValueApplies(item, value) && (!states.TryGetValue(item.Id, out var value2) || !(value2.State == "Unavailable")) && !(CurrentValue(item) == value))
			{
				await QueueValue(item, value);
			}
		}
	}

	private async Task ApplyRecommended(List<Tweak> list)
	{
		if (preview || applying)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		Dictionary<string, string> values;
		string title;
		if (current == "Toggles" || current == "Tweaks")
		{
			string text = ChoosePresetMode();
			if (text == null)
			{
				return;
			}
			values = ((text == "ultra") ? AzizPresets.Ultra : AzizPresets.Basic);
			title = ((text == "ultra") ? "Ultra Low Latency" : "Low Latency");
		}
		else if (current == "Services")
		{
			string text2 = ChooseServicesMode();
			if (text2 == null)
			{
				return;
			}
			Dictionary<string, string> dictionary = ServiceReference();
			values = new Dictionary<string, string>();
			foreach (Tweak item in list.Where((Tweak x) => x.Kind == "Service" && !ServiceBatch.Hidden(x.Service) && ServiceBatch.Inbox(x.Service)))
			{
				if (int.TryParse(CurrentValue(item), out var result))
				{
					string key = Regex.Replace(item.Service, "_[0-9a-fA-F]{4,8}$", "");
					values[item.Id] = ((!(text2 == "minimal")) ? ServiceBatch.Recommended(item.Service, result, item.Name).ToString() : (dictionary.TryGetValue(key, out var value4) ? value4 : ServiceBatch.Target(item.Service, manual: false, result, item.Name).ToString()));
				}
			}
			title = ((text2 == "minimal") ? "Services · Minimal" : "Services · Recommended");
		}
		else
		{
			values = list.Where((Tweak t) => Recommendation(t.Id) != "Not specified").ToDictionary((Tweak t) => t.Id, (Tweak t) => Recommendation(t.Id));
			title = "AZIZ recommended · " + current;
		}
		string value2;
		TweakStatus value3;
		List<Tweak> source = list.Where((Tweak t) => values.TryGetValue(t.Id, out value2) && ValueApplies(t, value2) && (!states.TryGetValue(t.Id, out value3) || !(value3.State == "Unavailable"))).ToList();
		List<Tweak> targets = source.Where((Tweak t) => CurrentValue(t) != values[t.Id]).ToList();
		List<Tweak> first = targets;
		if (targets.Count > 0 && !ReviewChanges(title, "Only the settings that differ are listed. Untick anything you want to keep.", targets.Select((Tweak t) => Tuple.Create(t, CurrentValue(t), values[t.Id])).ToList(), out targets))
		{
			return;
		}
		SetReference(title, source.ToDictionary((Tweak t) => t.Id, (Tweak t) => values[t.Id]), merge: true, from t in first.Except(targets)
			select t.Id);
		Record(title, "Apply preset", current, targets.Count + " changes", new ActionResult
		{
			Success = true,
			Message = string.Join(", ", targets.Select((Tweak t) => t.Name))
		});
		foreach (Tweak item2 in targets)
		{
			await QueueValue(item2, values[item2.Id]);
		}
		if (current == "Tweaks")
		{
			await EnsureGpuMsi();
		}
		notice.Text = title + ((targets.Count == 0) ? ": this page already matches." : (": " + targets.Count + " changes queued · they run in the background while you keep using AZIZ."));
	}

	private List<Tuple<string, string, string>> PagePresets(string page)
	{
		List<Tuple<string, string, string>> list = new List<Tuple<string, string, string>>();
		switch (page)
		{
		case "Toggles":
		case "Tweaks":
			list.Add(Tuple.Create("recommended", "Low Latency", "Low Latency: responsive everyday setup that keeps normal power saving."));
			list.Add(Tuple.Create("low-latency", "Ultra Low Latency", "Ultra Low Latency: lowest latency, more power and heat."));
			// No Default here: Windows Default lives in Profiles. Services keep their own Default as a safety net.
			break;
		case "Network":
			list.Add(Tuple.Create("recommended", "Recommended", "On: TCP/IP task offload, receive segment coalescing, CUBIC, QoS, throttling, auto-tuning, Nagle, large send offload and interrupt moderation. Everything else on this page off, including Delivery Optimization P2P (Windows Update is off)."));
			break;
		case "Services":
			list.Add(Tuple.Create("minimal", "Minimal", "The fewest services. Windows Update Disabled, BitLocker off, Task Scheduler Automatic. Only by hand from this page."));
			list.Add(Tuple.Create("recommended", "Recommended", "Used by Ultra Low Latency and Low Latency. Bluetooth, Wi-Fi and wireless, remote access, Phone Link, Search indexing and BitLocker off; update services (BITS, Delivery Optimization, Orchestrator, Medic) off and Windows Update service Manual."));
			list.Add(Tuple.Create("default", "Default", "Windows default startup types."));
			break;
		case "Security":
			list.Add(Tuple.Create("recommended", "Recommended", "AZIZ security recommendations for gaming."));
			break;
		}
		return list;
	}

	private Dictionary<string, string> PagePresetValues(string page, string mode, List<Tweak> list)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		if (page == "Services")
		{
			string mode2 = ((mode == "minimal") ? "minimal" : ((mode == "recommended") ? "recommended" : "default"));
			{
				foreach (Tweak item in list.Where((Tweak x) => x.Kind == "Service"))
				{
					int? num = ServicePresets.Target(mode2, item.Service);
					if (num.HasValue)
					{
						dictionary[item.Id] = num.Value.ToString();
					}
				}
				return dictionary;
			}
		}
		if (mode == "default")
		{
			Dictionary<string, string> dictionary2 = WindowsDefaultValues();
			{
				foreach (Tweak item2 in list)
				{
					if (dictionary2.TryGetValue(item2.Id, out var value))
					{
						dictionary[item2.Id] = value;
					}
				}
				return dictionary;
			}
		}
		foreach (Tweak item3 in list)
		{
			string value2 = null;
			if (page == "Network")
			{
				AzizPresets.Network.TryGetValue(item3.Id, out value2);
			}
			else if (page == "Security")
			{
				value2 = ProfileLogic.SecurityValue(item3);
			}
			else
			{
				((mode == "low-latency") ? AzizPresets.Ultra : AzizPresets.Basic).TryGetValue(item3.Id, out value2);
			}
			if (value2 != null)
			{
				dictionary[item3.Id] = value2;
			}
		}
		return dictionary;
	}

	private async Task ApplyPagePreset(string mode, List<Tweak> list)
	{
		if (preview || applying)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		string page = current;
		bool windowsDefault = mode == "default" && page != "Services";
		Dictionary<string, string> values = PagePresetValues(page, mode, list);
		Tuple<string, string, string> tuple = PagePresets(page).FirstOrDefault((Tuple<string, string, string> x) => x.Item1 == mode);
		string title = page + " · " + ((tuple == null) ? mode : tuple.Item2);
		List<Tweak> list2 = list.Where(delegate(Tweak t)
		{
			if (states.TryGetValue(t.Id, out var value3) && value3.State == "Unavailable")
			{
				return false;
			}
			if (windowsDefault && RestoresOriginal("windows-default", t))
			{
				return true;
			}
			string value4;
			return values.TryGetValue(t.Id, out value4) && ValueApplies(t, value4) && CurrentValue(t) != value4;
		}).ToList();
		if (list2.Count == 0)
		{
			notice.Text = title + ": this page already matches.";
		}
		else
		{
			if (!ReviewChanges(title, windowsDefault ? "Your Windows values from before AZIZ. Untick anything you want to keep." : "Only the settings that differ are listed. Untick anything you want to keep.", list2.Select(delegate(Tweak t)
			{
				values.TryGetValue(t.Id, out var value2);
				return Tuple.Create(t, CurrentValue(t), value2 ?? "Original");
			}).ToList(), out var chosen) || !EnsureProfile() || !EnsureEditable(null, null))
			{
				return;
			}
			Record(title, "Apply preset", page, chosen.Count + " changes", new ActionResult
			{
				Success = true,
				Message = string.Join(", ", chosen.Select((Tweak t) => t.Name))
			});
			foreach (Tweak item in chosen)
			{
				values.TryGetValue(item.Id, out var value);
				if (windowsDefault)
				{
					await QueueProfileValue("windows-default", item, value);
				}
				else
				{
					await QueueValue(item, value);
				}
			}
			if (page == "Tweaks" && !windowsDefault)
			{
				await EnsureGpuMsi();
			}
			notice.Text = title + ": " + chosen.Count + " changes queued · they run in the background while you keep using AZIZ.";
		}
	}

	private string ChoosePresetMode()
	{
		string mode = null;
		Window window = new Window();
		window.Owner = this;
		window.Title = "AZIZ recommended";
		window.Width = 620.0;
		window.Height = 330.0;
		window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window.Background = new SolidColorBrush(Bg);
		window.Foreground = Text;
		Window w = window;
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(24.0);
		stackPanel.Children.Add(Label("Choose a preset for " + current, 20.0, Text));
		stackPanel.Children.Add(Label("Low Latency keeps everyday power saving. Ultra Low Latency also turns off device power saving and adds the timer resolution, memory and NVMe latency settings. On AMD processors both turn interrupt steering and serialized timer expiration off. Both turn on MSI mode for the main graphics card (on AMD processors also with high interrupt priority on one core; Intel keeps Windows priority and affinity). Power-plan values change only while plugged in (AC).", 12.0, Muted));
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 2,
			Margin = new Thickness(0.0, 18.0, 0.0, 0.0)
		};
		Func<string, string, string, System.Windows.Controls.Button> func = delegate(string key, string name, string desc)
		{
			StackPanel stackPanel2 = Stack();
			stackPanel2.Children.Add(Label(name, 16.0, Text));
			stackPanel2.Children.Add(Label(desc, 11.0, Muted));
			System.Windows.Controls.Button button = Btn("", delegate
			{
				mode = key;
				w.Close();
			}, key == "basic");
			button.Content = stackPanel2;
			button.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left;
			button.Padding = new Thickness(16.0);
			button.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
			return button;
		};
		uniformGrid.Children.Add(func("basic", "Low Latency", "Responsive everyday setup"));
		uniformGrid.Children.Add(func("ultra", "Ultra Low Latency", "Lowest latency · more power and heat"));
		stackPanel.Children.Add(uniformGrid);
		w.Content = stackPanel;
		DarkDialog(w);
		w.ShowDialog();
		return mode;
	}

	private string ChooseServicesMode()
	{
		string mode = null;
		Window window = new Window();
		window.Owner = this;
		window.Title = "AZIZ · Services";
		window.Width = 660.0;
		window.Height = 350.0;
		window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window.Background = new SolidColorBrush(Bg);
		window.Foreground = Text;
		Window w = window;
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(24.0);
		stackPanel.Children.Add(Label("AZIZ for Services", 20.0, Text));
		stackPanel.Children.Add(Label("Only Windows' own services change. Services added by your apps, drivers, launchers and anti-cheat stay exactly as they are. You review every change before it applies.", 12.0, Muted));
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 2,
			Margin = new Thickness(0.0, 18.0, 0.0, 0.0)
		};
		Func<string, string, string, System.Windows.Controls.Button> func = delegate(string key, string name, string desc)
		{
			StackPanel stackPanel2 = Stack();
			stackPanel2.Children.Add(Label(name, 16.0, Text));
			stackPanel2.Children.Add(Label(desc, 11.0, Muted));
			System.Windows.Controls.Button button = Btn("", delegate
			{
				mode = key;
				w.Close();
			}, key == "recommended");
			button.Content = stackPanel2;
			button.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left;
			button.Padding = new Thickness(16.0);
			button.Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
			return button;
		};
		uniformGrid.Children.Add(func("recommended", "Recommended", "Used by Ultra Low Latency and Low Latency. Bluetooth, Wi-Fi and wireless, remote access, Phone Link, Search indexing and BitLocker off; update services (BITS, Delivery Optimization, Orchestrator, Medic) off and Windows Update service Manual; the rest as needed."));
		uniformGrid.Children.Add(func("minimal", "Minimal", "The fewest services possible. Windows Update Disabled, BitLocker off, Task Scheduler Automatic."));
		stackPanel.Children.Add(uniformGrid);
		w.Content = stackPanel;
		DarkDialog(w);
		w.ShowDialog();
		return mode;
	}

	private bool ReviewChanges(string title, string intro, List<Tuple<Tweak, string, string>> rows, out List<Tweak> chosen)
	{
		Dictionary<Tweak, bool> picked = new Dictionary<Tweak, bool>();
		List<Action> repaint = new List<Action>();
		bool ok = false;
		// Shown in the same blurred in-window sheet as Profiles and Reflex, so it matches the rest of the app.
		ShowSheet(delegate(StackPanel panel, Action close)
		{
				StackPanel head = Stack();
				head.Margin = new Thickness(28.0, 22.0, 28.0, 10.0);
				TextBlock kicker = Label("REVIEW CHANGES", 11.0, B("#5FD3F3"));
				kicker.FontWeight = FontWeights.SemiBold;
				head.Children.Add(kicker);
				TextBlock heading = Label(title, 24.0, Text);
				heading.FontWeight = FontWeights.SemiBold;
				heading.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
				head.Children.Add(heading);
				TextBlock about = Label(intro, 12.0, Muted);
				about.MaxWidth = 760.0;
				about.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
				head.Children.Add(about);
			head.Margin = new Thickness(0.0, 0.0, 0.0, 2.0);
			about.MaxWidth = 640.0;
				WrapPanel chips = new WrapPanel
				{
					Margin = new Thickness(0.0, 14.0, 0.0, 0.0)
				};
				Func<string, System.Windows.Media.Brush, Border> chip = delegate(string text, System.Windows.Media.Brush color)
				{
					TextBlock textBlock = Label(text, 11.0, color);
					textBlock.FontWeight = FontWeights.SemiBold;
					return new Border
					{
						Background = B("#171C33"),
						CornerRadius = new CornerRadius(20.0),
						Padding = new Thickness(12.0, 5.0, 12.0, 5.0),
						Margin = new Thickness(0.0, 0.0, 8.0, 0.0),
						Child = textBlock
					};
				};
				chips.Children.Add(chip(rows.Count + " changes", Purple));
				int restarts = rows.Count((Tuple<Tweak, string, string> r) => r.Item1.RequiresRestart);
				if (restarts > 0)
				{
					chips.Children.Add(chip(restarts + " need a restart", B("#F5A524")));
				}
				Border selectAll = chip("Select all", Text);
				selectAll.Cursor = System.Windows.Input.Cursors.Hand;
				Border selectNone = chip("Select none", Text);
				selectNone.Cursor = System.Windows.Input.Cursors.Hand;
				chips.Children.Add(selectAll);
				chips.Children.Add(selectNone);
				head.Children.Add(chips);
			panel.Children.Add(head);
				StackPanel list = Stack();
				list.Margin = new Thickness(28.0, 4.0, 22.0, 12.0);
				Func<string, bool, Border> pill = delegate(string text, bool target)
				{
					TextBlock textBlock = Label(text, 12.0, target ? System.Windows.Media.Brushes.White : B("#B4BCD3"));
					textBlock.FontWeight = (target ? FontWeights.SemiBold : FontWeights.Normal);
					textBlock.TextWrapping = TextWrapping.NoWrap;
					textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
					textBlock.MaxWidth = 150.0;
					return new Border
					{
						Background = (target ? ((System.Windows.Media.Brush)new LinearGradientBrush(System.Windows.Media.Color.FromRgb(124, 94, 240), System.Windows.Media.Color.FromRgb(86, 92, 230), 0.0)) : B("#1A2036")),
						CornerRadius = new CornerRadius(8.0),
						Padding = new Thickness(10.0, 5.0, 10.0, 5.0),
						VerticalAlignment = VerticalAlignment.Center,
						Child = textBlock,
						ToolTip = text
					};
				};
				foreach (IGrouping<string, Tuple<Tweak, string, string>> group in from r in rows
					group r by ProfilePage(r.Item1) into g
					orderby Array.IndexOf(new string[6] { "Toggles", "Tweaks", "Network", "Security", "Services", "Other" }, g.Key)
					select g)
				{
					TextBlock groupLabel = Label(L(group.Key) + "  ·  " + group.Count(), 12.0, Purple);
					groupLabel.FontWeight = FontWeights.SemiBold;
					groupLabel.Margin = new Thickness(2.0, 14.0, 0.0, 8.0);
					list.Children.Add(groupLabel);
					foreach (Tuple<Tweak, string, string> row in group)
					{
						Tweak t = row.Item1;
						picked[t] = ProfileLogic.PresetSafe(t, row.Item3);
						Grid grid = new Grid();
						grid.ColumnDefinitions.Add(new ColumnDefinition
						{
							Width = GridLength.Auto
						});
						grid.ColumnDefinitions.Add(new ColumnDefinition());
						grid.ColumnDefinitions.Add(new ColumnDefinition
						{
							Width = GridLength.Auto
						});
						TextBlock mark = new TextBlock
						{
							Text = "✓",
							FontSize = 12.0,
							FontWeight = FontWeights.Bold,
							Foreground = System.Windows.Media.Brushes.White,
							HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
							VerticalAlignment = VerticalAlignment.Center
						};
						Border box = new Border
						{
							Width = 22.0,
							Height = 22.0,
							CornerRadius = new CornerRadius(7.0),
							BorderThickness = new Thickness(1.5),
							Margin = new Thickness(0.0, 0.0, 14.0, 0.0),
							VerticalAlignment = VerticalAlignment.Center,
							Child = mark
						};
						grid.Children.Add(box);
						StackPanel text = Stack();
						text.VerticalAlignment = VerticalAlignment.Center;
						TextBlock name = Label(t.Name, 14.0, Text);
						name.FontWeight = FontWeights.SemiBold;
						text.Children.Add(name);
						if (!string.IsNullOrEmpty(t.Description))
						{
							TextBlock textBlock = Label(t.Description, 11.0, Muted);
							textBlock.MaxHeight = 30.0;
							textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
							textBlock.Margin = new Thickness(0.0, 2.0, 16.0, 0.0);
							textBlock.ToolTip = t.Description;
							text.Children.Add(textBlock);
						}
						string warning = ((t.Kind == "Service" && row.Item3 == "4") ? ServicePresets.Warning(t.Service) : null);
						if (warning != null)
						{
							TextBlock textBlock2 = Label("⚠ " + warning + (ProfileLogic.PresetSafe(t, row.Item3) ? "" : " This PC loads it as a disk/volume filter, so disabling it can stop Windows from booting. Left unticked: tick it only if you are sure."), 11.0, B("#F5A524"));
							textBlock2.Margin = new Thickness(0.0, 4.0, 16.0, 0.0);
							text.Children.Add(textBlock2);
						}
						Grid.SetColumn(text, 1);
						grid.Children.Add(text);
						StackPanel change = new StackPanel
						{
							Orientation = System.Windows.Controls.Orientation.Horizontal,
							VerticalAlignment = VerticalAlignment.Center
						};
						StackPanel was = Stack();
						TextBlock wasLabel = Label("NOW", 9.0, Muted);
						wasLabel.Margin = new Thickness(2.0, 0.0, 0.0, 3.0);
						was.Children.Add(wasLabel);
						was.Children.Add(pill(ValueText(t, row.Item2), false));
						change.Children.Add(was);
						TextBlock arrow = Label("→", 15.0, B("#8B7FD6"));
						arrow.VerticalAlignment = VerticalAlignment.Bottom;
						arrow.Margin = new Thickness(10.0, 0.0, 10.0, 4.0);
						change.Children.Add(arrow);
						StackPanel will = Stack();
						TextBlock willLabel = Label(t.RequiresRestart ? "AZIZ · RESTART" : "AZIZ", 9.0, B("#A99BFF"));
						willLabel.Margin = new Thickness(2.0, 0.0, 0.0, 3.0);
						will.Children.Add(willLabel);
						will.Children.Add(pill(ValueText(t, row.Item3), true));
						change.Children.Add(will);
						Grid.SetColumn(change, 2);
						grid.Children.Add(change);
						Border card = new Border
						{
							CornerRadius = new CornerRadius(14.0),
							Padding = new Thickness(16.0, 12.0, 16.0, 12.0),
							Margin = new Thickness(0.0, 0.0, 0.0, 8.0),
							BorderThickness = new Thickness(1.0),
							Cursor = System.Windows.Input.Cursors.Hand,
							Child = grid
						};
						bool hover = false;
						Action paint = delegate
						{
							bool flag = picked[t];
							box.Background = (flag ? ((System.Windows.Media.Brush)new LinearGradientBrush(System.Windows.Media.Color.FromRgb(139, 108, 245), System.Windows.Media.Color.FromRgb(98, 92, 236), 45.0)) : System.Windows.Media.Brushes.Transparent);
							box.BorderBrush = (flag ? System.Windows.Media.Brushes.Transparent : B("#3A4360"));
							mark.Visibility = (flag ? Visibility.Visible : Visibility.Hidden);
							card.Background = (flag ? B("#141A30") : B("#0F1424"));
							card.BorderBrush = (hover ? B("#5A44B8") : (flag ? B("#2A2858") : B("#1A2036")));
							text.Opacity = (flag ? 1.0 : 0.55);
							change.Opacity = (flag ? 1.0 : 0.45);
						};
						repaint.Add(paint);
						card.MouseEnter += delegate
						{
							hover = true;
							paint();
						};
						card.MouseLeave += delegate
						{
							hover = false;
							paint();
						};
						card.MouseLeftButtonUp += delegate
						{
							picked[t] = !picked[t];
							paint();
							repaint[repaint.Count - 1]();
						};
						paint();
						list.Children.Add(card);
					}
				}
			list.Margin = new Thickness(0.0, 4.0, 0.0, 10.0);
			panel.Children.Add(list);
			Grid footRow = new Grid();
			footRow.ColumnDefinitions.Add(new ColumnDefinition());
			footRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
			footRow.Margin = new Thickness(2.0, 6.0, 2.0, 0.0);
			TextBlock summary = Label("", 12.0, Muted);
			summary.VerticalAlignment = VerticalAlignment.Center;
			footRow.Children.Add(summary);
			StackPanel buttons = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal,
				HorizontalAlignment = System.Windows.HorizontalAlignment.Right
			};
			buttons.Children.Add(Btn("Cancel", close));
			System.Windows.Controls.Button apply = Btn("Apply selected", delegate
			{
				ok = true;
				close();
			}, primary: true);
			apply.Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(139, 108, 245), System.Windows.Media.Color.FromRgb(86, 92, 230), 0.0);
			apply.Padding = new Thickness(22.0, 10.0, 22.0, 10.0);
			apply.FontWeight = FontWeights.SemiBold;
			apply.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
			buttons.Children.Add(apply);
			Grid.SetColumn(buttons, 1);
			footRow.Children.Add(buttons);
			panel.Children.Add(footRow);
				Action count = delegate
				{
					int num = picked.Values.Count((bool x) => x);
					summary.Text = num + " of " + picked.Count + " selected";
					apply.IsEnabled = num > 0;
				};
				repaint.Add(count);
				count();
				selectAll.MouseLeftButtonUp += delegate
				{
					foreach (Tweak item in picked.Keys.ToList())
					{
						picked[item] = true;
					}
					foreach (Action item2 in repaint)
					{
						item2();
					}
				};
				selectNone.MouseLeftButtonUp += delegate
				{
					foreach (Tweak item3 in picked.Keys.ToList())
					{
						picked[item3] = false;
					}
					foreach (Action item4 in repaint)
					{
						item4();
					}
				};
		}, 820.0);
		chosen = (from r in rows
			where picked.TryGetValue(r.Item1, out var value) && value
			select r.Item1).ToList();
		if (ok)
		{
			return chosen.Count > 0;
		}
		return false;
	}
	private static DateTime? ReadPreviousSession()
	{
		try
		{
			string path = System.IO.Path.Combine(Program.Data, "last-states.json");
			return File.Exists(path) ? new DateTime?(File.GetLastWriteTime(path)) : null;
		}
		catch
		{
			return null;
		}
	}

	private string ProfileName(string key)
	{
		if (string.IsNullOrEmpty(key))
		{
			return "No profile";
		}
		string text = ProfileLogic.BuiltInName(key);
		if (text != null)
		{
			return text;
		}
		try
		{
			return ProfileFiles.Read(key).Name;
		}
		catch
		{
			return System.IO.Path.GetFileNameWithoutExtension(key);
		}
	}

	private void SetActiveProfile(string key)
	{
		settings.ActiveProfile = (string.IsNullOrEmpty(key) ? null : key);
		SaveSettings();
		UpdateProfileBadge();
		Engine.ActiveProfileName = ProfileName(ActiveKey);
	}

	private Dictionary<string, string> WindowsDefaultValues()
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		Dictionary<string, string> dictionary2 = WindowsBaseline.Values();
		foreach (Tweak item in engine.Tweaks.Where(Profileable))
		{
			string value = engine.OriginalValue(item.Id);
			if (!ValueApplies(item, value))
			{
				dictionary2.TryGetValue(item.Id, out value);
			}
			if (!ValueApplies(item, value))
			{
				value = ((item.Id == "foreground-boost") ? "2" : BaselineStore.WindowsDefault(item.Id));
			}
			if (ValueApplies(item, value))
			{
				dictionary[item.Id] = value;
			}
		}
		return dictionary;
	}

	private Dictionary<string, string> presetCache;

	private string presetCacheKey;

	// One option's value in a profile, without building the whole profile (a toggle click on Windows Default otherwise
	// reads every saved original on the UI thread).
	private string ProfileValue(string key, Tweak t)
	{
		if (key == "windows-default")
		{
			string value = engine.OriginalValue(t.Id);
			if (!ValueApplies(t, value))
			{
				WindowsBaseline.Values().TryGetValue(t.Id, out value);
			}
			if (!ValueApplies(t, value))
			{
				value = ((t.Id == "foreground-boost") ? "2" : BaselineStore.WindowsDefault(t.Id));
			}
			return ValueApplies(t, value) ? value : null;
		}
		if (key == "aziz-recommended" || key == "aziz-ultra")
		{
			string text = key + "|" + engine.Tweaks.Count;
			if (presetCache == null || presetCacheKey != text)
			{
				presetCache = ProfileLogic.PresetValues(engine.Tweaks, key == "aziz-ultra");
				presetCacheKey = text;
			}
			presetCache.TryGetValue(t.Id, out var value2);
			return value2;
		}
		ProfileValues(key).TryGetValue(t.Id, out var value3);
		return value3;
	}

	private Dictionary<string, string> ProfileValues(string key)
	{
		switch (key)
		{
		case "windows-default":
			return WindowsDefaultValues();
		case "aziz-recommended":
		case "aziz-ultra":
			return ProfileLogic.PresetValues(engine.Tweaks, key == "aziz-ultra");
		default:
			if (!string.IsNullOrEmpty(key))
			{
				try
				{
					return ProfileFiles.Read(key).Values;
				}
				catch
				{
				}
			}
			return new Dictionary<string, string>();
		}
	}

	private Dictionary<string, string> CaptureValues()
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (Tweak item in engine.Tweaks.Where(Profileable))
		{
			string value = CurrentValue(item);
			if (ValueApplies(item, value))
			{
				dictionary[item.Id] = value;
			}
		}
		return dictionary;
	}

	private AppliedReference LoadReference()
	{
		try
		{
			AppliedReference appliedReference = Program.Json.Deserialize<AppliedReference>(File.ReadAllText(ReferencePath));
			if (appliedReference == null || appliedReference.Values == null)
			{
				return null;
			}
			if (appliedReference.Accepted == null)
			{
				appliedReference.Accepted = new Dictionary<string, string>();
			}
			ProfileLogic.Upgrade(appliedReference.Values);
			appliedReference.Accepted.Remove("visual-best-performance");
			appliedReference.Accepted.Remove("animations");
			return appliedReference;
		}
		catch
		{
			return null;
		}
	}

	private void SaveReference(AppliedReference r)
	{
		if (!preview)
		{
			try
			{
				Utilities.AtomicWrite(ReferencePath, Program.Json.Serialize(r));
			}
			catch
			{
			}
		}
	}

	private void SetReference(string name, Dictionary<string, string> values, bool merge, IEnumerable<string> keepIds)
	{
		AppliedReference appliedReference = (merge ? LoadReference() : null);
		if (appliedReference == null)
		{
			appliedReference = new AppliedReference
			{
				Values = new Dictionary<string, string>(),
				Accepted = new Dictionary<string, string>()
			};
		}
		appliedReference.Name = name;
		foreach (KeyValuePair<string, string> value in values)
		{
			appliedReference.Values[value.Key] = value.Value;
			appliedReference.Accepted.Remove(value.Key);
		}
		foreach (string id in keepIds ?? new string[0])
		{
			List<Tweak> tweaks = engine.Tweaks;
			Func<Tweak, bool> predicate = (Tweak x) => x.Id == id;
			Tweak tweak = tweaks.FirstOrDefault(predicate);
			string text = ((tweak == null) ? null : CurrentValue(tweak));
			if (text != null)
			{
				appliedReference.Accepted[id] = text;
			}
		}
		SaveReference(appliedReference);
	}

	private void RecordFirstStart()
	{
		if (preview || !Program.IsAdmin)
		{
			return;
		}
		// First start only reads: nothing is written to Windows here. The AZIZ Backup restore point is made just before
		// the first change the user asks for (see BackupFirst).
		WindowsBaseline.Merge(CaptureValues());
		if (WindowsBaseline.OriginalsCaptured)
		{
			return;
		}
		Task.Run(delegate
		{
			try
			{
				engine.CaptureOriginals(() => closing);
				if (!closing)
				{
					WindowsBaseline.MarkOriginals();
				}
			}
			catch
			{
			}
		});
	}

	private bool EnsureEditable(Tweak t, string value)
	{
		if (preview || !ProfileLogic.BuiltIn(ActiveKey))
		{
			return true;
		}
		// Security options are free on a static profile: switching them on or off never asks for an own profile.
		if ((t != null) ? (t.Category == "Security") : (current == "Security"))
		{
			return true;
		}
		if (t != null && ProfileValue(ActiveKey, t) == value)
		{
			return true;
		}
		string text = ProfileName(ActiveKey);
		string choice = null;
		bool haveOwn = ProfileFiles.List().Count > 0;
		ShowSheet(delegate(StackPanel panel, Action close)
		{
			TextBlock textBlock = Label("⚡ STATIC PROFILE", 11.0, B("#F5B728"));
			textBlock.FontWeight = FontWeights.SemiBold;
			textBlock.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			panel.Children.Add(textBlock);
			TextBlock textBlock2 = Label(text + " stays as it is", 24.0, System.Windows.Media.Brushes.White);
			textBlock2.FontWeight = FontWeights.SemiBold;
			textBlock2.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock2.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
			panel.Children.Add(textBlock2);
			TextBlock textBlock3 = Label(((t == null) ? "This change is not part of " : (t.Name + " is set differently in ")) + text + ". Keep your change in your own profile: create a new one (it starts from what Windows has now) or choose one you saved.", 12.0, B("#B7AEE6"));
			textBlock3.TextAlignment = TextAlignment.Center;
			textBlock3.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock3.MaxWidth = 620.0;
			panel.Children.Add(textBlock3);
			StackPanel stackPanel = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal,
				HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
				Margin = new Thickness(0.0, 22.0, 0.0, 6.0)
			};
			Func<string, string, string, bool, string, Border> func = delegate(string glyph, string name, string desc, bool enabled, string key)
			{
				StackPanel stackPanel2 = Stack();
				TextBlock textBlock4 = Label(glyph, 22.0, B("#F5B728"));
				textBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 6.0);
				stackPanel2.Children.Add(textBlock4);
				TextBlock textBlock5 = Label(name, 18.0, System.Windows.Media.Brushes.White);
				textBlock5.FontWeight = FontWeights.Bold;
				stackPanel2.Children.Add(textBlock5);
				TextBlock textBlock6 = Label(desc, 12.0, B("#B7AEE6"));
				textBlock6.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
				stackPanel2.Children.Add(textBlock6);
				Border card = new Border
				{
					BorderThickness = new Thickness(1.0),
					BorderBrush = new SolidColorBrush(System.Windows.Media.Color.FromArgb(90, 245, 183, 40)),
					Width = 270.0,
					Padding = new Thickness(22.0, 18.0, 22.0, 20.0),
					Margin = new Thickness(8.0, 0.0, 8.0, 0.0),
					CornerRadius = new CornerRadius(18.0),
					Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(36, 30, 62), System.Windows.Media.Color.FromRgb(16, 13, 34), 90.0),
					Cursor = (enabled ? System.Windows.Input.Cursors.Hand : System.Windows.Input.Cursors.Arrow),
					Opacity = (enabled ? 1.0 : 0.45),
					Child = stackPanel2
				};
				card.MouseEnter += delegate
				{
					if (enabled)
					{
						card.Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(58, 46, 40), System.Windows.Media.Color.FromRgb(24, 18, 30), 90.0);
					}
				};
				card.MouseLeave += delegate
				{
					card.Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(36, 30, 62), System.Windows.Media.Color.FromRgb(16, 13, 34), 90.0);
				};
				card.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
				{
					if (enabled)
					{
						e.Handled = true;
						choice = key;
						close();
					}
				};
				return card;
			};
			stackPanel.Children.Add(func("＋", "Create my profile", "Name it and keep this change in it.", arg4: true, "create"));
			stackPanel.Children.Add(func("☰", "Choose my profile", haveOwn ? "Switch to a profile you saved." : "You have no saved profile yet.", haveOwn, "choose"));
			panel.Children.Add(stackPanel);
			TextBlock textBlock7 = Label("Click outside to cancel", 11.0, Muted);
			textBlock7.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock7.Margin = new Thickness(0.0, 12.0, 0.0, 0.0);
			panel.Children.Add(textBlock7);
		}, 720.0);
		if (choice == "choose")
		{
			ShowProfiles();
			return !ProfileLogic.BuiltIn(ActiveKey);
		}
		if (choice != "create")
		{
			return false;
		}
		string activeKey = ActiveKey;
		SetActiveProfile("");
		if (!CreateOwnProfile())
		{
			SetActiveProfile(activeKey);
			return false;
		}
		return true;
	}

	private bool CreateOwnProfile()
	{
		if (preview)
		{
			return true;
		}
		string text = AskName("Create your profile", "AZIZ keeps every change you make in your own profile, so you can always see and restore it. Name it (you can rename it later).", "My Profile");
		if (text == null)
		{
			return false;
		}
		try
		{
			string text2 = ProfileFiles.NewPath(text);
			Dictionary<string, string> dictionary = CaptureValues();
			ProfileFiles.Write(text2, new UserProfile
			{
				Name = ((ProfileFiles.SafeName(text).Length == 0) ? "My Profile" : text.Trim()),
				CreatedUtc = DateTime.UtcNow.ToString("o"),
				Values = dictionary
			});
			SetActiveProfile(text2);
			settings.ProfileAutoSave = true;
			SaveSettings();
			SetReference(ProfileName(text2), dictionary, merge: false, null);
			Record(ProfileName(text2), "Create profile", "", dictionary.Count + " settings", new ActionResult
			{
				Success = true,
				Message = "Created from the current Windows settings before the first change."
			});
			notice.Text = ProfileName(text2) + " created · your changes are saved into it.";
			UpdateProfileBadge();
			return true;
		}
		catch (Exception ex)
		{
			Say(ex.Message, "Profiles");
			return false;
		}
	}
	// No profile yet (nothing optimized, nothing created): changes just apply, no prompt. Profiles are made on request.
	private bool EnsureProfile()
	{
		return true;
	}


	private void SaveActiveProfile()
	{
		if (preview)
		{
			return;
		}
		try
		{
			string text = ActiveKey;
			if (!UserProfileActive)
			{
				string text2 = AskName("Save as profile", "Built-in profiles cannot be changed. Save the current settings as your own profile.", "My Profile");
				if (text2 == null)
				{
					return;
				}
				text = ProfileFiles.NewPath(text2);
				ProfileFiles.Write(text, new UserProfile
				{
					Name = ((ProfileFiles.SafeName(text2).Length == 0) ? "My Profile" : text2.Trim()),
					CreatedUtc = DateTime.UtcNow.ToString("o"),
					Values = new Dictionary<string, string>()
				});
				SetActiveProfile(text);
			}
			UserProfile userProfile = ProfileFiles.Read(text);
			userProfile.Values = CaptureValues();
			ProfileFiles.Write(text, userProfile);
			SetReference(userProfile.Name, userProfile.Values, merge: false, null);
			Record(userProfile.Name, "Save profile", "", userProfile.Values.Count + " settings", new ActionResult
			{
				Success = true,
				Message = "Profile updated from the current Windows settings."
			});
			notice.Text = userProfile.Name + " saved · " + userProfile.Values.Count + " settings. AZIZ asks Keep / Restore at the next start only if you change something without saving.";
			UpdateProfileBadge();
		}
		catch (Exception ex)
		{
			Say(ex.Message, "Profiles");
		}
	}

	// Every change goes straight into the active profile (no Save). The reference keeps the values the profile had when
	// this session started, so the next start asks Keep / Restore for what changed, and Export asks during the session.
	private void AutoSaveChange(Tweak t)
	{
		if (!UserProfileActive)
		{
			return;
		}
		try
		{
			string value = CurrentValue(t);
			if (ValueApplies(t, value))
			{
				UserProfile userProfile = ProfileFiles.Read(ActiveKey);
				userProfile.Values[t.Id] = value;
				ProfileFiles.Write(ActiveKey, userProfile);
			}
		}
		catch
		{
		}
	}

	// Settings of the active profile changed during this session (profile file vs. the reference from the session start).
	private List<Tuple<Tweak, string, string>> SessionChanges()
	{
		List<Tuple<Tweak, string, string>> list = new List<Tuple<Tweak, string, string>>();
		AppliedReference appliedReference = LoadReference();
		if (appliedReference == null || !UserProfileActive)
		{
			return list;
		}
		Dictionary<string, string> dictionary = ProfileValues(ActiveKey);
		foreach (Tweak item in engine.Tweaks.Where(Profileable))
		{
			if (appliedReference.Values.TryGetValue(item.Id, out var value) && dictionary.TryGetValue(item.Id, out var value2) && value != value2 && ValueApplies(item, value))
			{
				list.Add(Tuple.Create(item, value, value2));
			}
		}
		return list;
	}

	private void FinishFirstSession()
	{
		if (!settings.ProfileAutoSave)
		{
			return;
		}
		if (UserProfileActive)
		{
			try
			{
				UserProfile userProfile = ProfileFiles.Read(ActiveKey);
				foreach (KeyValuePair<string, string> item in CaptureValues())
				{
					userProfile.Values[item.Key] = item.Value;
				}
				ProfileFiles.Write(ActiveKey, userProfile);
				SetReference(userProfile.Name, userProfile.Values, merge: false, null);
			}
			catch
			{
			}
		}
		settings.ProfileAutoSave = false;
		SaveSettings();
	}

	private async void RestoreBackupPoint()
	{
		if (preview)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		RestorePointInfo point = await Task.Run(() => SystemRestore.BackupPoint());
		if (point == null)
		{
			Say("The AZIZ Backup restore point is not on this PC (Windows may have removed it to free space). Open Restore points to pick another one.", "AZIZ Backup");
			OpenSystemRestore();
		}
		else if (System.Windows.MessageBox.Show("Restore Windows to \"AZIZ Backup\" (" + Clock(point.Created) + ")?\n\nThis is the restore point AZIZ made the first time it opened, before any change. Windows restarts right away to restore. Save your work first. Personal files are not changed.", "AZIZ Backup", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
		{
			Record("System Restore", "Restore AZIZ Backup", "", "Restarting", new ActionResult
			{
				Success = true,
				Message = Clock(point.Created)
			});
			ActionResult actionResult = await Task.Run(() => SystemRestore.Restore(point.Sequence));
			if (!actionResult.Success)
			{
				Say("System Restore did not start: " + Utilities.Short(actionResult.Message), "AZIZ Backup");
			}
		}
	}

	private void ShowProfiles()
	{
		if (preview)
		{
			return;
		}
		StackPanel root = null;
		Action draw = null;
		draw = delegate
		{
			root.Children.Clear();
			TextBlock profilesTitle = Label("Profiles", 24.0, Text);
			profilesTitle.FontWeight = FontWeights.SemiBold;
			root.Children.Add(profilesTitle);
			if (AnyProfileActive)
			{
				System.Windows.Controls.Button valuesTab = Btn(ProfileName(ActiveKey) + " · values →", delegate
				{
					ShowProfileDetails(ActiveKey, fromList: true);
				});
				valuesTab.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
				valuesTab.Margin = new Thickness(0.0, 8.0, 0.0, 4.0);
				root.Children.Add(valuesTab);
			}
			TextBlock textBlock = Label("Active: " + ProfileName(ActiveKey), 13.0, Cyan);
			textBlock.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
			root.Children.Add(textBlock);
			root.Children.Add(Label((!AnyProfileActive) ? "No profile is active. Changes apply to Windows right away; at the next start AZIZ asks Keep / Restore for what changed. Create profile keeps your own set." : (UserProfileActive ? "Every change is saved into this profile at once. At the next start AZIZ asks Keep / Restore for the changes of the last session; Export asks the same during a session." : ("Ultra Low Latency and Low Latency come from One Click on Home. At the next start AZIZ lists anything that differs from " + ProfileName(ActiveKey) + ": Keep changes stores it, Restore puts the profile's value back.")), 12.0, Muted));
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 16.0, 0.0, 18.0)
			};
			wrapPanel.Children.Add(Btn("Create profile", delegate
			{
				string text3 = AskName("Create profile", "Name your profile. It starts from the settings Windows has right now.", "My profile");
				if (text3 == null)
				{
					return;
				}
				try
				{
					string text4 = ProfileFiles.NewPath(text3);
					ProfileFiles.Write(text4, new UserProfile
					{
						Name = ((ProfileFiles.SafeName(text3).Length == 0) ? "My profile" : text3.Trim()),
						CreatedUtc = DateTime.UtcNow.ToString("o"),
						Values = CaptureValues()
					});
					SetActiveProfile(text4);
					SetReference(ProfileName(text4), ProfileValues(text4), merge: false, null);
					Record(ProfileName(text4), "Create profile", "", ProfileValues(text4).Count + " settings", new ActionResult
					{
						Success = true,
						Message = "Created from the current Windows settings."
					});
					notice.Text = "Profile created and active: " + ProfileName(text4);
					draw();
				}
				catch (Exception ex2)
				{
					Say(ex2.Message, "Profiles");
				}
			}, primary: true));
			wrapPanel.Children.Add(Btn("Import", delegate
			{
				Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog
				{
					Title = "Import AZIZ profile",
					Filter = "AZIZ profile (*.azizprofile)|*.azizprofile|JSON (*.json)|*.json"
				};
				if (openFileDialog.ShowDialog() != true)
				{
					return;
				}
				try
				{
					UserProfile userProfile2 = ProfileFiles.Read(openFileDialog.FileName);
					ProfileFiles.Write(ProfileFiles.NewPath(userProfile2.Name), userProfile2);
					notice.Text = "Imported " + userProfile2.Name + " · press Use to apply it.";
					draw();
				}
				catch (Exception ex)
				{
					Say(ex.Message, "Import profile");
				}
			}));
			root.Children.Add(wrapPanel);
			root.Children.Add(Label("BUILT IN", 11.0, Purple));
			root.Children.Add(ProfileRow("windows-default", "Windows Default", "Not a generic Windows default: these are YOUR Windows readings, saved the first time AZIZ opened on this PC, before AZIZ Gaming Optimizer changed anything (values that existed, values that were missing, services, boot options and power-plan values). If it does not solve a problem, use Restore AZIZ Backup: the restore point AZIZ made at that same first start.", draw));
			List<string> list = ProfileFiles.List();
			root.Children.Add(Spacer(10));
			root.Children.Add(Label("YOUR PROFILES · " + list.Count, 11.0, Purple));
			if (list.Count == 0)
			{
				root.Children.Add(Label("Create profile saves what Windows has now as a new local profile. Export turns any profile into a file to share.", 12.0, Muted));
			}
			foreach (string item in list)
			{
				UserProfile userProfile = null;
				try
				{
					userProfile = ProfileFiles.Read(item);
				}
				catch
				{
				}
				DateTime result;
				string text2 = ((userProfile != null && DateTime.TryParse(userProfile.SavedUtc ?? userProfile.CreatedUtc, out result)) ? Clock(result.ToLocalTime()) : "");
				root.Children.Add(ProfileRow(item, (userProfile == null) ? (System.IO.Path.GetFileNameWithoutExtension(item) + " (unreadable)") : userProfile.Name, (userProfile == null) ? "This file cannot be read." : (userProfile.Values.Count + " settings · saved " + text2), draw));
			}
		};
		ShowSheet(delegate(StackPanel panel, Action closeSheet)
		{
			root = panel;
			draw();
		});
	}

	private Border ProfileRow(string key, string name, string detail, Action redraw)
	{
		DockPanel dockPanel = new DockPanel();
		StackPanel stackPanel = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			VerticalAlignment = VerticalAlignment.Center
		};
		bool isActive = ActiveKey == key;
		if (isActive)
		{
			TextBlock textBlock = Label("ACTIVE", 12.0, B("#3B9EFF"));
			textBlock.FontWeight = FontWeights.Bold;
			textBlock.VerticalAlignment = VerticalAlignment.Center;
			textBlock.Margin = new Thickness(0.0, 0.0, 12.0, 0.0);
			stackPanel.Children.Add(textBlock);
		}
		System.Windows.Controls.Button button = Btn("Use", async delegate
		{
			await UseProfile(key);
			redraw();
		}, !isActive);
		button.IsEnabled = !isActive;
		button.ToolTip = (isActive ? "Already in use" : ("Use " + name));
		stackPanel.Children.Add(button);
		stackPanel.Children.Add(Btn("Details", delegate
		{
			ShowProfileDetails(key, fromList: true);
		}));
		stackPanel.Children.Add(Btn("Export", delegate
		{
			ExportProfile(key);
		}));
		if (key == "windows-default")
		{
			stackPanel.Children.Add(Btn("Restore AZIZ Backup", RestoreBackupPoint));
		}
		if (!ProfileLogic.BuiltIn(key))
		{
			stackPanel.Children.Add(Btn("Remove", delegate
			{
				if (System.Windows.MessageBox.Show("Remove " + name + " from AZIZ?\n\nWindows settings are not changed.", "Remove profile", MessageBoxButton.OKCancel) != MessageBoxResult.OK)
				{
					return;
				}
				try
				{
					File.Delete(key);
					if (isActive)
					{
						SetActiveProfile("");
					}
					redraw();
				}
				catch (Exception ex)
				{
					Say(ex.Message);
				}
			}));
		}
		DockPanel.SetDock(stackPanel, Dock.Right);
		dockPanel.Children.Add(stackPanel);
		StackPanel stackPanel2 = Stack();
		TextBlock textBlock2 = Label(name, 15.0, isActive ? B("#3B9EFF") : Text);
		textBlock2.Cursor = System.Windows.Input.Cursors.Hand;
		textBlock2.ToolTip = "Open the full profile";
		textBlock2.MouseLeftButtonUp += delegate
		{
			ShowProfileDetails(key, fromList: true);
		};
		stackPanel2.Children.Add(textBlock2);
		stackPanel2.Children.Add(Label(detail, 11.0, Muted));
		dockPanel.Children.Add(stackPanel2);
		Border border = Card(dockPanel);
		border.Padding = new Thickness(16.0, 12.0, 14.0, 12.0);
		border.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
		return border;
	}

	private string ProfileAbout(string key)
	{
		switch (key)
		{
		case "windows-default":
			return "Your own Windows readings, saved the first time AZIZ opened on this PC, before AZIZ changed anything.";
		case "aziz-recommended":
			return "Static profile · Low Latency (LL). Toggles and Tweaks on Low Latency, MSI on for the main GPU, Network Recommended, Security Recommended (BitLocker off) and Services Recommended: Bluetooth, Wi-Fi and wireless, remote access, Phone Link, Search indexing and BitLocker off; update services (BITS, Delivery Optimization, Orchestrator, Medic) off and Windows Update service Manual. AZIZ registry set and debloat applied. Responsive everyday setup that keeps normal power saving.";
		case "aziz-ultra":
			return "Static profile · Ultra Low Latency (ULL). Toggles and Tweaks on Ultra Low Latency (0.5 ms timer, CPU latency tolerance), MSI on for the main GPU, Network Recommended, Security Recommended (BitLocker off) and Services Recommended: Bluetooth, Wi-Fi and wireless, remote access, Phone Link, Search indexing and BitLocker off; update services (BITS, Delivery Optimization, Orchestrator, Medic) off and Windows Update service Manual. AZIZ registry set and debloat applied. Lowest latency · more power and heat.";
		default:
			return "Your own profile.";
		}
	}

	private Grid sheetHost;

	private UIElement sheetRoot;

	// Blurred in-window sheet (same look as the Optimize picker and Keep changes). Blocks like a dialog; sheets can stack.
	private void ShowSheet(Action<StackPanel, Action> fill, double maxWidth = 880.0)
	{
		if (sheetHost == null)
		{
			sheetRoot = (UIElement)base.Content;
			base.Content = null;
			sheetRoot.Effect = new BlurEffect
			{
				Radius = 4.0,
				KernelType = KernelType.Gaussian
			};
			sheetHost = new Grid();
			sheetHost.Children.Add(sheetRoot);
			base.Content = sheetHost;
		}
		DispatcherFrame frame = new DispatcherFrame();
		Grid shade = new Grid
		{
			Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(70, 0, 0, 0)),
			Opacity = 0.0
		};
		shade.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(200.0)));
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(28.0, 22.0, 28.0, 24.0);
		bool closed = false;
		Action close = delegate
		{
			if (!closed)
			{
				closed = true;
				sheetHost.Children.Remove(shade);
				if (sheetHost.Children.Count <= 1)
				{
					sheetHost.Children.Clear();
					sheetRoot.Effect = null;
					base.Content = sheetRoot;
					sheetHost = null;
					sheetRoot = null;
				}
				frame.Continue = false;
			}
		};
		Grid grid = new Grid();
		grid.Children.Add(new ScrollViewer
		{
			Content = stackPanel,
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto
		});
		System.Windows.Controls.Button button = Btn("×", close);
		button.Background = System.Windows.Media.Brushes.Transparent;
		button.FontSize = 18.0;
		button.Padding = new Thickness(10.0, 2.0, 10.0, 4.0);
		button.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
		button.VerticalAlignment = VerticalAlignment.Top;
		button.Margin = new Thickness(0.0, 10.0, 10.0, 0.0);
		grid.Children.Add(button);
		Border border = new Border
		{
			MaxWidth = maxWidth,
			Margin = new Thickness(40.0, 36.0, 40.0, 36.0),
			CornerRadius = new CornerRadius(22.0),
			Background = new LinearGradientBrush(System.Windows.Media.Color.FromArgb(245, 26, 18, 62), System.Windows.Media.Color.FromArgb(245, 10, 12, 34), 90.0),
			BorderBrush = new SolidColorBrush(System.Windows.Media.Color.FromArgb(120, 120, 90, 230)),
			BorderThickness = new Thickness(1.0),
			Effect = new DropShadowEffect
			{
				Color = System.Windows.Media.Color.FromRgb(90, 60, 200),
				BlurRadius = 40.0,
				ShadowDepth = 0.0,
				Opacity = 0.35
			},
			VerticalAlignment = VerticalAlignment.Center,
			Child = grid
		};
		shade.Children.Add(border);
		shade.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
		{
			if (e.OriginalSource == shade)
			{
				close();
			}
		};
		fill(stackPanel, close);
		sheetHost.Children.Add(shade);
		Dispatcher.PushFrame(frame);
	}

	private void ShowProfileDetails(string key, bool fromList = false)
	{
		if (preview || string.IsNullOrEmpty(key))
		{
			ShowProfiles();
			return;
		}
		string name = ProfileName(key);
		Dictionary<string, string> values = ProfileValues(key);
		bool openAll = false;
		ShowSheet(delegate(StackPanel panel, Action closeSheet)
		{
			bool isActive = ActiveKey == key;
			TextBlock textBlock = Label(name, 26.0, Text);
			textBlock.FontWeight = FontWeights.SemiBold;
			panel.Children.Add(textBlock);
			TextBlock textBlock2 = Label((isActive ? "ACTIVE · " : "") + (ProfileLogic.BuiltIn(key) ? "STATIC PROFILE" : "YOUR PROFILE"), 11.0, isActive ? Cyan : Purple);
			textBlock2.FontWeight = FontWeights.SemiBold;
			textBlock2.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
			panel.Children.Add(textBlock2);
			panel.Children.Add(Label(ProfileAbout(key), 12.0, Muted));
			List<Tuple<Tweak, string>> rows = (from t in engine.Tweaks
				where values.ContainsKey(t.Id)
				select Tuple.Create(t, values[t.Id])).ToList();
			int differs = rows.Count((Tuple<Tweak, string> r) => CurrentValue(r.Item1) != r.Item2);
			TextBlock textBlock3 = Label(rows.Count + " settings · " + ((differs == 0) ? "Windows matches this profile" : (differs + " differ from what Windows has now")), 12.0, (differs == 0) ? Green : Purple);
			textBlock3.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
			panel.Children.Add(textBlock3);
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 14.0, 0.0, 4.0)
			};
			System.Windows.Controls.Button button = Btn(isActive ? "In use" : "Use this profile", async delegate
			{
				closeSheet();
				if (fromList)
				{
					return;
				}
				await UseProfile(key);
			}, !isActive);
			button.Visibility = ((fromList && !isActive) ? Visibility.Collapsed : Visibility.Visible);
			button.IsEnabled = !isActive;
			wrapPanel.Children.Add(button);
			if (!fromList)
			{
				wrapPanel.Children.Add(Btn("All profiles", delegate
				{
					openAll = true;
					closeSheet();
				}));
			}
			panel.Children.Add(wrapPanel);
			foreach (IGrouping<string, Tuple<Tweak, string>> item in from r in rows
				group r by ProfilePage(r.Item1) into g
				orderby Array.IndexOf(new string[6] { "Toggles", "Tweaks", "Network", "Security", "Services", "Other" }, g.Key)
				select g)
			{
				StackPanel list = Stack();
				bool folded = item.Key == "Services";
				bool filled = false;
				Action fill = delegate
				{
					if (filled)
					{
						return;
					}
					filled = true;
					foreach (Tuple<Tweak, string> r in item.OrderBy((Tuple<Tweak, string> x) => x.Item1.Name, StringComparer.OrdinalIgnoreCase))
					{
						list.Children.Add(ProfileDetailRow(r.Item1, r.Item2));
					}
				};
				int count = item.Count((Tuple<Tweak, string> r) => CurrentValue(r.Item1) != r.Item2);
				panel.Children.Add(GroupHeader(L(item.Key), item.Count(), folded, delegate(bool fold)
				{
					if (!fold)
					{
						fill();
					}
					list.Visibility = (fold ? Visibility.Collapsed : Visibility.Visible);
				}));
				if (count > 0)
				{
					TextBlock textBlock4 = Label(count + " differ from Windows now", 11.0, Muted);
					textBlock4.Margin = new Thickness(2.0, -6.0, 0.0, 8.0);
					panel.Children.Add(textBlock4);
				}
				if (folded)
				{
					list.Visibility = Visibility.Collapsed;
				}
				else
				{
					fill();
				}
				panel.Children.Add(list);
			}
		});
		if (openAll)
		{
			ShowProfiles();
		}
	}

	private string ProfilePage(Tweak t)
	{
		if (GeneralIds.Contains(t.Id))
		{
			return "Toggles";
		}
		string category = t.Category;
		if (category == "Tweaks" || category == "Network" || category == "Security" || category == "Services")
		{
			return category;
		}
		if (t.Kind == "Service")
		{
			return "Services";
		}
		return "Other";
	}

	private Border ProfileDetailRow(Tweak t, string value)
	{
		string text = CurrentValue(t);
		bool flag = text == value;
		Grid grid = new Grid();
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(t.Name, 13.0, Text));
		TextBlock textBlock = Label(t.Description, 11.0, Muted);
		textBlock.Margin = new Thickness(0.0, 3.0, 18.0, 0.0);
		textBlock.MaxHeight = 44.0;
		textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
		textBlock.ToolTip = t.Description;
		stackPanel.Children.Add(textBlock);
		grid.Children.Add(stackPanel);
		StackPanel stackPanel2 = Stack();
		stackPanel2.VerticalAlignment = VerticalAlignment.Center;
		stackPanel2.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
		TextBlock textBlock2 = Label(ValueText(t, value), 13.0, Cyan);
		textBlock2.FontWeight = FontWeights.SemiBold;
		textBlock2.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
		stackPanel2.Children.Add(textBlock2);
		TextBlock textBlock3 = Label(flag ? "✓ Windows matches" : ("Windows now: " + ValueText(t, text)), 11.0, flag ? Green : Muted);
		textBlock3.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
		stackPanel2.Children.Add(textBlock3);
		Grid.SetColumn(stackPanel2, 1);
		grid.Children.Add(stackPanel2);
		Border border = Card(grid);
		border.Padding = new Thickness(16.0, 10.0, 14.0, 10.0);
		border.Margin = new Thickness(0.0, 0.0, 0.0, 6.0);
		border.CornerRadius = new CornerRadius(10.0);
		return border;
	}

	private bool RestoresOriginal(string key, Tweak t)
	{
		if (key == "windows-default" && engine.CanRestore(t.Id) && engine.MatchesOriginal(t.Id) == false)
		{
			// Restore only when the option itself differs from the original. Values Windows rewrites on its own
			// (UserPreferencesMask) never match byte for byte, and would otherwise be restored on every apply.
			string text = engine.OriginalValue(t.Id);
			return text == null || CurrentValue(t) != text;
		}
		return false;
	}

	private async Task QueueProfileValue(string key, Tweak t, string value)
	{
		if (RestoresOriginal(key, t))
		{
			Enqueue(t, value != "Disabled" && value != "4", (t.Kind == "Service") ? value : null, restore: true);
		}
		else if (value != null)
		{
			await QueueValue(t, value);
		}
	}

	private async Task UseProfile(string key)
	{
		if (applying || optimizing || profileBusy)
		{
			if (profileBusy || optimizing)
			{
				notice.Text = "Another profile change is still running. Try again when it has finished.";
			}
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		profileBusy = true;
		try
		{
			await UseProfileNow(key);
		}
		finally
		{
			profileBusy = false;
		}
	}

	private async Task UseProfileNow(string key)
	{
		Dictionary<string, string> values = ProfileValues(key);
		List<Tweak> list = engine.Tweaks.Where(Profileable).Where(delegate(Tweak t)
		{
			if (states.TryGetValue(t.Id, out var value3) && value3.State == "Unavailable")
			{
				return false;
			}
			if (RestoresOriginal(key, t))
			{
				return true;
			}
			string value4;
			return values.TryGetValue(t.Id, out value4) && ValueApplies(t, value4) && CurrentValue(t) != value4;
		}).ToList();
		string name = ProfileName(key);
		List<Tweak> chosen = new List<Tweak>();
		if (list.Count > 0 && !ReviewChanges(name, "Settings that differ from this profile. Untick anything you want to keep as it is." + ((key == "aziz-recommended" || key == "aziz-ultra") ? " Also applied: the AZIZ registry set, the AZIZ debloat settings and removal of Microsoft Edge and WebView2 (listed in History)." : ""), list.Select(delegate(Tweak t)
		{
			values.TryGetValue(t.Id, out var value2);
			return Tuple.Create(t, CurrentValue(t), value2 ?? "Original");
		}).ToList(), out chosen))
		{
			return;
		}
		SetActiveProfile(key);
		SetReference(name, values, merge: false, from t in list.Except(chosen)
			select t.Id);
		Record(name, "Use profile", "", chosen.Count + " changes", new ActionResult
		{
			Success = true,
			Message = string.Join(", ", chosen.Select((Tweak t) => t.Name))
		});
		// Windows Default: the registry set and startup apps go back first. The registry set was applied after the
		// options, so its saved "before" values can be AZIZ values for keys an option also uses; each option's own
		// restore then runs on top and puts the real Windows original back.
		if (key == "windows-default")
		{
			List<string> regBack = await Task.Run(() => RegistryJournal.RestoreAll());
			if (regBack.Count > 0)
			{
				Record("AZIZ registry set", "Windows Default", "AZIZ values", regBack.Count + " values back", new ActionResult
				{
					Success = true,
					Message = string.Join("\n", regBack)
				});
			}
			List<string> back = await Task.Run(() => StartupApps.RestoreAll());
			if (back.Count > 0)
			{
				Record("Startup apps", "Windows Default", "Off", back.Count + " back on", new ActionResult
				{
					Success = true,
					Message = string.Join("\n", back)
				});
			}
			List<string> tasksBack = await Task.Run(() => TaskJournal.RestoreAll());
			if (tasksBack.Count > 0)
			{
				Record("Scheduled tasks", "Windows Default", "Off", tasksBack.Count + " back", new ActionResult
				{
					Success = true,
					Message = string.Join("\n", tasksBack)
				});
			}
		}
		foreach (Tweak item in chosen)
		{
			values.TryGetValue(item.Id, out var value);
			await QueueProfileValue(key, item, value);
		}
		if (key == "aziz-recommended" || key == "aziz-ultra")
		{
			// The profile's own options first (they save their Windows originals), then the registry set on top.
			Stopwatch wait = Stopwatch.StartNew();
			while ((pendingOrder.Count > 0 || workers > 0) && wait.Elapsed.TotalMinutes < 20.0)
			{
				await Task.Delay(500);
			}
			// The user may have switched to another profile meanwhile: then this one's extras no longer apply.
			if ((settings.ActiveProfile ?? "") != key)
			{
				return;
			}
			await EnsureGpuMsi();
			await ApplyAzizExtras("Use profile");
		}
		notice.Text = name + " is active" + ((chosen.Count > 0) ? (" · " + chosen.Count + " changes applying in the background.") : " · Windows already matches.");
	}

	private void ExportProfile(string key)
	{
		try
		{
			if (key == ActiveKey && UserProfileActive)
			{
				List<Tuple<Tweak, string, string>> list = SessionChanges();
				if (list.Count > 0)
				{
					MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(list.Count + " setting" + ((list.Count == 1) ? "" : "s") + " changed in this session:\n\n" + string.Join("\n", list.Take(12).Select((Tuple<Tweak, string, string> x) => "• " + x.Item1.Name + ": " + ValueText(x.Item1, x.Item2) + " → " + ValueText(x.Item1, x.Item3))) + ((list.Count > 12) ? "\n…" : "") + "\n\nYes: keep them (export with the new values).\nNo: restore the previous values (export those).", "Export profile", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
					if (messageBoxResult == MessageBoxResult.Cancel)
					{
						return;
					}
					AppliedReference appliedReference = LoadReference();
					UserProfile userProfile3 = ProfileFiles.Read(key);
					if (messageBoxResult == MessageBoxResult.Yes)
					{
						KeepChanges(appliedReference, list);
					}
					else
					{
						foreach (Tuple<Tweak, string, string> item in list)
						{
							userProfile3.Values[item.Item1.Id] = item.Item2;
							_ = QueueProfileValue(key, item.Item1, item.Item2);
						}
						ProfileFiles.Write(key, userProfile3);
						Record(userProfile3.Name, "Restore session changes", "", list.Count + " settings", new ActionResult
						{
							Success = true,
							Message = string.Join(", ", list.Select((Tuple<Tweak, string, string> x) => x.Item1.Name))
						});
					}
				}
			}
			UserProfile userProfile = (ProfileLogic.BuiltIn(key) ? new UserProfile
			{
				Name = ProfileName(key),
				CreatedUtc = DateTime.UtcNow.ToString("o"),
				Values = ProfileValues(key)
			} : ProfileFiles.Read(key));
			UserProfile userProfile2 = userProfile;
			Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
			{
				Title = "Export profile",
				Filter = "AZIZ profile (*.azizprofile)|*.azizprofile",
				FileName = ProfileFiles.SafeName(userProfile2.Name) + ".azizprofile",
				InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
			};
			if (saveFileDialog.ShowDialog() == true)
			{
				UserProfile p = new UserProfile
				{
					Name = userProfile2.Name,
					CreatedUtc = userProfile2.CreatedUtc,
					Values = userProfile2.Values
				};
				ProfileFiles.Write(saveFileDialog.FileName, p);
				notice.Text = "Exported " + userProfile2.Values.Count + " settings. The file holds setting IDs and values only; each PC reads its own devices.";
			}
		}
		catch (Exception ex)
		{
			Say(ex.Message, "Export profile");
		}
	}

	private string AskName(string title, string intro, string suggestion)
	{
		string result = null;
		Window window = new Window();
		window.Owner = this;
		window.Title = title;
		window.Width = 480.0;
		window.Height = 250.0;
		window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window.Background = new SolidColorBrush(Bg);
		window.Foreground = Text;
		Window w = window;
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(22.0);
		stackPanel.Children.Add(Label(title, 18.0, Text));
		stackPanel.Children.Add(Label(intro, 12.0, Muted));
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Text = suggestion;
		textBox.Margin = new Thickness(0.0, 14.0, 0.0, 14.0);
		System.Windows.Controls.TextBox input = textBox;
		stackPanel.Children.Add(input);
		TextBlock error = Label("", 11.0, B("#F87171"));
		stackPanel.Children.Add(error);
		WrapPanel wrapPanel = new WrapPanel();
		wrapPanel.Children.Add(Btn("Create", delegate
		{
			if (ProfileFiles.SafeName(input.Text).Length == 0)
			{
				error.Text = "Enter a name.";
			}
			else
			{
				result = input.Text.Trim();
				w.Close();
			}
		}, primary: true));
		wrapPanel.Children.Add(Btn("Cancel", delegate
		{
			w.Close();
		}));
		stackPanel.Children.Add(wrapPanel);
		input.TextChanged += delegate
		{
			error.Text = "";
		};
		w.Content = stackPanel;
		DarkDialog(w);
		w.Loaded += delegate
		{
			input.Focus();
			input.SelectAll();
		};
		w.ShowDialog();
		return result;
	}

	private static bool ServiceBackupOnly(string file)
	{
		try
		{
			string text = System.IO.Path.GetFileNameWithoutExtension(file);
			if (string.IsNullOrEmpty(text) || text.IndexOfAny(new char[3] { '\\', '[', ']' }) >= 0)
			{
				return false;
			}
			string text2 = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Services\\" + text;
			int num = 0;
			foreach (string item in File.ReadAllLines(file))
			{
				string text3 = item.Trim();
				if (!text3.StartsWith("["))
				{
					continue;
				}
				string text4 = text3.TrimStart('[', '-').TrimEnd(']');
				if (!text4.Equals(text2, StringComparison.OrdinalIgnoreCase) && !text4.StartsWith(text2 + "\\", StringComparison.OrdinalIgnoreCase))
				{
					return false;
				}
				num++;
			}
			return num > 0;
		}
		catch
		{
			return false;
		}
	}

	private void ShowRecentChanges()
	{
		AppliedReference baseline = LoadReference();
		if (baseline == null)
		{
			// No profile and nothing optimized: this start's Windows values become the reference, so the next start
			// asks Keep / Restore only if something changed (Keep makes the new values the reference; it is not asked again).
			if (!AnyProfileActive && !preview)
			{
				try
				{
					SetReference("Your Windows", CaptureValues(), merge: false, null);
				}
				catch
				{
				}
			}
			return;
		}
		Dictionary<string, string> values = baseline.Values;
		string label = (AnyProfileActive ? ProfileName(ActiveKey) : "your Windows settings");
		List<Tuple<Tweak, string, string>> rows = new List<Tuple<Tweak, string, string>>();
		bool staticProfile = ProfileLogic.BuiltIn(ActiveKey);
		foreach (Tweak item in engine.Tweaks.Where(Profileable))
		{
			// Security options changed by hand on a static profile are the user's choice: not listed at the next start.
			if (staticProfile && item.Category == "Security")
			{
				continue;
			}
			// A value Optimize never writes (a service that is a disk/volume filter on this PC) is never offered for Restore:
			// disabling it could stop Windows from booting.
			if (!values.TryGetValue(item.Id, out var value) || !ValueApplies(item, value) || !ProfileLogic.PresetSafe(item, value) || (states.TryGetValue(item.Id, out var value2) && value2.State == "Unavailable"))
			{
				continue;
			}
			string text = CurrentValue(item);
			if (text != null)
			{
				string value3;
				if (text == value)
				{
					baseline.Accepted.Remove(item.Id);
				}
				else if (!baseline.Accepted.TryGetValue(item.Id, out value3) || !(value3 == text))
				{
					rows.Add(Tuple.Create(item, value, text));
				}
			}
		}
		SaveReference(baseline);
		if (rows.Count == 0)
		{
			return;
		}
		List<HistoryEntry> source = cachedHistory.Concat(observations).ToList();
		bool builtIn = ProfileLogic.BuiltIn(ActiveKey);
		UIElement root = (UIElement)base.Content;
		base.Content = null;
		root.Effect = new BlurEffect
		{
			Radius = 4.0,
			KernelType = KernelType.Gaussian
		};
		Grid host = new Grid();
		host.Children.Add(root);
		Grid shade = new Grid
		{
			Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(70, 0, 0, 0)),
			Opacity = 0.0
		};
		shade.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(220.0)));
		StackPanel column = new StackPanel
		{
			HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center,
			MaxWidth = 760.0
		};
		TextBlock kicker = Label("CHANGES SINCE LAST TIME", 11.0, B("#5FD3F3"));
		kicker.FontWeight = FontWeights.SemiBold;
		kicker.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		column.Children.Add(kicker);
		TextBlock title = Label(rows.Count + " setting" + ((rows.Count == 1) ? "" : "s") + (AnyProfileActive ? (" differ from " + label) : " changed since last time"), 24.0, System.Windows.Media.Brushes.White);
		title.FontWeight = FontWeights.SemiBold;
		title.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI");
		title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		title.TextAlignment = TextAlignment.Center;
		title.Margin = new Thickness(0.0, 4.0, 0.0, 4.0);
		column.Children.Add(title);
		TextBlock about = Label((!AnyProfileActive) ? "No profile is active. Restore puts these settings back to how they were; Keep changes keeps them and does not ask about them again." : (builtIn ? (label + " is a static profile. Windows was changed outside it (by you, another app or Windows itself). Restore puts the profile back; Keep changes keeps Windows as it is and asks you to create or choose your own profile.") : ("Restore puts " + label + "'s values back. Keep changes saves what Windows has now into " + label + ".")), 12.0, B("#B7AEE6"));
		about.TextAlignment = TextAlignment.Center;
		about.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		about.MaxWidth = 640.0;
		column.Children.Add(about);
		StackPanel list = Stack();
		foreach (Tuple<Tweak, string, string> item2 in rows)
		{
			Tweak t = item2.Item1;
			HistoryEntry historyEntry = (from h in source
				where h.Name == t.Name
				orderby h.Time descending
				select h).FirstOrDefault();
			DateTime result;
			string text2 = ((historyEntry != null && DateTime.TryParse(((historyEntry.Time ?? "").Length > 19) ? historyEntry.Time.Substring(0, 19) : historyEntry.Time, out result)) ? Clock(result) : (previousSession.HasValue ? ("after " + Clock(previousSession.Value)) : ""));
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition());
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = GridLength.Auto
			});
			StackPanel stackPanel3 = Stack();
			TextBlock textBlock2 = Label(t.Name, 13.0, Text);
			textBlock2.FontWeight = FontWeights.SemiBold;
			textBlock2.TextTrimming = TextTrimming.CharacterEllipsis;
			textBlock2.TextWrapping = TextWrapping.NoWrap;
			stackPanel3.Children.Add(textBlock2);
			stackPanel3.Children.Add(Label("Profile " + ValueText(t, item2.Item2) + "   →   Now " + ValueText(t, item2.Item3) + (t.RequiresRestart ? " · after restart" : ""), 11.0, B("#A99BFF")));
			grid.Children.Add(stackPanel3);
			TextBlock textBlock3 = Label(text2, 10.0, Muted);
			textBlock3.VerticalAlignment = VerticalAlignment.Center;
			textBlock3.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
			Grid.SetColumn(textBlock3, 1);
			grid.Children.Add(textBlock3);
			list.Children.Add(new Border
			{
				Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(200, 18, 16, 44)),
				CornerRadius = new CornerRadius(12.0),
				Padding = new Thickness(14.0, 9.0, 14.0, 9.0),
				Margin = new Thickness(0.0, 0.0, 0.0, 6.0),
				Child = grid
			});
		}
		column.Children.Add(new ScrollViewer
		{
			Content = list,
			MaxHeight = 260.0,
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
			Margin = new Thickness(0.0, 16.0, 0.0, 0.0)
		});
		StackPanel options = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
			Margin = new Thickness(0.0, 22.0, 0.0, 0.0)
		};
		column.Children.Add(options);
		shade.Children.Add(column);
		Action close = delegate
		{
			host.Children.Clear();
			root.Effect = null;
			base.Content = root;
		};
		Func<string, string, string, int, Action, Border> option = delegate(string glyph, string name, string desc, int order, Action pick)
		{
			StackPanel stackPanel = Stack();
			TextBlock textBlock = Label(glyph, 20.0, B("#C9BAFF"));
			textBlock.Margin = new Thickness(0.0, 0.0, 0.0, 6.0);
			stackPanel.Children.Add(textBlock);
			TextBlock textBlock4 = Label(name, 19.0, System.Windows.Media.Brushes.White);
			textBlock4.FontWeight = FontWeights.Bold;
			textBlock4.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI");
			stackPanel.Children.Add(textBlock4);
			TextBlock textBlock5 = Label(desc, 12.0, B("#B7AEE6"));
			textBlock5.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
			stackPanel.Children.Add(textBlock5);
			ScaleTransform scale = new ScaleTransform(1.0, 1.0);
			TranslateTransform rise = new TranslateTransform(0.0, 18.0);
			DropShadowEffect glow = new DropShadowEffect
			{
				Color = System.Windows.Media.Color.FromRgb(118, 84, 232),
				BlurRadius = 34.0,
				ShadowDepth = 0.0,
				Opacity = 0.3
			};
			Border card = new Border
			{
				Width = 300.0,
				Padding = new Thickness(24.0, 20.0, 24.0, 22.0),
				Margin = new Thickness(10.0, 0.0, 10.0, 0.0),
				CornerRadius = new CornerRadius(20.0),
				Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(44, 30, 104), System.Windows.Media.Color.FromRgb(22, 14, 56), 90.0),
				Cursor = System.Windows.Input.Cursors.Hand,
				Effect = glow,
				Child = stackPanel,
				Opacity = 0.0,
				RenderTransformOrigin = new System.Windows.Point(0.5, 0.5),
				RenderTransform = new TransformGroup
				{
					Children = { (Transform)scale, (Transform)rise }
				}
			};
			TimeSpan beginTime = TimeSpan.FromMilliseconds(80 + order * 70);
			card.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(260.0))
			{
				BeginTime = beginTime
			});
			rise.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(18.0, 0.0, TimeSpan.FromMilliseconds(320.0))
			{
				BeginTime = beginTime,
				EasingFunction = new CubicEase
				{
					EasingMode = EasingMode.EaseOut
				}
			});
			card.MouseEnter += delegate
			{
				DoubleAnimation animation = new DoubleAnimation(1.04, TimeSpan.FromMilliseconds(150.0));
				scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
				scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
				glow.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(0.7, TimeSpan.FromMilliseconds(150.0)));
			};
			card.MouseLeave += delegate
			{
				DoubleAnimation animation = new DoubleAnimation(1.0, TimeSpan.FromMilliseconds(150.0));
				scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
				scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
				glow.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(0.3, TimeSpan.FromMilliseconds(150.0)));
			};
			card.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
			{
				e.Handled = true;
				close();
				pick();
			};
			return card;
		};
		options.Children.Add(option("↺", AnyProfileActive ? ("Restore " + label) : "Restore", AnyProfileActive ? ("Put the " + rows.Count + " setting" + ((rows.Count == 1) ? "" : "s") + " back to the profile and stay on " + label + ".") : ("Put the " + rows.Count + " setting" + ((rows.Count == 1) ? "" : "s") + " back to how they were."), 0, async delegate
		{
			if (!Program.IsAdmin)
			{
				Elevate();
				return;
			}
			Record("Changes since last time", "Restore profile", "Changed", label, new ActionResult
			{
				Success = true,
				Message = string.Join(", ", rows.Select((Tuple<Tweak, string, string> x) => x.Item1.Name))
			});
			foreach (Tuple<Tweak, string, string> item3 in rows)
			{
				await QueueProfileValue(ActiveKey, item3.Item1, item3.Item2);
			}
			notice.Text = "Restoring " + rows.Count + " settings to " + label + " in the background.";
		}));
		options.Children.Add(option("✓", "Keep changes", (!AnyProfileActive) ? "Keep Windows as it is. AZIZ will not ask about these settings again." : (builtIn ? "Keep Windows as it is, then create or choose your own profile." : ("Save what Windows has now into " + label + ".")), 1, delegate
		{
			KeepChanges(baseline, rows);
			if (builtIn)
			{
				EnsureEditable(null, null);
			}
		}));
		host.Children.Add(shade);
		base.Content = host;
	}

	private void KeepChanges(AppliedReference baseline, List<Tuple<Tweak, string, string>> rows)
	{
		string text = (AnyProfileActive ? ProfileName(ActiveKey) : "your Windows settings");
		foreach (Tuple<Tweak, string, string> row in rows)
		{
			baseline.Values[row.Item1.Id] = row.Item3;
			baseline.Accepted.Remove(row.Item1.Id);
		}
		if (UserProfileActive)
		{
			try
			{
				UserProfile userProfile = ProfileFiles.Read(ActiveKey);
				foreach (Tuple<Tweak, string, string> row2 in rows)
				{
					userProfile.Values[row2.Item1.Id] = row2.Item3;
				}
				ProfileFiles.Write(ActiveKey, userProfile);
			}
			catch
			{
				foreach (Tuple<Tweak, string, string> row3 in rows)
				{
					baseline.Accepted[row3.Item1.Id] = row3.Item3;
				}
			}
		}
		SaveReference(baseline);
		Record("Changes since last time", "Keep changes", text, rows.Count + " settings saved", new ActionResult
		{
			Success = true,
			Message = string.Join(", ", rows.Select((Tuple<Tweak, string, string> x) => x.Item1.Name + " → " + ValueText(x.Item1, x.Item3)))
		});
		notice.Text = rows.Count + " change" + ((rows.Count == 1) ? "" : "s") + " saved into " + text + ".";
	}

	public MainWindow(bool isPreview, bool sensorPreview = false, bool sunsetPreview = false)
	{
		pendingChanges = new Dictionary<string, PendingChange>();
		pendingOrder = new List<string>();
		inFlight = new HashSet<string>();
		batchFailed = new List<string>();
		adapterReasons = new List<string>();
		installingPackages = new HashSet<string>();
		downloadCategory = "All categories";
		downloadStatus = "All downloads";
		downloadQuery = "";
		games = new List<GameEntry>();
		downloads = new List<DownloadJob>();
		downloadViews = new Dictionary<DownloadJob, Action>();
		serviceQuery = "";
		tweakHosts = new Dictionary<string, Dictionary<string, Border>>();
		lastLiveRead = DateTime.MinValue;
		viewCache = new Dictionary<string, ViewSnapshot>();
		cachedPowerPlans = new List<PowerPlan>();
		installedLaunchers = new List<LaunchEntry>();
		cachedHistory = new List<HistoryEntry>();
		StartupTimings = new Dictionary<string, double>();
		pendingRegistry = new HashSet<string>();
		states = new Dictionary<string, TweakStatus>();
		favorites = new HashSet<string>();
		observations = new List<HistoryEntry>();
		current = "Home";
		metrics = new Dictionary<string, TextBlock>();
		traces = new Dictionary<string, Polyline>();
		points = new Dictionary<string, List<double>>();
		navButtons = new Dictionary<string, System.Windows.Controls.Button>();
		openingTools = new HashSet<string>();
		base.UseLayoutRounding = true;
		base.SnapsToDevicePixels = true;
		preview = isPreview;
		settings = (preview ? new AppSettings() : AppSettings.Load());
		if (sunsetPreview)
		{
			settings.Theme = "Sunset";
		}
		SetPalette();
		engine = new Engine(null, Program.Data);
		telemetry = new Telemetry(!preview || sensorPreview);
		base.Title = "AZIZ Gaming Optimizer";
		// Always opens at the default size (resizing lasts for that session only).
		System.Windows.Rect workArea = SystemParameters.WorkArea;
		double width = Math.Max(DefaultWidth, workArea.Width * 0.86);
		double height = Math.Max(DefaultHeight, workArea.Height * 0.88);
		base.Width = Math.Min(width, workArea.Width);
		base.Height = Math.Min(height, workArea.Height);
		// Small screens (1024×768, 1280×720): the window never starts larger than the screen.
		base.MinWidth = Math.Min(1080.0, workArea.Width);
		base.MinHeight = Math.Min(720.0, workArea.Height);
		base.Background = new SolidColorBrush(Bg);
		base.Foreground = Text;
		base.FontFamily = new System.Windows.Media.FontFamily("Segoe UI");
		base.FontSize = 14.0;
		base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		base.Icon = BrandLogo.ExternalImage();
		base.Resources.Add(typeof(System.Windows.Controls.Button), XamlReader.Parse("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='Button'><Setter Property='Foreground' Value='#E7EBF8'/><Setter Property='Background' Value='#202B40'/><Setter Property='BorderThickness' Value='0'/><Setter Property='Padding' Value='16,10'/><Setter Property='Cursor' Value='Hand'/><Setter Property='FontSize' Value='13'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'><Grid x:Name='box' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'><Border Background='{TemplateBinding Background}' CornerRadius='10'/><Border x:Name='hl' Background='#FFFFFF' CornerRadius='10' Opacity='0'/><ContentPresenter Margin='{TemplateBinding Padding}' HorizontalAlignment='{TemplateBinding HorizontalContentAlignment}' VerticalAlignment='Center'/></Grid><ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='hl' Property='Opacity' Value='.08'/></Trigger><Trigger Property='IsPressed' Value='True'><Setter TargetName='hl' Property='Opacity' Value='.16'/></Trigger><Trigger Property='IsEnabled' Value='False'><Setter TargetName='box' Property='Opacity' Value='.38'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>"));
		base.Resources.Add(typeof(System.Windows.Controls.Primitives.ScrollBar), XamlReader.Parse("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='ScrollBar'><Setter Property='Width' Value='7'/><Setter Property='Background' Value='Transparent'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ScrollBar'><Track xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' x:Name='PART_Track' IsDirectionReversed='True' Orientation='Vertical' Minimum='{TemplateBinding Minimum}' Maximum='{TemplateBinding Maximum}' ViewportSize='{TemplateBinding ViewportSize}' Value='{Binding Value, RelativeSource={RelativeSource TemplatedParent}, Mode=TwoWay}'><Track.Thumb><Thumb Width='5'><Thumb.Template><ControlTemplate TargetType='Thumb'><Border Background='#34415B' CornerRadius='3' Margin='1,0'/></ControlTemplate></Thumb.Template></Thumb></Track.Thumb></Track></ControlTemplate></Setter.Value></Setter></Style>"));
		ApplyInputStyles();
		BuildShell();
		LoadPreferences();
		Go("Home");
		SetupTray();
		base.StateChanged += delegate
		{
			if (sampleTimer != null)
			{
				if (base.WindowState == WindowState.Minimized)
				{
					sampleTimer.Stop();
				}
				else if (current == "Home" && base.IsVisible)
				{
					sampleTimer.Start();
				}
			}
			if (base.WindowState != WindowState.Minimized)
			{
				CatchUpPage();
			}
		};
		base.Loaded += async delegate
		{
			if (!preview)
			{
				await InitializeAsync();
				if (settings.StartMinimized && !shownOnce && !startedInTray)
				{
					HideToTray();
				}
				shownOnce = true;
			}
		};
		base.Closed += delegate
		{
			closing = true;
			if (tray != null)
			{
				((Component)tray).Dispose();
			}
			if (downloadTimer != null)
			{
				downloadTimer.Stop();
			}
			if (timerLease != null)
			{
				timerLease.Dispose();
			}
			StopWheel();
			if (registryWatch != null)
			{
				registryWatch.Dispose();
			}
			if (changeDebounce != null)
			{
				changeDebounce.Stop();
			}
			if (sampleTimer != null)
			{
				sampleTimer.Stop();
			}
			Task.Run(delegate
			{
				lock (telemetry)
				{
					telemetry.Dispose();
				}
			});
		};
	}

	private static System.Windows.Media.Brush B(string hex)
	{
		if (LightMode)
		{
			switch (hex)
			{
			case "#111B2C":
				hex = "#FFFFFF";
				break;
			case "#0D1423":
				hex = "#E7ECF5";
				break;
			case "#233049":
				hex = "#D5DDED";
				break;
			case "#233149":
				hex = "#DCE4F2";
				break;
			case "#252440":
				hex = "#DBD2FA";
				break;
			case "#131F32":
				hex = "#FFFFFF";
				break;
			case "#F1F4FC":
			case "#E9EDF7":
				hex = "#172238";
				break;
			}
		}
		else if (Orange)
		{
			switch (hex)
			{
			case "#111B2C":
				hex = "#251D25";
				break;
			case "#0D1423":
				hex = "#1B151E";
				break;
			case "#233049":
				hex = "#463047";
				break;
			case "#233149":
				hex = "#483047";
				break;
			case "#252440":
				hex = "#593440";
				break;
			case "#131F32":
				hex = "#281D2B";
				break;
			}
		}
		SolidColorBrush solidColorBrush = new SolidColorBrush((System.Windows.Media.Color)System.Windows.Media.ColorConverter.ConvertFromString(hex));
		solidColorBrush.Freeze();
		return solidColorBrush;
	}

	private static TextBlock Label(string text, double size, System.Windows.Media.Brush color)
	{
		return new TextBlock
		{
			Text = (text ?? ""),
			FontSize = size,
			Foreground = color,
			TextWrapping = TextWrapping.Wrap
		};
	}

	private static StackPanel Stack()
	{
		return new StackPanel();
	}

	private static Border Card(UIElement child)
	{
		return new Border
		{
			Background = ((LightMode || Orange) ? B("#111B2C") : B("#13122E")),
			BorderBrush = ((LightMode || Orange) ? B("#233049") : B("#221F45")),
			BorderThickness = new Thickness(1.0),
			CornerRadius = new CornerRadius(16.0),
			Padding = new Thickness(22.0),
			Margin = new Thickness(0.0, 0.0, 0.0, 14.0),
			Child = child
		};
	}

	// One accent for the main action buttons (the Recommended / Ultra violet): tools, downloads, Reflex, debloat,
	// Competitive and Hardware info.
	private static System.Windows.Media.Brush BrandBrush()
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(122, 60, 240), System.Windows.Media.Color.FromRgb(70, 36, 150), 0.0);
		linearGradientBrush.Freeze();
		return linearGradientBrush;
	}

	private static System.Windows.Controls.Button BrandBtn(string title, Action action, bool primary = false)
	{
		System.Windows.Controls.Button button = Btn(title, action, primary: true);
		button.Background = BrandBrush();
		button.Foreground = System.Windows.Media.Brushes.White;
		button.FontWeight = FontWeights.SemiBold;
		button.Effect = new DropShadowEffect
		{
			Color = System.Windows.Media.Color.FromRgb(122, 60, 240),
			BlurRadius = 14.0,
			ShadowDepth = 0.0,
			Opacity = 0.5
		};
		return button;
	}

	private static System.Windows.Controls.Button Btn(string title, Action action, bool primary = false)
	{
		System.Windows.Controls.Button button = new System.Windows.Controls.Button();
		button.Content = title;
		button.Foreground = (primary ? System.Windows.Media.Brushes.White : Text);
		button.Background = (primary ? Accent : B("#233149"));
		button.Margin = new Thickness(0.0, 0.0, 8.0, 0.0);
		button.Click += delegate
		{
			action();
		};
		return button;
	}

	// The app background follows the AZIZ wallpapers: a soft mauve corner melting through deep ink into a dark blue one.
	private System.Windows.Media.Brush ShellBackground()
	{
		if (settings.Light || Orange)
		{
			return new SolidColorBrush(Bg);
		}
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = new System.Windows.Point(0.0, 0.0),
			EndPoint = new System.Windows.Point(1.0, 1.0)
		};
		linearGradientBrush.GradientStops.Add(new GradientStop(System.Windows.Media.Color.FromRgb(24, 12, 44), 0.0));
		linearGradientBrush.GradientStops.Add(new GradientStop(System.Windows.Media.Color.FromRgb(10, 9, 30), 0.38));
		linearGradientBrush.GradientStops.Add(new GradientStop(System.Windows.Media.Color.FromRgb(6, 8, 24), 0.62));
		linearGradientBrush.GradientStops.Add(new GradientStop(System.Windows.Media.Color.FromRgb(9, 20, 52), 1.0));
		linearGradientBrush.Freeze();
		return linearGradientBrush;
	}

	private void BuildShell()
	{
		base.Resources["AzizAccent"] = Accent;
		Grid grid = new Grid
		{
			Background = ((settings.Light || Orange) ? ShellBackground() : System.Windows.Media.Brushes.Transparent)
		};
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(232.0)
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		ApplyWindowChrome(grid);
		Grid grid2 = new Grid
		{
			Background = ((settings.Light || Orange) ? B("#0D1423") : new SolidColorBrush(System.Windows.Media.Color.FromArgb(170, 6, 6, 20)))
		};
		grid2.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		grid2.RowDefinitions.Add(new RowDefinition());
		grid2.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		grid.Children.Add(grid2);
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(24.0, 30.0, 24.0, 25.0);
		Grid grid3 = new Grid();
		grid3.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(48.0)
		});
		grid3.ColumnDefinitions.Add(new ColumnDefinition());
		grid3.Children.Add(BrandLogo.View(1, 42.0));
		StackPanel stackPanel2 = Stack();
		Grid.SetColumn(stackPanel2, 1);
		stackPanel2.Children.Add(new TextBlock
		{
			Text = "AZIZ",
			FontSize = 24.0,
			FontWeight = FontWeights.Bold,
			Foreground = Text
		});
		stackPanel2.Children.Add(Label("GAMING OPTIMIZER", 9.0, Muted));
		grid3.Children.Add(stackPanel2);
		stackPanel.Children.Add(grid3);
		grid2.Children.Add(stackPanel);
		nav = Stack();
		nav.Margin = new Thickness(14.0, 0.0, 14.0, 0.0);
		ScrollViewer scrollViewer = new ScrollViewer
		{
			Content = nav,
			VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
			HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled
		};
		Grid.SetRow(scrollViewer, 1);
		grid2.Children.Add(scrollViewer);
		string[] array = new string[13]
		{
			"Home", "Toggles", "Tweaks", "Network", "Power plans", "Services", "Security", "Tools", "Downloads", "Uninstaller",
			"Shortcuts", "Favorites", "About"
		};
		string[] array2 = new string[14]
		{
			"#FDBA74", "#FACC15", "#38BDF8", "#FB7185", "#4ADE80", "#22D3EE", "#A78BFA", "#60A5FA", "#2DD4BF", "#C084FC",
			"#22D3EE", "#34D399", "#94A3B8", "#38BDF8"
		};
		for (int i = 0; i < array.Length; i++)
		{
			string p = array[i];
			StackPanel stackPanel3 = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal
			};
			stackPanel3.Children.Add(NavigationIcons.View(p, B(array2[i])));
			stackPanel3.Children.Add(Label(L(p), 16.0, Text));
			System.Windows.Controls.Button button = new System.Windows.Controls.Button
			{
				Content = stackPanel3,
				HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left,
				Height = 43.0,
				Padding = new Thickness(13.0, 4.0, 10.0, 4.0),
				Margin = new Thickness(0.0, 2.0, 0.0, 2.0),
				Background = System.Windows.Media.Brushes.Transparent
			};
			button.Click += delegate
			{
				Go(p);
			};
			nav.Children.Add(button);
			navButtons[p] = button;
		}
		StackPanel stackPanel4 = Stack();
		stackPanel4.Margin = new Thickness(26.0, 20.0, 24.0, 25.0);
		stackPanel4.Children.Add(Label("YOUR MACHINE. YOUR RULES.", 9.0, Purple));
		stackPanel4.Children.Add(Label("AZIZ  /  1.9.7", 11.0, Muted));
		if (!Program.IsAdmin)
		{
			stackPanel4.Children.Add(Btn("Run as administrator", Elevate));
		}
		Grid.SetRow(stackPanel4, 2);
		grid2.Children.Add(stackPanel4);
		Grid grid4 = new Grid
		{
			Margin = new Thickness(32.0, 25.0, 32.0, 20.0)
		};
		grid4.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		grid4.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		grid4.RowDefinitions.Add(new RowDefinition());
		grid4.RowDefinitions.Add(new RowDefinition
		{
			Height = GridLength.Auto
		});
		Grid.SetColumn(grid4, 1);
		grid.Children.Add(grid4);
		Grid grid5 = new Grid
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 22.0)
		};
		grid5.ColumnDefinitions.Add(new ColumnDefinition());
		grid5.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		StackPanel stackPanel5 = Stack();
		pageTitle = Label("Home", 29.0, Text);
		pageTitle.FontWeight = FontWeights.SemiBold;
		subtitle = Label("Your setup, in focus.", 13.0, Muted);
		subtitle.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
		stackPanel5.Children.Add(pageTitle);
		stackPanel5.Children.Add(subtitle);
		grid5.Children.Add(stackPanel5);
		StackPanel stackPanel6 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			VerticalAlignment = VerticalAlignment.Center
		};
		scanLabel = Label("●  Initial scan", 12.0, Cyan);
		scanLabel.VerticalAlignment = VerticalAlignment.Center;
		scanLabel.Margin = new Thickness(0.0, 0.0, 16.0, 0.0);
		profileButton = Btn("Profiles", delegate
		{
			ShowProfiles();
		});
		profileButton.ToolTip = "Open the active profile with every setting it holds";
		stackPanel6.Children.Add(profileButton);
		// No Save button: every change is written into the active profile at once.
		profileButton.Margin = new Thickness(0.0, 0.0, 6.0, 0.0);
		UpdateProfileBadge();
		stackPanel6.Children.Add(scanLabel);
		scanLabel.Visibility = Visibility.Collapsed;
		Grid.SetColumn(stackPanel6, 1);
		grid5.Children.Add(stackPanel6);
		grid4.Children.Add(grid5);
		Grid grid6 = new Grid();
		grid6.Margin = new Thickness(0.0, 0.0, 0.0, 18.0);
		searchBox = grid6;
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Background = B("#131F32");
		textBox.Foreground = Text;
		textBox.BorderBrush = B("#293750");
		textBox.BorderThickness = new Thickness(1.0);
		textBox.Padding = new Thickness(14.0, 11.0, 14.0, 11.0);
		textBox.FontSize = 14.0;
		textBox.ToolTip = "Search settings, services and tweaks";
		search = textBox;
		searchBox.Children.Add(search);
		TextBlock placeholder = Label((settings.Language == "العربية") ? "ابحث عن إعداد…" : "Find a setting…", 14.0, Muted);
		placeholder.Margin = new Thickness(15.0, 11.0, 15.0, 11.0);
		placeholder.IsHitTestVisible = false;
		searchBox.Children.Add(placeholder);
		search.TextChanged += delegate
		{
			placeholder.Visibility = (Visibility)((!string.IsNullOrEmpty(search.Text)) ? 2u : 0u);
			if (initialized && IsTweakPage(current))
			{
				RenderTweaks();
			}
		};
		Grid.SetRow(searchBox, 1);
		grid4.Children.Add(searchBox);
		content = Stack();
		ScrollViewer scrollViewer2 = new ScrollViewer();
		scrollViewer2.PanningMode = PanningMode.VerticalOnly;
		scrollViewer2.CanContentScroll = false;
		scrollViewer2.Content = content;
		scrollViewer2.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
		scrollViewer2.HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
		scrollViewer2.Padding = new Thickness(0.0, 0.0, 10.0, 0.0);
		scroll = scrollViewer2;
		scroll.PreviewMouseWheel += SmoothWheel;
		scroll.ScrollChanged += delegate(object s, ScrollChangedEventArgs e)
		{
			if (current == "Home" && e.VerticalChange != 0.0 && !sampling && sampleTimer != null && (DateTime.UtcNow - lastSampleRead).TotalMilliseconds > 700.0 && MetricsVisible())
			{
				ReadSample();
			}
		};
		scroll.PreviewMouseDown += delegate
		{
			StopWheel();
		};
		scroll.PreviewKeyDown += delegate
		{
			StopWheel();
		};
		Border border = new Border();
		border.Child = scroll;
		stage = border;
		Grid.SetRow(stage, 2);
		grid4.Children.Add(stage);
		Grid grid7 = new Grid
		{
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
		};
		grid7.ColumnDefinitions.Add(new ColumnDefinition());
		grid7.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		notice = Label("", 11.0, Muted);
		grid7.Children.Add(notice);
		deviceLabel = Label(Environment.MachineName + "  •  LOCAL", 10.0, Muted);
		Grid.SetColumn(deviceLabel, 1);
		grid7.Children.Add(deviceLabel);
		Grid.SetRow(grid7, 3);
		grid4.Children.Add(grid7);
	}

	private async Task ManualScan()
	{
		if (!scanning && !applying)
		{
			scanLabel.Text = "●  Detecting hardware…";
			machine = await Task.Run(() => telemetry.Inspect());
			await ScanAsync();
			if (current == "System")
			{
				RenderSystem();
			}
		}
	}

	private async Task ScanAsync(IEnumerable<string> ids = null, bool freshRead = true)
	{
		if (scanning || applying || closing)
		{
			return;
		}
		scanning = true;
		scanLabel.Text = "●  Scanning…";
		long scanSerial = applySerial;
		HashSet<string> busy = new HashSet<string>(pendingChanges.Keys);
		try
		{
			Dictionary<string, TweakStatus> dictionary = await Task.Run(() => engine.Scan(ids, freshRead));
			if (closing)
			{
				return;
			}
			foreach (string key in dictionary.Keys.Where((string k) => busy.Contains(k) || (appliedAt.TryGetValue(k, out var serial) && serial > scanSerial)).ToList())
			{
				dictionary.Remove(key);
			}
			bool flag = dictionary.Any((KeyValuePair<string, TweakStatus> x) => !states.ContainsKey(x.Key) || states[x.Key].State != x.Value.State || states[x.Key].Detail != x.Value.Detail);
			foreach (KeyValuePair<string, TweakStatus> item in dictionary)
			{
				Dictionary<string, TweakStatus> dictionary2 = states;
				KeyValuePair<string, TweakStatus> keyValuePair = item;
				if (!dictionary2.TryGetValue(keyValuePair.Key, out var value))
				{
					continue;
				}
				string state = value.State;
				KeyValuePair<string, TweakStatus> keyValuePair2 = item;
				if (!(state != keyValuePair2.Value.State))
				{
					continue;
				}
				Dictionary<string, PendingChange> dictionary3 = pendingChanges;
				KeyValuePair<string, TweakStatus> keyValuePair3 = item;
				if (!dictionary3.ContainsKey(keyValuePair3.Key) && !ownChanges.Contains(keyValuePair3.Key))
				{
					Tweak tweak = engine.Tweaks.FirstOrDefault(delegate(Tweak t)
					{
						string id2 = t.Id;
						KeyValuePair<string, TweakStatus> keyValuePair9 = item;
						return id2 == keyValuePair9.Key;
					});
					List<HistoryEntry> list = observations;
					HistoryEntry historyEntry = new HistoryEntry
					{
						Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
					};
					string name;
					if (tweak != null)
					{
						name = tweak.Name;
					}
					else
					{
						KeyValuePair<string, TweakStatus> keyValuePair4 = item;
						name = keyValuePair4.Key;
					}
					historyEntry.Name = name;
					historyEntry.Action = "Observed change";
					historyEntry.Before = value.State;
					KeyValuePair<string, TweakStatus> keyValuePair5 = item;
					historyEntry.After = keyValuePair5.Value.State;
					historyEntry.Result = "Changed outside AZIZ";
					historyEntry.Profile = ProfileName(ActiveKey);
					list.Insert(0, historyEntry);
				}
			}
			List<string> list2 = dictionary.Where(delegate(KeyValuePair<string, TweakStatus> x)
			{
				Dictionary<string, PendingChange> dictionary4 = pendingChanges;
				KeyValuePair<string, TweakStatus> keyValuePair8 = x;
				if (!dictionary4.ContainsKey(keyValuePair8.Key))
				{
					Dictionary<string, TweakStatus> dictionary5 = states;
					keyValuePair8 = x;
					if (dictionary5.ContainsKey(keyValuePair8.Key))
					{
						Dictionary<string, TweakStatus> dictionary6 = states;
						keyValuePair8 = x;
						string state2 = dictionary6[keyValuePair8.Key].State;
						keyValuePair8 = x;
						if (!(state2 != keyValuePair8.Value.State))
						{
							Dictionary<string, TweakStatus> dictionary7 = states;
							keyValuePair8 = x;
							string detail = dictionary7[keyValuePair8.Key].Detail;
							keyValuePair8 = x;
							return detail != keyValuePair8.Value.Detail;
						}
					}
					return true;
				}
				return false;
			}).Select(delegate(KeyValuePair<string, TweakStatus> x)
			{
				KeyValuePair<string, TweakStatus> keyValuePair7 = x;
				return keyValuePair7.Key;
			}).ToList();
			foreach (KeyValuePair<string, TweakStatus> item2 in dictionary)
			{
				if (!pendingChanges.ContainsKey(item2.Key))
				{
					states[item2.Key] = item2.Value;
				}
			}
			if (flag)
			{
				SaveObservations();
			}
			if (flag && !preview)
			{
				Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "last-states.json"), Program.Json.Serialize(states));
			}
			scanLabel.Text = "Read · " + DateTime.Now.ToString("h:mm tt", English);
			foreach (string item3 in list2)
			{
				RefreshTweak(item3);
			}
			if (flag && current == "History")
			{
				RenderHistory();
			}
		}
		catch (Exception ex)
		{
			scanLabel.Text = "Scan incomplete";
			notice.Text = ex.Message;
		}
		finally
		{
			scanning = false;
		}
	}

	private async Task ReadSample()
	{
		if (sampling || closing || (!preparingInterface && (!base.IsVisible || current != "Home" || base.WindowState == WindowState.Minimized || !MetricsVisible())))
		{
			return;
		}
		// Readings run every second while they can be seen (Home, cards on screen, window not minimized), also with
		// another window on top — only a full-screen app (a game) in front makes them idle.
		if (!preparingInterface && !base.IsActive && OtherAppFullscreen())
		{
			return;
		}
		sampling = true;
		lastSampleRead = DateTime.UtcNow;
		try
		{
			try
			{
				double? mhz = null;
				lastSample = await Task.Run(delegate
				{
					mhz = CpuClock.ReadMhz();
					lock (telemetry)
					{
						return telemetry.Read();
					}
				});
				cpuMhz = mhz;
				if (!closing)
				{
					UpdateMetric("CPU", lastSample.Cpu, "%");
					UpdateMetric("GPU", lastSample.Gpu, "%");
					UpdateMetric("RAM", lastSample.Ram, "%");
					UpdateMetric("CPU TEMP", lastSample.CpuTemp, "°C");
					UpdateMetric("CPU CLOCK", cpuMhz.HasValue ? new double?(cpuMhz.Value / 1000.0) : null, " GHz");
					UpdateMetric("GPU TEMP", lastSample.GpuTemp, "°C");
					UpdateMemoryCup();
					if (metrics.TryGetValue("sensors", out var value))
					{
						value.Text = lastSample.SensorNote;
					}
				}
			}
			catch (Exception ex)
			{
				notice.Text = "Monitoring: " + ex.Message;
			}
		}
		finally
		{
			sampling = false;
		}
	}

	[StructLayout(LayoutKind.Sequential)]
	private struct ScreenRect
	{
		public int Left;

		public int Top;

		public int Right;

		public int Bottom;
	}

	[StructLayout(LayoutKind.Sequential)]
	private struct MonitorData
	{
		public int Size;

		public ScreenRect Monitor;

		public ScreenRect Work;

		public int Flags;
	}

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern bool GetWindowRect(IntPtr hWnd, out ScreenRect rect);

	[DllImport("user32.dll")]
	private static extern IntPtr MonitorFromWindow(IntPtr hWnd, int flags);

	[DllImport("user32.dll")]
	private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorData data);

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern int GetClassName(IntPtr hWnd, StringBuilder name, int size);

	// The window in front is another app covering its whole monitor (a game, a full-screen video); the desktop does not count.
	private static bool OtherAppFullscreen()
	{
		try
		{
			IntPtr foregroundWindow = GetForegroundWindow();
			if (foregroundWindow == IntPtr.Zero || GetWindowThreadProcessId(foregroundWindow, out var pid) == 0 || pid == (uint)Process.GetCurrentProcess().Id)
			{
				return false;
			}
			StringBuilder stringBuilder = new StringBuilder(64);
			GetClassName(foregroundWindow, stringBuilder, 64);
			string text = stringBuilder.ToString();
			if (text == "Progman" || text == "WorkerW" || text == "Shell_TrayWnd")
			{
				return false;
			}
			MonitorData data = new MonitorData
			{
				Size = Marshal.SizeOf(typeof(MonitorData))
			};
			if (!GetWindowRect(foregroundWindow, out var rect) || !GetMonitorInfo(MonitorFromWindow(foregroundWindow, 2), ref data))
			{
				return false;
			}
			return rect.Left <= data.Monitor.Left && rect.Top <= data.Monitor.Top && rect.Right >= data.Monitor.Right && rect.Bottom >= data.Monitor.Bottom;
		}
		catch
		{
			return false;
		}
	}

	private bool MetricsVisible()
	{
		if (!metrics.TryGetValue("CPU", out var value) || !value.IsLoaded || scroll == null)
		{
			return true;
		}
		try
		{
			if (!scroll.IsAncestorOf(value))
			{
				return false;
			}
			System.Windows.Point point = value.TransformToAncestor(scroll).Transform(new System.Windows.Point(0.0, 0.0));
			return point.Y + value.ActualHeight + 40.0 > 0.0 && point.Y < scroll.ViewportHeight;
		}
		catch
		{
			return true;
		}
	}

	private void UpdateMetric(string key, double? value, string unit)
	{
		if (metrics.TryGetValue(key, out var value2))
		{
			value2.Text = (value.HasValue ? (value.Value.ToString((unit == " GHz") ? "0.00" : "0") + unit) : "—");
		}
		if (!points.ContainsKey(key))
		{
			points[key] = new List<double>();
		}
		if (value.HasValue)
		{
			points[key].Add((unit == " GHz") ? (value.Value * 20.0) : value.Value);
			if (points[key].Count > 36)
			{
				points[key].RemoveAt(0);
			}
		}
		if (traces.TryGetValue(key, out var value3))
		{
			List<double> list = points[key];
			PointCollection pointCollection = new PointCollection();
			for (int i = 0; i < list.Count; i++)
			{
				pointCollection.Add(new System.Windows.Point(i * 5, 36.0 - Math.Min(100.0, Math.Max(0.0, list[i])) * 0.34));
			}
			value3.Points = pointCollection;
		}
	}

	public void Go(string page)
	{
		SaveView();
		StopWheel();
		current = page;
		pageTitle.Text = L(page);
		scroll.ScrollToTop();
		metrics.Clear();
		traces.Clear();
		foreach (KeyValuePair<string, System.Windows.Controls.Button> navButton in navButtons)
		{
			navButton.Value.Background = ((navButton.Key == page) ? B("#252440") : System.Windows.Media.Brushes.Transparent);
		}
		searchBox.Visibility = (Visibility)((!IsTweakPage(page)) ? 2u : 0u);
		TextBlock textBlock = subtitle;
		textBlock.Text = page switch
		{
			"System" => "Automatically detected on this machine.", 
			"History" => "Every change, with its result and observed system state.", 
			"Home" => "Your setup, in focus. Live insights. Deliberate changes.", 
			"Uninstaller" => "Installed apps, with simple or deep removal.", 
			"Downloads" => "Choose an app. Download here. Keep everything local.", 
			_ => "Read the current state. Change only what you choose.", 
		};
		if (!RestoreView(page))
		{
			if (IsTweakPage(page))
			{
				RenderTweaks();
			}
			else
			{
				switch (page)
				{
				case "Home":
					RenderOverview();
					break;
				case "System":
					RenderSystem();
					break;
				case "History":
					RenderHistory();
					break;
				case "Restoration":
					RenderRestore();
					break;
				case "Power plans":
					RenderPower();
					break;
				case "Uninstaller":
					RenderUninstaller();
					break;
				case "Shortcuts":
					RenderShortcuts();
					break;
				case "Tools":
					RenderTools();
					break;
				case "Downloads":
					RenderDownloads();
					break;
				case "Settings":
					RenderSettings();
					break;
				case "About":
					RenderAbout();
					break;
				}
			}
		}
		if (sampleTimer != null)
		{
			if (page == "Home" && base.IsVisible && base.WindowState != WindowState.Minimized)
			{
				sampleTimer.Start();
				ReadSample();
			}
			else
			{
				sampleTimer.Stop();
			}
		}
		if (!preparingInterface)
		{
			CatchUpPage();
		}
	}

	private bool IsTweakPage(string p)
	{
		return new string[6] { "Favorites", "Toggles", "Tweaks", "Network", "Security", "Services" }.Contains(p);
	}

	private void RenderOverview()
	{
		content.Children.Clear();
		metrics.Clear();
		traces.Clear();
		Grid obj = new Grid
		{
			ColumnDefinitions = 
			{
				new ColumnDefinition(),
				new ColumnDefinition
				{
					Width = new GridLength(210.0)
				}
			}
		};
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("AZIZ  /  COMMAND CENTER", 11.0, Cyan));
		TextBlock textBlock = Label((machine == null) ? "Preparing your setup…" : WindowsTitle(machine.OsName), 18.0, Text);
		textBlock.FontWeight = FontWeights.SemiBold;
		textBlock.Margin = new Thickness(0.0, 5.0, 0.0, 3.0);
		stackPanel.Children.Add(textBlock);
		TextBlock textBlock2 = Label((machine == null) ? "Detecting your hardware…" : (machine.CpuName + "  ·  " + machine.GpuName), 11.0, Muted);
		textBlock2.Margin = new Thickness(0.0, 2.0, 0.0, 0.0);
		stackPanel.Children.Add(textBlock2);
		obj.Children.Add(stackPanel);
		StackPanel stackPanel2 = Stack();
		stackPanel2.HorizontalAlignment = System.Windows.HorizontalAlignment.Right;
		System.Windows.Controls.Button button = BrandBtn("Hardware info  →", delegate
		{
			ShowPanel("Hardware info", delegate(StackPanel panel)
			{
				StackPanel stackPanel3 = content;
				content = panel;
				try
				{
					RenderSystem();
				}
				finally
				{
					content = stackPanel3;
				}
			}, 900.0, 650.0);
		}, primary: true);
		button.Margin = new Thickness(0.0, 0.0, 0.0, 0.0);
		stackPanel2.VerticalAlignment = VerticalAlignment.Center;
		stackPanel2.Children.Add(button);
		Grid.SetColumn(stackPanel2, 1);
		obj.Children.Add(stackPanel2);
		// Command Center: same colour as the cards below it, so One Click is the one that stands out.
		Border border = Card(obj);
		border.Padding = new Thickness(18.0, 14.0, 18.0, 14.0);
		border.Margin = new Thickness(0.0, 0.0, 0.0, 10.0);
		content.Children.Add(OptimizeHero());
		content.Children.Add(border);
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = ((!settings.ShowTemperatures) ? 4 : ((lastSample != null && lastSample.CpuTemp.HasValue) ? 6 : 5)),
			Margin = new Thickness(0.0, 4.0, 0.0, 4.0)
		};
		AddMetric(uniformGrid, "CPU", "Total processor", (lastSample == null) ? null : lastSample.Cpu, "%", Purple);
		AddMetric(uniformGrid, "GPU", "Graphics load", (lastSample == null) ? null : lastSample.Gpu, "%", Cyan);
		AddMemoryCup(uniformGrid);
		AddMetric(uniformGrid, "CPU CLOCK", "Live processor speed", cpuMhz.HasValue ? new double?(cpuMhz.Value / 1000.0) : null, " GHz", B("#7C8CFF"));
		if (settings.ShowTemperatures && lastSample != null && lastSample.CpuTemp.HasValue)
		{
			AddMetric(uniformGrid, "CPU TEMP", "Sensor reading", (lastSample == null) ? null : lastSample.CpuTemp, "°C", B("#EAB570"));
		}
		if (settings.ShowTemperatures)
		{
			AddMetric(uniformGrid, "GPU TEMP", "Sensor reading", (lastSample == null) ? null : lastSample.GpuTemp, "°C", B("#E990C8"));
		}
		content.Children.Add(uniformGrid);
		TextBlock textBlock3 = Label((lastSample == null) ? "Sensors initializing…" : lastSample.SensorNote, 11.0, Muted);
		textBlock3.Margin = new Thickness(0.0, 0.0, 0.0, 18.0);
		metrics["sensors"] = textBlock3;
		AddHomeActivity();
		AddGamingPanel();
	}

	private static string WindowsTitle(string caption)
	{
		string text = (caption ?? "").Replace("Microsoft ", "").Trim();
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion");
			string text2 = Convert.ToString(registryKey?.GetValue("DisplayVersion"));
			if (string.IsNullOrEmpty(text2))
			{
				text2 = Convert.ToString(registryKey?.GetValue("ReleaseId"));
			}
			if (!string.IsNullOrEmpty(text2))
			{
				text = text + "  ·  " + text2;
			}
		}
		catch
		{
		}
		return text;
	}

	private Border OptimizeHero()
	{
		if (optimizeHero != null)
		{
			if (optimizeHero.Parent is System.Windows.Controls.Panel panel)
			{
				panel.Children.Remove(optimizeHero);
			}
			return optimizeHero;
		}
		Grid obj = new Grid
		{
			ColumnDefinitions = 
			{
				new ColumnDefinition()
			}
		};
		ColumnDefinition value = new ColumnDefinition
		{
			Width = GridLength.Auto
		};
		obj.ColumnDefinitions.Add(value);
		StackPanel stackPanel = Stack();
		stackPanel.VerticalAlignment = VerticalAlignment.Center;
		TextBlock textBlock = Label("AZIZ  /  ONE CLICK", 11.0, B("#5FD3F3"));
		textBlock.FontWeight = FontWeights.SemiBold;
		stackPanel.Children.Add(textBlock);
		TextBlock textBlock2 = Label("Optimize your PC for Gaming", 32.0, System.Windows.Media.Brushes.White);
		textBlock2.FontWeight = FontWeights.Black;
		textBlock2.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI Black, Segoe UI");
		textBlock2.Margin = new Thickness(0.0, 6.0, 0.0, 6.0);
		stackPanel.Children.Add(textBlock2);
		stackPanel.Children.Add(Label("Windows, services, startup apps and network tuned for games in one go. Your way back: Windows Default and the AZIZ Backup restore point.", 12.0, B("#C9C2F5")));
		optimizeStatus = Label(AnyProfileActive ? ("Active profile · " + ProfileName(ActiveKey)) : "Nothing has been changed yet.", 12.0, B("#C9C2F5"));
		optimizeStatus.Margin = new Thickness(0.0, 12.0, 0.0, 0.0);
		stackPanel.Children.Add(optimizeStatus);
		obj.Children.Add(stackPanel);
		optimizeButton = Btn("Optimize", async delegate
		{
			string text = await ChooseOptimizeMode();
			if (text != null)
			{
				await RunOptimize(text == "ultra");
			}
		}, primary: true);
		optimizeButton.FontSize = 20.0;
		optimizeButton.FontWeight = FontWeights.Black;
		optimizeButton.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI Black, Segoe UI");
		optimizeButton.Foreground = System.Windows.Media.Brushes.White;
		optimizeButton.Padding = new Thickness(38.0, 16.0, 38.0, 16.0);
		optimizeButton.Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(154, 124, 255), System.Windows.Media.Color.FromRgb(91, 134, 240), 0.0);
		optimizeButton.Effect = new DropShadowEffect
		{
			Color = System.Windows.Media.Color.FromRgb(118, 92, 240),
			BlurRadius = 22.0,
			ShadowDepth = 0.0,
			Opacity = 0.45
		};
		optimizeButton.VerticalAlignment = VerticalAlignment.Center;
		optimizeButton.Margin = new Thickness(24.0, 0.0, 0.0, 0.0);
		Grid.SetColumn(optimizeButton, 1);
		obj.Children.Add(optimizeButton);
		Border border = Card(obj);
		border.Padding = new Thickness(28.0, 24.0, 28.0, 24.0);
		// One Click in the profile colours: dark violet into dark blue with a soft lighter sweep, glowing edge.
		border.BorderBrush = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(120, 92, 230), System.Windows.Media.Color.FromRgb(70, 90, 200), 0.0);
		border.BorderThickness = new Thickness(1.0);
		border.Background = new LinearGradientBrush
		{
			StartPoint = new System.Windows.Point(0.0, 0.0),
			EndPoint = new System.Windows.Point(1.0, 0.0),
			GradientStops = 
			{
				new GradientStop(System.Windows.Media.Color.FromRgb(70, 36, 150), 0.0),
				new GradientStop(System.Windows.Media.Color.FromRgb(46, 44, 140), 0.55),
				new GradientStop(System.Windows.Media.Color.FromRgb(28, 42, 120), 1.0)
			}
		};
		border.Effect = new DropShadowEffect
		{
			Color = System.Windows.Media.Color.FromRgb(118, 92, 240),
			BlurRadius = 30.0,
			ShadowDepth = 0.0,
			Opacity = 0.35
		};
		optimizeHero = border;
		return border;
	}

	private static System.Windows.Media.Brush BrandEdge()
	{
		return new LinearGradientBrush(System.Windows.Media.Color.FromArgb(200, 139, 108, 245), System.Windows.Media.Color.FromArgb(200, 51, 201, 238), 0.0);
	}

	private Task<string> ChooseOptimizeMode()
	{
		TaskCompletionSource<string> done = new TaskCompletionSource<string>();
		UIElement root = (UIElement)base.Content;
		base.Content = null;
		root.Effect = new BlurEffect
		{
			Radius = 4.0,
			KernelType = KernelType.Gaussian
		};
		Grid host = new Grid();
		host.Children.Add(root);
		Grid shade = new Grid
		{
			Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(70, 0, 0, 0)),
			Opacity = 0.0
		};
		shade.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(220.0)));
		StackPanel column = new StackPanel
		{
			HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center
		};
		TextBlock title = Label("Choose how to optimize", 24.0, System.Windows.Media.Brushes.White);
		title.FontWeight = FontWeights.SemiBold;
		title.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI");
		title.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		column.Children.Add(title);
		TextBlock hint = Label("Click outside or press Esc to go back", 11.0, B("#9C94C9"));
		hint.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		hint.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
		column.Children.Add(hint);
		StackPanel options = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
			Margin = new Thickness(0.0, 26.0, 0.0, 0.0)
		};
		column.Children.Add(options);
		shade.Children.Add(column);
		System.Windows.Input.KeyEventHandler escape = null;
		Action<string> close = delegate(string key)
		{
			if (!done.Task.IsCompleted)
			{
				PreviewKeyDown -= escape;
				host.Children.Clear();
				root.Effect = null;
				base.Content = root;
				done.TrySetResult(key);
			}
		};
		escape = delegate(object s, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == Key.Escape)
			{
				e.Handled = true;
				close(null);
			}
		};
		PreviewKeyDown += escape;
		shade.MouseLeftButtonUp += delegate
		{
			close(null);
		};
		Func<string, string, string, int, Border> option = delegate(string key, string name, string desc, int order)
		{
			StackPanel stackPanel = Stack();
			TextBlock textBlock = Label("⚡", 22.0, B("#C9BAFF"));
			textBlock.Margin = new Thickness(0.0, 0.0, 0.0, 8.0);
			stackPanel.Children.Add(textBlock);
			TextBlock textBlock2 = Label(name, 21.0, System.Windows.Media.Brushes.White);
			textBlock2.FontWeight = FontWeights.Bold;
			textBlock2.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI");
			stackPanel.Children.Add(textBlock2);
			TextBlock textBlock3 = Label(desc, 12.0, B("#B7AEE6"));
			textBlock3.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
			stackPanel.Children.Add(textBlock3);
			ScaleTransform scale = new ScaleTransform(1.0, 1.0);
			TranslateTransform rise = new TranslateTransform(0.0, 18.0);
			DropShadowEffect glow = new DropShadowEffect
			{
				Color = System.Windows.Media.Color.FromRgb(118, 84, 232),
				BlurRadius = 34.0,
				ShadowDepth = 0.0,
				Opacity = 0.3
			};
			Border card = new Border
			{
				Width = 280.0,
				Padding = new Thickness(26.0, 22.0, 26.0, 24.0),
				Margin = new Thickness(12.0, 0.0, 12.0, 0.0),
				CornerRadius = new CornerRadius(20.0),
				BorderThickness = new Thickness(0.0),
				Background = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(44, 30, 104), System.Windows.Media.Color.FromRgb(22, 14, 56), 90.0),
				Cursor = System.Windows.Input.Cursors.Hand,
				Effect = glow,
				Child = stackPanel,
				Opacity = 0.0,
				RenderTransformOrigin = new System.Windows.Point(0.5, 0.5),
				RenderTransform = new TransformGroup
				{
					Children = { (Transform)scale, (Transform)rise }
				}
			};
			TimeSpan beginTime = TimeSpan.FromMilliseconds(60 + order * 70);
			card.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(260.0))
			{
				BeginTime = beginTime
			});
			rise.BeginAnimation(TranslateTransform.YProperty, new DoubleAnimation(18.0, 0.0, TimeSpan.FromMilliseconds(320.0))
			{
				BeginTime = beginTime,
				EasingFunction = new CubicEase
				{
					EasingMode = EasingMode.EaseOut
				}
			});
			Action<double, double> hover = delegate(double size, double light)
			{
				DoubleAnimation animation = new DoubleAnimation(size, TimeSpan.FromMilliseconds(150.0))
				{
					EasingFunction = new QuadraticEase()
				};
				scale.BeginAnimation(ScaleTransform.ScaleXProperty, animation);
				scale.BeginAnimation(ScaleTransform.ScaleYProperty, animation);
				glow.BeginAnimation(DropShadowEffect.OpacityProperty, new DoubleAnimation(light, TimeSpan.FromMilliseconds(150.0)));
			};
			card.MouseEnter += delegate
			{
				hover(1.045, 0.7);
			};
			card.MouseLeave += delegate
			{
				hover(1.0, 0.3);
			};
			card.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
			{
				e.Handled = true;
				close(key);
			};
			return card;
		};
		options.Children.Add(option("ultra", "Ultra Low Latency", "Toggles & Tweaks Ultra · Services Recommended · lowest latency", 0));
		options.Children.Add(option("basic", "Low Latency", "Toggles & Tweaks Low Latency · Services Recommended · everyday", 1));
		host.Children.Add(shade);
		base.Content = host;
		return done.Task;
	}

	private void ShowOptimizeOverlay()
	{
		optimizeRoot = (UIElement)base.Content;
		base.Content = null;
		optimizeRoot.Effect = new BlurEffect
		{
			Radius = 4.0,
			KernelType = KernelType.Gaussian
		};
		Grid grid = new Grid();
		grid.Children.Add(optimizeRoot);
		Grid grid2 = new Grid();
		grid2.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(70, 0, 0, 0));
		grid2.Opacity = 0.0;
		grid2.BeginAnimation(UIElement.OpacityProperty, new DoubleAnimation(0.0, 1.0, TimeSpan.FromMilliseconds(260.0)));
		StackPanel stackPanel = Stack();
		stackPanel.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		stackPanel.VerticalAlignment = VerticalAlignment.Center;
		optimizeVisual = new OptimizeVisual();
		optimizeVisual.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		stackPanel.Children.Add(optimizeVisual);
		overlayStatus = Label("Preparing…", 14.0, B("#C9BAFF"));
		overlayStatus.FontWeight = FontWeights.SemiBold;
		overlayStatus.TextAlignment = TextAlignment.Center;
		overlayStatus.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
		overlayStatus.Margin = new Thickness(0.0, 18.0, 0.0, 0.0);
		stackPanel.Children.Add(overlayStatus);
		grid2.Children.Add(stackPanel);
		grid.Children.Add(grid2);
		optimizeOverlay = grid;
		base.Content = grid;
	}

	private void HideOptimizeOverlay()
	{
		if (optimizeOverlay != null && optimizeRoot != null)
		{
			optimizeVisual?.Stop();
			optimizeOverlay.Children.Clear();
			optimizeRoot.Effect = null;
			base.Content = optimizeRoot;
			optimizeOverlay = null;
		}
	}

	// While Optimize runs nothing pops up: messages go to History instead (shown after it finishes).
	internal static bool Quiet;

	internal static readonly List<string> QuietMessages = new List<string>();

	internal static void Say(string message, string title = "AZIZ")
	{
		if (Quiet)
		{
			lock (QuietMessages)
			{
				QuietMessages.Add(((title == "AZIZ") ? "" : (title + ": ")) + message);
			}
			return;
		}
		System.Windows.MessageBox.Show(message, title);
	}

	private async Task RunOptimize(bool ultra)
	{
		if (preview || optimizing || applying || profileBusy)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Elevate();
			return;
		}
		string key = (ultra ? "aziz-ultra" : "aziz-recommended");
		string name = ProfileName(key);
		Dictionary<string, string> values = ProfileValues(key);
		List<Tweak> targets = engine.Tweaks.Where(Profileable).Where(delegate(Tweak t)
		{
			if (states.TryGetValue(t.Id, out var value) && value.State == "Unavailable")
			{
				return false;
			}
			string value2;
			return values.TryGetValue(t.Id, out value2) && ValueApplies(t, value2) && ProfileLogic.PresetSafe(t, value2) && CurrentValue(t) != value2;
		}).ToList();
		// No confirmation: the mode was chosen on the picker and every change is listed in History.
		optimizing = true;
		Quiet = true;
		optimizeButton.IsEnabled = false;
		ShowOptimizeOverlay();
		optimizeVisual.Start();
		optimizeStatus.Foreground = B("#C9D2FF");
		SetOptimizeStatus("Preparing · checking the AZIZ Backup restore point…");
		try
		{
			await BackupFirst();
			if (!settings.BackupPointCreated && (await Task.Run(() => SystemRestore.EnsureBackupPoint())).Success)
			{
				settings.BackupPointCreated = true;
				SaveSettings();
			}
			optimizeVisual.SetProgress(0.04);
			SetActiveProfile(key);
			SetReference(name, values, merge: false, null);
			Record(name, "Optimize your PC for Gaming", "", targets.Count + " changes", new ActionResult
			{
				Success = true,
				Message = string.Join(", ", targets.Select((Tweak t) => t.Name))
			});
			int total = Math.Max(1, targets.Count);
			int done = 0;
			int failed = 0;
			HashSet<string> waiting = new HashSet<string>();
			TaskCompletionSource<bool> finished = new TaskCompletionSource<bool>();
			Action report = delegate
			{
				optimizeVisual.SetProgress(0.04 + 0.92 * (double)done / (double)total);
				SetOptimizeStatus("Optimizing · " + done + " of " + targets.Count + " settings" + ((failed > 0) ? (" · " + failed + " need review") : ""));
				if (waiting.Count == 0)
				{
					finished.TrySetResult(result: true);
				}
			};
			Action<string, bool> handler = delegate(string id, bool ok)
			{
				if (waiting.Remove(id))
				{
					done++;
					if (!ok)
					{
						failed++;
					}
					report();
				}
			};
			ChangeFinished += handler;
			try
			{
				foreach (Tweak item in targets)
				{
					if (item.Kind != "Timer" && item.Id != "cpu-boost-settings")
					{
						waiting.Add(item.Id);
					}
				}
				foreach (Tweak t2 in targets)
				{
					await QueueValue(t2, values[t2.Id]);
					if (!waiting.Contains(t2.Id) && (t2.Kind == "Timer" || t2.Id == "cpu-boost-settings"))
					{
						done++;
						report();
					}
				}
				report();
				if (waiting.Count > 0)
				{
					await Task.WhenAny(finished.Task, Task.Delay(TimeSpan.FromMinutes(20.0)));
				}
			}
			finally
			{
				ChangeFinished -= handler;
			}
			SetOptimizeStatus("Finishing · graphics card interrupt mode…");
			await EnsureGpuMsi();
			if (File.Exists(NvidiaProfilePreset.FileName))
			{
				// Ultra / Low Latency: the AZIZ Ultra Low Latency NVIDIA profile is written straight to the driver (Profile Inspector is not opened).
				SetOptimizeStatus("Finishing · NVIDIA low-latency profile…");
				string nv = await Task.Run(delegate
				{
					try
					{
						return NvidiaProfilePreset.Import(!ultra);
					}
					catch (Exception ex2)
					{
						return "Skipped: " + ex2.Message;
					}
				});
				Record("NVIDIA profile", "Optimize", "", nv.StartsWith("Skipped") ? "Skipped" : "Applied", new ActionResult
				{
					Success = !nv.StartsWith("Skipped"),
					Message = nv
				});
			}
			SetOptimizeStatus("Finishing · AZIZ registry set and debloat settings…");
			await ApplyAzizExtras("Optimize");
			SetOptimizeStatus("Finishing · AZIZ wallpaper…");
			ApplyWallpaper(settings.WallpaperPicked ? settings.WallpaperStyle : 0);
			if (SteamHelper.SteamFolder() != null && !SteamHelper.Installed())
			{
				SetOptimizeStatus("Finishing · NoSteamWebHelper (Steam restarts)…");
				ActionResult steam = await Task.Run(() => SteamHelper.Install(null, interactiveFallback: false));
				Record("NoSteamWebHelper", "Optimize", "", steam.Success ? "Installed" : "Failed", steam);
			}
			TaskCompletionSource<bool> shown = new TaskCompletionSource<bool>();
			Action completed = delegate
			{
				shown.TrySetResult(result: true);
			};
			optimizeVisual.Completed += completed;
			optimizeVisual.SetProgress(1.0);
			await Task.WhenAny(shown.Task, Task.Delay(4000));
			optimizeVisual.Completed -= completed;
			await Task.Delay(1300);
			HideOptimizeOverlay();
			optimizeStatus.Foreground = Green;
			SetOptimizeStatus((targets.Count == 0) ? ("Already optimized · this PC matches " + name + ".") : ("Optimized with " + name + " · " + (targets.Count - failed) + " settings applied" + ((failed > 0) ? (" · " + failed + " need review in History") : "") + " · restart Windows to finish."));
		}
		catch (Exception ex)
		{
			HideOptimizeOverlay();
			optimizeStatus.Foreground = B("#F59E0B");
			SetOptimizeStatus("Optimize stopped: " + ex.Message);
		}
		finally
		{
			HideOptimizeOverlay();
			Quiet = false;
			lock (QuietMessages)
			{
				if (QuietMessages.Count > 0)
				{
					Record("Optimize messages", "Optimize", "", QuietMessages.Count + " messages", new ActionResult
					{
						Success = true,
						Message = string.Join("\n", QuietMessages)
					});
					QuietMessages.Clear();
				}
			}
			optimizing = false;
			optimizeButton.IsEnabled = true;
		}
	}

	private async Task ApplyAzizExtras(string action)
	{
		await BackupFirst();
		List<string> regSet = await Task.Run(delegate
		{
			RegistryJournal.Originals = engine.OriginalIndex();
			return SilentTweaks.Apply();
		});
		Record("AZIZ registry set", action, "", regSet.Count + " values", new ActionResult
		{
			Success = (regSet.Count > 0),
			Message = string.Join("\n", regSet)
		});
		Dictionary<string, List<string>> dictionary = await Task.Run(delegate
		{
			Dictionary<string, List<string>> dictionary2 = DebloatList.ApplyRegistry();
			RegistryJournal.Save();
			foreach (KeyValuePair<string, List<string>> item2 in DebloatList.ApplyRest())
			{
				dictionary2[item2.Key] = item2.Value;
			}
			return dictionary2;
		});
		foreach (KeyValuePair<string, List<string>> item in dictionary)
		{
			Record("Debloat · " + item.Key, action, "", item.Value.Count + " values", new ActionResult
			{
				Success = true,
				Message = string.Join("\n", item.Value)
			});
		}
		List<string> startup = await Task.Run(() => StartupApps.DisableAll());
		Record("Startup apps", action, "On", startup.Count + " off", new ActionResult
		{
			Success = true,
			Message = (startup.Count == 0) ? "Nothing else starts with Windows (Process Lasso, RivaTuner, MSI Afterburner, AZIZ and Windows Security stay)." : string.Join("\n", startup)
		});
		RunEdgeRemoval();
		notice.Text = action + ": AZIZ registry set (" + regSet.Count + " values) and " + dictionary.Count + " debloat groups applied · Microsoft Edge and WebView2 being removed · details in History.";
	}

	private void SetOptimizeStatus(string text)
	{
		optimizeStatus.Text = text;
		if (overlayStatus != null)
		{
			overlayStatus.Text = text;
		}
	}

	private static FrameworkElement Spacer(int height)
	{
		return new Border
		{
			Height = height
		};
	}

	private System.Windows.Controls.Button WideLink(string title, string description, Action action)
	{
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(title, 14.0, Text));
		stackPanel.Children.Add(Label(description, 11.0, Muted));
		System.Windows.Controls.Button button = Btn("", action);
		button.Content = stackPanel;
		button.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Left;
		button.Margin = new Thickness(0.0, 0.0, 0.0, 12.0);
		button.Padding = new Thickness(14.0);
		return button;
	}

	private void AddMetric(System.Windows.Controls.Panel parent, string key, string desc, double? value, string unit, System.Windows.Media.Brush color)
	{
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(key, 10.0, Muted));
		TextBlock textBlock = Label(value.HasValue ? (value.Value.ToString((unit == " GHz") ? "0.00" : "0") + unit) : "—", 22.0, color);
		textBlock.Margin = new Thickness(0.0, 4.0, 0.0, 1.0);
		stackPanel.Children.Add(textBlock);
		metrics[key] = textBlock;
		Canvas canvas = new Canvas
		{
			Height = 18.0,
			Margin = new Thickness(0.0, 5.0, 0.0, 0.0),
			ClipToBounds = true
		};
		Polyline polyline = new Polyline
		{
			Stroke = color,
			StrokeThickness = 1.8
		};
		canvas.Children.Add(polyline);
		stackPanel.Children.Add(canvas);
		traces[key] = polyline;
		Border border = Card(stackPanel);
		border.Padding = new Thickness(12.0, 9.0, 12.0, 9.0);
		border.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
		parent.Children.Add(border);
	}

	private System.Windows.Media.Brush StateColor(string state)
	{
		return state switch
		{
			"Mixed" => B("#EAC37C"), 
			"Disabled" => Muted, 
			"Enabled" => Green, 
			_ => B("#C09ACB"), 
		};
	}

	private void RenderSystem()
	{
		content.Children.Clear();
		if (machine == null)
		{
			content.Children.Add(Label("Detecting hardware…", 16.0, Muted));
			return;
		}
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(machine.ComputerName, 26.0, Text));
		stackPanel.Children.Add(Label(machine.OsName + "  ·  " + machine.FormFactor, 13.0, Muted));
		content.Children.Add(Card(stackPanel));
		foreach (SpecItem spec in machine.Specs)
		{
			Grid obj = new Grid
			{
				ColumnDefinitions = 
				{
					new ColumnDefinition
					{
						Width = new GridLength(190.0)
					},
					new ColumnDefinition()
				},
				Children = { (UIElement)Label(spec.Label, 12.0, Muted) }
			};
			TextBlock textBlock = Label(spec.Value, 13.0, Text);
			Grid.SetColumn(textBlock, 1);
			obj.Children.Add(textBlock);
			Border border = Card(obj);
			border.Padding = new Thickness(16.0);
			border.Margin = new Thickness(0.0, 0.0, 0.0, 7.0);
			content.Children.Add(border);
		}
		content.Children.Add(Btn("Export hardware report", delegate
		{
			Export("AZIZ-hardware.json", Program.Json.Serialize(machine));
		}));
	}

	private void RenderHistory()
	{
		content.Children.Clear();
		List<HistoryEntry> entries = HomeHistory().ToList();
		StackPanel stackPanel = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal,
			Margin = new Thickness(0.0, 0.0, 0.0, 20.0)
		};
		stackPanel.Children.Add(Btn("Export history", delegate
		{
			Export("AZIZ-history.json", Program.Json.Serialize(entries));
		}));
		stackPanel.Children.Add(Label(entries.Count + " recorded events", 12.0, Muted));
		content.Children.Add(stackPanel);
		FillHistory(content, entries.Take(300));
	}

	private void RenderRestore()
	{
		content.Children.Clear();
		AddRestoreApps();
		content.Children.Add(Card(Label("Restore the saved value from before a change made in AZIZ. This covers supported app changes; it does not reverse the entire playbook. Component recovery is available above.", 14.0, Muted)));
		List<Tweak> list = engine.Tweaks.Where((Tweak t) => engine.CanRestore(t.Id)).ToList();
		if (list.Count == 0)
		{
			content.Children.Add(Label("No saved changes on this account yet.", 16.0, Muted));
		}
		foreach (Tweak t2 in list)
		{
			StackPanel stackPanel = Stack();
			stackPanel.Children.Add(Label(t2.Name, 17.0, Text));
			stackPanel.Children.Add(Spacer(12));
			UIElementCollection children = stackPanel.Children;
			Action action = async delegate
			{
				if (!preview && !applying)
				{
					if (!Program.IsAdmin)
					{
						Say("Run as administrator to restore.");
					}
					else if (System.Windows.MessageBox.Show("Restore saved values for " + t2.Name + "?", "Restore", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
					{
						applying = true;
						try
						{
							ActionResult actionResult = await Task.Run(() => engine.Restore(t2.Id));
							notice.Text = actionResult.Message;
							if (!actionResult.Success)
							{
								Say(actionResult.Message);
							}
						}
						finally
						{
							applying = false;
						}
						// Only the restored option is read again (a full read takes a minute on some PCs).
						await ScanAsync(new string[1] { t2.Id });
						RenderRestore();
					}
				}
			};
			children.Add(Btn("Restore saved values", action));
			content.Children.Add(Card(stackPanel));
		}
		content.Children.Add(Btn("Open Windows recovery", delegate
		{
			OpenUri("ms-settings:recovery");
		}));
	}

	private void RenderPower()
	{
		List<PowerPlan> plans = cachedPowerPlans;
		content.Children.Clear();
		content.Children.Add(Card(Label("Select a plan for this machine. High-performance plans can increase power use and heat, especially on laptops. Imported .pow plans remain optional.", 14.0, Muted)));
		foreach (PowerPlan plan2 in plans)
		{
			StackPanel stackPanel = Stack();
			stackPanel.Children.Add(Label(plan2.Name, 19.0, Text));
			stackPanel.Children.Add(Label(plan2.Active ? "●  Currently active" : plan2.Id, 11.0, plan2.Active ? Green : Muted));
			stackPanel.Children.Add(Spacer(14));
			stackPanel.Children.Add(Btn(plan2.Active ? "Active" : "Activate", async delegate
			{
				if (!preview && !applying)
				{
					applying = true;
					try
					{
						PowerPlan before = plans.FirstOrDefault((PowerPlan x) => x.Active);
						ActionResult actionResult2 = await Task.Run(() => Utilities.ActivatePlan(plan2.Id));
						Record("Power plan", "Activate", (before == null) ? "Unknown" : before.Name, plan2.Name, actionResult2);
						notice.Text = actionResult2.Message;
					}
					finally
					{
						applying = false;
					}
					await RefreshPowerPlans();
					RenderPower();
				}
			}, !plan2.Active));
			if (!WindowsPlan(plan2.Id))
			{
				System.Windows.Controls.Button remove = Btn("Delete", async delegate
				{
					if (!preview && !applying)
					{
						await DeletePlans(new List<PowerPlan> { plan2 });
					}
				});
				remove.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
				remove.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
				stackPanel.Children.Add(remove);
			}
			content.Children.Add(Card(stackPanel));
		}
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		List<PowerPlan> extra = plans.Where((PowerPlan x) => !WindowsPlan(x.Id)).ToList();
		if (extra.Count > 0)
		{
			stackPanel2.Children.Add(Btn("Delete all except Windows plans (" + extra.Count + ")", async delegate
			{
				if (!preview && !applying && System.Windows.MessageBox.Show("Delete " + extra.Count + " power plan" + ((extra.Count == 1) ? "" : "s") + "? Balanced, High performance and Power saver stay.", "Power plans", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
				{
					await DeletePlans(extra);
				}
			}));
		}
		stackPanel2.Children.Add(Btn("Import .pow file", delegate
		{
			ChoosePowerImport(null);
		}));
		stackPanel2.Children.Add(Btn("Power & battery settings", delegate
		{
			OpenUri("ms-settings:powersleep");
		}));
		content.Children.Add(stackPanel2);
		string previous = System.IO.Path.Combine(Program.Data, "previous-power-plan.txt");
		if (File.Exists(previous))
		{
			content.Children.Add(Btn("Restore previous active plan", async delegate
			{
				if (!preview)
				{
					ActionResult actionResult = await Task.Run(() => Utilities.ActivatePlan(File.ReadAllText(previous).Trim()));
					notice.Text = actionResult.Message;
					await RefreshPowerPlans();
					RenderPower();
				}
			}));
		}
		content.Children.Add(Spacer(25));
		content.Children.Add(Label("Windows & community plans", 21.0, Text));
		content.Children.Add(Spacer(15));
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 3
		};
		foreach (BundledPlan item in Utilities.Catalog<BundledPlan>("power-plans.json"))
		{
			BundledPlan plan = item;
			StackPanel stackPanel3 = Stack();
			stackPanel3.Children.Add(Label(plan.Name, 16.0, Text));
			TextBlock textBlock = Label(plan.Description, 11.0, Muted);
			textBlock.MinHeight = 42.0;
			textBlock.Margin = new Thickness(0.0, 8.0, 0.0, 12.0);
			stackPanel3.Children.Add(textBlock);
			WrapPanel wrapPanel = new WrapPanel
			{
				Children = 
				{
					(UIElement)Btn("Import only", async delegate
					{
						await ImportBundledPower(plan, activate: false);
					}),
					(UIElement)Btn("Import & activate", async delegate
					{
						await ImportBundledPower(plan, activate: true);
					})
				}
			};
			stackPanel3.Children.Add(wrapPanel);
			Border border = Card(stackPanel3);
			border.Margin = new Thickness(0.0, 0.0, 12.0, 12.0);
			uniformGrid.Children.Add(border);
		}
		content.Children.Add(uniformGrid);
	}

	// Windows' own plans (Balanced, High performance, Power saver) are never deleted.
	private static bool WindowsPlan(string id)
	{
		return new string[3] { "381b4222-f694-41f0-9685-ff5bb260df2e", "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c", "a1841308-3541-4fab-bc81-f71556f20b4a" }.Contains((id ?? "").ToLowerInvariant());
	}

	private async Task DeletePlans(List<PowerPlan> list)
	{
		await BackupFirst();
		applying = true;
		try
		{
			List<string> done = await Task.Run(delegate
			{
				List<string> list2 = new List<string>();
				foreach (PowerPlan item in list)
				{
					if (!Regex.IsMatch(item.Id ?? "", "^[0-9a-fA-F-]{36}$"))
					{
						continue;
					}
					if (item.Active)
					{
						Utilities.ActivatePlan("381b4222-f694-41f0-9685-ff5bb260df2e");
					}
					if (Utilities.Run("powercfg.exe", "/delete " + item.Id).Success)
					{
						list2.Add(item.Name);
					}
				}
				return list2;
			});
			Record("Power plans", "Delete", list.Count + " plans", done.Count + " deleted", new ActionResult
			{
				Success = (done.Count == list.Count),
				Message = string.Join(", ", done)
			});
			notice.Text = done.Count + " power plan" + ((done.Count == 1) ? "" : "s") + " deleted.";
		}
		finally
		{
			applying = false;
		}
		await RefreshPowerPlans();
		RenderPower();
	}

	private async void RenderApps()
	{
		content.Children.Clear();
		content.Children.Add(Card(Label("Installed Microsoft Store applications for the current user. Removing an app affects this account; Windows may protect system packages. Reinstallation is separate from tweak restoration.", 14.0, Muted)));
		TextBlock loading = Label("Scanning application packages…", 16.0, Muted);
		content.Children.Add(loading);
		List<InstalledApp> list = await Task.Run(() => Utilities.InstalledApps());
		if (current != "Uninstaller" || closing)
		{
			return;
		}
		content.Children.Remove(loading);
		content.Children.Add(Btn("Manage desktop applications", delegate
		{
			OpenUri("ms-settings:appsfeatures");
		}));
		if (list.Count == 0)
		{
			content.Children.Add(Label("No removable Store packages returned. Open Windows application settings to inspect all software.", 14.0, Muted));
		}
		foreach (InstalledApp a in list)
		{
			Grid grid = new Grid();
			grid.ColumnDefinitions.Add(new ColumnDefinition());
			grid.ColumnDefinitions.Add(new ColumnDefinition
			{
				Width = GridLength.Auto
			});
			StackPanel stackPanel = Stack();
			stackPanel.Children.Add(Label(a.Name, 15.0, Text));
			stackPanel.Children.Add(Label(a.Version, 11.0, Muted));
			grid.Children.Add(stackPanel);
			Action action = async delegate
			{
				if (preview || applying || System.Windows.MessageBox.Show("Remove " + a.Name + " for this user?\n\nApp data can be lost. AZIZ cannot undo app removal.", "Uninstall application", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) != MessageBoxResult.OK)
				{
					return;
				}
				applying = true;
				try
				{
					ActionResult actionResult = await Task.Run(() => Utilities.RemoveApp(a));
					Record(a.Name, "Uninstall", "Installed", actionResult.Success ? "Removed" : "Unchanged", actionResult);
					notice.Text = actionResult.Message;
					if (!actionResult.Success)
					{
						Say(actionResult.Message);
					}
				}
				finally
				{
					applying = false;
					RenderApps();
				}
			};
			System.Windows.Controls.Button button = Btn("Uninstall", action);
			Grid.SetColumn(button, 1);
			grid.Children.Add(button);
			content.Children.Add(Card(grid));
		}
	}

	private void AddShortcut(string name, string desc, string url)
	{
		content.Children.Add(WideLink(name + "   ↗", desc, delegate
		{
			OpenUri(url);
		}));
	}

	private void OpenUri(string uri)
	{
		if (!preview)
		{
			Process.Start(new ProcessStartInfo(uri)
			{
				UseShellExecute = true
			});
		}
	}

	private void Elevate()
	{
		if (preview)
		{
			return;
		}
		try
		{
			Process.Start(new ProcessStartInfo(Program.ExePath)
			{
				Verb = "runas",
				UseShellExecute = true
			});
			exitRequested = true;
			Close();
		}
		catch (Exception ex)
		{
			notice.Text = ex.Message;
		}
	}

	private void Export(string name, string data)
	{
		if (!preview)
		{
			Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog
			{
				FileName = name,
				Filter = "JSON report (*.json)|*.json"
			};
			if (saveFileDialog.ShowDialog() == true)
			{
				File.WriteAllText(saveFileDialog.FileName, data, Encoding.UTF8);
				notice.Text = "Saved " + saveFileDialog.FileName;
			}
		}
	}

	private void Record(string name, string action, string before, string after, ActionResult result)
	{
		observations.Insert(0, new HistoryEntry
		{
			Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
			Name = name,
			Action = action,
			Before = before,
			After = after,
			Result = Utilities.CleanMessage(result.Message),
			Profile = ProfileName(ActiveKey)
		});
		SaveObservations();
	}

	private void LoadPreferences()
	{
		try
		{
			string path = System.IO.Path.Combine(Program.Data, "favorites.json");
			if (File.Exists(path))
			{
				favorites = new HashSet<string>(Program.Json.Deserialize<string[]>(File.ReadAllText(path)));
			}
			path = System.IO.Path.Combine(Program.Data, "observations.json");
			if (File.Exists(path))
			{
				observations = Program.Json.Deserialize<List<HistoryEntry>>(File.ReadAllText(path));
			}
		}
		catch
		{
		}
	}

	private void SaveFavorites()
	{
		if (preview)
		{
			return;
		}
		try
		{
			Directory.CreateDirectory(Program.Data);
			Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "favorites.json"), Program.Json.Serialize(favorites.ToArray()));
		}
		catch (Exception ex)
		{
			notice.Text = "Could not save favorites: " + ex.Message;
		}
	}

	private void SaveObservations()
	{
		if (preview)
		{
			return;
		}
		try
		{
			Directory.CreateDirectory(Program.Data);
			observations = observations.Take(2000).ToList();
			Utilities.AtomicWrite(System.IO.Path.Combine(Program.Data, "observations.json"), Program.Json.Serialize(observations));
		}
		catch (Exception ex)
		{
			notice.Text = "Could not save observed history: " + ex.Message;
		}
	}

	public async Task RefreshInventory()
	{
		if (inventoryScanning)
		{
			return;
		}
		inventoryScanning = true;
		try
		{
			Task<List<DesktopApp>> desktop = Task.Run(() => AppInventory.Read());
			Task<List<InstalledApp>> store = Task.Run(() => Utilities.InstalledApps());
			await Task.WhenAll(desktop, store);
			cachedDesktop = desktop.Result;
			cachedStore = store.Result;
			string[] array = new string[3] { "Downloads", "Uninstaller", "Tools" };
			foreach (string key in array)
			{
				viewCache.Remove(key);
			}
		}
		finally
		{
			inventoryScanning = false;
		}
	}

	private void ApplyWindowChrome(Grid body)
	{
		base.WindowStyle = WindowStyle.None;
		WindowChrome windowChrome = new WindowChrome();
		windowChrome.CaptionHeight = 38.0;
		windowChrome.ResizeBorderThickness = new Thickness(6.0);
		windowChrome.GlassFrameThickness = new Thickness(0.0);
		windowChrome.CornerRadius = new CornerRadius(0.0);
		windowChrome.UseAeroCaptionButtons = false;
		WindowChrome.SetWindowChrome(this, windowChrome);
		bool dark = !settings.Light && !Orange;
		DockPanel dockPanel = new DockPanel
		{
			Background = (dark ? ShellBackground() : new SolidColorBrush(Bg))
		};
		Grid grid = new Grid
		{
			Height = 38.0,
			Background = (dark ? new SolidColorBrush(System.Windows.Media.Color.FromArgb(170, 6, 6, 20)) : B("#0D1423"))
		};
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = GridLength.Auto
		});
		StackPanel stackPanel = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		Tuple<string, Action>[] array = new Tuple<string, Action>[3]
		{
			Tuple.Create<string, Action>("—", delegate
			{
				base.WindowState = WindowState.Minimized;
			}),
			Tuple.Create<string, Action>("□", delegate
			{
				base.WindowState = ((base.WindowState != WindowState.Maximized) ? WindowState.Maximized : WindowState.Normal);
			}),
			Tuple.Create<string, Action>("×", delegate
			{
				Close();
			})
		};
		// Top-left: day / night switch (drawn moon or sun). Top-right: settings gear, then the window buttons. No hover highlight.
		Grid themeIcon = ThemeGlyph(!settings.Light);
		themeIcon.Margin = new Thickness(14.0, 0.0, 0.0, 0.0);
		themeIcon.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		themeIcon.MouseLeftButtonUp += delegate
		{
			ToggleDayNight();
		};
		WindowChrome.SetIsHitTestVisibleInChrome(themeIcon, hitTestVisible: true);
		grid.Children.Add(themeIcon);
		TextBlock gear = new TextBlock
		{
			Text = "⚙",
			FontSize = 17.0,
			Foreground = B("#B9B3DE"),
			Background = System.Windows.Media.Brushes.Transparent,
			Width = 40.0,
			TextAlignment = TextAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center,
			Cursor = System.Windows.Input.Cursors.Hand,
			ToolTip = "Settings"
		};
		gear.MouseLeftButtonUp += delegate
		{
			Go("Settings");
		};
		WindowChrome.SetIsHitTestVisibleInChrome(gear, hitTestVisible: true);
		stackPanel.Children.Add(gear);
		foreach (Tuple<string, Action> tuple in array)
		{
			System.Windows.Controls.Button button = Btn(tuple.Item1, tuple.Item2);
			button.Width = 46.0;
			button.Height = 34.0;
			button.Padding = new Thickness(0.0);
			button.Margin = new Thickness(0.0);
			button.Background = System.Windows.Media.Brushes.Transparent;
			button.FontSize = 18.0;
			// The three window marks share one size and one centre line.
			button.FontFamily = new System.Windows.Media.FontFamily("Segoe MDL2 Assets, Segoe Fluent Icons");
			button.FontSize = 10.0;
			button.Content = ((tuple.Item1 == "—") ? "\ue921" : ((tuple.Item1 == "□") ? "\ue922" : "\ue8bb"));
			button.HorizontalContentAlignment = System.Windows.HorizontalAlignment.Center;
			button.VerticalContentAlignment = VerticalAlignment.Center;
			WindowChrome.SetIsHitTestVisibleInChrome(button, hitTestVisible: true);
			stackPanel.Children.Add(button);
		}
		Grid.SetColumn(stackPanel, 1);
		grid.Children.Add(stackPanel);
		DockPanel.SetDock(grid, Dock.Top);
		dockPanel.Children.Add(grid);
		dockPanel.Children.Add(body);
		Border border = new Border();
		border.BorderBrush = (dark ? B("#1C1834") : B("#233049"));
		border.BorderThickness = new Thickness(1.0);
		border.Child = dockPanel;
		base.Content = border;
	}

	private Grid WithPlaceholder(System.Windows.Controls.TextBox input, string text)
	{
		Grid obj = new Grid
		{
			Width = input.Width,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
			Children = { (UIElement)input }
		};
		TextBlock hint = Label(text, 12.0, Muted);
		hint.Visibility = (Visibility)((!string.IsNullOrEmpty(input.Text)) ? 2u : 0u);
		hint.IsHitTestVisible = false;
		hint.Margin = new Thickness(11.0, 0.0, 0.0, 0.0);
		hint.VerticalAlignment = VerticalAlignment.Center;
		obj.Children.Add(hint);
		input.TextChanged += delegate
		{
			hint.Visibility = (Visibility)((!string.IsNullOrEmpty(input.Text)) ? 2u : 0u);
		};
		return obj;
	}

	private object InputStyle(string xaml)
	{
		if (settings.Light)
		{
			xaml = xaml.Replace("#E9EDF7", "#172238").Replace("#182235", "#FFFFFF").Replace("#233149", "#DCE4F2")
				.Replace("#35405A", "#C9D3E5")
				.Replace("#C0C8DE", "#52617A")
				.Replace("#433660", "#DDD2FA")
				.Replace("Property='CaretBrush' Value='White'", "Property='CaretBrush' Value='#172238'");
		}
		return XamlReader.Parse(xaml);
	}

	private void ApplyInputStyles()
	{
		base.Resources[typeof(System.Windows.Controls.CheckBox)] = InputStyle("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='CheckBox'><Setter Property='Foreground' Value='#E9EDF7'/><Setter Property='Cursor' Value='Hand'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='CheckBox'><DockPanel Background='Transparent'><Border x:Name='box' Width='19' Height='19' CornerRadius='4' BorderBrush='#77829C' BorderThickness='1' Background='#182235' Margin='0,0,8,0'><TextBlock x:Name='tick' Text='✓' Foreground='White' Visibility='Collapsed' FontSize='13' HorizontalAlignment='Center' VerticalAlignment='Center'/></Border><ContentPresenter RecognizesAccessKey='True' VerticalAlignment='Center'/></DockPanel><ControlTemplate.Triggers><Trigger Property='IsChecked' Value='True'><Setter TargetName='box' Property='Background' Value='{DynamicResource AzizAccent}'/><Setter TargetName='box' Property='BorderBrush' Value='{DynamicResource AzizAccent}'/><Setter TargetName='tick' Property='Visibility' Value='Visible'/></Trigger><Trigger Property='IsEnabled' Value='False'><Setter Property='Opacity' Value='.5'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>");
		base.Resources[typeof(System.Windows.Controls.TextBox)] = InputStyle("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='TextBox'><Setter Property='Background' Value='#182235'/><Setter Property='Foreground' Value='#E9EDF7'/><Setter Property='BorderBrush' Value='#35405A'/><Setter Property='CaretBrush' Value='White'/><Setter Property='SelectionBrush' Value='#7654E8'/><Setter Property='Padding' Value='10,7'/></Style>");
		base.Resources[typeof(System.Windows.Controls.ComboBox)] = InputStyle("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' TargetType='ComboBox'><Setter Property='Foreground' Value='#E9EDF7'/><Setter Property='Background' Value='#233149'/><Setter Property='MinHeight' Value='34'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ComboBox'><Grid><Border Background='{TemplateBinding Background}' CornerRadius='6'/><ToggleButton Focusable='False' ClickMode='Press' IsChecked='{Binding IsDropDownOpen,RelativeSource={RelativeSource TemplatedParent},Mode=TwoWay}'><ToggleButton.Template><ControlTemplate TargetType='ToggleButton'><Border Background='Transparent'><TextBlock Text='⌄' Foreground='#C0C8DE' HorizontalAlignment='Right' VerticalAlignment='Center' Margin='0,0,12,0'/></Border></ControlTemplate></ToggleButton.Template></ToggleButton><ContentPresenter IsHitTestVisible='False' Margin='12,5,30,5' VerticalAlignment='Center' Content='{TemplateBinding SelectionBoxItem}' ContentTemplate='{TemplateBinding SelectionBoxItemTemplate}'/><Popup Name='PART_Popup' Placement='Bottom' IsOpen='{TemplateBinding IsDropDownOpen}' AllowsTransparency='True' Focusable='False' PopupAnimation='Fade'><Border Background='#182235' BorderBrush='#35405A' BorderThickness='1' CornerRadius='6' MinWidth='{Binding ActualWidth,RelativeSource={RelativeSource TemplatedParent}}' MaxHeight='300'><ScrollViewer><ItemsPresenter/></ScrollViewer></Border></Popup></Grid></ControlTemplate></Setter.Value></Setter></Style>");
		base.Resources[typeof(ComboBoxItem)] = InputStyle("<Style xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' TargetType='ComboBoxItem'><Setter Property='Foreground' Value='#E9EDF7'/><Setter Property='Padding' Value='10,7'/><Setter Property='Template'><Setter.Value><ControlTemplate TargetType='ComboBoxItem'><Border xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml' x:Name='row' Background='Transparent' Padding='{TemplateBinding Padding}'><ContentPresenter/></Border><ControlTemplate.Triggers><Trigger Property='IsHighlighted' Value='True'><Setter TargetName='row' Property='Background' Value='#433660'/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>");
	}

	public void AfterStartup(bool fromPlaybook)
	{
		if (!preview)
		{
			ApplyBrandIcon();
			BaselineStore.UpdateDeployment(fromPlaybook, states);
			PlayCue("open");
			if (sampleTimer != null && current == "Home" && base.IsVisible && base.WindowState != WindowState.Minimized)
			{
				sampleTimer.Start();
				ReadSample();
			}
			RecordFirstStart();
			FinishFirstSession();
			FirstRunDefaults();
			CheckForUpdate();
			// RivaTuner is prepared quietly in the background so the first Reflex ON is instant; the window never waits for it.
			if (Program.IsAdmin)
			{
				ReflexFallback.Prefetch();
			}
			ready = true;
			if (bringForwardPending && !base.IsVisible)
			{
				ShowFromTray();
			}
			// With a profile: changes against it. Without one: changes against the Windows values of the first start.
			// After a reinstall: Welcome back instead (nothing is applied by itself).
			if (!WelcomeBack() && !settings.StartMinimized && !startedInTray)
			{
				ShowRecentChanges();
			}
		}
	}

	private readonly Dictionary<string, SoundPlayer> clickPlayers = new Dictionary<string, SoundPlayer>();

	// Switch sound when a card is turned on or off (a slightly lower tone for off): loaded once, played without blocking.
	private void Click(bool on = true)
	{
		if (preview || !settings.Sounds)
		{
			return;
		}
		try
		{
			string text = (on ? "click-on" : "click-off");
			if (!clickPlayers.TryGetValue(text, out var value))
			{
				string text2 = System.IO.Path.Combine(Program.Root, "assets", text + ".wav");
				if (!File.Exists(text2))
				{
					text2 = System.IO.Path.Combine(Program.Root, "assets", "click.wav");
				}
				if (!File.Exists(text2))
				{
					return;
				}
				value = new SoundPlayer(text2);
				value.Load();
				clickPlayers[text] = value;
			}
			value.Play();
		}
		catch
		{
		}
	}

	private void PlayCue(string name, bool wait = false)
	{
		if (preview || !settings.Sounds)
		{
			return;
		}
		string file = System.IO.Path.Combine(Program.Root, "assets", name + ".wav");
		if (!File.Exists(file))
		{
			return;
		}
		Action action = delegate
		{
			try
			{
				using SoundPlayer soundPlayer = new SoundPlayer(file);
				soundPlayer.PlaySync();
			}
			catch
			{
			}
		};
		if (wait)
		{
			action();
		}
		else
		{
			Task.Run(action);
		}
	}

	// Inner pages open as the modern blurred sheet over the app; NVIDIA pages carry NVIDIA green, AMD pages AMD red.
	private void ShowPanel(string title, Action<StackPanel> fill, double width = 840.0, double height = 660.0)
	{
		bool nvidia = title.IndexOf("NVIDIA", StringComparison.OrdinalIgnoreCase) >= 0;
		bool amd = title.IndexOf("AMD", StringComparison.OrdinalIgnoreCase) >= 0;
		string accent = (nvidia ? "#76B900" : (amd ? "#ED1C24" : "#B9A6FF"));
		ShowSheet(delegate(StackPanel p, Action close)
		{
			DockPanel head = new DockPanel
			{
				Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
			};
			System.Windows.Controls.Button x = Btn("✕", close);
			x.Background = System.Windows.Media.Brushes.Transparent;
			x.Padding = new Thickness(10.0, 4.0, 10.0, 4.0);
			DockPanel.SetDock(x, Dock.Right);
			head.Children.Add(x);
			StackPanel kick = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal
			};
			kick.Children.Add(new Border
			{
				Width = 4.0,
				Height = 18.0,
				CornerRadius = new CornerRadius(2.0),
				Background = B(accent),
				Margin = new Thickness(0.0, 0.0, 10.0, 0.0)
			});
			TextBlock t = Label(title.ToUpperInvariant(), 11.0, B(accent));
			t.FontWeight = FontWeights.SemiBold;
			t.VerticalAlignment = VerticalAlignment.Center;
			kick.Children.Add(t);
			head.Children.Add(kick);
			p.Children.Add(head);
			fill(p);
		}, Math.Max(760.0, width));
	}

	private void DarkDialog(Window w)
	{
		w.Resources = base.Resources;
		w.WindowStyle = WindowStyle.None;
		WindowChrome.SetWindowChrome(w, new WindowChrome
		{
			CaptionHeight = 36.0,
			GlassFrameThickness = new Thickness(0.0),
			ResizeBorderThickness = new Thickness(4.0),
			UseAeroCaptionButtons = false
		});
		UIElement element = (UIElement)w.Content;
		w.Content = null;
		DockPanel dockPanel = new DockPanel
		{
			Background = new SolidColorBrush(Bg)
		};
		DockPanel dockPanel2 = new DockPanel
		{
			Height = 36.0,
			Background = B("#0D1423")
		};
		System.Windows.Controls.Button button = Btn("×", delegate
		{
			w.Close();
		});
		button.Width = 44.0;
		button.Padding = new Thickness(0.0);
		button.Background = System.Windows.Media.Brushes.Transparent;
		WindowChrome.SetIsHitTestVisibleInChrome(button, hitTestVisible: true);
		DockPanel.SetDock(button, Dock.Right);
		dockPanel2.Children.Add(button);
		TextBlock textBlock = Label(w.Title, 12.0, Muted);
		textBlock.Margin = new Thickness(16.0, 0.0, 0.0, 0.0);
		textBlock.VerticalAlignment = VerticalAlignment.Center;
		dockPanel2.Children.Add(textBlock);
		DockPanel.SetDock(dockPanel2, Dock.Top);
		dockPanel.Children.Add(dockPanel2);
		dockPanel.Children.Add(element);
		w.Content = new Border
		{
			BorderBrush = B("#35405A"),
			BorderThickness = new Thickness(1.0),
			Child = dockPanel
		};
	}

	private void AddHomeActivity()
	{
		StackPanel stackPanel = Stack();
		DockPanel dockPanel = new DockPanel();
		StackPanel stackPanel2 = new StackPanel
		{
			Orientation = System.Windows.Controls.Orientation.Horizontal
		};
		stackPanel2.Children.Add(Btn("Restore apps", ShowAppRecovery));
		stackPanel2.Children.Add(Btn("Restore points", OpenSystemRestore));
		stackPanel2.Children.Add(Btn("Clear history", ClearAllHistory));
		stackPanel2.Children.Add(Btn("All history", ShowHistory));
		DockPanel.SetDock(stackPanel2, Dock.Right);
		dockPanel.Children.Add(stackPanel2);
		StackPanel stackPanel3 = Stack();
		stackPanel3.Children.Add(Label("Recent changes", 18.0, Text));
		stackPanel3.Children.Add(Label("Active profile · " + ProfileName(ActiveKey), 11.0, Cyan));
		dockPanel.Children.Add(stackPanel3);
		stackPanel.Children.Add(dockPanel);
		StackPanel stackPanel4 = Stack();
		stackPanel4.Margin = new Thickness(0.0, 12.0, 0.0, 0.0);
		foreach (HistoryEntry item in HomeHistory().Take(3))
		{
			stackPanel4.Children.Add(HistoryCard(item, compact: true));
		}
		stackPanel.Children.Add(stackPanel4);
		if (!HomeHistory().Any())
		{
			stackPanel.Children.Add(Label("Your changes appear here after you use a control.", 12.0, Muted));
		}
		content.Children.Add(Card(stackPanel));
	}

	private void ShowAppRecovery()
	{
		ShowPanel("Restore apps", delegate(StackPanel panel)
		{
			StackPanel stackPanel = content;
			content = panel;
			try
			{
				AddRestoreApps();
			}
			finally
			{
				content = stackPanel;
			}
		}, 1000.0, 720.0);
	}

	private void ApplyWallpaper(int style)
	{
		try
		{
			// The official files exactly as designed (assets\wallpapers); drawing it in the app is only a fallback.
			string text = System.IO.Path.Combine(Program.Root, "assets", "wallpapers", "AZIZ-" + Wallpaper.Styles[style] + ".png");
			if (!File.Exists(text))
			{
				text = Wallpaper.Render(0, 0, style);
			}
			Wallpaper.Set(text);
			settings.WallpaperStyle = style;
			SaveSettings();
			Record("AZIZ wallpaper", "Set wallpaper", Wallpaper.Styles[style], "Applied", new ActionResult
			{
				Success = true,
				Message = text
			});
			notice.Text = "AZIZ wallpaper set · " + Wallpaper.Styles[style] + ".";
		}
		catch (Exception ex)
		{
			notice.Text = "Wallpaper: " + ex.Message;
		}
	}

	private void ShowControlDetails(Tweak t)
	{
		states.TryGetValue(t.Id, out var currentState);
		// This PC's real value: read at AZIZ's first start; else saved just before AZIZ first changed it; else Windows' own default.
		string first = null;
		string firstNote = "Read when AZIZ first opened";
		try
		{
			WindowsBaseline.Values().TryGetValue(t.Id, out first);
			if (!ValueApplies(t, first))
			{
				first = engine.OriginalValue(t.Id);
				firstNote = "Saved before AZIZ first changed it";
			}
			if (!ValueApplies(t, first))
			{
				first = BaselineStore.WindowsDefault(t.Id);
				firstNote = "Windows default (not read on this PC)";
			}
		}
		catch
		{
		}
		string profileValue = null;
		if (AnyProfileActive)
		{
			try
			{
				ProfileValues(ActiveKey).TryGetValue(t.Id, out profileValue);
			}
			catch
			{
			}
		}
		ShowSheet(delegate(StackPanel p, Action closeSheet)
		{
			TextBlock textBlock = Label(t.Name, 22.0, Text);
			textBlock.FontWeight = FontWeights.SemiBold;
			p.Children.Add(textBlock);
			TextBlock textBlock2 = Label(t.Description, 12.0, Muted);
			textBlock2.Margin = new Thickness(0.0, 6.0, 0.0, 14.0);
			p.Children.Add(textBlock2);
			string text = ((currentState == null) ? "Reading…" : ((currentState.State == "Enabled") ? "On" : ((currentState.State == "Disabled") ? "Off" : ((currentState.State == "Mixed") ? (MixedShowsOn(t) ? "On · mixed" : "Off · mixed") : currentState.State))));
			// Design C: Default → Now → Profile as a flow of chips.
			StackPanel flow = new StackPanel
			{
				Orientation = System.Windows.Controls.Orientation.Horizontal,
				Margin = new Thickness(0.0, 0.0, 0.0, 8.0)
			};
			flow.Children.Add(FlowChip("Default", (first == null) ? "Not recorded" : (ValueApplies(t, first) ? ValueText(t, first) : first), System.Windows.Media.Color.FromRgb(30, 34, 58), firstNote));
			flow.Children.Add(FlowArrow());
			flow.Children.Add(FlowChip("Now", text, System.Windows.Media.Color.FromRgb(40, 30, 100), (currentState != null && currentState.State == "Mixed") ? "Some parts on, some off" : "Read live from Windows"));
			if (AnyProfileActive)
			{
				flow.Children.Add(FlowArrow());
				flow.Children.Add(FlowChip("Profile", (profileValue == null) ? "Not in profile" : ValueText(t, profileValue), System.Windows.Media.Color.FromRgb(60, 40, 140), ProfileName(ActiveKey)));
			}
			p.Children.Add(flow);
			TextBlock activeLine = Label("Active profile: " + (AnyProfileActive ? ProfileName(ActiveKey) : "none"), 11.0, Muted);
			activeLine.Margin = new Thickness(2.0, 0.0, 0.0, 12.0);
			p.Children.Add(activeLine);
			if (currentState != null && !string.IsNullOrWhiteSpace(currentState.Detail))
			{
				TextBlock textBlock3 = Label(currentState.Detail, 11.0, (currentState.State == "Mixed") ? B("#F5A524") : Muted);
				textBlock3.Margin = new Thickness(2.0, 0.0, 0.0, 12.0);
				p.Children.Add(textBlock3);
			}
			if (!string.IsNullOrWhiteSpace(t.Risk))
			{
				TextBlock textBlock4 = Label("⚠ " + t.Risk, 11.0, B("#F5A524"));
				textBlock4.Margin = new Thickness(2.0, 0.0, 0.0, 12.0);
				p.Children.Add(textBlock4);
			}
			List<Tuple<RegistryOperation, string, string>> parts = (t.Kind == "Registry") ? engine.LiveParts(t) : new List<Tuple<RegistryOperation, string, string>>();
			if (parts.Count > 1)
			{
				int onCount = parts.Count((Tuple<RegistryOperation, string, string> x) => x.Item2 == "On");
				StackPanel partRows = Stack();
				bool mixedNow = currentState != null && currentState.State == "Mixed";
				partRows.Visibility = (mixedNow ? Visibility.Visible : Visibility.Collapsed);
				string head = "Live parts · " + onCount + " of " + parts.Count + " on";
				TextBlock partHeader = Label((mixedNow ? "▾ " : "▸ ") + head, 12.0, mixedNow ? B("#F5A524") : Purple);
				partHeader.FontWeight = FontWeights.SemiBold;
				partHeader.Cursor = System.Windows.Input.Cursors.Hand;
				partHeader.Margin = new Thickness(2.0, 4.0, 0.0, 6.0);
				partHeader.MouseLeftButtonUp += delegate
				{
					bool flag3 = partRows.Visibility != Visibility.Visible;
					partRows.Visibility = (flag3 ? Visibility.Visible : Visibility.Collapsed);
					partHeader.Text = (flag3 ? "▾ " : "▸ ") + head;
				};
				p.Children.Add(partHeader);
				p.Children.Add(partRows);
				foreach (Tuple<RegistryOperation, string, string> part in parts.OrderBy((Tuple<RegistryOperation, string, string> x) => x.Item2 == "On"))
				{
					Grid partGrid = new Grid();
					partGrid.ColumnDefinitions.Add(new ColumnDefinition
					{
						Width = new GridLength(56.0)
					});
					partGrid.ColumnDefinitions.Add(new ColumnDefinition());
					partGrid.ColumnDefinitions.Add(new ColumnDefinition
					{
						Width = GridLength.Auto
					});
					TextBlock partState = Label(part.Item2, 11.0, (part.Item2 == "On") ? B("#7EE2A8") : ((part.Item2 == "Off") ? B("#9AA3B8") : B("#F5A524")));
					partState.FontWeight = FontWeights.SemiBold;
					partGrid.Children.Add(partState);
					TextBlock partName = Label(ShortPath(part.Item1.Hive, part.Item1.Path) + " · " + part.Item1.Name, 11.0, Text);
					partName.FontFamily = new System.Windows.Media.FontFamily("Cascadia Mono, Consolas");
					partName.TextTrimming = TextTrimming.CharacterEllipsis;
					partName.TextWrapping = TextWrapping.NoWrap;
					Grid.SetColumn(partName, 1);
					partGrid.Children.Add(partName);
					TextBlock partValue = Label(part.Item3, 11.0, Muted);
					partValue.Margin = new Thickness(10.0, 0.0, 0.0, 0.0);
					Grid.SetColumn(partValue, 2);
					partGrid.Children.Add(partValue);
					partRows.Children.Add(new Border
					{
						Background = B("#0F1424"),
						CornerRadius = new CornerRadius(8.0),
						Padding = new Thickness(10.0, 6.0, 10.0, 6.0),
						Margin = new Thickness(0.0, 0.0, 0.0, 4.0),
						Child = partGrid
					});
				}
			}
			List<Tuple<string, string>> list = ControlChanges(t);
			if (list.Count > 0)
			{
				StackPanel detailRows = Stack();
				detailRows.Visibility = Visibility.Collapsed;
				TextBlock textBlock5 = Label("▸ Show registry details (" + list.Count + ")", 12.0, Purple);
				textBlock5.FontWeight = FontWeights.SemiBold;
				textBlock5.Cursor = System.Windows.Input.Cursors.Hand;
				textBlock5.Margin = new Thickness(2.0, 4.0, 0.0, 6.0);
				textBlock5.MouseLeftButtonUp += delegate
				{
					bool flag = detailRows.Visibility != Visibility.Visible;
					detailRows.Visibility = (flag ? Visibility.Visible : Visibility.Collapsed);
					textBlock5.Text = (flag ? "▾ Hide registry details (" : "▸ Show registry details (") + list.Count + ")";
				};
				p.Children.Add(textBlock5);
				p.Children.Add(detailRows);
				foreach (Tuple<string, string> item in list)
				{
					Grid grid = new Grid();
					grid.ColumnDefinitions.Add(new ColumnDefinition
					{
						Width = new GridLength(70.0)
					});
					grid.ColumnDefinitions.Add(new ColumnDefinition());
					TextBlock textBlock6 = Label(item.Item1, 11.0, Cyan);
					textBlock6.FontWeight = FontWeights.SemiBold;
					grid.Children.Add(textBlock6);
					TextBlock textBlock7 = Label(item.Item2, 11.0, Text);
					textBlock7.FontFamily = new System.Windows.Media.FontFamily("Cascadia Mono, Consolas");
					Grid.SetColumn(textBlock7, 1);
					grid.Children.Add(textBlock7);
					Border border = new Border
					{
						Background = B("#0F1424"),
						CornerRadius = new CornerRadius(8.0),
						Padding = new Thickness(10.0, 7.0, 10.0, 7.0),
						Margin = new Thickness(0.0, 0.0, 0.0, 5.0),
						Child = grid
					};
					detailRows.Children.Add(border);
				}
			}
			if (engine.CanRestore(t.Id))
			{
				p.Children.Add(Spacer(12));
				p.Children.Add(Btn("Restore this PC's original value", async delegate
				{
					if (!preview && !applying)
					{
						applying = true;
						try
						{
							Say((await Task.Run(() => engine.Restore(t.Id))).Message);
						}
						finally
						{
							applying = false;
						}
						await ScanAsync(new string[1] { t.Id });
					}
				}));
			}
		}, 780.0);
	}

	private FrameworkElement FlowChip(string title, string value, System.Windows.Media.Color fill, string note)
	{
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label(title, 10.0, B("#BEBBE6")));
		TextBlock textBlock = Label(value, 15.0, System.Windows.Media.Brushes.White);
		textBlock.FontWeight = FontWeights.SemiBold;
		textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
		textBlock.TextWrapping = TextWrapping.NoWrap;
		stackPanel.Children.Add(textBlock);
		return new Border
		{
			Background = new SolidColorBrush(fill),
			CornerRadius = new CornerRadius(24.0),
			Padding = new Thickness(18.0, 7.0, 18.0, 8.0),
			MinWidth = 150.0,
			MaxWidth = 210.0,
			ToolTip = note,
			Child = stackPanel
		};
	}

	private FrameworkElement FlowArrow()
	{
		TextBlock textBlock = Label("→", 16.0, Muted);
		textBlock.VerticalAlignment = VerticalAlignment.Center;
		textBlock.Margin = new Thickness(8.0, 0.0, 8.0, 0.0);
		return textBlock;
	}

	private Border InfoTile(string title, string value, string note)
	{
		StackPanel stackPanel = Stack();
		TextBlock textBlock = Label(title, 9.0, Muted);
		textBlock.FontWeight = FontWeights.SemiBold;
		stackPanel.Children.Add(textBlock);
		TextBlock textBlock2 = Label(value, 15.0, Text);
		textBlock2.FontWeight = FontWeights.SemiBold;
		textBlock2.Margin = new Thickness(0.0, 4.0, 0.0, 2.0);
		stackPanel.Children.Add(textBlock2);
		if (!string.IsNullOrEmpty(note))
		{
			stackPanel.Children.Add(Label(note, 10.0, Muted));
		}
		return new Border
		{
			Background = B("#141A30"),
			CornerRadius = new CornerRadius(12.0),
			Padding = new Thickness(12.0, 10.0, 12.0, 10.0),
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0),
			Child = stackPanel
		};
	}

	private static string ShortPath(string hive, string path)
	{
		string text = (hive + "\\" + path).Replace("/", "\\");
		string[][] array = new string[6][]
		{
			new string[2] { "HKLM\\SYSTEM\\CurrentControlSet\\Services\\", "svc\\" },
			new string[2] { "HKLM\\SYSTEM\\CurrentControlSet\\", "sys\\" },
			new string[2] { "HKLM\\SOFTWARE\\Policies\\", "policy\\" },
			new string[2] { "HKLM\\SOFTWARE\\", "sw\\" },
			new string[2] { "HKCU\\SOFTWARE\\", "user\\" },
			new string[2] { "HKCU\\", "user\\" }
		};
		foreach (string[] array2 in array)
		{
			if (text.StartsWith(array2[0], StringComparison.OrdinalIgnoreCase))
			{
				text = array2[1] + text.Substring(array2[0].Length);
				break;
			}
		}
		return text.Replace("\\Microsoft\\Windows\\CurrentVersion\\", "\\…\\").Replace("Microsoft\\Windows\\CurrentVersion\\", "…\\").Replace("\\Microsoft\\Windows NT\\CurrentVersion\\", "\\…NT\\");
	}

	private List<Tuple<string, string>> ControlChanges(Tweak t)
	{
		List<Tuple<string, string>> list = new List<Tuple<string, string>>();
		if (t.Kind == "Service")
		{
			list.Add(Tuple.Create("Start", "svc\\" + t.Service + " · 2 Auto · 3 Manual · 4 Disabled"));
		}
		string[] array = new string[2] { "On", "Off" };
		foreach (string text in array)
		{
			List<RegistryOperation> list2 = ((text == "On") ? t.Enable : t.Disable);
			if (list2 == null)
			{
				continue;
			}
			foreach (RegistryOperation item in list2.Take(12))
			{
				list.Add(Tuple.Create(text, ShortPath(item.Hive, item.Path) + "\\" + item.Name + " = " + ((item.Value == null) ? "delete" : Program.Json.Serialize(item.Value).Trim('"'))));
			}
			if (list2.Count > 12)
			{
				list.Add(Tuple.Create(text, "+ " + (list2.Count - 12) + " more values"));
			}
		}
		if (t.Kind == "Bcd")
		{
			list.Add(Tuple.Create("On", "bcdedit " + t.BcdKey + " = " + t.BcdOnValue));
			list.Add(Tuple.Create("Off", "bcdedit delete " + t.BcdKey));
		}
		if (t.Kind == "Native" || !string.IsNullOrEmpty(t.EnableScript))
		{
			list.Add(Tuple.Create("Native", "Windows command (PowerShell) for devices, services and tasks"));
		}
		return list;
	}

	private void OpenSystemRestore()
	{
		if (preview)
		{
			return;
		}
		Window window = null;
		window = new Window
		{
			Owner = this,
			Title = "Restore points",
			Width = 760.0,
			Height = 620.0,
			WindowStartupLocation = WindowStartupLocation.CenterOwner,
			Background = new SolidColorBrush(Bg),
			Foreground = Text
		};
		DockPanel dockPanel = new DockPanel
		{
			Margin = new Thickness(22.0)
		};
		StackPanel stackPanel = Stack();
		stackPanel.Children.Add(Label("Restore points", 22.0, Text));
		TextBlock status = Label("Reading restore points…", 12.0, Muted);
		stackPanel.Children.Add(status);
		DockPanel dockPanel2 = new DockPanel
		{
			Margin = new Thickness(0.0, 14.0, 0.0, 10.0)
		};
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Text = "AZIZ · " + DateTime.Now.ToString("d MMM yyyy h:mm tt", English);
		textBox.Padding = new Thickness(10.0, 8.0, 10.0, 8.0);
		textBox.Background = B("#131F32");
		textBox.Foreground = Text;
		System.Windows.Controls.TextBox name = textBox;
		System.Windows.Controls.Button createBtn = Btn("Create restore point", delegate
		{
		}, primary: true);
		createBtn.Margin = new Thickness(8.0, 0.0, 0.0, 0.0);
		DockPanel.SetDock(createBtn, Dock.Right);
		dockPanel2.Children.Add(createBtn);
		dockPanel2.Children.Add(name);
		stackPanel.Children.Add(dockPanel2);
		DockPanel.SetDock(stackPanel, Dock.Top);
		dockPanel.Children.Add(stackPanel);
		WrapPanel wrapPanel = new WrapPanel
		{
			Margin = new Thickness(0.0, 12.0, 0.0, 0.0)
		};
		System.Windows.Controls.Button restoreBtn = Btn("Restore to selected point", delegate
		{
		});
		restoreBtn.IsEnabled = false;
		wrapPanel.Children.Add(restoreBtn);
		wrapPanel.Children.Add(Btn("Restore AZIZ Backup", delegate
		{
			RestoreBackupPoint();
		}, primary: true));
		wrapPanel.Children.Add(Btn("Windows System Restore ↗", delegate
		{
			try
			{
				SystemRestore.OpenWindowsRestore();
			}
			catch (Exception ex2)
			{
				status.Text = ex2.Message;
			}
		}));
		wrapPanel.Children.Add(Btn("System Properties ↗", delegate
		{
			try
			{
				Process.Start(new ProcessStartInfo(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "SystemPropertiesProtection.exe"))
				{
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				status.Text = ex.Message;
			}
		}));
		DockPanel.SetDock(wrapPanel, Dock.Bottom);
		dockPanel.Children.Add(wrapPanel);
		System.Windows.Controls.ListBox listBox = new System.Windows.Controls.ListBox();
		listBox.Background = B("#111B2C");
		listBox.BorderBrush = B("#233049");
		listBox.Foreground = Text;
		System.Windows.Controls.ListBox list = listBox;
		dockPanel.Children.Add(list);
		window.Content = dockPanel;
		bool busy = false;
		Func<Task> load = async delegate
		{
			status.Text = "Reading restore points…";
			List<RestorePointInfo> points = await Task.Run(() => SystemRestore.Points());
			bool flag = await Task.Run(() => SystemRestore.ProtectionOn());
			list.Items.Clear();
			foreach (RestorePointInfo item in points)
			{
				Grid grid2 = new Grid
				{
					Tag = item,
					Margin = new Thickness(4.0, 6.0, 4.0, 6.0)
				};
				grid2.ColumnDefinitions.Add(new ColumnDefinition());
				grid2.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = GridLength.Auto
				});
				StackPanel stackPanel2 = Stack();
				stackPanel2.Children.Add(Label(item.Description, 13.0, Text));
				stackPanel2.Children.Add(Label(item.TypeName, 10.0, Muted));
				grid2.Children.Add(stackPanel2);
				TextBlock textBlock = Label((item.Created == DateTime.MinValue) ? "" : Clock(item.Created), 11.0, Muted);
				textBlock.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
				Grid.SetColumn(textBlock, 1);
				grid2.Children.Add(textBlock);
				list.Items.Add(grid2);
			}
			status.Text = (flag ? "Protection on" : "Protection off · Create restore point turns it on") + " · " + points.Count + " restore point" + ((points.Count == 1) ? "" : "s");
		};
		list.SelectionChanged += delegate
		{
			restoreBtn.IsEnabled = list.SelectedItem != null && !busy;
		};
		createBtn.Click += async delegate
		{
			if (!busy)
			{
				if (!Program.IsAdmin)
				{
					Elevate();
				}
				else
				{
					busy = true;
					createBtn.IsEnabled = false;
					status.Text = "Creating restore point… (this can take a minute)";
					ActionResult r2 = await Task.Run(() => SystemRestore.Create(name.Text));
					Record("System Restore", "Create restore point", "", r2.Success ? name.Text : "Failed", r2);
					busy = false;
					createBtn.IsEnabled = true;
					await load();
					status.Text = (r2.Success ? ("Restore point created · " + status.Text) : ("Not created: " + Utilities.Short(r2.Message)));
				}
			}
		};
		restoreBtn.Click += async delegate
		{
			object selectedItem = list.SelectedItem;
			Grid grid = (Grid)((selectedItem is Grid) ? selectedItem : null);
			if (grid != null && !busy)
			{
				RestorePointInfo pt = (RestorePointInfo)grid.Tag;
				if (System.Windows.MessageBox.Show("Restore Windows to \"" + pt.Description + "\" (" + Clock(pt.Created) + ")?\n\nWindows restarts right away to restore. Save your work first. Personal files are not changed.", "System Restore", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
				{
					busy = true;
					status.Text = "Starting System Restore… Windows will restart.";
					Record("System Restore", "Restore", pt.Description, "Restarting", new ActionResult
					{
						Success = true,
						Message = Clock(pt.Created)
					});
					ActionResult actionResult = await Task.Run(() => SystemRestore.Restore(pt.Sequence));
					busy = false;
					if (!actionResult.Success)
					{
						status.Text = "System Restore did not start: " + Utilities.Short(actionResult.Message);
					}
				}
			}
		};
		DarkDialog(window);
		window.Loaded += async delegate
		{
			await load();
		};
		window.ShowDialog();
	}

	private void OpenSystemProperties()
	{
		if (preview)
		{
			return;
		}
		try
		{
			Process.Start(new ProcessStartInfo(System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "SystemPropertiesProtection.exe"))
			{
				UseShellExecute = true
			});
		}
		catch (Exception ex)
		{
			notice.Text = "System Restore: " + ex.Message;
		}
	}

	// Always the same name: runs the 0.5 ms test (requesting it if needed). Releasing is the Set Timer Resolution switch in Tweaks.
	private async void ToggleTimer()
	{
		await SetTimer(enabled: true);
	}

	private async Task SetTimer(bool enabled, bool report = true)
	{
		await BackupFirst();
		if (preview)
		{
			return;
		}
		bool restartNeeded = false;
		try
		{
			if (enabled)
			{
				restartNeeded = TimerLease.EnableGlobalRequests();
			}
			if (enabled && timerLease == null)
			{
				timerLease = new TimerLease();
			}
			if (!enabled && timerLease != null)
			{
				timerLease.Dispose();
				timerLease = null;
			}
			ActionResult actionResult = await Task.Run(() => enabled ? TimerService.Install() : TimerService.Remove());
			if (!actionResult.Success)
			{
				notice.Text = "Boot timer service: " + actionResult.Message;
			}
		}
		catch (Exception ex)
		{
			Say(ex.Message);
			return;
		}
		states["global-timer-resolution"] = TimerLease.State();
		if (restartNeeded)
		{
			notice.Text = "Set Timer Resolution 0.5: system-wide requests turned on · restart Windows once so every app gets 0.5 ms.";
		}
		Record("Set Timer Resolution 0.5", enabled ? "Enable" : "Disable", "Windows managed", enabled ? "Requested 0.5 ms" : "Released", new ActionResult
		{
			Success = true,
			Message = "Measured report is temporary and cleared when closed."
		});
		InvalidateViews();
		if (IsTweakPage(current))
		{
			RenderTweaks();
		}
		if (!report || Quiet)
		{
			return;
		}
		Window window = new Window();
		window.Owner = this;
		window.Title = "Timer Resolution Test";
		window.Width = 570.0;
		window.Height = 310.0;
		window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
		window.Background = new SolidColorBrush(Bg);
		window.Foreground = Text;
		Window w = window;
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(24.0);
		TextBlock label = Label("Testing for five seconds…", 20.0, Text);
		stackPanel.Children.Add(label);
		System.Windows.Controls.ProgressBar progressBar = new System.Windows.Controls.ProgressBar();
		progressBar.IsIndeterminate = true;
		progressBar.Height = 4.0;
		progressBar.Margin = new Thickness(0.0, 18.0, 0.0, 18.0);
		progressBar.Foreground = Accent;
		System.Windows.Controls.ProgressBar progress = progressBar;
		stackPanel.Children.Add(progress);
		TextBlock detail = Label((enabled ? "Requested 0.500 ms. " : "AZIZ request released. ") + "This measures actual timer resolution and 0.5 ms requested waits, not input latency.", 12.0, Muted);
		stackPanel.Children.Add(detail);
		System.Windows.Controls.Button button = Btn("Close and clear report", delegate
		{
			w.Close();
		});
		button.Margin = new Thickness(0.0, 18.0, 0.0, 0.0);
		stackPanel.Children.Add(button);
		w.Content = stackPanel;
		DarkDialog(w);
		CancellationTokenSource cancellation = new CancellationTokenSource();
		w.Closed += delegate
		{
			cancellation.Cancel();
			TextBlock textBlock = label;
			string text2 = (detail.Text = "");
			string text3 = text2;
			textBlock.Text = text3;
		};
		w.Show();
		try
		{
			double[] array = await Task.Run(delegate
			{
				List<double> list = new List<double>();
				Stopwatch stopwatch = Stopwatch.StartNew();
				double num = TimerLease.Query();
				Stopwatch stopwatch2 = Stopwatch.StartNew();
				while (enabled && num > 0.51 && stopwatch2.Elapsed.TotalSeconds < 3.0)
				{
					Thread.Sleep(100);
					num = TimerLease.Query();
				}
				while (stopwatch.Elapsed.TotalSeconds < 5.0)
				{
					cancellation.Token.ThrowIfCancellationRequested();
					Stopwatch stopwatch3 = Stopwatch.StartNew();
					TimerLease.WaitHalfMillisecond();
					list.Add(stopwatch3.Elapsed.TotalMilliseconds);
				}
				list.Sort();
				return new double[4]
				{
					num,
					list.Average(),
					list[list.Count / 2],
					list[(int)((double)(list.Count - 1) * 0.95)]
				};
			}, cancellation.Token);
			if (!cancellation.IsCancellationRequested)
			{
				progress.Visibility = Visibility.Collapsed;
				label.Text = "Timer: " + array[0].ToString("0.000") + " ms";
				detail.Text = "Requested 0.5 ms waits over 5 seconds · mean " + array[1].ToString("0.000") + " ms · median " + array[2].ToString("0.000") + " ms · p95 " + array[3].ToString("0.000") + " ms\n" + ((array[0] <= 0.51) ? "A 0.5 ms wait ends on the second 0.5 ms tick, so about 1.0 ms is the expected result. " : (enabled ? "Windows is not applying 0.5 ms right now; the AZIZ timer service renews the request every second. " : "")) + (enabled ? "AZIZ request stays active until released or AZIZ exits." : "AZIZ request was released. Other applications may keep a lower resolution active.") + " Closing clears this report; test results are not saved.";
			}
		}
		catch (OperationCanceledException)
		{
		}
		catch (Exception ex3)
		{
			if (w.IsVisible)
			{
				detail.Text = ex3.Message;
			}
		}
		InvalidateViews();
		if (current == "Home")
		{
			RenderOverview();
		}
		else if (IsTweakPage(current))
		{
			RenderTweaks();
		}
	}

	private static ImageSource ToolImage(string id)
	{
		try
		{
			string text = System.IO.Path.Combine(Program.Root, "assets", "tools", id + ".png");
			if (!File.Exists(text))
			{
				return null;
			}
			BitmapImage bitmapImage = new BitmapImage();
			bitmapImage.BeginInit();
			bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
			bitmapImage.UriSource = new Uri(text);
			bitmapImage.EndInit();
			bitmapImage.Freeze();
			return bitmapImage;
		}
		catch
		{
			return null;
		}
	}

	private void RenderTools()
	{
		content.Children.Clear();
		AddReflexCard();
		AddDriverHeader();
		AddDebloatCard();
		AddAppDebloatCard();
		// Debloat Apps sits small on the right of Scan & Debloat, in one row.
		UIElement scanCard = content.Children[content.Children.Count - 2];
		UIElement appsCard = content.Children[content.Children.Count - 1];
		content.Children.Remove(scanCard);
		content.Children.Remove(appsCard);
		Grid debloatRow = new Grid
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 4.0)
		};
		// Same three columns as the driver cards above: Scan & Debloat under NVIDIA + BIOS, Debloat Apps under AMD.
		debloatRow.ColumnDefinitions.Add(new ColumnDefinition());
		debloatRow.ColumnDefinitions.Add(new ColumnDefinition());
		debloatRow.ColumnDefinitions.Add(new ColumnDefinition());
		Grid.SetColumnSpan(scanCard, 2);
		((FrameworkElement)scanCard).Margin = new Thickness(0.0, 0.0, 10.0, 0.0);
		((FrameworkElement)appsCard).Margin = new Thickness(0.0);
		((FrameworkElement)appsCard).VerticalAlignment = VerticalAlignment.Stretch;
		Grid.SetColumn(appsCard, 2);
		debloatRow.Children.Add(scanCard);
		debloatRow.Children.Add(appsCard);
		content.Children.Add(debloatRow);
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.Width = 300.0;
		textBox.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		textBox.Margin = new Thickness(0.0, 14.0, 0.0, 14.0);
		System.Windows.Controls.TextBox query = textBox;
		content.Children.Add(WithPlaceholder(query, "Find a tool…"));
		UniformGrid uniformGrid = new UniformGrid();
		uniformGrid.Columns = 3;
		UniformGrid grid = uniformGrid;
		content.Children.Add(grid);
		Action draw = delegate
		{
			grid.Children.Clear();
			foreach (DownloadItem item in from x in DownloadManager.Catalog()
				where x.Tool && !new string[4] { "gamepadla-polling", "nvcleanstall", "ntlite", "dismpp" }.Contains(x.Id) && (x.Name + " " + x.Description).IndexOf(query.Text, StringComparison.OrdinalIgnoreCase) >= 0
				orderby x.Name
				select x)
			{
				StackPanel stackPanel = Stack();
				LaunchEntry launchEntry = Installed(item);
				ImageSource imageSource = ((item.Id == "power-settings-explorer") ? ToolImage(item.Id) : null) ?? AppIcons.Load((launchEntry != null) ? launchEntry.Icon : ((!string.IsNullOrEmpty(item.BundledPath)) ? System.IO.Path.Combine(Program.Root, item.BundledPath) : null)) ?? ToolImage(item.Id);
				DockPanel dockPanel = new DockPanel();
				FrameworkElement frameworkElement;
				if (imageSource != null)
				{
					frameworkElement = new System.Windows.Controls.Image
					{
						Source = imageSource,
						Width = 34.0,
						Height = 34.0
					};
				}
				else
				{
					if (!ToolArt.TryGetValue(item.Id, out var value))
					{
						value = new string[2] { "\ue90f", "#475569" };
					}
					frameworkElement = ToolBadge(value[0], value[1], 34.0);
				}
				DockPanel.SetDock(frameworkElement, Dock.Left);
				dockPanel.Children.Add(frameworkElement);
				TextBlock textBlock = Label(item.Name, 14.0, Text);
				textBlock.FontWeight = FontWeights.SemiBold;
				textBlock.VerticalAlignment = VerticalAlignment.Center;
				textBlock.Margin = new Thickness(12.0, 0.0, 0.0, 0.0);
				textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
				textBlock.TextWrapping = TextWrapping.NoWrap;
				textBlock.ToolTip = item.Name;
				dockPanel.Children.Add(textBlock);
				stackPanel.Children.Add(dockPanel);
				TextBlock textBlock2 = Label(item.Description, 11.0, Muted);
				textBlock2.Margin = new Thickness(0.0, 9.0, 0.0, 0.0);
				textBlock2.Height = 46.0;
				textBlock2.TextTrimming = TextTrimming.CharacterEllipsis;
				textBlock2.ToolTip = item.Description;
				stackPanel.Children.Add(textBlock2);
				TextBlock status = Label("", 10.0, Muted);
				stackPanel.Children.Add(status);
				WrapPanel wrapPanel = new WrapPanel
				{
					Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
				};
				System.Windows.Controls.Button open = BrandBtn("Open", delegate
				{
				});
				open.Padding = new Thickness(14.0, 7.0, 14.0, 7.0);
				open.Background = BrandBrush();
				open.Foreground = System.Windows.Media.Brushes.White;
				open.IsEnabled = !openingTools.Contains(item.Id);
				open.Click += async delegate
				{
					await OpenTool(item, open, status);
				};
				wrapPanel.Children.Add(open);
				wrapPanel.Children.Add(Btn("Shortcut", async delegate
				{
					await CreateToolShortcut(item, status);
				}));
				if (item.Id == "hidusbf")
				{
					System.Windows.Controls.Button test = Btn("Test", delegate
					{
					});
					test.Click += async delegate
					{
						await OpenTool(DownloadManager.Catalog().First((DownloadItem x) => x.Id == "gamepadla-polling"), test, status);
					};
					wrapPanel.Children.Add(test);
				}
				if (item.Id == "cru")
				{
					wrapPanel.Children.Add(Btn("restart64", delegate
					{
						RestartCru();
					}));
				}
				stackPanel.Children.Add(wrapPanel);
				Border border = Card(stackPanel);
				border.Padding = new Thickness(16.0);
				border.Margin = new Thickness(0.0, 0.0, 10.0, 10.0);
				grid.Children.Add(border);
			}
		};
		query.TextChanged += delegate
		{
			draw();
		};
		draw();
	}

	private void AddDebloatCard()
	{
		DockPanel dockPanel = new DockPanel();
		// Opening only scans. Edge and WebView2 go with Remove selected (and with One Click), never on a mere look.
		System.Windows.Controls.Button button = BrandBtn("Scan & Debloat", delegate
		{
			ShowUltraLite();
		}, primary: true);
		button.VerticalAlignment = VerticalAlignment.Center;
		DockPanel.SetDock(button, Dock.Right);
		dockPanel.Children.Add(button);
		Border border = ToolBadge("\ue74d", "#7C3AED", 40.0);
		DockPanel.SetDock(border, Dock.Left);
		dockPanel.Children.Add(border);
		StackPanel stackPanel = Stack();
		stackPanel.Margin = new Thickness(14.0, 0.0, 14.0, 0.0);
		TextBlock textBlock = Label("Scan & Debloat", 17.0, Text);
		textBlock.FontWeight = FontWeights.SemiBold;
		stackPanel.Children.Add(textBlock);
		stackPanel.Children.Add(Label("Reads Windows and lists only what is still on this PC: apps, Xbox parts, services, tasks, features and privacy settings. Recommended selects the AZIZ debloat list. Also removes Microsoft Edge and WebView2 (listed in History).", 11.0, Muted));
		dockPanel.Children.Add(stackPanel);
		Border border2 = Card(dockPanel);
		border2.Padding = new Thickness(16.0);
		border2.Margin = new Thickness(0.0, 0.0, 0.0, 4.0);
		content.Children.Add(border2);
	}

	// Debloat apps: one switch per browser (Steam and Discord come next).
	// Debloat Apps: one compact card; the options open in a sheet.
	private void AddAppDebloatCard()
	{
		DockPanel dockPanel = new DockPanel();
		System.Windows.Controls.Button button = BrandBtn("Open", delegate
		{
			ShowSheet(delegate(StackPanel p, Action close)
			{
				FillAppDebloat(p);
				System.Windows.Controls.Button done = Btn("Done", close);
				done.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
				done.Margin = new Thickness(0.0, 12.0, 0.0, 0.0);
				p.Children.Add(done);
			}, 760.0);
		});
		button.VerticalAlignment = VerticalAlignment.Center;
		button.Padding = new Thickness(14.0, 6.0, 14.0, 6.0);
		DockPanel.SetDock(button, Dock.Right);
		dockPanel.Children.Add(button);
		StackPanel text = Stack();
		TextBlock title = Label("Debloat Apps", 14.0, Text);
		title.FontWeight = FontWeights.SemiBold;
		text.Children.Add(title);
		text.Children.Add(Label("Discord · Steam · Edge · Chrome · Brave", 11.0, Muted));
		dockPanel.Children.Add(text);
		Border border = Card(dockPanel);
		border.Padding = new Thickness(14.0, 10.0, 14.0, 10.0);
		border.Margin = new Thickness(0.0, 8.0, 0.0, 4.0);
		content.Children.Add(border);
	}

	private void FillAppDebloat(StackPanel p)
	{
		StackPanel stackPanel = Stack();
		TextBlock textBlock = Label("Debloat apps", 17.0, Text);
		textBlock.FontWeight = FontWeights.SemiBold;
		stackPanel.Children.Add(textBlock);
		stackPanel.Children.Add(Label("Browsers: telemetry, running in the background and hardware acceleration off (by policy, on the next browser start). Click again to undo.", 11.0, Muted));
		WrapPanel wrapPanel = new WrapPanel
		{
			Margin = new Thickness(0.0, 10.0, 0.0, 0.0)
		};
		TextBlock status = Label("", 11.0, Muted);
		foreach (string name in AppDebloat.Names.ToList())
		{
			System.Windows.Controls.Button button = Btn("", delegate
			{
			});
			Action paint = delegate
			{
				button.Content = (AppDebloat.Applied(name) ? ("✓ " + name + " debloated") : ("Debloat " + name));
			};
			paint();
			button.Margin = new Thickness(0.0, 0.0, 8.0, 6.0);
			button.Click += async delegate
			{
				if (preview)
				{
					return;
				}
				if (!Program.IsAdmin)
				{
					Elevate();
					return;
				}
				bool on = !AppDebloat.Applied(name);
				if (on)
				{
					await BackupFirst();
				}
				ActionResult actionResult = AppDebloat.Apply(name, on);
				Record("Debloat apps · " + name, on ? "Apply" : "Undo", "", actionResult.Success ? "Done" : "Failed", actionResult);
				status.Text = actionResult.Message;
				paint();
			};
			wrapPanel.Children.Add(button);
		}
		System.Windows.Controls.Button discord = null;
		discord = Btn("Debloat Discord", async delegate
		{
			if (preview || System.Windows.MessageBox.Show("Discord will close (a voice call ends) and reopen clean. Continue?", "Debloat Discord", MessageBoxButton.OKCancel) != MessageBoxResult.OK)
			{
				return;
			}
			discord.IsEnabled = false;
			status.Text = "Debloating Discord…";
			ActionResult actionResult = await Task.Run(() => AppDebloat.Discord());
			Record("Debloat apps · Discord", "Apply", "", actionResult.Success ? "Done" : "Failed", actionResult);
			status.Text = actionResult.Message;
			discord.IsEnabled = true;
		});
		discord.Margin = new Thickness(0.0, 0.0, 8.0, 6.0);
		wrapPanel.Children.Add(discord);
		System.Windows.Controls.Button steamGuide = Btn("Debloat Steam · step by step", ShowSteamGuide);
		steamGuide.Margin = new Thickness(0.0, 0.0, 8.0, 6.0);
		wrapPanel.Children.Add(steamGuide);
		stackPanel.Children.Add(wrapPanel);
		stackPanel.Children.Add(status);
		p.Children.Add(stackPanel);
	}

	// Steam settings guide: each step shows where the option is (a small drawing of Steam's settings) and what to set.
	private static readonly string[][] SteamSteps = new string[10][]
	{
		new string[4] { "Remote Play", "Enable Remote Play", "Off", "Stops the Remote Play service from running in the background." },
		new string[4] { "Voice", "Voice Transmission Threshold", "Off", "Scroll down in Voice." },
		new string[4] { "Voice", "Advanced: Echo cancellation · Noise cancellation · Automatic volume/gain control", "All three off", "Open Show advanced options at the bottom of Voice." },
		new string[4] { "Game Recording", "Recording", "Recording Off", "Steam's recorder runs in the background; Discord or the game's own capture is better." },
		new string[4] { "Accessibility", "Reduce motion", "On", "Fewer animations and effects in Steam." },
		new string[4] { "Library", "Low Bandwidth Mode · Low Performance Mode", "Both on", "Lighter library." },
		new string[4] { "Library", "Show community content", "Off", "No community content in the library." },
		new string[4] { "Interface", "Run Steam when my computer starts", "Off", "Steam starts only when you open it." },
		new string[4] { "Interface", "Notify me about additions or changes to my games", "Off", "No pop-ups about game changes." },
		new string[4] { "Music · Broadcast", "Music volume · Broadcasting", "Volume 0 · Broadcast Disabled", "Nothing plays or streams in the background." }
	};

	private FrameworkElement SteamShot(string section, string option, string value)
	{
		string[] sections = new string[9] { "Account", "Interface", "Library", "Game Recording", "Accessibility", "Voice", "Remote Play", "Broadcast", "Music" };
		Grid grid = new Grid
		{
			Width = 360.0,
			Height = 150.0
		};
		grid.ColumnDefinitions.Add(new ColumnDefinition
		{
			Width = new GridLength(118.0)
		});
		grid.ColumnDefinitions.Add(new ColumnDefinition());
		StackPanel side = new StackPanel
		{
			Background = B("#1B2838")
		};
		foreach (string text in sections)
		{
			bool on = section.Contains(text);
			side.Children.Add(new Border
			{
				Background = (on ? B("#3D6C99") : System.Windows.Media.Brushes.Transparent),
				Padding = new Thickness(8.0, 1.0, 4.0, 1.0),
				Child = new TextBlock
				{
					Text = text,
					FontSize = 10.0,
					Foreground = (on ? System.Windows.Media.Brushes.White : B("#8F98A0"))
				}
			});
		}
		grid.Children.Add(side);
		StackPanel main = new StackPanel
		{
			Background = B("#171D25"),
			Margin = new Thickness(0.0)
		};
		Grid.SetColumn(main, 1);
		main.Children.Add(new TextBlock
		{
			Text = section.ToUpperInvariant(),
			FontSize = 10.0,
			Foreground = B("#C7D5E0"),
			Margin = new Thickness(10.0, 8.0, 0.0, 6.0)
		});
		DockPanel row = new DockPanel
		{
			Margin = new Thickness(6.0, 4.0, 6.0, 0.0)
		};
		TextBlock state = new TextBlock
		{
			Text = value,
			FontSize = 10.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = B("#F5B728"),
			VerticalAlignment = VerticalAlignment.Center
		};
		DockPanel.SetDock(state, Dock.Right);
		row.Children.Add(state);
		row.Children.Add(new TextBlock
		{
			Text = option,
			FontSize = 10.0,
			Foreground = System.Windows.Media.Brushes.White,
			TextWrapping = TextWrapping.Wrap,
			Margin = new Thickness(0.0, 0.0, 8.0, 0.0)
		});
		main.Children.Add(new Border
		{
			BorderBrush = B("#F5B728"),
			BorderThickness = new Thickness(2.0),
			CornerRadius = new CornerRadius(4.0),
			Padding = new Thickness(6.0, 5.0, 6.0, 5.0),
			Margin = new Thickness(4.0, 0.0, 4.0, 0.0),
			Child = row
		});
		for (int i = 0; i < 3; i++)
		{
			main.Children.Add(new Border
			{
				Height = 6.0,
				Margin = new Thickness(12.0, 10.0, 40.0 + i * 20, 0.0),
				CornerRadius = new CornerRadius(3.0),
				Background = B("#2A3542")
			});
		}
		grid.Children.Add(main);
		return new Border
		{
			CornerRadius = new CornerRadius(8.0),
			ClipToBounds = true,
			BorderBrush = B("#2A3542"),
			BorderThickness = new Thickness(1.0),
			Child = grid
		};
	}

	private void ShowSteamGuide()
	{
		ShowSheet(delegate(StackPanel p, Action close)
		{
			TextBlock title = Label("Debloat Steam", 24.0, System.Windows.Media.Brushes.White);
			title.FontWeight = FontWeights.SemiBold;
			p.Children.Add(title);
			p.Children.Add(Label("Steam ▸ Settings. Each step shows the section on the left and the option to change (gold frame).", 12.0, Muted));
			System.Windows.Controls.Button open = Btn("Open Steam settings", delegate
			{
				try
				{
					Process.Start(new ProcessStartInfo("steam://open/settings")
					{
						UseShellExecute = true
					});
				}
				catch
				{
				}
			}, primary: true);
			open.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
			open.Margin = new Thickness(0.0, 10.0, 0.0, 12.0);
			p.Children.Add(open);
			int n = 1;
			foreach (string[] step in SteamSteps)
			{
				Grid row = new Grid
				{
					Margin = new Thickness(0.0, 0.0, 0.0, 12.0)
				};
				row.ColumnDefinitions.Add(new ColumnDefinition
				{
					Width = GridLength.Auto
				});
				row.ColumnDefinitions.Add(new ColumnDefinition());
				row.Children.Add(SteamShot(step[0], step[1], step[2]));
				StackPanel text = Stack();
				text.Margin = new Thickness(14.0, 4.0, 0.0, 0.0);
				Grid.SetColumn(text, 1);
				TextBlock head = Label(n++ + " · " + step[0], 14.0, System.Windows.Media.Brushes.White);
				head.FontWeight = FontWeights.SemiBold;
				text.Children.Add(head);
				text.Children.Add(Label(step[1] + " → " + step[2], 12.0, B("#F5B728")));
				text.Children.Add(Label(step[3], 11.0, Muted));
				row.Children.Add(text);
				p.Children.Add(row);
			}
			System.Windows.Controls.Button done = Btn("Done", close);
			done.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
			p.Children.Add(done);
		}, 900.0);
	}

	private void RunEdgeRemoval()
	{
		if (preview || !Program.IsAdmin)
		{
			return;
		}
		string dir = System.IO.Path.Combine(Program.Root, "Tools", "EdgeRemoval");
		string[] tools = new string[3] { "Remove-NoTerm.exe", "Remove-Edge.exe", "Remove-EdgeWeb.exe" };
		if (!tools.Any((string x) => File.Exists(System.IO.Path.Combine(dir, x))))
		{
			return;
		}
		Task.Run(delegate
		{
			List<string> list = new List<string>();
			string[] array = tools;
			foreach (string text in array)
			{
				string text2 = System.IO.Path.Combine(dir, text);
				if (File.Exists(text2))
				{
					try
					{
						using (Process process = Process.Start(new ProcessStartInfo(text2, "/s")
						{
							UseShellExecute = false,
							CreateNoWindow = true,
							WindowStyle = ProcessWindowStyle.Hidden,
							WorkingDirectory = dir
						}))
						{
							process?.WaitForExit(900000);
						}
						list.Add(text);
					}
					catch
					{
					}
					for (int j = 0; j < 10; j++)
					{
						try
						{
							File.Delete(text2);
						}
						catch
						{
							Thread.Sleep(1000);
							continue;
						}
						break;
					}
				}
			}
			try
			{
				if (Directory.Exists(dir) && !Directory.EnumerateFileSystemEntries(dir).Any())
				{
					Directory.Delete(dir);
				}
			}
			catch
			{
			}
			if (list.Count > 0)
			{
				base.Dispatcher.BeginInvoke((Action)delegate
				{
					Record("Microsoft Edge", "Remove Edge and WebView2", "Installed", "Removed", new ActionResult
					{
						Success = true,
						Message = string.Join(", ", list)
					});
				});
			}
		});
	}

	private async Task CreateToolShortcut(DownloadItem item, TextBlock status)
	{
		if (preview)
		{
			return;
		}
		try
		{
			LaunchEntry launchEntry = Installed(item);
			if (launchEntry == null)
			{
				string text;
				if (!string.IsNullOrEmpty(item.BundledPath))
				{
					text = System.IO.Path.GetFullPath(System.IO.Path.Combine(Program.Root, item.BundledPath));
					if (!DownloadLibrary.Within(text, Program.Root))
					{
						throw new IOException("Invalid bundled tool path.");
					}
					DownloadLibrary.NoLinks(text);
					if (!File.Exists(text) || Utilities.Sha256File(text) != item.Sha256)
					{
						throw new IOException("Extract a fresh complete AZIZ package.");
					}
				}
				else
				{
					DownloadJob job = downloads.LastOrDefault((DownloadJob x) => x.Item.Id == item.Id && x.State == "Completed" && File.Exists(x.FilePath));
					if (job == null)
					{
						throw new IOException("Open this tool once to download it before creating a shortcut.");
					}
					text = await Task.Run(() => DownloadLibrary.Prepare(job));
				}
				launchEntry = AppLauncher.Portable(new DownloadJob
				{
					Item = item
				}, text);
			}
			AppLauncher.Shortcut(launchEntry);
			status.Text = "Desktop shortcut created";
		}
		catch (Exception ex)
		{
			Say(ex.Message, item.Name);
		}
	}

	private async Task OpenTool(DownloadItem item, System.Windows.Controls.Button button, TextBlock status)
	{
		if (preview || openingTools.Contains(item.Id))
		{
			return;
		}
		openingTools.Add(item.Id);
		button.IsEnabled = false;
		try
		{
			if (item.Id == "rweverything")
			{
				ToolCompatibility.CheckRw();
			}
			LaunchEntry launchEntry = ((item.Id == "gamepadla-polling" || item.Id == "rweverything") ? null : Installed(item));
			if (launchEntry != null)
			{
				AppLauncher.Open(launchEntry);
				return;
			}
			string target;
			if (!string.IsNullOrEmpty(item.BundledPath))
			{
				target = System.IO.Path.GetFullPath(System.IO.Path.Combine(Program.Root, item.BundledPath));
				if (!DownloadLibrary.Within(target, Program.Root))
				{
					throw new IOException("Invalid bundled tool path");
				}
				DownloadLibrary.NoLinks(target);
				if (!File.Exists(target))
				{
					throw new FileNotFoundException("The bundled tool is missing. Extract the complete AZIZ package.");
				}
				if (Utilities.Sha256File(target) != item.Sha256)
				{
					throw new IOException("The bundled tool changed. Extract a fresh AZIZ copy.");
				}
			}
			else
			{
				DownloadJob job = downloads.LastOrDefault((DownloadJob x) => x.Item.Id == item.Id && x.State == "Completed" && File.Exists(x.FilePath));
				if (job == null)
				{
					if (downloads.Any((DownloadJob x) => x.Item.Id == item.Id && x.Running))
					{
						throw new InvalidOperationException("This tool is already being prepared in Downloads.");
					}
					job = new DownloadJob
					{
						Item = item
					};
					downloads.Add(job);
					await DownloadManager.Run(job, delegate
					{
						base.Dispatcher.BeginInvoke((Action)delegate
						{
							if (!closing)
							{
								status.Text = job.State + ((job.State == "Downloading") ? (" · " + ((job.Total > 0) ? (((double)job.Bytes * 100.0 / (double)job.Total.Value).ToString("0") + "% · ") : "") + (job.Speed / 1048576.0).ToString("0.0") + " MB/s") : "");
							}
						});
					});
					if (job.State != "Completed")
					{
						throw new IOException(job.Error ?? job.State);
					}
					DownloadLibrary.Remember(job);
				}
				status.Text = "Preparing portable files…";
				DownloadJob ready = job;
				Exception prepare = null;
				target = null;
				try
				{
					target = await Task.Run(() => DownloadLibrary.Prepare(ready));
				}
				catch (Exception ex)
				{
					prepare = ex;
				}
				if (prepare != null)
				{
					if (!(prepare is InvalidDataException) && prepare.Message.IndexOf("archive", StringComparison.OrdinalIgnoreCase) < 0)
					{
						throw prepare;
					}
					status.Text = "Re-downloading a clean copy…";
					DownloadJob fresh = new DownloadJob
					{
						Item = item
					};
					downloads.Add(fresh);
					await DownloadManager.Run(fresh, delegate
					{
					});
					if (fresh.State != "Completed")
					{
						throw new IOException(fresh.Error ?? fresh.State);
					}
					DownloadLibrary.Remember(fresh);
					target = await Task.Run(() => DownloadLibrary.Prepare(fresh));
				}
				if (!File.Exists(target))
				{
					throw new IOException("The publisher archive has no matching executable. Open its local folder from Downloads.");
				}
				if (!item.Portable)
				{
					string text = AppLauncher.FindInstalled(item);
					if (text == null)
					{
						status.Text = "Installing " + item.Name + "…";
						string setup = target;
						text = await Task.Run(delegate
						{
							InstallerRun.Run(setup);
							return AppLauncher.FindInstalled(item);
						});
					}
					if (text == null)
					{
						status.Text = "Finish the installer, then press Open again";
						return;
					}
					target = text;
				}
				LaunchEntry entry = AppLauncher.Portable(job, target);
				if (!item.Portable)
				{
					entry.Source = "Installed in Windows";
				}
				await Task.Run(delegate
				{
					AppLauncher.RememberManual(entry);
				});
				installedLaunchers.RemoveAll((LaunchEntry x) => x.CatalogId == item.Id);
				installedLaunchers.Add(entry);
			}
			if (!closing)
			{
				ToolCompatibility.CheckExecutable(target);
				status.Text = "Opening…";
				string arguments = ((item.Id == "brave") ? ("--user-data-dir=\"" + System.IO.Path.Combine(System.IO.Path.GetDirectoryName(target), "UserData") + "\"") : "");
				Process.Start(new ProcessStartInfo(target, arguments)
				{
					UseShellExecute = true,
					Verb = ((item.Id == "rweverything") ? "runas" : ""),
					WorkingDirectory = System.IO.Path.GetDirectoryName(target)
				});
				status.Text = "Ready locally · no shortcut created";
				viewCache.Remove("Downloads");
			}
		}
		catch (Exception ex2)
		{
			status.Text = "Could not open";
			Say(ex2.Message, item.Name);
		}
		finally
		{
			openingTools.Remove(item.Id);
			button.IsEnabled = true;
		}
	}

	private void ShowUltraLite()
	{
		if (preview)
		{
			return;
		}
		if (!Program.IsAdmin)
		{
			Say("Run AZIZ as administrator to read every installed app, service and feature.");
			return;
		}
		ShowSheet(delegate(StackPanel p, Action closeSheet)
		{
			TextBlock debloatKicker = Label("AZIZ · CLEAN WINDOWS", 11.0, B("#5FD3F3"));
			debloatKicker.FontWeight = FontWeights.SemiBold;
			p.Children.Add(debloatKicker);
			TextBlock debloatTitle = Label("Scan & Debloat", 26.0, System.Windows.Media.Brushes.White);
			debloatTitle.FontWeight = FontWeights.SemiBold;
			debloatTitle.FontFamily = new System.Windows.Media.FontFamily("Bahnschrift, Segoe UI");
			debloatTitle.Margin = new Thickness(0.0, 2.0, 0.0, 6.0);
			p.Children.Add(debloatTitle);
			p.Children.Add(Label("AZIZ reads this Windows installation and lists only what is really here, then removes it at the root: services (registry backup first), drivers, features with their files, capabilities, apps and policies. Protected parts run as SYSTEM. Nothing is pre-selected: tick items yourself or use Select recommended. Each item shows its result as soon as it finishes. What is already gone (removed by AZIZ, removed earlier, waiting for a restart, or never part of this Windows) is listed greyed out at the end. Scheduled tasks: use Task Scheduler for full manual control.", 12.0, Muted));
			WrapPanel wrapPanel = new WrapPanel
			{
				Margin = new Thickness(0.0, 14.0, 0.0, 8.0)
			};
			System.Windows.Controls.Button scan = Btn("Scan this PC", delegate
			{
			}, primary: true);
			System.Windows.Controls.Button recommended = Btn("Select recommended", delegate
			{
			});
			System.Windows.Controls.Button none = Btn("Clear selection", delegate
			{
			});
			System.Windows.Controls.Button apply = Btn("Remove selected", delegate
			{
			}, primary: true);
			System.Windows.Controls.Button button = recommended;
			System.Windows.Controls.Button button2 = none;
			bool flag2 = (apply.IsEnabled = false);
			bool flag3 = flag2;
			flag2 = (button2.IsEnabled = flag3);
			bool isEnabled = flag2;
			button.IsEnabled = isEnabled;
			wrapPanel.Children.Add(scan);
			wrapPanel.Children.Add(recommended);
			wrapPanel.Children.Add(none);
			wrapPanel.Children.Add(apply);
			wrapPanel.Children.Add(Btn("Task Scheduler (manual) ↗", delegate
			{
				try
				{
					Process.Start(new ProcessStartInfo("taskschd.msc")
					{
						UseShellExecute = true
					});
				}
				catch (Exception ex3)
				{
					Say(ex3.Message);
				}
			}));
			p.Children.Add(wrapPanel);
			TextBlock status = Label("Press Scan this PC.", 12.0, Cyan);
			p.Children.Add(status);
			StackPanel rows = Stack();
			p.Children.Add(rows);
			List<System.Windows.Controls.CheckBox> choices = new List<System.Windows.Controls.CheckBox>();
			Dictionary<string, Tuple<System.Windows.Controls.CheckBox, TextBlock>> rowViews = new Dictionary<string, Tuple<System.Windows.Controls.CheckBox, TextBlock>>();
			bool busy = false;
			Action<List<DebloatRow>> fill = delegate(List<DebloatRow> plan)
			{
				rows.Children.Clear();
				choices.Clear();
				rowViews.Clear();
				Action count = delegate
				{
					int num3 = choices.Count((System.Windows.Controls.CheckBox x) => x.IsChecked == true);
					apply.Content = ((num3 == 0) ? "Remove selected" : ("Remove " + num3 + " selected"));
					apply.IsEnabled = num3 > 0 && !busy;
				};
				foreach (IGrouping<string, DebloatRow> item in (from x in plan
					where x.Present
					group x by x.Group).OrderBy(delegate(IGrouping<string, DebloatRow> g)
				{
					int num2 = Array.IndexOf(DebloatGroups, g.Key);
					return (num2 < 0) ? 99 : num2;
				}))
				{
					TextBlock textBlock = Label(item.Key + " · " + item.Count(), 14.0, Purple);
					textBlock.Margin = new Thickness(0.0, 16.0, 0.0, 6.0);
					rows.Children.Add(textBlock);
					UniformGrid uniformGrid = new UniformGrid
					{
						Columns = 2
					};
					foreach (DebloatRow item2 in item.OrderBy((DebloatRow x) => x.Name))
					{
						StackPanel stackPanel = Stack();
						System.Windows.Controls.CheckBox checkBox2 = new System.Windows.Controls.CheckBox
						{
							Content = item2.Name,
							Tag = item2,
							IsChecked = false,
							Foreground = Text,
							Margin = new Thickness(0.0, 2.0, 0.0, 4.0)
						};
						checkBox2.Checked += delegate
						{
							count();
						};
						checkBox2.Unchecked += delegate
						{
							count();
						};
						stackPanel.Children.Add(checkBox2);
						TextBlock textBlock2 = Label(item2.Action + (item2.Recommended ? " · recommended" : "") + "\n" + item2.Detail, 10.0, Muted);
						textBlock2.Margin = new Thickness(27.0, 0.0, 0.0, 0.0);
						stackPanel.Children.Add(textBlock2);
						Border border = Card(stackPanel);
						border.Padding = new Thickness(12.0, 9.0, 12.0, 9.0);
						border.Margin = new Thickness(0.0, 0.0, 8.0, 6.0);
						uniformGrid.Children.Add(border);
						choices.Add(checkBox2);
						rowViews[item2.Id] = Tuple.Create(checkBox2, textBlock2);
					}
					rows.Children.Add(uniformGrid);
				}
				if (plan.Count((DebloatRow x) => x.Present) == 0)
				{
					rows.Children.Add(Label("Nothing left to remove on this PC.", 13.0, Muted));
				}
				List<DebloatRow> gone = plan.Where((DebloatRow x) => !x.Present).ToList();
				if (gone.Count > 0)
				{
					StackPanel more = Stack();
					more.Visibility = Visibility.Collapsed;
					System.Windows.Controls.Button toggle = Btn("Show unavailable · " + gone.Count, delegate
					{
					});
					toggle.Margin = new Thickness(0.0, 18.0, 0.0, 8.0);
					toggle.Click += delegate
					{
						bool flag21 = more.Visibility != Visibility.Visible;
						more.Visibility = (Visibility)((!flag21) ? 2u : 0u);
						toggle.Content = (flag21 ? "Hide unavailable · " : "Show unavailable · ") + gone.Count;
					};
					rows.Children.Add(toggle);
					foreach (IGrouping<string, DebloatRow> item3 in (from x in gone
						group x by x.Group).OrderBy(delegate(IGrouping<string, DebloatRow> g)
					{
						int num = Array.IndexOf(DebloatGroups, g.Key);
						return (num < 0) ? 99 : num;
					}))
					{
						TextBlock textBlock3 = Label(item3.Key + " · " + item3.Count(), 13.0, Muted);
						textBlock3.Margin = new Thickness(0.0, 12.0, 0.0, 6.0);
						more.Children.Add(textBlock3);
						UniformGrid uniformGrid2 = new UniformGrid
						{
							Columns = 2
						};
						foreach (DebloatRow item4 in item3.OrderBy((DebloatRow x) => x.Name))
						{
							StackPanel stackPanel2 = Stack();
							stackPanel2.Opacity = 0.5;
							System.Windows.Controls.CheckBox checkBox3 = new System.Windows.Controls.CheckBox
							{
								Content = item4.Name,
								IsChecked = false,
								IsEnabled = false,
								Foreground = Text,
								Margin = new Thickness(0.0, 2.0, 0.0, 4.0)
							};
							stackPanel2.Children.Add(checkBox3);
							TextBlock textBlock4 = Label(string.IsNullOrEmpty(item4.Reason) ? "Not on this PC" : item4.Reason, 10.0, Muted);
							textBlock4.Margin = new Thickness(27.0, 0.0, 0.0, 0.0);
							stackPanel2.Children.Add(textBlock4);
							Border border2 = Card(stackPanel2);
							border2.Padding = new Thickness(12.0, 8.0, 12.0, 8.0);
							border2.Margin = new Thickness(0.0, 0.0, 8.0, 6.0);
							uniformGrid2.Children.Add(border2);
						}
						more.Children.Add(uniformGrid2);
					}
					rows.Children.Add(more);
				}
				System.Windows.Controls.Button button9 = recommended;
				bool flag20 = (none.IsEnabled = choices.Count > 0);
				bool isEnabled4 = flag20;
				button9.IsEnabled = isEnabled4;
				count();
				status.Text = plan.Count((DebloatRow x) => x.Present) + " items found on this PC · " + gone.Count + " already gone";
			};
			Func<Task> runScan = async delegate
			{
				busy = true;
				System.Windows.Controls.Button button6 = scan;
				System.Windows.Controls.Button button7 = recommended;
				System.Windows.Controls.Button button8 = none;
				bool flag14 = (apply.IsEnabled = false);
				bool flag15 = flag14;
				flag14 = (button8.IsEnabled = flag15);
				bool flag17 = flag14;
				flag14 = (button7.IsEnabled = flag17);
				bool isEnabled3 = flag14;
				button6.IsEnabled = isEnabled3;
				Stopwatch watch = Stopwatch.StartNew();
				DispatcherTimer tick = new DispatcherTimer
				{
					Interval = TimeSpan.FromSeconds(1.0)
				};
				tick.Tick += delegate
				{
					status.Text = "Reading apps, protected apps, services, tasks, privacy settings and Windows features… " + (int)watch.Elapsed.TotalSeconds + " s";
				};
				tick.Start();
				try
				{
					List<DebloatRow> obj5 = await Task.Run(() => UltraLite.Plan());
					fill(obj5);
				}
				catch (Exception ex2)
				{
					status.Text = "Scan failed: " + ex2.Message;
				}
				finally
				{
					tick.Stop();
					busy = false;
					scan.IsEnabled = true;
				}
			};
			scan.Click += async delegate
			{
				if (!busy)
				{
					await runScan();
				}
			};
			recommended.Click += delegate
			{
				foreach (System.Windows.Controls.CheckBox item5 in choices)
				{
					DebloatRow debloatRow = (DebloatRow)item5.Tag;
					// Xbox and Microsoft Store are never removed by Optimize; they are part of the manual Recommended selection here.
					item5.IsChecked = debloatRow.Recommended || debloatRow.Group == "Xbox & gaming" || (debloatRow.Name ?? "").IndexOf("Store", StringComparison.OrdinalIgnoreCase) >= 0 || (debloatRow.Name ?? "").IndexOf("Xbox", StringComparison.OrdinalIgnoreCase) >= 0;
				}
			};
			none.Click += delegate
			{
				foreach (System.Windows.Controls.CheckBox item6 in choices)
				{
					item6.IsChecked = false;
				}
			};
			apply.Click += async delegate
			{
				if (!busy)
				{
					List<DebloatRow> selected = (from x in choices
						where x.IsChecked == true
						select (DebloatRow)x.Tag).ToList();
					if (selected.Count != 0 && System.Windows.MessageBox.Show("Remove or disable these " + selected.Count + " items?\n\n" + string.Join("\n", from x in selected.Take(25)
						select "• " + x.Name) + ((selected.Count > 25) ? "\n…" : "") + "\n\nApps can be reinstalled from Downloads > Windows apps. Some changes finish after a restart.", "Deep Debloat", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
					{
						busy = true;
						System.Windows.Controls.Button button3 = scan;
						System.Windows.Controls.Button button4 = recommended;
						System.Windows.Controls.Button button5 = none;
						bool flag6 = (apply.IsEnabled = false);
						bool flag7 = flag6;
						flag6 = (button5.IsEnabled = flag7);
						bool flag9 = flag6;
						flag6 = (button4.IsEnabled = flag9);
						bool isEnabled2 = flag6;
						button3.IsEnabled = isEnabled2;
						string text = System.IO.Path.Combine(Program.Data, "UltraLite", DateTime.Now.ToString("yyyyMMdd-HHmmss"));
						Directory.CreateDirectory(text);
						Utilities.AtomicWrite(System.IO.Path.Combine(text, "reviewed-plan.json"), Program.Json.Serialize(selected));
						status.Text = "Removing " + selected.Count + " items in the background…";
						int failed = 0;
						string reportFile = System.IO.Path.Combine(text, "results.json");
						HashSet<string> shown = new HashSet<string>();
						Action<List<Dictionary<string, object>>> showResults = delegate(List<Dictionary<string, object>> list)
						{
							foreach (Dictionary<string, object> item7 in list)
							{
								string text2 = Convert.ToString(item7["Id"]);
								if (shown.Add(text2) && rowViews.TryGetValue(text2, out var value))
								{
									bool flag12 = Convert.ToBoolean(item7["Success"]);
									value.Item1.IsChecked = false;
									value.Item1.IsEnabled = false;
									value.Item2.Text = (flag12 ? "✓ Removed · " : "✗ Kept by Windows · ") + Convert.ToString(item7["Result"]);
									value.Item2.Foreground = (flag12 ? Green : B("#F59E0B"));
								}
							}
							status.Text = "Removing… " + shown.Count + " of " + selected.Count + " done";
						};
						DispatcherTimer progress = new DispatcherTimer
						{
							Interval = TimeSpan.FromSeconds(1.0)
						};
						progress.Tick += delegate
						{
							try
							{
								if (File.Exists(reportFile))
								{
									showResults(Program.Json.Deserialize<List<Dictionary<string, object>>>(File.ReadAllText(reportFile)) ?? new List<Dictionary<string, object>>());
								}
							}
							catch
							{
							}
						};
						progress.Start();
						try
						{
							string input;
							try
							{
								await BackupFirst();
								input = await Task.Run(() => UltraLite.Run("Apply", selected.Select((DebloatRow x) => x.Id), reportFile));
								RunEdgeRemoval();
							}
							finally
							{
								progress.Stop();
							}
							try
							{
								showResults(Program.Json.Deserialize<List<Dictionary<string, object>>>(input) ?? new List<Dictionary<string, object>>());
							}
							catch
							{
							}
							List<Dictionary<string, object>> obj2 = Program.Json.Deserialize<List<Dictionary<string, object>>>(input) ?? new List<Dictionary<string, object>>();
							List<string> list2 = new List<string>();
							foreach (Dictionary<string, object> item8 in obj2)
							{
								bool flag11 = Convert.ToBoolean(item8["Success"]);
								if (!flag11)
								{
									failed++;
								}
								else
								{
									list2.Add(Convert.ToString(item8["Id"]));
								}
								Record(Convert.ToString(item8["Name"]), "Deep Debloat", "Present", flag11 ? "Removed" : "Kept", new ActionResult
								{
									Success = flag11,
									Message = Convert.ToString(item8["Result"])
								});
							}
							try
							{
								UltraLite.Remember(list2);
							}
							catch
							{
							}
						}
						catch (Exception ex)
						{
							status.Text = "Incomplete: " + ex.Message;
							failed++;
						}
						busy = false;
						string summary = selected.Count - failed + " removed · " + failed + " kept by Windows (see History)";
						status.Text = summary + " · refreshing the list from Windows…";
						await runScan();
						status.Text = summary + " · list refreshed from Windows. Items that finish after a restart are listed under unavailable.";
					}
				}
			};
			runScan();
		}, 1060.0);
	}

	private async void RenderUninstaller()
	{
		_003C_003Ec__DisplayClass713 CS_0024_003C_003E8__locals0 = new _003C_003Ec__DisplayClass713();
		CS_0024_003C_003E8__locals0._003C_003E4__this = this;
		if (current != "Uninstaller")
		{
			return;
		}
		content.Children.Clear();
		if (cachedDesktop == null || cachedStore == null)
		{
			content.Children.Add(Label("Reading installed applications…", 15.0, Muted));
			await RefreshInventory();
			if (current != "Uninstaller" || closing)
			{
				return;
			}
			content.Children.Clear();
		}
		CS_0024_003C_003E8__locals0.desktop = cachedDesktop ?? new List<DesktopApp>();
		List<InstalledApp> list = cachedStore ?? new List<InstalledApp>();
		CS_0024_003C_003E8__locals0.selectedDesktop = new HashSet<DesktopApp>();
		CS_0024_003C_003E8__locals0.selectedStore = new HashSet<InstalledApp>();
		CS_0024_003C_003E8__locals0.checks = new List<System.Windows.Controls.CheckBox>();
		DockPanel dockPanel = new DockPanel
		{
			Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
		};
		CS_0024_003C_003E8__locals0.remove = Btn("Uninstall selected", async delegate
		{
			_003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass717 _003C_003Ec__DisplayClass3 = new _003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass717();
			_003C_003Ec__DisplayClass3.CS_0024_003C_003E8__locals714 = CS_0024_003C_003E8__locals0;
			if (!CS_0024_003C_003E8__locals0._003C_003E4__this.preview && !CS_0024_003C_003E8__locals0._003C_003E4__this.applying)
			{
				List<string> names = CS_0024_003C_003E8__locals0.selectedDesktop.Select((DesktopApp x) => x.Name).Concat(CS_0024_003C_003E8__locals0.selectedStore.Select((InstalledApp x) => FriendlyApp(x.Name))).ToList();
				if (names.Count != 0)
				{
					_003C_003Ec__DisplayClass3.mode = CS_0024_003C_003E8__locals0._003C_003E4__this.ReviewUninstall(names);
					if (_003C_003Ec__DisplayClass3.mode != 0)
					{
						if (_003C_003Ec__DisplayClass3.mode != 2 || Program.IsAdmin)
						{
							CS_0024_003C_003E8__locals0._003C_003E4__this.applying = true;
							int failures = 0;
							try
							{
								InstalledApp[] array = CS_0024_003C_003E8__locals0.selectedStore.ToArray();
								for (int i = 0; i < array.Length; i++)
								{
									_003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass717 _003C_003Ec__DisplayClass4 = _003C_003Ec__DisplayClass3;
									_ = CS_0024_003C_003E8__locals0;
									InstalledApp app3 = array[i];
									CS_0024_003C_003E8__locals0._003C_003E4__this.notice.Text = "Removing " + FriendlyApp(app3.Name);
									ActionResult actionResult = await Task.Run(() => (_003C_003Ec__DisplayClass4.mode == 2) ? PackageRemoval.Deep(app3) : Utilities.RemoveApp(app3));
									CS_0024_003C_003E8__locals0._003C_003E4__this.Record(FriendlyApp(app3.Name), (_003C_003Ec__DisplayClass3.mode == 2) ? "Deep uninstall" : "Uninstall", "Installed", actionResult.Success ? "Removed" : "Needs review", actionResult);
									if (!actionResult.Success)
									{
										failures++;
										Say(actionResult.Message, "Removal result");
									}
								}
								int num3 = 0;
								DesktopApp[] array2 = null;
								int num2 = 0;
								Func<ActionResult> func2 = null;
								_003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass71e _003C_003Ec__DisplayClass71e = null;
								_003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass721 _003C_003Ec__DisplayClass6 = null;
								Func<ActionResult> func3 = null;
								Func<string> func4 = null;
								_003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass721 _003C_003Ec__DisplayClass5;
								object obj;
								switch (num3)
								{
								default:
									array2 = CS_0024_003C_003E8__locals0.selectedDesktop.ToArray();
									num2 = 0;
									goto IL_05b9;
								case 1:
								{
									_003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass721 _003C_003Ec__DisplayClass7 = null;
									_003C_003Ec__DisplayClass5 = _003C_003Ec__DisplayClass7;
									goto IL_0756;
								}
								case 2:
								{
									ActionResult actionResult2 = await Task.Run(func2);
									CS_0024_003C_003E8__locals0._003C_003E4__this.Record(_003C_003Ec__DisplayClass71e.app.Name, "Vendor uninstall", "Installed", actionResult2.Success ? "Removed" : "Needs review", actionResult2);
									if (!actionResult2.Success)
									{
										failures++;
										Say(actionResult2.Message, "Removal result");
									}
									else if (_003C_003Ec__DisplayClass3.mode == 2 && _003C_003Ec__DisplayClass6.path != null && Directory.Exists(_003C_003Ec__DisplayClass6.path) && System.Windows.MessageBox.Show("The vendor uninstaller left this folder:\n\n" + _003C_003Ec__DisplayClass6.path + "\n\nRemove its remaining files? Any saved app settings inside this exact folder will also be removed.", "Review residual folder", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
									{
										if (func3 == null)
										{
											func3 = _003C_003Ec__DisplayClass6._003CRenderUninstaller_003Eb__708;
										}
										goto case 3;
									}
									goto IL_07c7;
								}
								case 3:
									{
										ActionResult actionResult3 = await Task.Run(func3);
										CS_0024_003C_003E8__locals0._003C_003E4__this.Record(_003C_003Ec__DisplayClass71e.app.Name, "Residual cleanup", _003C_003Ec__DisplayClass6.path, actionResult3.Success ? "Removed" : "Preserved", actionResult3);
										if (!actionResult3.Success)
										{
											failures++;
											Say(actionResult3.Message);
										}
										goto IL_07c7;
									}
									IL_05b9:
									if (num2 >= array2.Length)
									{
										await CS_0024_003C_003E8__locals0._003C_003E4__this.RefreshInventory();
										break;
									}
									func4 = null;
									func2 = null;
									_003C_003Ec__DisplayClass71e = new _003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass71e();
									_003C_003Ec__DisplayClass71e.CS_0024_003C_003E8__locals718 = _003C_003Ec__DisplayClass3;
									_003C_003Ec__DisplayClass71e.CS_0024_003C_003E8__locals714 = CS_0024_003C_003E8__locals0;
									_003C_003Ec__DisplayClass71e.app = array2[num2];
									func3 = null;
									_003C_003Ec__DisplayClass6 = new _003C_003Ec__DisplayClass713._003C_003Ec__DisplayClass721();
									_003C_003Ec__DisplayClass6.CS_0024_003C_003E8__locals71f = _003C_003Ec__DisplayClass71e;
									_003C_003Ec__DisplayClass6.CS_0024_003C_003E8__locals718 = _003C_003Ec__DisplayClass3;
									_003C_003Ec__DisplayClass6.CS_0024_003C_003E8__locals714 = CS_0024_003C_003E8__locals0;
									_003C_003Ec__DisplayClass5 = _003C_003Ec__DisplayClass6;
									if (_003C_003Ec__DisplayClass3.mode == 2)
									{
										if (func4 == null)
										{
											func4 = _003C_003Ec__DisplayClass71e._003CRenderUninstaller_003Eb__706;
										}
										goto IL_0756;
									}
									obj = null;
									goto IL_075f;
									IL_075f:
									_003C_003Ec__DisplayClass5.path = (string)obj;
									CS_0024_003C_003E8__locals0._003C_003E4__this.notice.Text = "Opening uninstaller: " + _003C_003Ec__DisplayClass71e.app.Name;
									if (func2 == null)
									{
										func2 = _003C_003Ec__DisplayClass71e._003CRenderUninstaller_003Eb__707;
									}
									goto case 2;
									IL_07c7:
									num2++;
									goto IL_05b9;
									IL_0756:
									obj = await Task.Run(func4);
									goto IL_075f;
								}
								return;
							}
							finally
							{
								CS_0024_003C_003E8__locals0._003C_003E4__this.applying = false;
								CS_0024_003C_003E8__locals0._003C_003E4__this.notice.Text = names.Count + " requested · " + failures + " need review. Results saved in Home history.";
								if (CS_0024_003C_003E8__locals0._003C_003E4__this.current == "Uninstaller")
								{
									CS_0024_003C_003E8__locals0._003C_003E4__this.RenderUninstaller();
								}
								else
								{
									CS_0024_003C_003E8__locals0._003C_003E4__this.viewCache.Remove("Uninstaller");
								}
							}
						}
						CS_0024_003C_003E8__locals0._003C_003E4__this.Elevate();
					}
				}
			}
		}, primary: true);
		DockPanel.SetDock(CS_0024_003C_003E8__locals0.remove, Dock.Right);
		dockPanel.Children.Add(CS_0024_003C_003E8__locals0.remove);
		CS_0024_003C_003E8__locals0.count = Label("0 selected", 11.0, Muted);
		CS_0024_003C_003E8__locals0.count.Margin = new Thickness(14.0, 0.0, 12.0, 0.0);
		CS_0024_003C_003E8__locals0.count.VerticalAlignment = VerticalAlignment.Center;
		DockPanel.SetDock(CS_0024_003C_003E8__locals0.count, Dock.Right);
		dockPanel.Children.Add(CS_0024_003C_003E8__locals0.count);
		System.Windows.Controls.CheckBox checkBox = new System.Windows.Controls.CheckBox
		{
			Content = "Select all",
			Foreground = Text,
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(16.0, 0.0, 12.0, 0.0)
		};
		DockPanel.SetDock(checkBox, Dock.Right);
		dockPanel.Children.Add(checkBox);
		checkBox.Checked += delegate
		{
			foreach (System.Windows.Controls.CheckBox item in CS_0024_003C_003E8__locals0.checks.Where((System.Windows.Controls.CheckBox c) => c.IsVisible))
			{
				item.IsChecked = true;
			}
		};
		checkBox.Unchecked += delegate
		{
			foreach (System.Windows.Controls.CheckBox check in CS_0024_003C_003E8__locals0.checks)
			{
				check.IsChecked = false;
			}
		};
		System.Windows.Controls.TextBox textBox = new System.Windows.Controls.TextBox();
		textBox.ToolTip = "Search for an app";
		textBox.Width = 260.0;
		textBox.HorizontalAlignment = System.Windows.HorizontalAlignment.Left;
		CS_0024_003C_003E8__locals0.filter = textBox;
		dockPanel.Children.Add(WithPlaceholder(CS_0024_003C_003E8__locals0.filter, "Search for an app…"));
		content.Children.Add(dockPanel);
		CS_0024_003C_003E8__locals0.update = delegate
		{
			CS_0024_003C_003E8__locals0.count.Text = CS_0024_003C_003E8__locals0.selectedDesktop.Count + CS_0024_003C_003E8__locals0.selectedStore.Count + " selected";
			CS_0024_003C_003E8__locals0.remove.IsEnabled = CS_0024_003C_003E8__locals0.selectedDesktop.Count + CS_0024_003C_003E8__locals0.selectedStore.Count > 0;
		};
		CS_0024_003C_003E8__locals0.update();
		UniformGrid uniformGrid = new UniformGrid
		{
			Columns = 2
		};
		CS_0024_003C_003E8__locals0.cards = new List<Tuple<string, Border>>();
		using (List<DesktopApp>.Enumerator enumerator = CS_0024_003C_003E8__locals0.desktop.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				_003C_003Ec__DisplayClass713 _003C_003Ec__DisplayClass = CS_0024_003C_003E8__locals0;
				DesktopApp app2 = enumerator.Current;
				System.Windows.Controls.CheckBox checkBox2 = new System.Windows.Controls.CheckBox
				{
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(0.0)
				};
				RoutedEventHandler value = delegate
				{
					_003C_003Ec__DisplayClass.selectedDesktop.Add(app2);
					_003C_003Ec__DisplayClass.update();
				};
				checkBox2.Checked += value;
				checkBox2.Unchecked += delegate
				{
					_003C_003Ec__DisplayClass.selectedDesktop.Remove(app2);
					_003C_003Ec__DisplayClass.update();
				};
				CS_0024_003C_003E8__locals0.checks.Add(checkBox2);
				Border border = AppCard(app2.Name, app2.Publisher + (string.IsNullOrWhiteSpace(app2.Version) ? "" : (" · " + app2.Version)), checkBox2, app2.Icon);
				uniformGrid.Children.Add(border);
				CS_0024_003C_003E8__locals0.cards.Add(Tuple.Create(app2.Name, border));
			}
		}
		using (List<InstalledApp>.Enumerator enumerator2 = list.GetEnumerator())
		{
			while (enumerator2.MoveNext())
			{
				_003C_003Ec__DisplayClass713 _003C_003Ec__DisplayClass2 = CS_0024_003C_003E8__locals0;
				InstalledApp app = enumerator2.Current;
				System.Windows.Controls.CheckBox checkBox3 = new System.Windows.Controls.CheckBox
				{
					VerticalAlignment = VerticalAlignment.Center,
					Margin = new Thickness(0.0)
				};
				RoutedEventHandler value2 = delegate
				{
					_003C_003Ec__DisplayClass2.selectedStore.Add(app);
					_003C_003Ec__DisplayClass2.update();
				};
				checkBox3.Checked += value2;
				checkBox3.Unchecked += delegate
				{
					_003C_003Ec__DisplayClass2.selectedStore.Remove(app);
					_003C_003Ec__DisplayClass2.update();
				};
				CS_0024_003C_003E8__locals0.checks.Add(checkBox3);
				Border border2 = AppCard(FriendlyApp(app.Name), app.Publisher ?? "Microsoft Store", checkBox3, app.IconPath);
				uniformGrid.Children.Add(border2);
				CS_0024_003C_003E8__locals0.cards.Add(Tuple.Create(app.Name + " " + FriendlyApp(app.Name), border2));
			}
		}
		CS_0024_003C_003E8__locals0.filter.TextChanged += delegate
		{
			foreach (Tuple<string, Border> card in CS_0024_003C_003E8__locals0.cards)
			{
				card.Item2.Visibility = (Visibility)((card.Item1.IndexOf(CS_0024_003C_003E8__locals0.filter.Text, StringComparison.OrdinalIgnoreCase) < 0) ? 2u : 0u);
			}
		};
		content.Children.Add(Label(CS_0024_003C_003E8__locals0.desktop.Count + list.Count + " applications", 11.0, Muted));
		content.Children.Add(Spacer(10));
		content.Children.Add(uniformGrid);
		content.Children.Add(Btn("Refresh list", async delegate
		{
			await RefreshInventory();
			if (current == "Uninstaller")
			{
				RenderUninstaller();
			}
		}));
	}

	private int ReviewUninstall(List<string> names)
	{
		string text = ChooseSheet("UNINSTALL", names.Count + " app" + ((names.Count == 1) ? "" : "s") + " selected", string.Join(" · ", names.Take(12)) + ((names.Count > 12) ? (" · +" + (names.Count - 12) + " more") : ""), Tuple.Create("deep", "⟲", "Deep uninstall", "Removed for all users and from new accounts, with leftovers. Includes Store and Xbox apps when Windows allows.", true), Tuple.Create("simple", "–", "Simple uninstall", "Current-user Store removal or the app's own uninstaller.", true));
		if (text == "deep")
		{
			return 2;
		}
		return (text == "simple") ? 1 : 0;
	}

	// Two (or more) frameless violet choices over the blurred app; returns the chosen key, or null when closed.
	private string ChooseSheet(string kicker, string title, string about, params Tuple<string, string, string, string, bool>[] options)
	{
		string choice = null;
		ShowSheet(delegate(StackPanel panel, Action close)
		{
			TextBlock textBlock = Label(kicker, 11.0, B("#5FD3F3"));
			textBlock.FontWeight = FontWeights.SemiBold;
			textBlock.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			panel.Children.Add(textBlock);
			TextBlock textBlock2 = Label(title, 24.0, System.Windows.Media.Brushes.White);
			textBlock2.FontWeight = FontWeights.SemiBold;
			textBlock2.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock2.TextAlignment = TextAlignment.Center;
			textBlock2.Margin = new Thickness(0.0, 4.0, 0.0, 6.0);
			panel.Children.Add(textBlock2);
			if (!string.IsNullOrEmpty(about))
			{
				TextBlock textBlock3 = Label(about, 12.0, B("#B7AEE6"));
				textBlock3.TextAlignment = TextAlignment.Center;
				textBlock3.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
				textBlock3.MaxWidth = 640.0;
				panel.Children.Add(textBlock3);
			}
			WrapPanel wrapPanel = new WrapPanel
			{
				HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
				Margin = new Thickness(0.0, 22.0, 0.0, 6.0)
			};
			foreach (Tuple<string, string, string, string, bool> option in options)
			{
				StackPanel stackPanel = Stack();
				TextBlock textBlock4 = Label(option.Item2, 20.0, B("#C9BAFF"));
				textBlock4.Margin = new Thickness(0.0, 0.0, 0.0, 6.0);
				stackPanel.Children.Add(textBlock4);
				TextBlock textBlock5 = Label(option.Item3, 18.0, System.Windows.Media.Brushes.White);
				textBlock5.FontWeight = FontWeights.Bold;
				stackPanel.Children.Add(textBlock5);
				TextBlock textBlock6 = Label(option.Item4, 12.0, B("#B7AEE6"));
				textBlock6.Margin = new Thickness(0.0, 6.0, 0.0, 0.0);
				stackPanel.Children.Add(textBlock6);
				System.Windows.Media.Brush rest = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(44, 30, 104), System.Windows.Media.Color.FromRgb(22, 14, 56), 90.0);
				System.Windows.Media.Brush hot = new LinearGradientBrush(System.Windows.Media.Color.FromRgb(58, 40, 132), System.Windows.Media.Color.FromRgb(28, 18, 70), 90.0);
				Border card = new Border
				{
					Width = 270.0,
					Padding = new Thickness(22.0, 18.0, 22.0, 20.0),
					Margin = new Thickness(8.0, 0.0, 8.0, 8.0),
					CornerRadius = new CornerRadius(18.0),
					Background = rest,
					Cursor = (option.Item5 ? System.Windows.Input.Cursors.Hand : System.Windows.Input.Cursors.Arrow),
					Opacity = (option.Item5 ? 1.0 : 0.45),
					Child = stackPanel
				};
				card.MouseEnter += delegate
				{
					if (option.Item5)
					{
						card.Background = hot;
					}
				};
				card.MouseLeave += delegate
				{
					card.Background = rest;
				};
				card.MouseLeftButtonUp += delegate(object s, MouseButtonEventArgs e)
				{
					if (option.Item5)
					{
						e.Handled = true;
						choice = option.Item1;
						close();
					}
				};
				wrapPanel.Children.Add(card);
			}
			panel.Children.Add(wrapPanel);
			TextBlock textBlock7 = Label("Click outside to cancel", 11.0, Muted);
			textBlock7.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
			textBlock7.Margin = new Thickness(0.0, 8.0, 0.0, 0.0);
			panel.Children.Add(textBlock7);
		}, 720.0);
		return choice;
	}

	private Border AppCard(string title, string desc, System.Windows.Controls.CheckBox cb, string icon)
	{
		Grid obj = new Grid
		{
			Height = 44.0,
			ColumnDefinitions = 
			{
				new ColumnDefinition
				{
					Width = new GridLength(36.0)
				},
				new ColumnDefinition
				{
					Width = new GridLength(52.0)
				},
				new ColumnDefinition()
			},
			Children = { (UIElement)cb }
		};
		ImageSource imageSource = AppIcons.Load(icon);
		UIElement child = ((imageSource == null) ? ((UIElement)new TextBlock
		{
			Text = ((title.Length == 0) ? "□" : title.Substring(0, 1)),
			FontSize = 23.0,
			Foreground = Cyan,
			HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center
		}) : ((UIElement)new System.Windows.Controls.Image
		{
			Source = imageSource,
			Width = 34.0,
			Height = 34.0,
			Stretch = Stretch.Uniform
		}));
		Border border = new Border
		{
			Width = 40.0,
			Height = 40.0,
			CornerRadius = new CornerRadius(8.0),
			Background = B("#233149"),
			Child = child
		};
		Grid.SetColumn(border, 1);
		obj.Children.Add(border);
		StackPanel stackPanel = Stack();
		stackPanel.VerticalAlignment = VerticalAlignment.Center;
		TextBlock textBlock = Label(title, 13.0, Text);
		textBlock.TextWrapping = TextWrapping.NoWrap;
		textBlock.TextTrimming = TextTrimming.CharacterEllipsis;
		textBlock.ToolTip = title;
		stackPanel.Children.Add(textBlock);
		TextBlock textBlock2 = Label(desc, 10.0, Muted);
		textBlock2.Margin = new Thickness(0.0, 5.0, 0.0, 0.0);
		textBlock2.TextWrapping = TextWrapping.NoWrap;
		textBlock2.TextTrimming = TextTrimming.CharacterEllipsis;
		stackPanel.Children.Add(textBlock2);
		Grid.SetColumn(stackPanel, 2);
		obj.Children.Add(stackPanel);
		Border border2 = Card(obj);
		border2.Padding = new Thickness(14.0);
		border2.CornerRadius = new CornerRadius(9.0);
		border2.Margin = new Thickness(0.0, 0.0, 10.0, 8.0);
		return border2;
	}

	private static string FriendlyApp(string name)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>
		{
			{ "Microsoft.WindowsStore", "Microsoft Store" },
			{ "Microsoft.GamingApp", "Xbox" },
			{ "Microsoft.GamingServices", "Gaming Services" },
			{ "Microsoft.XboxGamingOverlay", "Xbox Game Bar" },
			{ "Microsoft.WindowsCalculator", "Calculator" },
			{ "Microsoft.Windows.Photos", "Photos" },
			{ "Microsoft.WindowsNotepad", "Notepad" },
			{ "Microsoft.ZuneMusic", "Media Player" },
			{ "Microsoft.OutlookForWindows", "Outlook" },
			{ "Microsoft.ScreenSketch", "Snipping Tool" },
			{ "Microsoft.StorePurchaseApp", "Store Purchase App" }
		};
		if (!dictionary.ContainsKey(name))
		{
			return name.Replace("Microsoft.", "");
		}
		return dictionary[name];
	}
}
