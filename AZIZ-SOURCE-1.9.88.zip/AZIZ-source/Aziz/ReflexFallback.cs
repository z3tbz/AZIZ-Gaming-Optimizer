using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using Microsoft.Win32;

namespace Aziz;

// Reflex Fallback: per-game NVIDIA Reflex frame limiter through RivaTuner Statistics Server (RTSS), driven from AZIZ.
// AZIZ writes the game's RTSS profile (Reflex limiter, after-frame-presentation markers, sleep 2, per frame), keeps RTSS
// running hidden from Windows start, and a small tray helper (--reflex-tray) changes the limit even with AZIZ closed.
internal static class ReflexFallback
{
	private const string RunKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";

	private static string ListFile => Path.Combine(Program.Data, "reflex-games.json");

	// Written only when AZIZ installed RivaTuner itself (for Reflex Fallback). When the user already had RivaTuner, this
	// file never exists, so AZIZ keeps their RivaTuner fully visible and never closes it.
	private static string OwnMarker => Path.Combine(Program.Data, "rtss-aziz-owned.on");

	public static bool AzizOwnsRtss => File.Exists(OwnMarker);

	private static void MarkOwned()
	{
		try
		{
			Directory.CreateDirectory(Program.Data);
			File.WriteAllText(OwnMarker, "1");
		}
		catch
		{
		}
	}

	private static int prefetchStarted;

	// Called once shortly after AZIZ starts: if RivaTuner is already on the PC it is left alone; if it is missing it is
	// downloaded and installed in the background, silently, so the first Reflex ON is instant. The app never waits for it.
	public static void Prefetch()
	{
		if (Interlocked.Exchange(ref prefetchStarted, 1) != 0)
		{
			return;
		}
		if (RtssFolder() != null)
		{
			return;
		}
		ThreadPool.QueueUserWorkItem(delegate
		{
			try
			{
				InstallRtss();
			}
			catch
			{
			}
		});
	}

	public static string TaskName => "AZIZ Reflex - " + WindowsIdentity.GetCurrent().User.Value;

	public static string RtssFolder()
	{
		foreach (RegistryView view in new RegistryView[2] { RegistryView.Registry32, RegistryView.Registry64 })
		{
			try
			{
				using RegistryKey registryKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, view).OpenSubKey("SOFTWARE\\Unwinder\\RTSS");
				string text = Convert.ToString(registryKey?.GetValue("InstallDir"));
				if (!string.IsNullOrEmpty(text) && File.Exists(Path.Combine(text, "RTSS.exe")))
				{
					return text;
				}
			}
			catch
			{
			}
		}
		string text2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "RivaTuner Statistics Server");
		return File.Exists(Path.Combine(text2, "RTSS.exe")) ? text2 : null;
	}

	// Games that already ship NVIDIA Reflex (Streamline / Reflex DLLs inside the game) do not need the fallback.
	// One walk of the game's own folder (Unreal games: the folder above <Project>\Binaries\Win64), five levels deep,
	// at most 3000 folders, never a drive root or a whole library.
	public static bool HasReflex(string exe)
	{
		try
		{
			string root = Path.GetDirectoryName(Path.GetFullPath(exe));
			string[] parts = root.Split('\\');
			int binaries = Array.FindLastIndex(parts, (string x) => x.Equals("Binaries", StringComparison.OrdinalIgnoreCase));
			if (binaries >= 2)
			{
				root = string.Join("\\", parts, 0, binaries - 1);
			}
			if (Path.GetPathRoot(root).TrimEnd('\\').Equals(root.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase))
			{
				root = Path.GetDirectoryName(exe);
			}
			Queue<Tuple<string, int>> queue = new Queue<Tuple<string, int>>();
			queue.Enqueue(Tuple.Create(root, 0));
			int visited = 0;
			while (queue.Count > 0 && visited++ < 3000)
			{
				Tuple<string, int> tuple = queue.Dequeue();
				try
				{
					foreach (string file in Directory.EnumerateFiles(tuple.Item1, "*.dll"))
					{
						string name = Path.GetFileName(file);
						if (name.Equals("sl.reflex.dll", StringComparison.OrdinalIgnoreCase) || name.Equals("sl.pcl.dll", StringComparison.OrdinalIgnoreCase) || name.Equals("NvLowLatencyVk.dll", StringComparison.OrdinalIgnoreCase) || name.StartsWith("GFSDK_Reflex", StringComparison.OrdinalIgnoreCase))
						{
							return true;
						}
					}
					if (tuple.Item2 < 5)
					{
						foreach (string dir in Directory.EnumerateDirectories(tuple.Item1))
						{
							if ((File.GetAttributes(dir) & FileAttributes.ReparsePoint) == 0)
							{
								queue.Enqueue(Tuple.Create(dir, tuple.Item2 + 1));
							}
						}
					}
				}
				catch
				{
				}
			}
		}
		catch
		{
		}
		return false;
	}

	public static Dictionary<string, int> Games()
	{
		try
		{
			return new Dictionary<string, int>(Program.Json.Deserialize<Dictionary<string, int>>(File.ReadAllText(ListFile)) ?? new Dictionary<string, int>(), StringComparer.OrdinalIgnoreCase);
		}
		catch
		{
			return new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		}
	}

	// AZIZ and the limiter by the clock both write this list: one writer at a time, never a half-written file.
	private static void Save(Dictionary<string, int> games)
	{
		Directory.CreateDirectory(Program.Data);
		using Mutex mutex = new Mutex(initiallyOwned: false, "Local\\AZIZ-ReflexList-" + WindowsIdentity.GetCurrent().User.Value);
		bool flag = false;
		try
		{
			try
			{
				flag = mutex.WaitOne(3000);
			}
			catch (AbandonedMutexException)
			{
				flag = true;
			}
			Utilities.AtomicWrite(ListFile, Program.Json.Serialize(games));
		}
		finally
		{
			if (flag)
			{
				mutex.ReleaseMutex();
			}
		}
	}

	// Uninstall: every game's Reflex profile goes (the user's own RTSS profiles come back).
	public static void RemoveAll()
	{
		Serialized(delegate
		{
			foreach (string item in Games().Keys.ToList())
			{
				RemoveNow(item, keepRunning: false);
			}
			return null;
		});
	}

	private static string Profile(string folder, string exe)
	{
		return Path.Combine(folder, "Profiles", Path.GetFileName(exe) + ".cfg");
	}

	// Same values as the hand-tuned profile: Reflex limiter (SyncLimiter 3), fallback on, low latency, sleep 2, per-frame sleep mode, latency markers.
	private static string ProfileText(int limit)
	{
		// RivaTuner never draws anything: EnableOSD/EnableStat stay off. The FPS counter is AZIZ's own overlay, not RTSS's.
		return ProfileBody(limit) + "[OSD]\r\nEnableOSD=0\r\nEnableStat=0\r\n";
	}

	private static string ProfileBody(int limit)
	{
		return "[Framerate]\r\nLimit=" + limit + "\r\nLimitDenominator=1\r\nLimitTime=0\r\nLimitTimeDenominator=1\r\nSyncLimiter=3\r\nPassiveWait=0\r\nReflexFallback=1\r\nReflexLowLatency=1\r\nReflexLowLatencyBoost=0\r\nReflexSetSleepModePerFrame=1\r\nReflexSleep=2\r\nReflexGetLatency=1\r\nReflexSetLatencyMarker=1\r\n[Hooking]\r\nEnableHooking=1\r\nHookDirect3D8=1\r\nHookDirect3D9=1\r\nHookDirect3DSwapChain9Present=1\r\nHookDXGI=1\r\nHookDirect3D12=1\r\nHookOpenGL=1\r\nHookVulkan=1\r\nInjectionDelay=15000\r\n";
	}

	public static ActionResult InstallRtss()
	{
		if (RtssFolder() != null)
		{
			// The user already has RivaTuner: use it as is, never hide or close it.
			return new ActionResult
			{
				Success = true,
				Message = "Reflex Fallback is ready."
			};
		}
		// Silent and hidden: winget first; if winget is missing or fails, the signed installer straight from Guru3D's mirror.
		// MSI Afterburner is closed for the install (its setup otherwise asks to restart it) and started again afterwards.
		string afterburner = CloseAfterburner();
		ActionResult actionResult = new ActionResult();
		try
		{
			actionResult = Utilities.Run("winget.exe", "install --id Guru3D.RTSS --exact --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity");
		}
		catch (Exception ex)
		{
			actionResult.Message = ex.Message;
		}
		// winget gives up after 90 s but its RivaTuner setup may still be running: let it finish before a second installer starts.
		for (int i = 0; i < 120 && RtssFolder() == null && Process.GetProcesses().Any(delegate(Process x)
		{
			using (x)
			{
				return x.ProcessName.StartsWith("RTSSSetup", StringComparison.OrdinalIgnoreCase) || x.ProcessName.Equals("winget", StringComparison.OrdinalIgnoreCase);
			}
		}); i++)
		{
			Thread.Sleep(1000);
		}
		if (RtssFolder() == null)
		{
			ActionResult actionResult2 = DirectInstall();
			if (!actionResult2.Success)
			{
				actionResult = actionResult2;
			}
		}
		if (RtssFolder() != null)
		{
			MarkOwned();
		}
		Conceal(wait: true);
		if (afterburner != null)
		{
			try
			{
				Process.Start(Utilities.Explorer, "\"" + afterburner + "\"");
			}
			catch
			{
			}
		}
		HideTrayIcon();
		if (RtssFolder() == null)
		{
			return new ActionResult
			{
				Message = "Reflex Fallback could not be prepared (no internet?). " + Utilities.Short(actionResult.Message)
			};
		}
		return new ActionResult
		{
			Success = true,
			Message = "Reflex Fallback is ready."
		};
	}

	private const string MirrorZip = "https://ftp.nluug.nl/pub/games/PC/guru3d/afterburner/[Guru3D]-RTSSSetup737Build28314.zip";

	private const string MirrorSha256 = "9B084A8CB3E53EC1A673894D0B66E22B16C9FD8785636B020B2D422F3F2A820E";

	private static ActionResult DirectInstall()
	{
		string text = SecureWork.NewFolder("rtss");
		try
		{
			Directory.CreateDirectory(text);
			string text2 = Path.Combine(text, "rtss.zip");
			System.Net.ServicePointManager.SecurityProtocol |= System.Net.SecurityProtocolType.Tls12;
			using (System.Net.WebClient webClient = new System.Net.WebClient())
			{
				webClient.Headers["User-Agent"] = "AZIZ-Gaming-Optimizer";
				webClient.DownloadFile(MirrorZip, text2);
			}
			using (System.Security.Cryptography.SHA256 sHA = System.Security.Cryptography.SHA256.Create())
			{
				using FileStream inputStream = File.OpenRead(text2);
				if (!BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").Equals(MirrorSha256, StringComparison.OrdinalIgnoreCase))
				{
					throw new InvalidDataException("The download did not match the expected file.");
				}
			}
			System.IO.Compression.ZipFile.ExtractToDirectory(text2, text);
			string text3 = Directory.GetFiles(text, "RTSSSetup*.exe", SearchOption.AllDirectories).FirstOrDefault();
			if (text3 == null)
			{
				throw new FileNotFoundException("Installer missing in the download.");
			}
			using (Process process = Process.Start(new ProcessStartInfo(text3, "/S")
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				WindowStyle = ProcessWindowStyle.Hidden
			}))
			{
				process.WaitForExit(180000);
			}
			return new ActionResult
			{
				Success = (RtssFolder() != null)
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
		finally
		{
			try
			{
				Directory.Delete(text, recursive: true);
			}
			catch
			{
			}
		}
	}

	// RTSS starts with Windows and lives only in the tray; restarting it reloads the profiles.
	public static void KeepRunning(bool restart)
	{
		string text = RtssFolder();
		if (text == null)
		{
			return;
		}
		string text2 = Path.Combine(text, "RTSS.exe");
		// Start RivaTuner with Windows only when it is AZIZ's own copy; a user's own RivaTuner keeps its own autostart.
		if (AzizOwnsRtss)
		{
			using RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(RunKey);
			registryKey.SetValue("RTSS", "\"" + text2 + "\"");
		}
		if (restart)
		{
			foreach (Process item in Process.GetProcessesByName("RTSS"))
			{
				try
				{
					item.Kill();
					item.WaitForExit(3000);
				}
				catch
				{
				}
			}
		}
		bool started = false;
		if (!RtssRunning())
		{
			Process.Start(new ProcessStartInfo(text2)
			{
				UseShellExecute = true,
				WorkingDirectory = text,
				WindowStyle = ProcessWindowStyle.Minimized
			});
			started = true;
		}
		Conceal(started);
		HideTrayIcon();
	}

	[DllImport("user32.dll")]
	private static extern bool ShowWindow(IntPtr hWnd, int cmd);

	private static bool RtssRunning()
	{
		Process[] processesByName = Process.GetProcessesByName("RTSS");
		foreach (Process process in processesByName)
		{
			process.Dispose();
		}
		return processesByName.Length != 0;
	}

	// Closes MSI Afterburner if it runs; returns its path to start it again.
	private static string CloseAfterburner()
	{
		string result = null;
		foreach (Process item in Process.GetProcessesByName("MSIAfterburner"))
		{
			using (item)
			{
				try
				{
					result = item.MainModule.FileName;
					item.Kill();
					item.WaitForExit(5000);
				}
				catch
				{
				}
			}
		}
		return result;
	}

	// Windows 11 keeps a setting per tray icon: RTSS is moved out of the taskbar corner into the hidden icons (^),
	// so only AZIZ's limiter icon shows.
	public static void HideTrayIcon()
	{
		// Only AZIZ's own RivaTuner is moved into the hidden-icons area; the user's own RivaTuner icon is left where it is.
		if (!AzizOwnsRtss)
		{
			return;
		}
		try
		{
			using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Control Panel\\NotifyIconSettings");
			if (registryKey == null)
			{
				return;
			}
			string[] subKeyNames = registryKey.GetSubKeyNames();
			foreach (string name in subKeyNames)
			{
				using RegistryKey registryKey2 = registryKey.OpenSubKey(name, writable: true);
				string text = Convert.ToString(registryKey2?.GetValue("ExecutablePath"));
				if (text.EndsWith("\\RTSS.exe", StringComparison.OrdinalIgnoreCase) || text.EndsWith("\\EncoderServer.exe", StringComparison.OrdinalIgnoreCase))
				{
					registryKey2.SetValue("IsPromoted", 0, RegistryValueKind.DWord);
				}
			}
		}
		catch
		{
		}
	}

	private delegate bool EnumProc(IntPtr hWnd, IntPtr lParam);

	[DllImport("user32.dll")]
	private static extern bool EnumWindows(EnumProc proc, IntPtr lParam);

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

	[DllImport("user32.dll")]
	private static extern bool IsWindowVisible(IntPtr hWnd);

	[DllImport("user32.dll", EntryPoint = "GetWindowLongW")]
	private static extern int GetWindowLong(IntPtr hWnd, int index);

	[DllImport("user32.dll", EntryPoint = "SetWindowLongW")]
	private static extern int SetWindowLong(IntPtr hWnd, int index, int value);

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct NotifyData
	{
		public int cbSize;

		public IntPtr hWnd;

		public int uID;

		public int uFlags;

		public int uCallbackMessage;

		public IntPtr hIcon;

		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
		public string szTip;

		public int dwState;

		public int dwStateMask;

		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
		public string szInfo;

		public int uVersion;

		[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
		public string szInfoTitle;

		public int dwInfoFlags;

		public Guid guidItem;

		public IntPtr hBalloonIcon;
	}

	[DllImport("shell32.dll", CharSet = CharSet.Unicode)]
	private static extern bool Shell_NotifyIcon(int message, ref NotifyData data);

	// RTSS windows whose tray icon is already gone (Explorer restarts make RTSS add it again, so this is checked again then).
	private static readonly Dictionary<IntPtr, int> removedIcons = new Dictionary<IntPtr, int>();

	// When each RTSS window was first searched for an icon, per taskbar: a window is searched during its first minute (RTSS
	// adds the icon a moment after its window) and then left alone until a new taskbar (Explorer restart), so the check
	// stays cheap while playing.
	private static readonly Dictionary<IntPtr, DateTime> probedWindows = new Dictionary<IntPtr, DateTime>();

	private static IntPtr probedTaskbar;

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern IntPtr FindWindow(string className, string windowName);

	// RTSS runs like a background service for AZIZ: it still starts with Windows, but has no window, no taskbar button
	// and no tray icon, so nobody changes its settings by accident and breaks Reflex Fallback. Safe to call often.
	public static void Conceal(bool wait = false)
	{
		// Hiding RivaTuner's window and tray icon is only for AZIZ's own copy; a user's own RivaTuner stays fully visible.
		if (!AzizOwnsRtss)
		{
			return;
		}
		for (int i = 0; i < (wait ? 24 : 1); i++)
		{
			if (ConcealOnce() && !wait)
			{
				return;
			}
			if (wait)
			{
				Thread.Sleep(250);
			}
		}
	}

	private static bool ConcealOnce()
	{
		HashSet<uint> pids = new HashSet<uint>();
		foreach (Process item in Process.GetProcessesByName("RTSS"))
		{
			using (item)
			{
				pids.Add((uint)item.Id);
			}
		}
		if (pids.Count == 0)
		{
			return false;
		}
		List<IntPtr> windows = new List<IntPtr>();
		EnumWindows(delegate(IntPtr h, IntPtr l)
		{
			if (GetWindowThreadProcessId(h, out var pid) != 0 && pids.Contains(pid))
			{
				windows.Add(h);
			}
			return true;
		}, IntPtr.Zero);
		bool removed = false;
		lock (removedIcons)
		{
			IntPtr taskbar = FindWindow("Shell_TrayWnd", null);
			if (taskbar != probedTaskbar)
			{
				probedTaskbar = taskbar;
				probedWindows.Clear();
				removedIcons.Clear();
			}
			foreach (IntPtr window in windows)
			{
				if (IsWindowVisible(window))
				{
					ShowWindow(window, 0);
				}
				// Tool window, not an app window: Windows never gives it a taskbar button, even if RTSS shows it again.
				int style = GetWindowLong(window, -20);
				int hidden = (style | 0x80) & ~0x40000;
				if (hidden != style)
				{
					SetWindowLong(window, -20, hidden);
				}
				NotifyData data = new NotifyData
				{
					cbSize = Marshal.SizeOf(typeof(NotifyData)),
					hWnd = window
				};
				if (removedIcons.TryGetValue(window, out var id))
				{
					data.uID = id;
					if (Shell_NotifyIcon(2, ref data))
					{
						removed = true;
					}
					continue;
				}
				if (!probedWindows.TryGetValue(window, out var seen))
				{
					probedWindows[window] = (seen = DateTime.UtcNow);
				}
				if ((DateTime.UtcNow - seen).TotalSeconds > 60.0)
				{
					continue;
				}
				for (int j = 0; j < 32; j++)
				{
					data.uID = j;
					if (Shell_NotifyIcon(2, ref data))
					{
						removedIcons[window] = j;
						removed = true;
					}
				}
			}
		}
		return removed || windows.Count > 0;
	}

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern IntPtr LoadLibrary(string path);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
	private static extern IntPtr GetProcAddress(IntPtr module, string name);

	// RTSSHooks: LoadProfile and SaveProfile return nothing (void); only SetProfileProperty reports success.
	[UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
	private delegate void ProfileCall(string profile);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl, CharSet = CharSet.Ansi)]
	private delegate bool SetProperty(string name, ref uint data, uint size);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate void UpdateCall();

	// Changes the limit while the game runs, the way MSI Afterburner does: RTSSHooks LoadProfile → SetProfileProperty("FramerateLimit")
	// → SaveProfile → UpdateProfiles. Running games pick it up at once; no restart of RTSS or the game.
	private static bool LiveLimit(string folder, string exe, int limit)
	{
		try
		{
			if (!RtssRunning())
			{
				return false;
			}
			IntPtr intPtr = LoadLibrary(Path.Combine(folder, Environment.Is64BitProcess ? "RTSSHooks64.dll" : "RTSSHooks.dll"));
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			IntPtr load = GetProcAddress(intPtr, "LoadProfile");
			IntPtr set = GetProcAddress(intPtr, "SetProfileProperty");
			IntPtr save = GetProcAddress(intPtr, "SaveProfile");
			IntPtr update = GetProcAddress(intPtr, "UpdateProfiles");
			if (load == IntPtr.Zero || set == IntPtr.Zero || save == IntPtr.Zero || update == IntPtr.Zero)
			{
				return false;
			}
			string name = Path.GetFileName(exe);
			uint data = (uint)limit;
			((ProfileCall)Marshal.GetDelegateForFunctionPointer(load, typeof(ProfileCall)))(name);
			if (!((SetProperty)Marshal.GetDelegateForFunctionPointer(set, typeof(SetProperty)))("FramerateLimit", ref data, 4u))
			{
				return false;
			}
			((ProfileCall)Marshal.GetDelegateForFunctionPointer(save, typeof(ProfileCall)))(name);
			((UpdateCall)Marshal.GetDelegateForFunctionPointer(update, typeof(UpdateCall)))();
			return true;
		}
		catch
		{
			return false;
		}
	}

	private static readonly object operationGate = new object();

	private static readonly Dictionary<string, long> latestRequest = new Dictionary<string, long>(StringComparer.OrdinalIgnoreCase);

	private static long requestSerial;

	// One Reflex change at a time across AZIZ and the limiter by the clock: the game list is read, the RTSS profile edited
	// and the list saved as one step, so two quick changes never lose a game or back up AZIZ's own profile as the user's.
	private static ActionResult Serialized(Func<ActionResult> body)
	{
		lock (operationGate)
		{
			using Mutex mutex = new Mutex(initiallyOwned: false, "Local\\AZIZ-ReflexOperation-" + WindowsIdentity.GetCurrent().User.Value);
			bool flag = false;
			try
			{
				try
				{
					flag = mutex.WaitOne(120000);
				}
				catch (AbandonedMutexException)
				{
					flag = true;
				}
				return body();
			}
			finally
			{
				if (flag)
				{
					mutex.ReleaseMutex();
				}
			}
		}
	}

	public static ActionResult Apply(string exe, int limit)
	{
		// Slider drags send many limits: only the newest one for a game is applied.
		long me;
		lock (latestRequest)
		{
			me = ++requestSerial;
			latestRequest[exe] = me;
		}
		return Serialized(delegate
		{
			lock (latestRequest)
			{
				if (latestRequest[exe] != me)
				{
					return new ActionResult
					{
						Success = true,
						Message = Path.GetFileNameWithoutExtension(exe) + ": NVIDIA Reflex on · updating the limit…"
					};
				}
			}
			return ApplyNow(exe, limit);
		});
	}

	public static ActionResult Remove(string exe)
	{
		return Serialized(() => RemoveNow(exe, keepRunning: true));
	}

	private static ActionResult ApplyNow(string exe, int limit)
	{
		try
		{
			ActionResult actionResult = InstallRtss();
			if (!actionResult.Success)
			{
				return actionResult;
			}
			string text = RtssFolder();
			// 0 = no FPS cap; Reflex low latency stays on.
			// 0 = no cap; anything else at least 20 FPS (a tiny drag near 0 never caps a game at a few frames).
			limit = ((limit <= 0) ? 0 : Math.Max(20, Math.Min(1000, limit)));
			Directory.CreateDirectory(Path.Combine(text, "Profiles"));
			bool known = File.Exists(Profile(text, exe));
			Dictionary<string, int> dictionary = Games();
			bool live = false;
			if (known && dictionary.ContainsKey(exe))
			{
				// The limit goes into the game's profile file itself, RTSS reloads its profiles, and the running game is
				// asked to take its profile again (without that, a hooked game keeps the limit it started with).
				string profile2 = Profile(text, exe);
				File.WriteAllText(profile2, SetIni(File.ReadAllText(profile2), "Framerate", "Limit", limit.ToString()));
				LiveLimit(text, exe, limit);
				Reload(text);
				live = RequestProfileUpdate(exe);
			}
			else
			{
				// First time for this game: keep the user's own RTSS profile aside (Off puts it back), write the whole
				// Reflex profile, then let RTSS reload it.
				string profile = Profile(text, exe);
				if (known && !dictionary.ContainsKey(exe) && !File.Exists(profile + ".aziz-backup") && File.ReadAllText(profile).IndexOf("ReflexFallback=1", StringComparison.OrdinalIgnoreCase) < 0)
				{
					File.Copy(profile, profile + ".aziz-backup");
				}
				File.WriteAllText(profile, ProfileText(limit));
				KeepRunning(restart: false);
				Reload(text);
				live = RequestProfileUpdate(exe);
			}
			dictionary[exe] = limit;
			Save(dictionary);
			return new ActionResult
			{
				Success = true,
				Message = Path.GetFileNameWithoutExtension(exe) + ": NVIDIA Reflex on · " + ((limit == 0) ? "no FPS cap" : (limit + " FPS")) + (live ? " · applied to the running game." : " · active from the next game start.")
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	private static ActionResult RemoveNow(string exe, bool keepRunning)
	{
		try
		{
			string text = RtssFolder();
			if (text != null)
			{
				string profile = Profile(text, exe);
				if (File.Exists(profile + ".aziz-backup"))
				{
					File.Copy(profile + ".aziz-backup", profile, overwrite: true);
					File.Delete(profile + ".aziz-backup");
				}
				else if (File.Exists(profile))
				{
					File.Delete(profile);
				}
			}
			Dictionary<string, int> dictionary = Games();
			dictionary.Remove(exe);
			Save(dictionary);
			if (dictionary.Count > 0)
			{
				if (keepRunning)
				{
					KeepRunning(restart: false);
				}
			}
			else
			{
				// No Reflex games left: the tray helper is not needed at sign-in any more.
				RemoveTray();
				// Only AZIZ's own RivaTuner is removed from startup and closed; a user's own RivaTuner is never touched.
				if (AzizOwnsRtss && Process.GetProcessesByName("MSIAfterburner").Length == 0)
				{
					try
					{
						using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(RunKey, writable: true);
						registryKey?.DeleteValue("RTSS", throwOnMissingValue: false);
					}
					catch
					{
					}
					foreach (Process item in Process.GetProcessesByName("RTSS"))
					{
						using (item)
						{
							try
							{
								item.Kill();
							}
							catch
							{
							}
						}
					}
				}
			}
			return new ActionResult
			{
				Success = true,
				Message = Path.GetFileNameWithoutExtension(exe) + ": Reflex fallback removed."
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	private static string Q(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	// Tray helper at sign-in (elevated, because RTSS profiles live under Program Files).
	public static ActionResult InstallTray()
	{
		try
		{
			AgentFiles.Deploy();
			string exe = AgentFiles.Exe;
			string value = WindowsIdentity.GetCurrent().User.Value;
			string script = "$action=New-ScheduledTaskAction -Execute " + Q(exe) + " -Argument '--reflex-tray'; $trigger=New-ScheduledTaskTrigger -AtLogOn -User " + Q(value) + "; $principal=New-ScheduledTaskPrincipal -UserId " + Q(value) + " -LogonType Interactive -RunLevel Highest; $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew; Register-ScheduledTask -TaskName " + Q(TaskName) + " -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null; Start-ScheduledTask -TaskName " + Q(TaskName) + "; 'Reflex tray on.'";
			return Utilities.Run("powershell.exe", GameWatch.PsArgs(script));
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	internal static string TrayExitEvent => "Local\\AZIZ-ReflexTray-Exit-" + WindowsIdentity.GetCurrent().User.Value;

	public static void RemoveTray()
	{
		try
		{
			Utilities.Run("schtasks.exe", "/Delete /TN \"" + TaskName + "\" /F");
		}
		catch
		{
		}
		try
		{
			using EventWaitHandle eventWaitHandle = EventWaitHandle.OpenExisting(TrayExitEvent);
			eventWaitHandle.Set();
		}
		catch
		{
		}
	}

	// ---- FPS counter (RTSS on-screen statistics) and live frame rate -------------------------------------------------
	// The counter is drawn inside the game's own frames, so the modern flip model (MPO, independent flip) is untouched.
	// It is never turned on for DirectX 11 games.

	private static string CounterFile => Path.Combine(Program.Data, "reflex-counter.on");

	private static string ApiFile => Path.Combine(Program.Data, "reflex-api.json");

	public static bool Counter => File.Exists(CounterFile);

	private const int ApiD3D11 = 7;

	private static Dictionary<string, int> Apis()
	{
		try
		{
			return Program.Json.Deserialize<Dictionary<string, int>>(File.ReadAllText(ApiFile)) ?? new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		}
		catch
		{
			return new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
		}
	}

	private static bool CounterFor(string exe)
	{
		return Counter && (!Apis().TryGetValue(Path.GetFileName(exe), out var value) || value != ApiD3D11);
	}

	internal static string CounterEvent => "Local\\AZIZ-ReflexCounter-" + WindowsIdentity.GetCurrent().User.Value;

	public static void SetCounter(bool on)
	{
		Directory.CreateDirectory(Program.Data);
		if (on)
		{
			File.WriteAllText(CounterFile, "1");
		}
		else if (File.Exists(CounterFile))
		{
			File.Delete(CounterFile);
		}
		SyncCounter();
		// Wake the AZIZ overlay (tray agent) so it shows/hides the counter at once.
		try
		{
			using EventWaitHandle eventWaitHandle = EventWaitHandle.OpenExisting(CounterEvent);
			eventWaitHandle.Set();
		}
		catch
		{
		}
		if (on)
		{
			KeepRunning(restart: false);
		}
	}

	// Makes sure RivaTuner's own on-screen display stays off in every Reflex game (AZIZ draws the counter itself).
	public static void SyncCounter()
	{
		string text = RtssFolder();
		if (text == null)
		{
			return;
		}
		bool changed = false;
		foreach (string key in Games().Keys)
		{
			string path = Profile(text, key);
			if (!File.Exists(path))
			{
				continue;
			}
			string text2 = File.ReadAllText(path);
			string text3 = SetIni(SetIni(text2, "OSD", "EnableOSD", "0"), "OSD", "EnableStat", "0");
			if (text3 != text2)
			{
				File.WriteAllText(path, text3);
				changed = true;
			}
		}
		if (changed)
		{
			Reload(text);
		}
	}

	private static string SetIni(string text, string section, string key, string value)
	{
		List<string> list = text.Replace("\r\n", "\n").Split('\n').ToList();
		int num = list.FindIndex((string l) => l.Trim().Equals("[" + section + "]", StringComparison.OrdinalIgnoreCase));
		if (num < 0)
		{
			while (list.Count > 0 && list[list.Count - 1].Length == 0)
			{
				list.RemoveAt(list.Count - 1);
			}
			list.Add("[" + section + "]");
			list.Add(key + "=" + value);
			list.Add("");
			return string.Join("\r\n", list);
		}
		int i;
		for (i = num + 1; i < list.Count && !list[i].TrimStart().StartsWith("["); i++)
		{
			if (list[i].StartsWith(key + "=", StringComparison.OrdinalIgnoreCase))
			{
				list[i] = key + "=" + value;
				return string.Join("\r\n", list);
			}
		}
		list.Insert(num + 1, key + "=" + value);
		return string.Join("\r\n", list);
	}

	private static void Reload(string folder)
	{
		try
		{
			IntPtr intPtr = LoadLibrary(Path.Combine(folder, Environment.Is64BitProcess ? "RTSSHooks64.dll" : "RTSSHooks.dll"));
			IntPtr intPtr2 = ((intPtr == IntPtr.Zero) ? IntPtr.Zero : GetProcAddress(intPtr, "UpdateProfiles"));
			if (intPtr2 != IntPtr.Zero)
			{
				((UpdateCall)Marshal.GetDelegateForFunctionPointer(intPtr2, typeof(UpdateCall)))();
			}
		}
		catch
		{
		}
	}

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern IntPtr OpenFileMapping(uint access, bool inherit, string name);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr MapViewOfFile(IntPtr mapping, uint access, uint high, uint low, UIntPtr bytes);

	[DllImport("kernel32.dll")]
	private static extern bool UnmapViewOfFile(IntPtr view);

	[DllImport("kernel32.dll")]
	private static extern bool CloseHandle(IntPtr handle);

	[StructLayout(LayoutKind.Sequential)]
	private struct MemoryInfo
	{
		public IntPtr BaseAddress;

		public IntPtr AllocationBase;

		public uint AllocationProtect;

		public IntPtr RegionSize;

		public uint State;

		public uint Protect;

		public uint Type;
	}

	[DllImport("kernel32.dll")]
	private static extern UIntPtr VirtualQuery(IntPtr address, out MemoryInfo info, UIntPtr length);

	// RTSS shared memory header, checked against the real size of the mapped view: a malformed block (any program can create
	// one while RTSS is not running) is ignored instead of crashing AZIZ.
	private static bool Layout(IntPtr view, out int entrySize, out int offset, out int count)
	{
		entrySize = (offset = (count = 0));
		if (view == IntPtr.Zero || VirtualQuery(view, out var info, (UIntPtr)(ulong)Marshal.SizeOf(typeof(MemoryInfo))) == UIntPtr.Zero)
		{
			return false;
		}
		long region = info.RegionSize.ToInt64();
		if (region < 32 || (uint)Marshal.ReadInt32(view, 0) != 0x52545353u || (uint)Marshal.ReadInt32(view, 4) < 0x20000u)
		{
			return false;
		}
		entrySize = Marshal.ReadInt32(view, 8);
		offset = Marshal.ReadInt32(view, 12);
		count = Math.Min(Marshal.ReadInt32(view, 16), 256);
		if (entrySize < 280 || offset < 20 || count < 0)
		{
			return false;
		}
		while (count > 0 && offset + (long)count * entrySize > region)
		{
			count--;
		}
		return true;
	}

	private static string EntryName(IntPtr view, int entry)
	{
		string text = Marshal.PtrToStringAnsi(IntPtr.Add(view, entry + 4), 260) ?? "";
		int num = text.IndexOf('\0');
		return Path.GetFileName((num >= 0) ? text.Substring(0, num) : text);
	}

	// Asks RTSS to re-apply the profile to a game that is already running (APPFLAG_PROFILE_UPDATE_REQUESTED on its entry in
	// RTSS shared memory). Returns true when the game is running and hooked.
	public static bool RequestProfileUpdate(string exe)
	{
		string fileName = Path.GetFileName(exe);
		bool result = false;
		IntPtr intPtr = OpenFileMapping(6u, inherit: false, "RTSSSharedMemoryV2");
		if (intPtr == IntPtr.Zero)
		{
			return false;
		}
		IntPtr intPtr2 = MapViewOfFile(intPtr, 6u, 0u, 0u, UIntPtr.Zero);
		try
		{
			if (!Layout(intPtr2, out var num, out var num2, out var num3))
			{
				return false;
			}
			for (int i = 0; i < num3; i++)
			{
				int num4 = num2 + i * num;
				if (Marshal.ReadInt32(intPtr2, num4) != 0 && string.Equals(EntryName(intPtr2, num4), fileName, StringComparison.OrdinalIgnoreCase))
				{
					int num5 = Marshal.ReadInt32(intPtr2, num4 + 264);
					Marshal.WriteInt32(intPtr2, num4 + 264, num5 | 0x10000000);
					result = true;
				}
			}
		}
		catch
		{
		}
		finally
		{
			if (intPtr2 != IntPtr.Zero)
			{
				UnmapViewOfFile(intPtr2);
			}
			CloseHandle(intPtr);
		}
		return result;
	}

	// Live frame rate per running game from RTSS shared memory (read only while the tray panel is open).
	// Key: exe file name. Also remembers each game's graphics API, so the counter can skip DirectX 11 games.
	// Light, no-side-effect FPS read for one process (the AZIZ overlay calls this ~5 times a second). Returns 0 when the
	// game is not being measured. RivaTuner provides the frame counters; it never draws anything itself.
	public static double FpsOf(string fileName)
	{
		if (string.IsNullOrEmpty(fileName))
		{
			return 0.0;
		}
		IntPtr mapping = OpenFileMapping(4u, inherit: false, "RTSSSharedMemoryV2");
		if (mapping == IntPtr.Zero)
		{
			return 0.0;
		}
		IntPtr view = MapViewOfFile(mapping, 4u, 0u, 0u, UIntPtr.Zero);
		double result = 0.0;
		try
		{
			if (view != IntPtr.Zero && Layout(view, out var entrySize, out var offset, out var count))
			{
				for (int i = 0; i < count; i++)
				{
					int entry = offset + i * entrySize;
					if (Marshal.ReadInt32(view, entry) == 0 || !string.Equals(EntryName(view, entry), fileName, StringComparison.OrdinalIgnoreCase))
					{
						continue;
					}
					uint t0 = (uint)Marshal.ReadInt32(view, entry + 268);
					uint t1 = (uint)Marshal.ReadInt32(view, entry + 272);
					uint frames = (uint)Marshal.ReadInt32(view, entry + 276);
					if (t0 != 0 && t1 > t0)
					{
						result = 1000.0 * frames / (t1 - t0);
					}
					break;
				}
			}
		}
		catch
		{
		}
		finally
		{
			if (view != IntPtr.Zero)
			{
				UnmapViewOfFile(view);
			}
			CloseHandle(mapping);
		}
		return result;
	}

	public static Dictionary<string, double> LiveFps()
	{
		Dictionary<string, double> dictionary = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
		IntPtr intPtr = OpenFileMapping(4u, inherit: false, "RTSSSharedMemoryV2");
		if (intPtr == IntPtr.Zero)
		{
			return dictionary;
		}
		IntPtr intPtr2 = MapViewOfFile(intPtr, 4u, 0u, 0u, UIntPtr.Zero);
		try
		{
			if (!Layout(intPtr2, out var num, out var num2, out var num3))
			{
				return dictionary;
			}
			Dictionary<string, int> apis = null;
			for (int i = 0; i < num3; i++)
			{
				int num4 = num2 + i * num;
				if (Marshal.ReadInt32(intPtr2, num4) == 0)
				{
					continue;
				}
				string fileName = EntryName(intPtr2, num4);
				int num5 = Marshal.ReadInt32(intPtr2, num4 + 264) & 0xFFFF;
				uint num6 = (uint)Marshal.ReadInt32(intPtr2, num4 + 268);
				uint num7 = (uint)Marshal.ReadInt32(intPtr2, num4 + 272);
				uint num8 = (uint)Marshal.ReadInt32(intPtr2, num4 + 276);
				if (string.IsNullOrEmpty(fileName))
				{
					continue;
				}
				if (num6 != 0 && num7 > num6)
				{
					dictionary[fileName] = 1000.0 * num8 / (num7 - num6);
				}
				if (num5 != 0)
				{
					apis = apis ?? Apis();
					if (!apis.TryGetValue(fileName, out var value) || value != num5)
					{
						apis[fileName] = num5;
						try
						{
							Directory.CreateDirectory(Program.Data);
							Utilities.AtomicWrite(ApiFile, Program.Json.Serialize(apis));
						}
						catch
						{
						}

					}
				}
			}
		}
		catch
		{
		}
		finally
		{
			if (intPtr2 != IntPtr.Zero)
			{
				UnmapViewOfFile(intPtr2);
			}
			CloseHandle(intPtr);
		}
		return dictionary;
	}

	public static bool TrayRunning()
	{
		try
		{
			using (Mutex.OpenExisting("Local\\AZIZ-ReflexTray-" + WindowsIdentity.GetCurrent().User.Value))
			{
				return true;
			}
		}
		catch
		{
			return false;
		}
	}
}
