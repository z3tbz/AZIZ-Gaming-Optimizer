using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class ServicePresets
{
	internal const string Minimal = "minimal";

	internal const string Recommended = "recommended";

	internal const string Default = "default";

	private static Dictionary<string, Dictionary<string, int>> lists;

	private static readonly Regex PerUser = new Regex("^(.+)_[0-9a-fA-F]{4,8}$");

	internal static readonly Dictionary<string, string> Critical = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
	{
		{ "RpcSs", "Remote Procedure Call: almost every Windows part depends on it. Windows will not start." },
		{ "RpcEptMapper", "RPC Endpoint Mapper: networking, the Store and many system services stop working." },
		{ "DcomLaunch", "DCOM Server Process Launcher: Windows cannot boot." },
		{ "Power", "Power: power plans, sleep and parts of the desktop break." },
		{ "LSM", "Local Session Manager: you will not be able to sign in." },
		{ "SamSs", "Security Accounts Manager: sign-in, Settings and services that check accounts can fail." },
		{ "BrokerInfrastructure", "Background Tasks Infrastructure: Start menu, Store apps and notifications break." },
		{ "SystemEventsBroker", "System Events Broker: Start menu and app background tasks break." },
		{ "CoreMessagingRegistrar", "CoreMessaging: the taskbar, Start menu and input can stop responding." },
		{ "ProfSvc", "User Profile Service: you sign in to a temporary profile or cannot sign in." },
		{ "UserManager", "User Manager: Start menu, Search and sign-in break." },
		{ "Schedule", "Task Scheduler: Windows maintenance, the AZIZ timer and game agents and many apps stop working." },
		{ "EventLog", "Windows Event Log: many services fail to start and errors cannot be investigated." },
		{ "gpsvc", "Group Policy Client: sign-in can hang and policies stop applying." },
		{ "Winmgmt", "WMI: hardware readings, Task Manager details, many apps and AZIZ readings break." },
		{ "Dhcp", "DHCP Client: no automatic IP address, so the internet stops on most networks." },
		{ "Dnscache", "DNS Client: websites and game servers can fail to resolve." },
		{ "nsi", "Network Store Interface: no network connection at all." },
		{ "NlaSvc", "Network Location Awareness: Windows shows \"No internet\" and some apps refuse to connect." },
		{ "netprofm", "Network List Service: the network icon, firewall profiles and apps that check the connection break." },
		{ "BFE", "Base Filtering Engine: firewall, VPNs and IPsec stop; some games and anti-cheat need it." },
		{ "mpssvc", "Windows Firewall: some games, anti-cheat and the Store refuse to install or run." },
		{ "CryptSvc", "Cryptographic Services: app installs, signatures, Windows Update and the Store fail." },
		{ "KeyIso", "CNG Key Isolation: saved Wi-Fi passwords, credentials and some sign-ins break." },
		{ "AudioEndpointBuilder", "Windows Audio Endpoint Builder: no sound." },
		{ "Audiosrv", "Windows Audio: no sound." },
		{ "PlugPlay", "Plug and Play: new devices and USB stop working; can stop some PCs from booting." },
		{ "StateRepository", "State Repository: Start menu, Settings and all Store apps break." },
		{ "AppXSvc", "AppX Deployment: Store apps cannot install or update; Xbox and Game Pass fail." },
		{ "ClipSVC", "Client License Service: Store apps and Game Pass games will not start." },
		{ "TimeBrokerSvc", "Time Broker: background app tasks and notifications break." },
		{ "Appinfo", "Application Information: Run as administrator stops working, including for AZIZ." },
		{ "EventSystem", "COM+ Event System: sign-in notifications and many apps fail." },
		{ "SENS", "System Event Notification: logon events and network-aware apps break." },
		{ "Themes", "Themes: Windows falls back to the classic look." },
		{ "TextInputManagementService", "Text Input Management: typing in Start, Search and some apps can break." },
		{ "StorSvc", "Storage Service: Store installs and storage settings break." },
		{ "DeviceInstall", "Device Install: new drivers and devices will not install." },
		{ "WlanSvc", "WLAN AutoConfig: Wi-Fi stops working." },
		{ "Wcmsvc", "Windows Connection Manager: Wi-Fi and Ethernet stop connecting automatically." },
		{ "msiserver", "Windows Installer: .msi installers (drivers, apps, game redistributables) fail." },
		{ "TrustedInstaller", "Windows Modules Installer: updates and Windows feature changes fail." },
		{ "VaultSvc", "Credential Manager: saved sign-ins (Xbox, Store, browsers) fail." },
		{ "hidserv", "Human Interface Device service: media keys and some controllers stop working." },
		{ "InstallService", "Microsoft Store Install: Store and Game Pass installs fail." },
		{ "WinHttpAutoProxySvc", "WinHTTP Auto-Proxy: parts of Windows networking depend on it." },
		{ "LanmanWorkstation", "Workstation: network shares and some launchers break." },
		{ "fvevol", "BitLocker volume driver: the PC will not boot if any drive is encrypted." },
		{ "rdyboost", "ReadyBoost volume filter: disabling it while Windows lists it as a volume filter stops Windows from booting." },
		{ "acpiex", "ACPI extension driver: touchpads, GPIO/I2C devices and on some PCs booting depend on it." },
		{ "CLFS", "Common Log File System: the registry and many services use it; Windows can fail to start." },
		{ "EhStorClass", "Enhanced Storage: on some PCs disks are not accessible without it." },
		{ "Tcpip6", "IPv6: some games, Xbox networking and Windows features need it." },
		{ "afunix", "AF_UNIX sockets: WSL and some apps fail." },
		{ "luafv", "UAC file virtualization: older apps that write to Program Files fail." }
	};

	internal static readonly HashSet<string> Main = new HashSet<string>("SysMain WSearch BDESVC DiagTrack dmwappushservice diagnosticshub.standardcollector.service WerSvc wercplsupport PcaSvc DPS WdiServiceHost WdiSystemHost Spooler PrintNotify Fax wuauserv UsoSvc WaaSMedicSvc BITS DoSvc InstallService XblAuthManager XblGameSave XboxNetApiSvc XboxGipSvc GamingServices GamingServicesNet BcastDVRUserService bthserv BTAGService BthAvctpSvc BluetoothUserService WlanSvc icssvc WFDSConMgrSvc MapsBroker lfsvc RetailDemo RemoteRegistry RemoteAccess TermService SessionEnv UmRdpService TabletInputService TextInputManagementService WpnService WpnUserService TrkWks CDPSvc CDPUserSvc OneSyncSvc PimIndexMaintenanceSvc UnistoreSvc UserDataSvc MessagingService WalletService SEMgrSvc PhoneSvc wisvc SCardSvr ScDeviceEnum WbioSrvc Themes FontCache iphlpsvc seclogon stisvc WiaRpc SharedAccess WMPNetworkSvc AppReadiness Audiosrv AudioEndpointBuilder Dhcp Dnscache NlaSvc netprofm Winmgmt EventLog Schedule mpssvc BFE CryptSvc".Split(' '), StringComparer.OrdinalIgnoreCase);

	private static HashSet<string> filters;

	private static Dictionary<string, Dictionary<string, int>> Lists
	{
		get
		{
			if (lists == null)
			{
				try
				{
					using Stream stream = typeof(ServicePresets).Assembly.GetManifestResourceStream("Aziz.services-presets.json");
					using StreamReader streamReader = new StreamReader(stream);
					lists = Program.Json.Deserialize<Dictionary<string, Dictionary<string, int>>>(streamReader.ReadToEnd()).ToDictionary((KeyValuePair<string, Dictionary<string, int>> x) => x.Key, (KeyValuePair<string, Dictionary<string, int>> x) => new Dictionary<string, int>(x.Value, StringComparer.OrdinalIgnoreCase));
				}
				catch
				{
					lists = new Dictionary<string, Dictionary<string, int>>();
				}
			}
			return lists;
		}
	}

	internal static string BaseName(string name)
	{
		Match match = PerUser.Match(name ?? "");
		if (!match.Success)
		{
			return name ?? "";
		}
		return match.Groups[1].Value;
	}

	internal static int? Target(string mode, string service)
	{
		if (!Lists.TryGetValue(mode, out var value))
		{
			return null;
		}
		if (value.TryGetValue(service ?? "", out var value2) || value.TryGetValue(BaseName(service), out value2))
		{
			return value2;
		}
		return null;
	}

	internal static bool Listed(string service)
	{
		if (!Target("minimal", service).HasValue && !Target("recommended", service).HasValue)
		{
			return Target("default", service).HasValue;
		}
		return true;
	}

	internal static IEnumerable<string> AllNames()
	{
		return Lists.Values.SelectMany((Dictionary<string, int> x) => x.Keys).Distinct(StringComparer.OrdinalIgnoreCase);
	}

	internal static string Warning(string service)
	{
		if (Critical.TryGetValue(service ?? "", out var value) || Critical.TryGetValue(BaseName(service), out value))
		{
			return value;
		}
		if (BootDriver(service))
		{
			return "Boot driver: Windows loads it while starting. Disabling it can stop Windows from booting (blue screen).";
		}
		return null;
	}

	internal static bool BootDriver(string service)
	{
		int? num = Target("default", service);
		if (num.HasValue)
		{
			return num.Value <= 1;
		}
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + service);
			if (registryKey == null)
			{
				return false;
			}
			int num2 = Convert.ToInt32(registryKey.GetValue("Type", 0));
			int num3 = Convert.ToInt32(registryKey.GetValue("Start", 3));
			return ((uint)num2 & 3u) != 0 && num3 <= 1;
		}
		catch
		{
			return false;
		}
	}

	internal static bool RegisteredFilter(string service)
	{
		if (filters == null)
		{
			HashSet<string> hashSet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
			try
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Class");
				string[] array = registryKey?.GetSubKeyNames() ?? new string[0];
				foreach (string name in array)
				{
					try
					{
						using RegistryKey registryKey2 = registryKey.OpenSubKey(name);
						string[] array2 = new string[2] { "UpperFilters", "LowerFilters" };
						foreach (string name2 in array2)
						{
							if (registryKey2?.GetValue(name2) is string[] source)
							{
								hashSet.UnionWith(source.Where((string x) => !string.IsNullOrWhiteSpace(x)));
							}
						}
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			filters = hashSet;
		}
		return filters.Contains(service ?? "");
	}

	internal static string StartText(int start)
	{
		return start switch
		{
			0 => "Boot", 
			1 => "System", 
			2 => "Automatic", 
			3 => "Manual", 
			4 => "Disabled", 
			_ => start.ToString(), 
		};
	}
}
