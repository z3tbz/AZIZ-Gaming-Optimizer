using System;

namespace Aziz;

internal static class ScrollMotion
{
	public static double Next(double current, double target, double seconds)
	{
		double num = Math.Max(0.001, Math.Min(0.04, seconds));
		double num2 = target - current;
		double value = num2 * (1.0 - Math.Exp(-18.0 * num));
		value = (double)Math.Sign(value) * Math.Min(Math.Abs(value), 1800.0 * num);
		if (!(Math.Abs(num2) < 0.5))
		{
			return current + value;
		}
		return target;
	}
}
