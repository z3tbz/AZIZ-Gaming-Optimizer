using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Aziz;

internal static class AppIcons
{
	private static readonly Dictionary<string, ImageSource> Cache = new Dictionary<string, ImageSource>(StringComparer.OrdinalIgnoreCase);

	[DllImport("shell32.dll", CharSet = CharSet.Unicode)]
	private static extern uint ExtractIconEx(string file, int index, IntPtr[] large, IntPtr[] small, uint count);

	[DllImport("user32.dll")]
	private static extern bool DestroyIcon(IntPtr icon);

	public static string ExecutablePath(string specification)
	{
		if (string.IsNullOrWhiteSpace(specification))
		{
			return null;
		}
		return Regex.Replace(Environment.ExpandEnvironmentVariables(specification).Trim(), ",\\s*-?\\d+$", "").Trim('"');
	}

	public static ImageSource Load(string specification)
	{
		if (string.IsNullOrEmpty(specification))
		{
			return null;
		}
		lock (Cache)
		{
			if (Cache.TryGetValue(specification, out var value))
			{
				return value;
			}
			ImageSource imageSource = null;
			try
			{
				string text = Environment.ExpandEnvironmentVariables(specification).Trim();
				int index = 0;
				Match match = Regex.Match(text, "^(.*),\\s*(-?\\d+)$");
				if (match.Success)
				{
					text = match.Groups[1].Value;
					index = int.Parse(match.Groups[2].Value);
				}
				text = text.Trim('"');
				if (File.Exists(text))
				{
					if (new string[4] { ".png", ".jpg", ".jpeg", ".ico" }.Contains(Path.GetExtension(text).ToLowerInvariant()))
					{
						BitmapImage bitmapImage = new BitmapImage();
						bitmapImage.BeginInit();
						bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
						bitmapImage.UriSource = new Uri(text);
						bitmapImage.DecodePixelWidth = 48;
						bitmapImage.EndInit();
						bitmapImage.Freeze();
						imageSource = bitmapImage;
					}
					else
					{
						IntPtr[] array = new IntPtr[1];
						IntPtr[] array2 = new IntPtr[1];
						ExtractIconEx(text, index, array, array2, 1u);
						try
						{
							IntPtr intPtr = ((array[0] != IntPtr.Zero) ? array[0] : array2[0]);
							if (intPtr != IntPtr.Zero)
							{
								BitmapSource bitmapSource = Imaging.CreateBitmapSourceFromHIcon(intPtr, Int32Rect.Empty, BitmapSizeOptions.FromWidthAndHeight(40, 40));
								bitmapSource.Freeze();
								imageSource = bitmapSource;
							}
						}
						finally
						{
							if (array[0] != IntPtr.Zero)
							{
								DestroyIcon(array[0]);
							}
							if (array2[0] != IntPtr.Zero)
							{
								DestroyIcon(array2[0]);
							}
						}
					}
				}
			}
			catch
			{
			}
			Cache[specification] = imageSource;
			return imageSource;
		}
	}
}
