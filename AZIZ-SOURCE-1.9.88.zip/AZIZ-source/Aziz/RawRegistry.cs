using System;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace Aziz;

internal static class RawRegistry
{
	[DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
	private static extern int RegQueryValueEx(SafeRegistryHandle h, string n, IntPtr r, out uint type, byte[] data, ref uint size);

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
	private static extern int RegSetValueEx(SafeRegistryHandle h, string n, int r, uint type, byte[] data, int size);

	public static object Read(RegistryKey key, string name)
	{
		if (key == null)
		{
			return null;
		}
		uint size = 0u;
		int num = RegQueryValueEx(key.Handle, name, IntPtr.Zero, out var type, null, ref size);
		switch (num)
		{
		case 2:
			return null;
		default:
			throw new Win32Exception(num);
		case 0:
		{
			if (type == 1 || type == 2 || type == 3 || type == 4 || type == 7 || type == 11)
			{
				return key.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
			}
			if (size > 1048576)
			{
				throw new IOException("Registry value exceeds size limit.");
			}
			byte[] array = new byte[size];
			num = RegQueryValueEx(key.Handle, name, IntPtr.Zero, out type, array, ref size);
			if (num != 0)
			{
				throw new Win32Exception(num);
			}
			return array;
		}
		}
	}

	public static string Kind(RegistryKey key, string name)
	{
		uint size = 0u;
		uint type;
		int num = RegQueryValueEx(key.Handle, name, IntPtr.Zero, out type, null, ref size);
		if (num != 0)
		{
			throw new Win32Exception(num);
		}
		switch (type)
		{
		default:
			return "Raw:" + type;
		case 1u:
		case 2u:
		case 3u:
		case 4u:
		case 7u:
		case 11u:
			return key.GetValueKind(name).ToString();
		case 0u:
			return "None";
		}
	}

	public static void WriteNone(RegistryKey key, string name, byte[] value)
	{
		WriteRaw(key, name, 0u, value);
	}

	public static void WriteRaw(RegistryKey key, string name, uint type, byte[] value)
	{
		int num = RegSetValueEx(key.Handle, name, 0, type, value, value.Length);
		if (num != 0)
		{
			throw new Win32Exception(num);
		}
	}
}
