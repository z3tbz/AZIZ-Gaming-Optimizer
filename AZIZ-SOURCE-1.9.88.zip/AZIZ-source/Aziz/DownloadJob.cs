using System.Threading;

namespace Aziz;

internal class DownloadJob
{
	public DownloadItem Item;

	public string State = "Queued";

	public string FilePath;

	public string Hash;

	public string Error;

	public long Bytes;

	public long? Total;

	public double Speed;

	public CancellationTokenSource Cancel = new CancellationTokenSource();

	public bool Running
	{
		get
		{
			if (!(State == "Resolving") && !(State == "Downloading"))
			{
				return State == "Verifying";
			}
			return true;
		}
	}
}
