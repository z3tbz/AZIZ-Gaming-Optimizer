using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Aziz;

internal static class DownloadLibrary
{
	private static readonly object Gate = new object();

	internal static string FolderOverride { get; set; }

	// Downloads live in Windows' own Downloads folder (Downloads\AZIZ), so they stay when AZIZ is updated, moved or removed.
	public static string Folder => FolderOverride ?? Path.Combine(UserDownloads(), "AZIZ");

	[System.Runtime.InteropServices.DllImport("shell32.dll")]
	private static extern int SHGetKnownFolderPath([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPStruct)] Guid id, uint flags, IntPtr token, out IntPtr path);

	private static string downloads;

	private static string UserDownloads()
	{
		if (downloads != null)
		{
			return downloads;
		}
		try
		{
			if (SHGetKnownFolderPath(new Guid("374DE290-123F-4565-9164-39C4925E467B"), 0u, IntPtr.Zero, out var path) == 0)
			{
				downloads = System.Runtime.InteropServices.Marshal.PtrToStringUni(path);
				System.Runtime.InteropServices.Marshal.FreeCoTaskMem(path);
			}
		}
		catch
		{
		}
		return downloads = downloads ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
	}

	// Older builds kept downloads next to the app: move them once (the index stores relative paths, so it moves too).
	public static void Migrate()
	{
		try
		{
			string text = Path.Combine(Program.Root, "Downloads");
			if (FolderOverride != null || !Directory.Exists(text) || Full(text).Equals(Full(Folder), StringComparison.OrdinalIgnoreCase))
			{
				return;
			}
			lock (Gate)
			{
				Directory.CreateDirectory(Folder);
				foreach (string item in Directory.EnumerateFileSystemEntries(text).ToList())
				{
					string text2 = Path.Combine(Folder, Path.GetFileName(item));
					try
					{
						if (Directory.Exists(item))
						{
							if (!Directory.Exists(text2))
							{
								if (Path.GetPathRoot(item).Equals(Path.GetPathRoot(text2), StringComparison.OrdinalIgnoreCase))
								{
									Directory.Move(item, text2);
								}
								else
								{
									Copy(item, text2);
									Directory.Delete(item, recursive: true);
								}
							}
						}
						else if (!File.Exists(text2))
						{
							File.Copy(item, text2);
							File.Delete(item);
						}
					}
					catch
					{
					}
				}
				if (!Directory.EnumerateFileSystemEntries(text).Any())
				{
					Directory.Delete(text);
				}
			}
		}
		catch
		{
		}
	}

	private static void Copy(string from, string to)
	{
		Directory.CreateDirectory(to);
		foreach (string file in Directory.GetFiles(from))
		{
			File.Copy(file, Path.Combine(to, Path.GetFileName(file)));
		}
		foreach (string directory in Directory.GetDirectories(from))
		{
			Copy(directory, Path.Combine(to, Path.GetFileName(directory)));
		}
	}

	private static string Index => Path.Combine(Folder, "library.json");

	private static string Full(string path)
	{
		return Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar);
	}

	public static bool Within(string path, string root)
	{
		try
		{
			return Full(path).StartsWith(Full(root) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
		}
		catch
		{
			return false;
		}
	}

	public static void NoLinks(string path)
	{
		for (DirectoryInfo directoryInfo = new DirectoryInfo(path); directoryInfo != null; directoryInfo = directoryInfo.Parent)
		{
			if (directoryInfo.Exists && (directoryInfo.Attributes & FileAttributes.ReparsePoint) != 0)
			{
				throw new IOException("A download path contains a directory link.");
			}
		}
		if (File.Exists(path) && (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
		{
			throw new IOException("A download file cannot be a link.");
		}
	}

	private static string Resolve(string path)
	{
		if (string.IsNullOrWhiteSpace(path))
		{
			return null;
		}
		string fullPath = Path.GetFullPath(Path.IsPathRooted(path) ? path : Path.Combine(Folder, path));
		if (!Within(fullPath, Folder))
		{
			return null;
		}
		NoLinks(fullPath);
		return fullPath;
	}

	public static List<DownloadRecord> Read()
	{
		lock (Gate)
		{
			List<DownloadRecord> list = new List<DownloadRecord>();
			try
			{
				NoLinks(Index);
				foreach (DownloadRecord item in Program.Json.Deserialize<List<DownloadRecord>>(File.ReadAllText(Index)) ?? new List<DownloadRecord>())
				{
					try
					{
						item.FilePath = Resolve(item.FilePath);
						item.OpenPath = Resolve(item.OpenPath);
						if (item.FilePath != null && File.Exists(item.FilePath) && new FileInfo(item.FilePath).Length == item.Bytes)
						{
							list.Add(item);
						}
					}
					catch
					{
					}
				}
			}
			catch
			{
			}
			return list;
		}
	}

	private static void Save(List<DownloadRecord> records)
	{
		NoLinks(Index);
		Directory.CreateDirectory(Folder);
		List<DownloadRecord> obj = records.Select((DownloadRecord x) => new DownloadRecord
		{
			Id = x.Id,
			FilePath = Relative(x.FilePath),
			Hash = x.Hash,
			Bytes = x.Bytes,
			FinishedUtc = x.FinishedUtc,
			OpenPath = Relative(x.OpenPath),
			OpenHash = x.OpenHash
		}).ToList();
		Utilities.AtomicWrite(Index, Program.Json.Serialize(obj));
	}

	private static string Relative(string path)
	{
		if (!string.IsNullOrEmpty(path))
		{
			if (!Within(path, Folder))
			{
				return null;
			}
			return Path.GetFullPath(path).Substring(Full(Folder).Length + 1);
		}
		return null;
	}

	public static void Remember(DownloadJob job)
	{
		if (job.State != "Completed" || !Within(job.FilePath, Folder))
		{
			return;
		}
		lock (Gate)
		{
			List<DownloadRecord> list = Read();
			list.RemoveAll((DownloadRecord x) => x.Id == job.Item.Id);
			list.Add(new DownloadRecord
			{
				Id = job.Item.Id,
				FilePath = job.FilePath,
				Hash = job.Hash,
				Bytes = job.Bytes,
				FinishedUtc = DateTime.UtcNow
			});
			Save(list);
		}
	}

	internal static string CleanName(string name)
	{
		if (string.IsNullOrWhiteSpace(name) || Path.GetFileName(name) != name || name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || name.EndsWith(".") || name.EndsWith(" ") || name == "." || name == ".." || Regex.IsMatch(name, "^(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])(?:\\.|$)", RegexOptions.IgnoreCase))
		{
			throw new InvalidDataException("Invalid download filename.");
		}
		return name;
	}

	internal static string FreeName(string folder, string name)
	{
		CleanName(name);
		string text = Path.Combine(folder, name);
		int num = 2;
		while (File.Exists(text) || Directory.Exists(text))
		{
			text = Path.Combine(folder, Path.GetFileNameWithoutExtension(name) + " (" + num + ")" + Path.GetExtension(name));
			num++;
		}
		NoLinks(text);
		return text;
	}

	internal static string Commit(string temporary, string folder, string name)
	{
		lock (Gate)
		{
			string text = FreeName(folder, name);
			File.Move(temporary, text);
			return text;
		}
	}

	public static DownloadJob LoadJob(DownloadItem item)
	{
		DownloadRecord downloadRecord = Read().FirstOrDefault((DownloadRecord x) => x.Id == item.Id);
		if (downloadRecord != null)
		{
			return new DownloadJob
			{
				Item = item,
				State = "Completed",
				FilePath = downloadRecord.FilePath,
				Hash = downloadRecord.Hash,
				Bytes = downloadRecord.Bytes,
				Total = downloadRecord.Bytes
			};
		}
		return null;
	}

	public static List<DownloadJob> LoadJobs()
	{
		List<DownloadItem> items = DownloadManager.Catalog();
		return (from x in Read()
			where items.Any((DownloadItem i) => i.Id == x.Id)
			select new DownloadJob
			{
				Item = items.First((DownloadItem i) => i.Id == x.Id),
				State = "Completed",
				FilePath = x.FilePath,
				Hash = x.Hash,
				Bytes = x.Bytes,
				Total = x.Bytes
			}).ToList();
	}

	private static string Hash(string path)
	{
		using SHA256 sHA = SHA256.Create();
		using FileStream inputStream = File.OpenRead(path);
		return BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").ToLowerInvariant();
	}

	public static void Verify(DownloadJob job)
	{
		if (!Within(job.FilePath, Folder))
		{
			throw new IOException("The file is outside AZIZ Downloads.");
		}
		NoLinks(job.FilePath);
		if (!File.Exists(job.FilePath) || !string.Equals(Hash(job.FilePath), job.Hash, StringComparison.OrdinalIgnoreCase))
		{
			throw new IOException("The downloaded file changed or is missing. Download it again before opening.");
		}
	}

	public static string Prepare(DownloadJob job)
	{
		Verify(job);
		if (!(job.Item.Archive != "7z") || !(job.Item.Archive != "zip") || Path.GetExtension(job.FilePath).Equals(".zip", StringComparison.OrdinalIgnoreCase))
		{
			lock (Gate)
			{
				List<DownloadRecord> list = Read();
				DownloadRecord downloadRecord = list.FirstOrDefault((DownloadRecord x) => x.Id == job.Item.Id && x.FilePath == job.FilePath);
				if (downloadRecord != null && downloadRecord.OpenPath != null && Within(downloadRecord.OpenPath, Folder))
				{
					try
					{
						NoLinks(downloadRecord.OpenPath);
						if (File.Exists(downloadRecord.OpenPath) && Hash(downloadRecord.OpenPath) == downloadRecord.OpenHash)
						{
							return downloadRecord.OpenPath;
						}
						if (Directory.Exists(downloadRecord.OpenPath) && downloadRecord.OpenHash == "folder")
						{
							return downloadRecord.OpenPath;
						}
					}
					catch
					{
					}
				}
				string text = FreeName(Path.Combine(Folder, "Portable"), job.Item.Id);
				PortableArchives.Extract(job.FilePath, text);
				string text2 = text;
				if (!string.IsNullOrEmpty(job.Item.EntryExe))
				{
					if (Path.GetFileName(job.Item.EntryExe) != job.Item.EntryExe || !job.Item.EntryExe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
					{
						throw new InvalidDataException("Invalid portable launch entry.");
					}
					text2 = (from x in Directory.GetFiles(text, job.Item.EntryExe, SearchOption.AllDirectories)
						orderby x.Length
						select x).FirstOrDefault() ?? text;
				}
				if (job.Item.Portable && job.Item.Id == "vscode" && File.Exists(text2))
				{
					Directory.CreateDirectory(Path.Combine(Path.GetDirectoryName(text2), "data"));
				}
				if (job.Item.Portable && job.Item.Id == "obs" && File.Exists(text2))
				{
					File.WriteAllText(Path.Combine(text, "portable_mode.txt"), "");
				}
				if (downloadRecord != null)
				{
					downloadRecord.OpenPath = text2;
					downloadRecord.OpenHash = (File.Exists(text2) ? Hash(text2) : "folder");
					Save(list);
				}
				return text2;
			}
		}
		return job.FilePath;
	}
}
