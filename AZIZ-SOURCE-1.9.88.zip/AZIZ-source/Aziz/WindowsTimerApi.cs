using System;
using System.Runtime.InteropServices;

namespace Aziz;

internal sealed class WindowsTimerApi : ITimerApi
{
	private struct PowerState
	{
		public uint Version;

		public uint ControlMask;

		public uint StateMask;
	}

	private const int NotSet = -1073741243;

	private PowerState previous;

	private bool captured;

	[DllImport("ntdll.dll")]
	private static extern int NtSetTimerResolution(uint desired, [MarshalAs(UnmanagedType.U1)] bool set, out uint actual);

	[DllImport("ntdll.dll")]
	private static extern int NtQueryTimerResolution(out uint maximum, out uint minimum, out uint current);

	[DllImport("ntdll.dll")]
	private static extern int NtDelayExecution([MarshalAs(UnmanagedType.U1)] bool alertable, ref long interval);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool SetProcessInformation(IntPtr process, int kind, ref PowerState state, uint size);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool GetProcessInformation(IntPtr process, int kind, ref PowerState state, uint size);

	public uint Query()
	{
		if (NtQueryTimerResolution(out var _, out var _, out var current) < 0)
		{
			throw new InvalidOperationException("Windows timer query failed.");
		}
		return current;
	}

	public uint Set(bool enabled)
	{
		uint actual;
		int num = NtSetTimerResolution(5000u, enabled, out actual);
		if (num < 0 && (num != -1073741243 || enabled))
		{
			throw new InvalidOperationException("Windows timer request failed: 0x" + num.ToString("X8"));
		}
		return actual;
	}

	public bool Honor(bool enabled)
	{
		try
		{
			PowerState powerState = default(PowerState);
			powerState.Version = 1u;
			PowerState state = powerState;
			if (enabled)
			{
				captured = GetProcessInformation(new IntPtr(-1), 4, ref state, 12u);
				previous = state;
				state.Version = 1u;
				state.ControlMask |= 4u;
				state.StateMask &= 4294967291u;
			}
			else
			{
				PowerState powerState3;
				if (!captured)
				{
					PowerState powerState2 = default(PowerState);
					powerState2.Version = 1u;
					powerState3 = powerState2;
				}
				else
				{
					powerState3 = previous;
				}
				state = powerState3;
			}
			return SetProcessInformation(new IntPtr(-1), 4, ref state, 12u);
		}
		catch (EntryPointNotFoundException)
		{
			return false;
		}
	}

	public void WaitHalfMillisecond()
	{
		long interval = -5000L;
		int num = NtDelayExecution(alertable: false, ref interval);
		if (num < 0)
		{
			throw new InvalidOperationException("Windows wait failed: 0x" + num.ToString("X8"));
		}
	}
}
