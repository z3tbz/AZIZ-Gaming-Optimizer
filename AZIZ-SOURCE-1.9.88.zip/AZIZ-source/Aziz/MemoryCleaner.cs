using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;

namespace Aziz;

// RAM cleaner through the memory-list API (no defrag, nothing written to disk). Both the button and the background helper
// (sign-in, idle priority: at 80% RAM at most every 10 minutes, and once an hour, also while you play) trim every
// process except the games installed on this PC, so a running game never loses its memory. The button also clears the
// whole standby list; the background helper only the low-priority part.
internal static class MemoryCleaner
{
	[StructLayout(LayoutKind.Sequential)]
	private struct MemoryStatus
	{
		public uint Length;

		public uint Load;

		public ulong TotalPhys;

		public ulong AvailPhys;

		public ulong TotalPageFile;

		public ulong AvailPageFile;

		public ulong TotalVirtual;

		public ulong AvailVirtual;

		public ulong AvailExtendedVirtual;
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);

	[DllImport("ntdll.dll")]
	private static extern int NtSetSystemInformation(int kind, ref int value, int size);

	private const int MemoryListInformation = 80;

	private const int EmptyWorkingSets = 2;

	private const int PurgeStandby = 4;

	private const int PurgeLowPriorityStandby = 5;

	public static string TaskName => "AZIZ Memory Cleaner - " + WindowsIdentity.GetCurrent().User.Value;

	public static int Load()
	{
		MemoryStatus status = new MemoryStatus
		{
			Length = (uint)Marshal.SizeOf(typeof(MemoryStatus))
		};
		return GlobalMemoryStatusEx(ref status) ? ((int)status.Load) : (-1);
	}

	private static ulong Available()
	{
		MemoryStatus status = new MemoryStatus
		{
			Length = (uint)Marshal.SizeOf(typeof(MemoryStatus))
		};
		return GlobalMemoryStatusEx(ref status) ? status.AvailPhys : 0uL;
	}

	private static void Command(int command)
	{
		int value = command;
		int num = NtSetSystemInformation(MemoryListInformation, ref value, 4);
		if (num != 0)
		{
			throw new InvalidOperationException("Windows rejected the memory command (0x" + num.ToString("X8") + ")");
		}
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

	[DllImport("kernel32.dll")]
	private static extern bool CloseHandle(IntPtr handle);

	[DllImport("psapi.dll")]
	private static extern bool EmptyWorkingSet(IntPtr process);

	private static List<string> gameFolders;

	private static DateTime gameFoldersRead;

	// Install folders of every game AZIZ finds on this PC (Steam, Epic, EA, Ubisoft, Battle.net, Xbox, …), refreshed every
	// 6 hours. Processes running from these folders are never trimmed.
	private static List<string> GameFolders()
	{
		if (gameFolders != null && (DateTime.UtcNow - gameFoldersRead).TotalHours < 6.0)
		{
			return gameFolders;
		}
		List<string> list = new List<string>();
		try
		{
			string[] source = new string[8] { "win64", "win32", "x64", "x86", "binaries", "bin", "bin64", "retail" };
			foreach (GameEntry item in GameDiscovery.Scan())
			{
				if (string.IsNullOrEmpty(item.Exe))
				{
					continue;
				}
				string text = Path.GetDirectoryName(Path.GetFullPath(item.Exe));
				bool flag = false;
				while (text != null && source.Contains(Path.GetFileName(text).ToLowerInvariant()))
				{
					text = Path.GetDirectoryName(text);
					flag = true;
				}
				if (flag && text != null && Path.GetDirectoryName(text) != null && Path.GetPathRoot(text) != Path.GetDirectoryName(text))
				{
					text = Path.GetDirectoryName(text);
				}
				if (!string.IsNullOrEmpty(text) && Path.GetPathRoot(text) != text)
				{
					list.Add(text.TrimEnd('\\') + "\\");
				}
			}
		}
		catch
		{
		}
		gameFolders = list.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
		gameFoldersRead = DateTime.UtcNow;
		return gameFolders;
	}

	// Never trimmed: Windows' desktop, audio and session processes (trimming them causes stutter and audio crackle), anti-cheat,
	// voice chat and the overlay/limiter tools a game runs with.
	private static readonly string[] Untouched = new string[22]
	{
		"dwm", "audiodg", "csrss", "wininit", "winlogon", "lsass", "smss", "services", "fontdrvhost", "System", "Registry", "MsMpEng",
		"EasyAntiCheat", "BEService", "vgc", "FACEIT", "Discord", "RTSS", "RTSSHooksLoader", "EncoderServer", "MSIAfterburner", "ProcessLasso"
	};

	[DllImport("user32.dll")]
	private static extern IntPtr GetForegroundWindow();

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

	// Games the user added by hand, set up in Game Watch or turned on in Reflex Fallback: these are kept even when they are
	// not in a launcher's folder.
	private static HashSet<string> KnownGameExes()
	{
		HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
		Action<string> add = delegate(string exe)
		{
			if (!string.IsNullOrWhiteSpace(exe))
			{
				set.Add(exe.Trim().Trim('"'));
				set.Add(Path.GetFileName(exe.Trim().Trim('"')));
			}
		};
		try
		{
			string path = Path.Combine(Program.Data, "manual-games.json");
			if (File.Exists(path))
			{
				foreach (GameEntry item in Program.Json.Deserialize<List<GameEntry>>(File.ReadAllText(path)) ?? new List<GameEntry>())
				{
					add(item.Exe);
				}
			}
		}
		catch
		{
		}
		try
		{
			foreach (GameRule rule in GameWatch.Load().Rules ?? new List<GameRule>())
			{
				add(rule.Exe);
			}
		}
		catch
		{
		}
		try
		{
			foreach (string key in ReflexFallback.Games().Keys)
			{
				add(key);
			}
		}
		catch
		{
		}
		return set;
	}

	// Trims the working set of every process except games (launcher folders and the games the user set up), the game in
	// front, Windows' desktop/audio processes and AZIZ itself, so a running game keeps all of its memory.
	private static void TrimExceptGames()
	{
		List<string> list = GameFolders();
		HashSet<string> games = KnownGameExes();
		uint front = 0;
		try
		{
			GetWindowThreadProcessId(GetForegroundWindow(), out front);
		}
		catch
		{
		}
		int id;
		using (Process current = Process.GetCurrentProcess())
		{
			id = current.Id;
		}
		Process[] processes = Process.GetProcesses();
		foreach (Process process in processes)
		{
			using (process)
			{
				try
				{
					if (process.Id <= 4 || process.Id == id || process.Id == front)
					{
						continue;
					}
					string name = process.ProcessName;
					if (Untouched.Any((string u) => name.StartsWith(u, StringComparison.OrdinalIgnoreCase)))
					{
						continue;
					}
					string text = CompetitiveLaunch.ImagePath(process.Id);
					if (text == null || games.Contains(text) || games.Contains(Path.GetFileName(text)) || list.Any((string f) => text.StartsWith(f, StringComparison.OrdinalIgnoreCase)))
					{
						continue;
					}
					IntPtr intPtr = OpenProcess(4352u, inherit: false, process.Id);
					if (intPtr != IntPtr.Zero)
					{
						EmptyWorkingSet(intPtr);
						CloseHandle(intPtr);
					}
				}
				catch
				{
				}
			}
		}
	}

	// full (button): every process but the games is trimmed, and the whole standby list is cleared. Background: the same
	// trim, plus only the low-priority standby list (old cache), so games keep both their memory and their cached files.
	public static ActionResult Clean(bool full)
	{
		try
		{
			ulong num = Available();
			GameNative.PrivilegeOn("SeProfileSingleProcessPrivilege");
			try
			{
				GameNative.PrivilegeOn("SeIncreaseQuotaPrivilege");
			}
			catch
			{
			}
			TrimExceptGames();
			Command(full ? PurgeStandby : PurgeLowPriorityStandby);
			ulong num2 = Available();
			long num3 = (long)(num2 - num) / 1048576L;
			return new ActionResult
			{
				Success = true,
				Message = ((num3 > 0) ? (num3 + " MB freed") : "Memory already clean")
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	private static string Q(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	private static bool? installed;

	// Cached: asked on every Home render, so schtasks runs once per AZIZ start (off the UI thread by the caller).
	public static bool Installed()
	{
		if (installed.HasValue)
		{
			return installed.Value;
		}
		try
		{
			installed = Utilities.Run("schtasks.exe", "/Query /TN \"" + TaskName + "\"").Success;
		}
		catch
		{
			installed = false;
		}
		return installed.Value;
	}

	public static bool KnownInstalled => installed == true;

	private static string ExitEvent => "Local\\AZIZ-MemoryCleaner-Exit-" + WindowsIdentity.GetCurrent().User.Value;

	// Off switch: removes the sign-in task and tells the running cleaner to stop.
	public static ActionResult Remove()
	{
		ActionResult result = Utilities.Run("schtasks.exe", "/Delete /TN \"" + TaskName + "\" /F");
		installed = false;
		try
		{
			using EventWaitHandle eventWaitHandle = EventWaitHandle.OpenExisting(ExitEvent);
			eventWaitHandle.Set();
		}
		catch
		{
		}
		result.Success = true;
		result.Message = "Automatic memory cleaner off.";
		return result;
	}

	public static ActionResult Install()
	{
		try
		{
			AgentFiles.Deploy();
			string exe = AgentFiles.Exe;
			string value = WindowsIdentity.GetCurrent().User.Value;
			string script = "$action=New-ScheduledTaskAction -Execute " + Q(exe) + " -Argument '--memory-clean'; $trigger=New-ScheduledTaskTrigger -AtLogOn -User " + Q(value) + "; $principal=New-ScheduledTaskPrincipal -UserId " + Q(value) + " -LogonType Interactive -RunLevel Highest; $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -Priority 7; Register-ScheduledTask -TaskName " + Q(TaskName) + " -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null; Start-ScheduledTask -TaskName " + Q(TaskName) + "; 'Automatic memory cleaner on.'";
			installed = null;
			return Utilities.Run("powershell.exe", GameWatch.PsArgs(script));
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	// Background loop (--memory-clean): checks every 30 seconds, sleeps the rest of the time.
	public static int Run()
	{
		bool createdNew;
		using (new Mutex(initiallyOwned: true, "Local\\AZIZ-MemoryCleaner-" + WindowsIdentity.GetCurrent().User.Value, out createdNew))
		{
			if (!createdNew)
			{
				return 0;
			}
			try
			{
				using Process process = Process.GetCurrentProcess();
				process.PriorityClass = ProcessPriorityClass.Idle;
			}
			catch
			{
			}
			DateTime dateTime = DateTime.UtcNow;
			DateTime dateTime2 = DateTime.MinValue;
			using EventWaitHandle exit = new EventWaitHandle(initialState: false, EventResetMode.ManualReset, ExitEvent);
			while (true)
			{
				if (exit.WaitOne(30000))
				{
					return 0;
				}
				DateTime utcNow = DateTime.UtcNow;
				int num = Load();
				bool flag = num >= 80 && utcNow - dateTime2 > TimeSpan.FromMinutes(10.0);
				bool flag2 = utcNow - dateTime >= TimeSpan.FromHours(1.0);
				if (flag || flag2)
				{
					ActionResult actionResult = Clean(full: false);
					dateTime2 = utcNow;
					if (flag2)
					{
						dateTime = utcNow;
					}
					try
					{
						GameWatch.Log("Memory cleaner", flag ? ("RAM " + num + "%") : "Hourly", actionResult.Message);
					}
					catch
					{
					}
				}
			}
		}
	}
}
