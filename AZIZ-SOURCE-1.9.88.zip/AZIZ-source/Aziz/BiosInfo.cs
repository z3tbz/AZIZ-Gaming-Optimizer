namespace Aziz;

internal class BiosInfo
{
	public string Vendor;

	public string Model;

	public string Version;

	public string Url;

	public string Board;

	public bool Exact;
}
