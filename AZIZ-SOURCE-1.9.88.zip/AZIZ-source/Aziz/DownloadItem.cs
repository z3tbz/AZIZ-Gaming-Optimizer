namespace Aziz;

internal class DownloadItem
{
	public bool Parallel { get; set; }

	public bool Tool { get; set; }

	public string Archive { get; set; }

	public string BundledPath { get; set; }

	public string Sha256 { get; set; }

	public string Resolver { get; set; }

	public bool Portable { get; set; }

	public string EntryExe { get; set; }

	public string Id { get; set; }

	public string Name { get; set; }

	public string Description { get; set; }

	public string Publisher { get; set; }

	public string Category { get; set; }

	public string DirectUrl { get; set; }

	public string Repo { get; set; }

	public string Pattern { get; set; }

	public string FileName { get; set; }

	public string Referer { get; set; }

	public string Builtin { get; set; }

	public string Winget { get; set; }
}
