namespace Aziz;

public class RegistryOperation
{
	public string Hive { get; set; }

	public string Path { get; set; }

	public string Name { get; set; }

	public string Kind { get; set; }

	public object Value { get; set; }

	public string Token { get; set; }

	public bool ExistingKeyOnly { get; set; }
}
