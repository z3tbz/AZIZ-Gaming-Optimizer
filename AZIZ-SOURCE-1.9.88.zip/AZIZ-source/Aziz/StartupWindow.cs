using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace Aziz;

// Splash: only the AZIZ icon; the loading line and its text sit inside the icon, at the bottom. No window frame or box.
internal sealed class StartupWindow : Window
{
	public bool Cancelled;

	private TextBlock status;

	private Border fill;

	private Border runner;

	private const double BarWidth = 176.0;

	public void Report(string text, int percent)
	{
		if (status != null)
		{
			status.Text = text;
		}
		if (fill != null)
		{
			runner.Visibility = Visibility.Collapsed;
			fill.BeginAnimation(FrameworkElement.WidthProperty, new DoubleAnimation(BarWidth * Math.Max(0, Math.Min(100, percent)) / 100.0, TimeSpan.FromMilliseconds(220.0)));
		}
	}

	public StartupWindow()
	{
		base.Width = 440.0;
		base.Height = 470.0;
		base.WindowStyle = WindowStyle.None;
		base.AllowsTransparency = true;
		base.Background = Brushes.Transparent;
		base.ResizeMode = ResizeMode.NoResize;
		base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
		base.ShowInTaskbar = true;
		base.Title = "AZIZ · Loading";
		base.Icon = BrandLogo.Image(0);
		StackPanel stackPanel = new StackPanel
		{
			HorizontalAlignment = HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center
		};
		DrawingImage drawingImage = new DrawingImage(BrandArt.Drawing());
		drawingImage.Freeze();
		Image image = new Image
		{
			Source = drawingImage,
			Width = 300.0,
			Height = 300.0,
			Stretch = Stretch.Uniform,
			SnapsToDevicePixels = true,
			Effect = new DropShadowEffect
			{
				Color = Color.FromRgb(110, 70, 230),
				BlurRadius = 48.0,
				ShadowDepth = 0.0,
				Opacity = 0.55
			}
		};
		RenderOptions.SetBitmapScalingMode(image, BitmapScalingMode.HighQuality);
		RenderOptions.SetEdgeMode(image, EdgeMode.Unspecified);
		Grid logo = new Grid
		{
			Width = 300.0,
			Height = 300.0
		};
		logo.Children.Add(image);
		StackPanel inner = new StackPanel
		{
			VerticalAlignment = VerticalAlignment.Bottom,
			HorizontalAlignment = HorizontalAlignment.Center,
			Margin = new Thickness(0.0, 0.0, 0.0, 30.0)
		};
		logo.Children.Add(inner);
		stackPanel.Children.Add(logo);
		Grid grid = new Grid
		{
			Width = BarWidth,
			Height = 6.0,
			ClipToBounds = true
		};
		grid.Children.Add(new Border
		{
			CornerRadius = new CornerRadius(3.0),
			Background = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255))
		});
		LinearGradientBrush background = new LinearGradientBrush(Color.FromRgb(108, 58, 220), Color.FromRgb(95, 211, 243), 0.0);
		fill = new Border
		{
			CornerRadius = new CornerRadius(3.0),
			Background = background,
			HorizontalAlignment = HorizontalAlignment.Left,
			Width = 0.0,
			Effect = new DropShadowEffect
			{
				Color = Color.FromRgb(95, 211, 243),
				BlurRadius = 10.0,
				ShadowDepth = 0.0,
				Opacity = 0.8
			}
		};
		grid.Children.Add(fill);
		TranslateTransform translateTransform = new TranslateTransform(-60.0, 0.0);
		runner = new Border
		{
			Width = 60.0,
			CornerRadius = new CornerRadius(3.0),
			Background = background,
			HorizontalAlignment = HorizontalAlignment.Left,
			RenderTransform = translateTransform
		};
		grid.Children.Add(runner);
		translateTransform.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(-60.0, BarWidth, TimeSpan.FromMilliseconds(1100.0))
		{
			RepeatBehavior = RepeatBehavior.Forever,
			EasingFunction = new SineEase
			{
				EasingMode = EasingMode.EaseInOut
			}
		});
		inner.Children.Add(grid);
		status = new TextBlock
		{
			Text = "Loading…",
			FontSize = 12.5,
			FontWeight = FontWeights.SemiBold,
			Foreground = Brushes.White,
			TextAlignment = TextAlignment.Center,
			HorizontalAlignment = HorizontalAlignment.Center,
			MaxWidth = 230.0,
			TextTrimming = TextTrimming.CharacterEllipsis,
			Margin = new Thickness(0.0, 9.0, 0.0, 0.0),
			Effect = new DropShadowEffect
			{
				Color = Colors.Black,
				BlurRadius = 6.0,
				ShadowDepth = 0.0,
				Opacity = 0.8
			}
		};
		inner.Children.Add(status);
		base.Content = stackPanel;
		base.MouseLeftButtonDown += delegate
		{
			try
			{
				DragMove();
			}
			catch
			{
			}
		};
		CancelEventHandler value = delegate
		{
			Cancelled = true;
		};
		base.Closing += value;
	}
}
