namespace Aziz;

internal class BundledPlan
{
	public string Name { get; set; }

	public string File { get; set; }

	public string Description { get; set; }

	public string BuiltInGuid { get; set; }

	public string DuplicateFromGuid { get; set; }
}
