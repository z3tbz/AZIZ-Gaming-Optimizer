﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Aziz;

internal static class AzizPresets
{
	private static readonly string[] BothOn;

	private static readonly string[] BothOff;

	private static readonly string[] BasicOnly;

	private static readonly string[] UltraOnly;

	public static readonly Dictionary<string, string> Basic;

	public static readonly Dictionary<string, string> Ultra;

	public static readonly Dictionary<string, string> Network;

	public static readonly string[] SecurityOn;

	private static string[] Ids(string text)
	{
		return text.Split(new char[3] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
	}

	private static Dictionary<string, string> Make(bool ultra)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		string[] bothOn = BothOn;
		foreach (string key in bothOn)
		{
			dictionary[key] = "Enabled";
		}
		bothOn = BothOff;
		foreach (string key2 in bothOn)
		{
			dictionary[key2] = "Disabled";
		}
		bothOn = BasicOnly;
		foreach (string key3 in bothOn)
		{
			dictionary[key3] = (ultra ? "Disabled" : "Enabled");
		}
		bothOn = UltraOnly;
		foreach (string key4 in bothOn)
		{
			dictionary[key4] = (ultra ? "Enabled" : "Disabled");
		}
		bool amd = Engine.CpuVendor() == "AuthenticAMD";
		dictionary["disable-interrupt-steering"] = (amd ? "Enabled" : "Disabled");
		dictionary["serialize-timer-expiration"] = (amd ? "Enabled" : "Disabled");
		dictionary["foreground-boost"] = "40";
		dictionary["input-data-queue"] = "100";
		dictionary["csrss-priority"] = "3";
		dictionary["cpu-boost-settings"] = "boost:100";
		return dictionary;
	}

	static AzizPresets()
	{
		BothOn = Ids("low-latency-cpu disable-animations dynamic-lighting center-taskbar combine-taskbar-buttons end-task-right-click show-hidden-files legacy-context-menu dark-theme settings-home start-recommendations window-snapping menu-delay explorer-launch-target disable-throttle-states responsive-time-trigger system-responsiveness nvidia-hdcp nvidia-no-scaling gpu-preemption hags mpo windowed-optimizations keyboard-response mouse-throttling mouse-one-to-one text-input-service threaded-dpc disable-timer-coalescing disable-dynamic-tick tsc-sync-policy energy-estimation fixed-pagefile");
		BothOff = Ids("windows-update telemetry disable-apps-telemetry activity-history bgapps consumer-features auto-defrag storagesense wifi bluetooth hotspot auto-driver-updates location printing taskbar-search taskbar-task-view taskbar-battery small-desktop-icons transparency scrollbars-visible start-bing-search sticky-keys cpu-minimum hibernation interrupt-steering modern-standby-fix pcie-power-saving power-throttling-off disable-tsx tdr-delay gpu-latency-tolerance nvidia-crash-reports nvidia-ecc nvidia-telemetry-tasks fullscreen-optimizations variable-refresh-rate windows-game-mode game-bar kernel-paging-executive long-paths memory-compression ntfs-last-access sysmain distribute-timers allowed-in-memory-settings use-platform-tick auto-reboot-crash fault-tolerant-heap auto-maintenance copilot-policy error-reporting notifications onedrive-policy search-indexing usb3-link-power deep-sleep event-processor");
		BasicOnly = Ids("power-saving energyrecs usb-selective-suspend audio-enhancements");
		UltraOnly = Ids("cpu-latency-tolerance no-lazy-mode nvidia-memory-compression nvme-latency disable-platform-clock global-timer-resolution");
		Basic = Make(ultra: false);
		Ultra = Make(ultra: true);
		Network = Ids("nic-interrupt-moderation nic-lso nagle-algorithm tcp-autotuning network-throttling qos-reserved-bandwidth tcp-congestion tcp-rsc tcpip-task-offload").ToDictionary((string x) => x, (string x) => "Enabled");
		SecurityOn = Ids("user-account-control vulnerable-driver-blocklist");
		string[] array = Ids("tcp-ack-frequency ndu-service netbios llmnr fast-send-datagram-threshold nic-eee delivery-optimization-p2p");
		foreach (string key in array)
		{
			Network[key] = "Disabled";
		}
	}
}
