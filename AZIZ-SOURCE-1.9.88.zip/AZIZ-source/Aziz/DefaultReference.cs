namespace Aziz;

internal class DefaultReference
{
	public string Windows { get; set; }

	public string Playbook { get; set; }
}
