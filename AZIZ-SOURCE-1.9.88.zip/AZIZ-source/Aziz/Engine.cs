using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using Microsoft.Win32;

namespace Aziz;

public sealed class Engine
{
	private readonly object gate = new object();

	private readonly string dataPath;

	public static string ActiveProfileName;

	private static string vendor;

	private readonly Dictionary<string, object> idGates = new Dictionary<string, object>();

	private static readonly object bcdLane = new object();

	private static readonly object componentLane = new object();

	private static readonly object mitigationLane = new object();

	private static readonly object sysmainLane = new object();

	private static readonly object powerLane = new object();

	private static readonly object logGate = new object();

	private static readonly Dictionary<string, Tuple<DateTime, TweakStatus>> probeCache = new Dictionary<string, Tuple<DateTime, TweakStatus>>();

	private JavaScriptSerializer json => new JavaScriptSerializer
	{
		MaxJsonLength = 16777216
	};

	public List<Tweak> Tweaks { get; private set; }

	public string DataPath => dataPath;

	public static bool IsAdministrator
	{
		get
		{
			using WindowsIdentity ntIdentity = WindowsIdentity.GetCurrent();
			return new WindowsPrincipal(ntIdentity).IsInRole(WindowsBuiltInRole.Administrator);
		}
	}

	public Engine()
		: this(null, null)
	{
	}

	public Engine(string catalogPath, string statePath)
	{
		dataPath = statePath ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AZIZ", "GamingOptimizer");
		string input = null;
		if (catalogPath != null)
		{
			input = File.ReadAllText(catalogPath);
		}
		else
		{
			Assembly assembly = typeof(Engine).Assembly;
			string text = assembly.GetManifestResourceNames().FirstOrDefault((string x) => x.EndsWith("catalog.json", StringComparison.OrdinalIgnoreCase));
			if (text != null)
			{
				using Stream stream = assembly.GetManifestResourceStream(text);
				using StreamReader streamReader = new StreamReader(stream);
				input = streamReader.ReadToEnd();
			}
			else
			{
				input = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "catalog.json"));
			}
		}
		Tweaks = json.Deserialize<List<Tweak>>(input);
		if (Tweaks == null || (from x in Tweaks
			group x by x.Id).Any((IGrouping<string, Tweak> g) => g.Count() != 1))
		{
			throw new InvalidDataException("Invalid or duplicate tweak IDs.");
		}
		try
		{
			string path = Path.Combine(dataPath, "snapshots", "disable-bitlocker.json");
			string path2 = Path.Combine(dataPath, "snapshots", "bitlocker.json");
			if (File.Exists(path) && !File.Exists(path2))
			{
				File.WriteAllText(path2, File.ReadAllText(path).Replace("\"disable-bitlocker\"", "\"bitlocker\""));
			}
		}
		catch
		{
		}
	}

	private static TweakStatus Status(string state, string detail)
	{
		return new TweakStatus
		{
			State = state,
			Detail = detail
		};
	}

	private RegistryKey Root(string hive)
	{
		return RegistryKey.OpenBaseKey((hive == "HKCU") ? RegistryHive.CurrentUser : RegistryHive.LocalMachine, Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32);
	}

	private object Read(RegistryOperation op)
	{
		using RegistryKey registryKey = Root(op.Hive);
		using RegistryKey key = registryKey.OpenSubKey(op.Path);
		return RawRegistry.Read(key, op.Name);
	}

	private List<RegistryOperation> Expand(IEnumerable<RegistryOperation> operations)
	{
		List<RegistryOperation> list = new List<RegistryOperation>();
		if (operations == null)
		{
			return list;
		}
		foreach (RegistryOperation operation in operations)
		{
			int num = operation.Path.IndexOf('*');
			if (num < 0)
			{
				if (operation.ExistingKeyOnly)
				{
					using RegistryKey registryKey = Root(operation.Hive);
					using RegistryKey registryKey2 = registryKey.OpenSubKey(operation.Path);
					if (registryKey2 == null)
					{
						continue;
					}
				}
				list.Add(operation);
				continue;
			}
			string text = operation.Path.Substring(0, num).TrimEnd('\\');
			string text2 = operation.Path.Substring(num + 1);
			using RegistryKey registryKey3 = Root(operation.Hive);
			using RegistryKey registryKey4 = registryKey3.OpenSubKey(text);
			if (registryKey4 != null)
			{
				string[] subKeyNames = registryKey4.GetSubKeyNames();
				foreach (string text3 in subKeyNames)
				{
					list.Add(new RegistryOperation
					{
						Hive = operation.Hive,
						Path = text + "\\" + text3 + text2,
						Name = operation.Name,
						Kind = operation.Kind,
						Value = operation.Value,
						Token = operation.Token
					});
				}
			}
		}
		return list;
	}

	private static bool Same(object a, object b)
	{
		if (a == null || b == null)
		{
			if (a == null)
			{
				return b == null;
			}
			return false;
		}
		if (a is byte[] first)
		{
			if (!(b is IEnumerable source))
			{
				return false;
			}
			return first.SequenceEqual(source.Cast<object>().Select(Convert.ToByte));
		}
		if (a is string[] first2)
		{
			if (!(b is IEnumerable source2))
			{
				return false;
			}
			return first2.SequenceEqual(source2.Cast<object>().Select(Convert.ToString));
		}
		return Convert.ToString(a, CultureInfo.InvariantCulture) == Convert.ToString(b, CultureInfo.InvariantCulture);
	}

	private bool Matches(RegistryOperation op)
	{
		object obj = Read(op);
		if (op.Kind == "PageVisibility")
		{
			return PageHomeVisible(Convert.ToString(obj)) == (Convert.ToInt32(op.Value) == 1);
		}
		if (op.Kind == "StickyFlags")
		{
			int.TryParse(Convert.ToString(obj), out var result);
			return (result & 1) != 0 == (Convert.ToInt32(op.Value) == 1);
		}
		if (!string.IsNullOrEmpty(op.Token))
		{
			obj = (Convert.ToString(obj) ?? "").Split(';').FirstOrDefault((string x) => x.StartsWith(op.Token + "=", StringComparison.OrdinalIgnoreCase))?.Substring(op.Token.Length + 1);
		}
		return Same(obj, op.Value);
	}

	public Dictionary<string, TweakStatus> Scan()
	{
		return Scan(null);
	}

	public Dictionary<string, TweakStatus> Scan(IEnumerable<string> ids)
	{
		return Scan(ids, fresh: true);
	}

	public Dictionary<string, TweakStatus> Scan(IEnumerable<string> ids, bool fresh)
	{
		Dictionary<string, TweakStatus> result = new Dictionary<string, TweakStatus>();
		HashSet<string> wanted = ((ids == null) ? null : new HashSet<string>(ids));
		List<Tweak> list;
		lock (gate)
		{
			list = ((wanted == null) ? Tweaks.ToList() : Tweaks.Where((Tweak t) => wanted.Contains(t.Id)).ToList());
		}
		foreach (Tweak item in list)
		{
			result[item.Id] = ScanOne(item, native: false);
			if (string.IsNullOrWhiteSpace(item.ProbeScript) || !(result[item.Id].State != "Unavailable"))
			{
				continue;
			}
			if (NativeProbes.TryProbe(item, out var status))
			{
				result[item.Id] = Combine(item, status);
			}
			else
			{
				if (fresh)
				{
					continue;
				}
				lock (probeCache)
				{
					if (probeCache.TryGetValue(item.Id, out var value) && (DateTime.UtcNow - value.Item1).TotalSeconds < (HeavyProbes.Contains(item.Id) ? 600.0 : 60.0))
					{
						result[item.Id] = value.Item2;
					}
				}
			}
		}
		List<Tweak> list2 = list.Where((Tweak t) => !string.IsNullOrWhiteSpace(t.ProbeScript) && result[t.Id].State != "Unavailable" && result[t.Id].Detail == "Reading live system state…").ToList();
		// Windows-feature probes (DISM) can take minutes on a busy PC: each runs alone with a longer limit, so it never
		// makes the quick probes of its batch time out.
		List<List<Tweak>> list3 = list2.Where((Tweak t) => HeavyProbes.Contains(t.Id)).Select((Tweak t) => new List<Tweak> { t }).ToList();
		list2 = list2.Where((Tweak t) => !HeavyProbes.Contains(t.Id)).ToList();
		int num = 0;
		while (num < list2.Count)
		{
			List<Tweak> list4 = new List<Tweak>();
			int num2 = 0;
			while (num < list2.Count && (list4.Count == 0 || num2 + list2[num].ProbeScript.Length < 6500))
			{
				Tweak tweak = list2[num++];
				list4.Add(tweak);
				num2 += tweak.ProbeScript.Length + 200;
			}
			list3.Add(list4);
		}
		SemaphoreSlim slots = new SemaphoreSlim((ids != null) ? 1 : Math.Max(1, Math.Min(2, Environment.ProcessorCount / 2)));
		try
		{
			Task[] tasks;
			Task[] array = (tasks = list3.Select((List<Tweak> batch) => Task.Run(delegate
			{
				slots.Wait();
				try
				{
					Dictionary<string, TweakStatus> dictionary = new Dictionary<string, TweakStatus>();
					StringBuilder stringBuilder = new StringBuilder("$result=@{};\n");
					foreach (Tweak item2 in batch)
					{
						stringBuilder.Append("try{$result['").Append(item2.Id.Replace("'", "''")).Append("']=(& { ")
							.Append(item2.ProbeScript)
							.Append(" })}catch{$result['")
							.Append(item2.Id.Replace("'", "''"))
							.Append("']=@{State='Unknown';Detail=$_.Exception.Message}};\n");
					}
					stringBuilder.Append("$result | ConvertTo-Json -Depth 8 -Compress");
					try
					{
						dictionary = new JavaScriptSerializer
						{
							MaxJsonLength = 16777216
						}.Deserialize<Dictionary<string, TweakStatus>>(PowerShell(stringBuilder.ToString(), batch.Any((Tweak x) => HeavyProbes.Contains(x.Id)) ? 600000 : 45000));
					}
					catch (Exception ex)
					{
						foreach (Tweak item3 in batch)
						{
							dictionary[item3.Id] = Status("Unknown", "Live probe failed: " + ex.Message);
						}
					}
					return dictionary;
				}
				finally
				{
					slots.Release();
				}
			})).ToArray());
			Task.WaitAll(tasks);
			Task<Dictionary<string, TweakStatus>>[] array2 = (Task<Dictionary<string, TweakStatus>>[])array;
			for (int i = 0; i < array2.Length; i++)
			{
				foreach (KeyValuePair<string, TweakStatus> pair in array2[i].Result)
				{
					KeyValuePair<string, TweakStatus> keyValuePair = pair;
					if (keyValuePair.Value == null)
					{
						continue;
					}
					Tweak tweak2 = list.FirstOrDefault(delegate(Tweak t)
					{
						string id = t.Id;
						KeyValuePair<string, TweakStatus> keyValuePair2 = pair;
						return id == keyValuePair2.Key;
					});
					if (tweak2 != null)
					{
						TweakStatus tweakStatus = Combine(tweak2, pair.Value);
						result[pair.Key] = tweakStatus;
						lock (probeCache)
						{
							probeCache[pair.Key] = Tuple.Create(DateTime.UtcNow, tweakStatus);
						}
					}
				}
			}
		}
		finally
		{
			if (slots != null)
			{
				((IDisposable)slots).Dispose();
			}
		}
		return result;
	}

	// Read once: the build does not change while AZIZ runs (was read for every option of every scan).
	private static readonly int WindowsBuild = ReadBuild();

	private static int ReadBuild()
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion");
			int.TryParse(Convert.ToString(registryKey?.GetValue("CurrentBuildNumber")), out var result);
			return result;
		}
		catch
		{
			return 0;
		}
	}

	// Probes that cost seconds (Windows features through DISM, BitLocker) are kept 10 minutes instead of 1.
	private static readonly HashSet<string> HeavyProbes = new HashSet<string> { "hyper-v", "virtualization-stack", "bitlocker" };

	private TweakStatus ScanOne(Tweak t, bool native)
	{
		try
		{
			int result = WindowsBuild;
			if (result > 0 && t.MinBuild > result)
			{
				return Status("Unavailable", "Requires Windows build " + t.MinBuild + " or later; current build " + result + ".");
			}
			if (t.Kind == "Unavailable")
			{
				return Status("Unavailable", t.AvailabilityNote);
			}
			if (!string.IsNullOrEmpty(t.CpuVendor) && !string.Equals(CpuVendor(), t.CpuVendor, StringComparison.OrdinalIgnoreCase))
			{
				return Status("Unavailable", ((t.CpuVendor == "AuthenticAMD") ? "AMD" : t.CpuVendor) + " processors only; this PC reports " + (CpuVendor() ?? "an unknown processor") + ".");
			}
			if (t.Kind == "PowerSwitch" || t.Kind == "PowerConfigure")
			{
				return PowerControls.State(t.Id);
			}
			if (t.Kind == "Timer")
			{
				return TimerLease.State();
			}
			if (t.Kind == "NvidiaHdcp")
			{
				return DisplayHardware.Hdcp(t);
			}
			if (t.Kind == "NvidiaMemoryCompression")
			{
				return DisplayHardware.MemoryCompression(t);
			}
			if (t.Kind == "NvidiaScaling")
			{
				return NvidiaScaling.State();
			}
			if (t.Kind == "Action")
			{
				return Status("Disabled", "Windows action; read the details for its one-boot behavior.");
			}
			if (t.Kind == "GpuMsi")
			{
				return GpuInterrupt.State();
			}
			if (t.Kind == "SystemRestore")
			{
				return SystemRestore.State();
			}
			if (t.Kind == "Service")
			{
				using (RegistryKey registryKey2 = Root("HKLM"))
				{
					using RegistryKey registryKey3 = registryKey2.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + t.Service);
					if (registryKey3 == null)
					{
						return Status("Disabled", "Startup: Disabled; not installed on this device. Enabling needs component recovery.");
					}
					int num = Convert.ToInt32(registryKey3.GetValue("Start", -1));
					string text = "";
					try
					{
						using ServiceController serviceController = new ServiceController(t.Service);
						text = serviceController.Status.ToString();
					}
					catch
					{
					}
					if (num != 4 && !ServiceInventory.IsDriver(t.Service) && !ServiceAvailability.Ready(t.Service, out var reason))
					{
						// The start type stays in the detail: profiles compare it, so a service whose dependency is off still
						// matches its preset instead of being re-applied on every Optimize.
						return Status("Disabled", reason + "; Startup: " + ServicePresets.StartText(num) + "; runtime: " + text);
					}
					object obj2;
					switch (num)
					{
					default:
						obj2 = "Unknown";
						break;
					case 0:
					case 1:
					case 2:
					case 3:
						obj2 = "Enabled";
						break;
					case 4:
						obj2 = "Disabled";
						break;
					}
					return Status((string)obj2, "Startup: " + ServicePresets.StartText(num) + "; runtime: " + text);
				}
			}
			if (t.Kind == "Bcd")
			{
				string text2 = BcdRead(t.BcdKey);
				return Status((text2 == (t.BcdOnValue ?? "yes")) ? "Enabled" : "Disabled", "Configured boot value (" + text2 + "); restart required after changes.");
			}
			if (!string.IsNullOrEmpty(t.ReadMode))
			{
				if (t.ReadMode == "TimerCoalescing")
				{
					object obj3 = Read(t.Enable[0]);
					byte[] array = Read(t.Enable[1]) as byte[];
					bool num2 = Same(obj3, 0) && array != null && array.All((byte b) => b == 0);
					bool flag = obj3 == null && array == null;
					return Status(num2 ? "Enabled" : (flag ? "Disabled" : "Mixed"), "Timer coalescing overrides: interval=" + Convert.ToString(obj3 ?? "default") + ", binary bytes=" + ((array == null) ? "missing" : array.Length.ToString()) + ". Off deletes both overrides.");
				}
				if (t.Id == "copilot-policy")
				{
					// Off = the policies that actually switch Cortana and Copilot off; the notification extras do not decide it.
					List<RegistryOperation> core = Expand(t.Disable).Where((RegistryOperation o) => o.Name == "AllowCortana" || o.Name == "TurnOffWindowsCopilot").ToList();
					List<RegistryOperation> notSet = core.Where((RegistryOperation o) => !Matches(o)).ToList();
					if (notSet.Count == 0)
					{
						return Status("Disabled", "Cortana and Copilot are turned off by policy.");
					}
					return Status((notSet.Count == core.Count) ? "Enabled" : "Mixed", ((notSet.Count == core.Count) ? "" : "Mixed · cause: ") + "not set yet: " + PartNames(notSet));
				}
				bool flag2;
				if (t.ReadMode == "DriverUpdates")
				{
					flag2 = !t.Disable.Any((RegistryOperation o) => o.Value != null && Matches(o));
				}
				else if (!(t.ReadMode == "Nonzero"))
				{
					flag2 = ((!(t.ReadMode == "Mpo")) ? ((t.ReadMode == "Energy") ? t.Disable.Where((RegistryOperation o) => o.Name != "EnergySaverState").All((RegistryOperation o) => Read(o) == null || !Same(Read(o), 0)) : ((!(t.ReadMode == "DefaultOff")) ? (!t.Disable.All(Matches)) : t.Enable.All(Matches))) : (!Same(Read(t.Disable.First((RegistryOperation o) => o.Name == "OverlayTestMode")), 5) && !Same(Read(t.Enable.First((RegistryOperation o) => o.Name == "DisableOverlays")), 1) && !Same(Read(t.Enable.First((RegistryOperation o) => o.Name == "EnableOverlay")), 0)));
				}
				else
				{
					object obj4 = Read(t.Enable[0]);
					flag2 = obj4 == null || Convert.ToInt32(obj4) != 0;
				}
				if (t.ReadMode != "Mpo" && t.ReadMode != "Energy" && t.ReadMode != "Nonzero")
				{
					// Several values: only all-on or all-off is a clean state; anything between is Mixed and names the parts.
					List<RegistryOperation> on = Expand(t.Enable);
					List<RegistryOperation> off = Expand(t.Disable);
					if (on.Count > 1 && !on.All(Matches) && !off.All(Matches) && (on.Any((RegistryOperation o) => o.Value != null && Matches(o)) || off.Any((RegistryOperation o) => o.Value != null && Matches(o))))
					{
						return Status("Mixed", "Mixed: " + on.Count(Matches) + " of " + on.Count + " parts on.\nOn: " + PartNames(on.Where(Matches).ToList()) + "\nOff (cause): " + PartNames(on.Where((RegistryOperation o) => !Matches(o)).ToList()));
					}
				}
				return Status(flag2 ? "Enabled" : "Disabled", "Configured Windows state; missing values use Windows defaults. Runtime may require restart.");
			}
			if (!string.IsNullOrEmpty(t.ProbeScript))
			{
				if (!native)
				{
					return Status("Unknown", "Reading live system state…");
				}
				if (NativeProbes.TryProbe(t, out var status))
				{
					return Combine(t, status);
				}
				return Combine(t, json.Deserialize<TweakStatus>(PowerShell("& {" + t.ProbeScript + "} | ConvertTo-Json -Depth 6 -Compress", HeavyProbes.Contains(t.Id) ? 600000 : 45000)));
			}
			List<RegistryOperation> list = Expand(t.Enable);
			List<RegistryOperation> list2 = Expand(t.Disable);
			if (t.Id == "disable-animations")
			{
				// Animations & Visual Effects: the UserPreferencesMask bits are rewritten by Windows itself, and the two effects
				// kept on in both states (window contents while dragging, font smoothing) say nothing about On or Off.
				// A part decides the state only when its On and Off values differ: each op is compared with the other side.
				Func<RegistryOperation, List<RegistryOperation>, bool> decides = (RegistryOperation o, List<RegistryOperation> other) => o.Kind != "Binary" && !Same(o.Value, other.Where((RegistryOperation x) => string.Equals(x.Path, o.Path, StringComparison.OrdinalIgnoreCase) && string.Equals(x.Name, o.Name, StringComparison.OrdinalIgnoreCase)).Select((RegistryOperation x) => x.Value).FirstOrDefault());
				List<RegistryOperation> on = list.Where((RegistryOperation o) => decides(o, list2)).ToList();
				List<RegistryOperation> off = list2.Where((RegistryOperation o) => decides(o, list)).ToList();
				list = on;
				list2 = off;
			}
			if (list.Count == 0 || list2.Count == 0)
			{
				return Status("Unavailable", string.IsNullOrEmpty(t.AvailabilityNote) ? "No supported target was discovered." : t.AvailabilityNote);
			}
			if (t.Choices != null && t.Choices.Count > 0)
			{
				object value = Read(list[0]);
				TweakChoice tweakChoice = t.Choices.FirstOrDefault((TweakChoice c) => Same(c.Value, value));
				if (!list.All((RegistryOperation o) => Same(Read(o), value)))
				{
					return Status("Mixed", "The configured targets have different values. Select a value to set them together.");
				}
				return Status((value == null) ? "Unknown" : "Enabled", "Configured value: " + ((tweakChoice == null) ? Convert.ToString(value ?? "Windows default") : (tweakChoice.Label + " (" + tweakChoice.Value + ")")));
			}
			bool flag3 = list.All(Matches);
			bool flag4 = list2.All(Matches);
			string detail = (t.RequiresRestart ? "Configured state. Restart may be required for active behavior." : "Verified from current system settings.");
			if (flag3 && !flag4)
			{
				return Status("Enabled", detail);
			}
			if (flag4 && !flag3)
			{
				return Status("Disabled", detail);
			}
			if (list.Concat(list2).ToList().Any((RegistryOperation o) => Read(o) != null))
			{
				List<RegistryOperation> list3 = list2.Where(Matches).ToList();
				List<RegistryOperation> source = list2.Where((RegistryOperation o) => !Matches(o)).ToList();
				List<RegistryOperation> onParts = list.Where(Matches).ToList();
				List<RegistryOperation> offParts = list.Where((RegistryOperation o) => !Matches(o)).ToList();
				return Status("Mixed", "Mixed: " + onParts.Count + " of " + list.Count + " parts on.\nOn: " + PartNames(onParts) + "\nOff (cause): " + PartNames(offParts));
			}
			return Status("Unknown", "Windows default / value not explicitly configured. No changes were made.");
		}
		catch (UnauthorizedAccessException)
		{
			return Status("Unknown", "Access denied while reading; run as administrator.");
		}
		catch (Exception ex2)
		{
			return Status("Unknown", ex2.Message);
		}
	}

	internal static string CpuVendor()
	{
		if (vendor == null)
		{
			try
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0");
				vendor = ((registryKey == null) ? "" : (Convert.ToString(registryKey.GetValue("VendorIdentifier")) ?? ""));
			}
			catch
			{
				vendor = "";
			}
		}
		if (vendor.Length != 0)
		{
			return vendor;
		}
		return null;
	}

	// Every registry part of a control with its live value: On (matches the On value), Off (matches the Off value) or Other.
	public List<Tuple<RegistryOperation, string, string>> LiveParts(Tweak t)
	{
		List<Tuple<RegistryOperation, string, string>> list = new List<Tuple<RegistryOperation, string, string>>();
		if (t == null || t.Enable == null || t.Disable == null)
		{
			return list;
		}
		try
		{
			List<RegistryOperation> off = Expand(t.Disable);
			foreach (RegistryOperation op in Expand(t.Enable))
			{
				// A clean-up delete with no Off counterpart is not a part of the switch: leave it out of the list.
				if (op.Value == null && !off.Any((RegistryOperation o) => string.Equals(o.Hive, op.Hive, StringComparison.OrdinalIgnoreCase) && string.Equals(o.Path, op.Path, StringComparison.OrdinalIgnoreCase) && string.Equals(o.Name, op.Name, StringComparison.OrdinalIgnoreCase)))
				{
					continue;
				}
				RegistryOperation registryOperation = off.FirstOrDefault((RegistryOperation o) => string.Equals(o.Hive, op.Hive, StringComparison.OrdinalIgnoreCase) && string.Equals(o.Path, op.Path, StringComparison.OrdinalIgnoreCase) && string.Equals(o.Name, op.Name, StringComparison.OrdinalIgnoreCase));
				if (registryOperation != null && Same(registryOperation.Value, op.Value))
				{
					continue;
				}
				object obj = Read(op);
				string item = (Matches(op) ? "On" : ((registryOperation != null && Matches(registryOperation)) ? "Off" : "Other"));
				list.Add(Tuple.Create(op, item, (obj == null) ? "not set" : ((obj is byte[] array) ? (array.Length + " bytes") : Convert.ToString(obj))));
			}
		}
		catch
		{
		}
		return list;
	}

	private static string PartNames(List<RegistryOperation> parts)
	{
		if (parts.Count == 0)
		{
			return "none";
		}
		List<string> list = parts.Select((RegistryOperation o) => o.Name + " (" + o.Path.Split('\\').Last() + ")").Distinct().ToList();
		return string.Join(", ", list.Take(12)) + ((list.Count > 12) ? (" … +" + (list.Count - 12)) : "");
	}

	private TweakStatus Combine(Tweak t, TweakStatus status)
	{
		if (status == null)
		{
			return Status("Unknown", "No state returned by the system probe.");
		}
		if (status.State != "Enabled" && status.State != "Disabled")
		{
			return status;
		}
		if (t.ProbeAuthoritative)
		{
			return status;
		}
		List<RegistryOperation> list = Expand((status.State == "Enabled") ? t.Enable : t.Disable);
		if (list.Count > 0 && !list.All(Matches))
		{
			return Status("Mixed", status.Detail + "\nMixed: the live state is " + ((status.State == "Enabled") ? "On" : "Off") + " but these registry parts are not: " + PartNames(list.Where((RegistryOperation o) => !Matches(o)).ToList()));
		}
		return status;
	}

	// Saved Windows originals of every registry value an option owns (see RegistryJournal.Originals).
	public Dictionary<string, SavedValue> OriginalIndex()
	{
		Dictionary<string, SavedValue> dictionary = new Dictionary<string, SavedValue>();
		List<Tweak> list;
		lock (gate)
		{
			list = Tweaks.Where((Tweak t) => t.Kind != "Service").ToList();
		}
		foreach (Tweak item in list)
		{
			try
			{
				string path = SnapshotPath(item.Id);
				if (!File.Exists(path))
				{
					continue;
				}
				TweakSnapshot tweakSnapshot = json.Deserialize<TweakSnapshot>(File.ReadAllText(path));
				foreach (SavedValue value in tweakSnapshot?.Values ?? new List<SavedValue>())
				{
					if (!string.IsNullOrEmpty(value.Hive) && !string.IsNullOrEmpty(value.Path) && !string.IsNullOrEmpty(value.Name))
					{
						string key = RegistryJournal.KeyOf(value.Hive, value.Path, value.Name);
						if (!dictionary.ContainsKey(key))
						{
							dictionary[key] = value;
						}
					}
				}
			}
			catch
			{
			}
		}
		return dictionary;
	}

	private string SnapshotPath(string id)
	{
		if (!Regex.IsMatch(id, "^[a-zA-Z0-9._-]+$"))
		{
			throw new InvalidDataException("Invalid tweak ID.");
		}
		return Path.Combine(dataPath, "snapshots", id + ".json");
	}

	public bool CanRestore(string id)
	{
		Tweak tweak = Find(id);
		if (tweak != null && (tweak.Kind == "PowerSwitch" || tweak.Kind == "PowerConfigure"))
		{
			return PowerControls.CanRestore(dataPath, id);
		}
		return File.Exists(SnapshotPath(id));
	}

	private void AtomicSave(string path, string text)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string text2 = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		using (FileStream fileStream = new FileStream(text2, FileMode.CreateNew, FileAccess.Write, FileShare.None))
		{
			byte[] bytes = Encoding.UTF8.GetBytes(text);
			fileStream.Write(bytes, 0, bytes.Length);
			fileStream.Flush(flushToDisk: true);
		}
		if (File.Exists(path))
		{
			File.Replace(text2, path, null);
		}
		else
		{
			File.Move(text2, path);
		}
	}

	private TweakSnapshot Capture(Tweak t)
	{
		TweakSnapshot tweakSnapshot = new TweakSnapshot
		{
			Id = t.Id,
			CreatedUtc = DateTime.UtcNow.ToString("o"),
			Values = new List<SavedValue>()
		};
		foreach (RegistryOperation item in from o in Expand((t.Enable ?? new List<RegistryOperation>()).Concat(t.Disable ?? new List<RegistryOperation>()))
			group o by o.Hive + "|" + o.Path + "|" + o.Name into g
			select g.First())
		{
			using RegistryKey registryKey = Root(item.Hive);
			using RegistryKey key = registryKey.OpenSubKey(item.Path);
			object obj = RawRegistry.Read(key, item.Name);
			tweakSnapshot.Values.Add(new SavedValue
			{
				Hive = item.Hive,
				Path = item.Path,
				Name = item.Name,
				Exists = (obj != null),
				Kind = ((obj == null) ? "None" : RawRegistry.Kind(key, item.Name)),
				Value = obj
			});
		}
		if (t.Kind == "Service")
		{
			using RegistryKey registryKey2 = Root("HKLM");
			using RegistryKey registryKey3 = registryKey2.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + t.Service);
			if (registryKey3 == null)
			{
				throw new InvalidOperationException("Service is not installed.");
			}
			tweakSnapshot.ServiceStart = Convert.ToInt32(registryKey3.GetValue("Start"));
			tweakSnapshot.ServiceDelayed = Convert.ToInt32(registryKey3.GetValue("DelayedAutoStart", 0)) == 1;
			try
			{
				using ServiceController serviceController = new ServiceController(t.Service);
				tweakSnapshot.ServiceRunning = serviceController.Status == ServiceControllerStatus.Running;
			}
			catch (InvalidOperationException)
			{
				tweakSnapshot.ServiceRunning = false;
			}
		}
		if (!string.IsNullOrEmpty(t.EnableScript) || !string.IsNullOrEmpty(t.DisableScript))
		{
			if (string.IsNullOrEmpty(t.CaptureScript) || string.IsNullOrEmpty(t.RestoreScript))
			{
				throw new InvalidOperationException("Reversible handler is not available.");
			}
			tweakSnapshot.Native = Capture(t.CaptureScript, t);
			if (string.IsNullOrWhiteSpace(tweakSnapshot.Native))
			{
				throw new InvalidOperationException("Could not capture native state.");
			}
		}
		if (t.Kind == "Bcd")
		{
			tweakSnapshot.Native = BcdRead(t.BcdKey);
		}
		return tweakSnapshot;
	}

	private void Write(RegistryOperation op)
	{
		try
		{
			WriteDirect(op);
		}
		catch (Exception ex)
		{
			if (!(ex is UnauthorizedAccessException) && !(ex is SecurityException))
			{
				throw;
			}
			if (SystemRunner.BackupWrite(op) || SystemRunner.WriteRegistry(op))
			{
				return;
			}
			throw;
		}
	}

	private void WriteDirect(RegistryOperation op)
	{
		using RegistryKey registryKey = Root(op.Hive);
		if (op.Value == null && string.IsNullOrEmpty(op.Token))
		{
			using (RegistryKey registryKey2 = registryKey.OpenSubKey(op.Path, writable: true))
			{
				registryKey2?.DeleteValue(op.Name, throwOnMissingValue: false);
				return;
			}
		}
		using RegistryKey registryKey3 = registryKey.CreateSubKey(op.Path);
		object obj = op.Value;
		if (op.Kind == "PageVisibility")
		{
			registryKey3.SetValue(op.Name, SetPageHome(Convert.ToString(registryKey3.GetValue(op.Name, "")), Convert.ToInt32(obj) == 1), RegistryValueKind.String);
			return;
		}
		if (op.Kind == "StickyFlags")
		{
			if (!int.TryParse(Convert.ToString(registryKey3.GetValue(op.Name, "510")), out var result))
			{
				throw new IOException("Invalid Sticky Keys flags");
			}
			registryKey3.SetValue(op.Name, ((result & -2) | ((Convert.ToInt32(obj) == 1) ? 1 : 0)).ToString(), RegistryValueKind.String);
			return;
		}
		if (op.Kind == "None" || op.Kind.StartsWith("Raw:"))
		{
			RawRegistry.WriteRaw(registryKey3, op.Name, (!(op.Kind == "None")) ? uint.Parse(op.Kind.Substring(4)) : 0u, ((IEnumerable)obj).Cast<object>().Select(Convert.ToByte).ToArray());
			return;
		}
		RegistryValueKind registryValueKind = (RegistryValueKind)Enum.Parse(typeof(RegistryValueKind), op.Kind);
		if (!string.IsNullOrEmpty(op.Token))
		{
			List<string> list = (from x in (Convert.ToString(registryKey3.GetValue(op.Name, "")) ?? "").Split(';')
				where x.Length > 0 && !x.StartsWith(op.Token + "=", StringComparison.OrdinalIgnoreCase)
				select x).ToList();
			if (obj != null)
			{
				list.Add(op.Token + "=" + Convert.ToString(obj));
			}
			obj = string.Join(";", list) + ";";
			registryValueKind = RegistryValueKind.String;
		}
		switch (registryValueKind)
		{
		case RegistryValueKind.DWord:
			obj = (int)Convert.ToInt64(obj);
			break;
		case RegistryValueKind.QWord:
			obj = Convert.ToInt64(obj);
			break;
		case RegistryValueKind.Binary:
			obj = ((IEnumerable)obj).Cast<object>().Select(Convert.ToByte).ToArray();
			break;
		case RegistryValueKind.MultiString:
			obj = ((IEnumerable)obj).Cast<object>().Select(Convert.ToString).ToArray();
			break;
		}
		registryKey3.SetValue(op.Name, obj, registryValueKind);
	}

	private void SetService(Tweak t, int start, bool running, bool delayed)
	{
		if (start < 0 || start > 4)
		{
			throw new ArgumentOutOfRangeException("start");
		}
		if (string.IsNullOrWhiteSpace(t.Service) || t.Service.IndexOfAny(new char[3] { '"', '\r', '\n' }) >= 0)
		{
			throw new ArgumentException("Invalid service name.");
		}
		string text = start switch
		{
			3 => "demand", 
			2 => delayed ? "delayed-auto" : "auto", 
			1 => "system", 
			0 => "boot", 
			_ => "disabled", 
		};
		// The Service Control Manager is told directly (what sc.exe does), so a services preset no longer starts one
		// sc.exe process per service; sc.exe stays as the fallback, and the registry check below as the last resort.
		if (!ServiceConfig.SetStart(t.Service, start, delayed))
		{
			try
			{
				Run(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "sc.exe"), "config \"" + t.Service + "\" start= " + text, 15000);
			}
			catch
			{
			}
		}
		using (RegistryKey registryKey = Root("HKLM"))
		{
			using (RegistryKey registryKey2 = registryKey.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + t.Service))
			{
				if (registryKey2 == null)
				{
					throw new IOException("Service is not installed.");
				}
				if (Convert.ToInt32(registryKey2.GetValue("Start")) != start)
				{
					string path = "SYSTEM\\CurrentControlSet\\Services\\" + t.Service;
					Write(new RegistryOperation
					{
						Hive = "HKLM",
						Path = path,
						Name = "Start",
						Kind = "DWord",
						Value = start
					});
					if (start == 2)
					{
						Write(new RegistryOperation
						{
							Hive = "HKLM",
							Path = path,
							Name = "DelayedAutoStart",
							Kind = "DWord",
							Value = (delayed ? 1 : 0)
						});
					}
				}
			}
			Match match = Regex.Match(t.Service, "^(.+)_[0-9a-fA-F]{4,8}$");
			if (match.Success)
			{
				try
				{
					using RegistryKey registryKey3 = registryKey.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + match.Groups[1].Value);
					if (registryKey3 != null)
					{
						Write(new RegistryOperation
						{
							Hive = "HKLM",
							Path = "SYSTEM\\CurrentControlSet\\Services\\" + match.Groups[1].Value,
							Name = "Start",
							Kind = "DWord",
							Value = start
						});
					}
				}
				catch
				{
				}
			}
			using RegistryKey registryKey4 = registryKey.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + t.Service);
			if (registryKey4 == null || Convert.ToInt32(registryKey4.GetValue("Start")) != start)
			{
				throw new IOException("Service startup read-back failed.");
			}
		}
		if (ServiceInventory.IsDriver(t.Service))
		{
			return;
		}
		try
		{
			using ServiceController serviceController = new ServiceController(t.Service);
			serviceController.Refresh();
			if ((start == 4 || !running) && serviceController.Status != ServiceControllerStatus.Stopped)
			{
				serviceController.Stop();
				serviceController.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(5.0));
			}
			else if (running && serviceController.Status == ServiceControllerStatus.Stopped)
			{
				serviceController.Start();
				serviceController.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(5.0));
			}
		}
		catch
		{
		}
	}

	// A saved value is only written back when this option itself writes that value: snapshot files live in the user's
	// folder, so a changed file must never make AZIZ (running as admin) write some other registry key.
	private static bool Owned(Tweak t, SavedValue v)
	{
		foreach (RegistryOperation item in (t.Enable ?? new List<RegistryOperation>()).Concat(t.Disable ?? new List<RegistryOperation>()))
		{
			if (item == null || item.Path == null || !string.Equals(item.Hive, v.Hive, StringComparison.OrdinalIgnoreCase) || !string.Equals(item.Name, v.Name, StringComparison.OrdinalIgnoreCase))
			{
				continue;
			}
			if (item.Path.IndexOf('*') < 0)
			{
				if (string.Equals(item.Path.Trim('\\'), (v.Path ?? "").Trim('\\'), StringComparison.OrdinalIgnoreCase))
				{
					return true;
				}
			}
			else if (Regex.IsMatch(v.Path ?? "", "^" + Regex.Escape(item.Path.Trim('\\')).Replace("\\*", "[^\\\\]+") + "$", RegexOptions.IgnoreCase))
			{
				return true;
			}
		}
		return false;
	}

	private void RestoreSnapshot(Tweak t, TweakSnapshot snapshot)
	{
		snapshot.Values = (snapshot.Values ?? new List<SavedValue>()).Where((SavedValue v) => Owned(t, v)).ToList();
		if (t.Kind == "Service" && (snapshot.ServiceStart < 0 || snapshot.ServiceStart > 4))
		{
			throw new IOException("The saved startup type is not valid.");
		}
		if ((t.Kind == "NvidiaHdcp" || t.Kind == "NvidiaMemoryCompression") && snapshot.Values.Any((SavedValue v) => !t.Enable.Any((RegistryOperation o) => o.Path == v.Path && o.Name == v.Name)))
		{
			throw new IOException("The GPU driver path changed. The old snapshot cannot be written into the new driver installation. Switch Off to remove the current override.");
		}
		if (t.Kind == "Bcd")
		{
			BcdWrite(t.BcdKey, snapshot.Native);
			return;
		}
		if (t.Kind == "Service")
		{
			SetService(t, snapshot.ServiceStart, snapshot.ServiceRunning, snapshot.ServiceDelayed);
		}
		if (!string.IsNullOrEmpty(snapshot.Native))
		{
			// The saved state goes in as data (Base64 of checked JSON), never as script text.
			json.DeserializeObject(snapshot.Native);
			PowerShell("$snapshot=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + Convert.ToBase64String(Encoding.UTF8.GetBytes(snapshot.Native)) + "'))|ConvertFrom-Json;\n" + t.RestoreScript, Servicing(t) ? 1800000 : 120000);
		}
		foreach (SavedValue value in snapshot.Values)
		{
			Write(new RegistryOperation
			{
				Hive = value.Hive,
				Path = value.Path,
				Name = value.Name,
				Kind = value.Kind,
				Value = (value.Exists ? value.Value : null)
			});
		}
		foreach (SavedValue value2 in snapshot.Values)
		{
			if (!Same(Read(new RegistryOperation
			{
				Hive = value2.Hive,
				Path = value2.Path,
				Name = value2.Name
			}), value2.Exists ? value2.Value : null))
			{
				throw new IOException("Restoration verification failed: " + value2.Path + " / " + value2.Name);
			}
		}
		if (!string.IsNullOrEmpty(snapshot.Native))
		{
			string input = Capture(t.CaptureScript, t);
			// Running/stopped is not compared: trigger-start services (lfsvc, icssvc, WdiSystemHost…) start and stop by
			// themselves, and a correct restore must not be rolled back for that.
			string text = Canonical(WithoutRunning(json.DeserializeObject(input)));
			string text2 = Canonical(WithoutRunning(json.DeserializeObject(snapshot.Native)));
			if (text != text2)
			{
				throw new IOException("Native restoration read-back differs from the saved state (saved " + Utilities.Short(text2) + " · now " + Utilities.Short(text) + ").");
			}
		}
		if (t.Kind == "Service")
		{
			TweakSnapshot tweakSnapshot = Capture(t);
			// Startup type only: trigger-start services (WdiSystemHost, lfsvc, icssvc) start and stop by themselves, so their
			// running state is no reason to roll a correct restore back.
			if (tweakSnapshot.ServiceStart != snapshot.ServiceStart || (tweakSnapshot.ServiceStart == 2 && tweakSnapshot.ServiceDelayed != snapshot.ServiceDelayed))
			{
				throw new IOException("Service restoration read-back differs from saved startup/runtime state.");
			}
		}
	}

	private static object WithoutRunning(object value)
	{
		if (value is IDictionary<string, object> dictionary)
		{
			// A page file managed by Windows has no fixed entries worth comparing (Windows adds or drops them itself).
			bool automatic = dictionary.TryGetValue("Automatic", out var value2) && value2 is bool && (bool)value2;
			return dictionary.Where((KeyValuePair<string, object> p) => p.Key != "Running" && (!automatic || p.Key != "Files")).ToDictionary((KeyValuePair<string, object> p) => p.Key, (KeyValuePair<string, object> p) => WithoutRunning(p.Value));
		}
		if (value is object[] source)
		{
			return source.Select(WithoutRunning).ToArray();
		}
		return value;
	}

	private string Canonical(object value)
	{
		if (value is IDictionary<string, object> source)
		{
			return "{" + string.Join(",", source.OrderBy((KeyValuePair<string, object> p) => p.Key, StringComparer.Ordinal).Select(delegate(KeyValuePair<string, object> p)
			{
				JavaScriptSerializer javaScriptSerializer = json;
				KeyValuePair<string, object> keyValuePair = p;
				string text = javaScriptSerializer.Serialize(keyValuePair.Key);
				keyValuePair = p;
				return text + ":" + Canonical(keyValuePair.Value);
			})) + "}";
		}
		if (value is object[] source2)
		{
			return "[" + string.Join(",", source2.Select(Canonical)) + "]";
		}
		return json.Serialize(value);
	}

	private void SeedMerged(string id)
	{
		try
		{
			if (File.Exists(SnapshotPath(id)))
			{
				return;
			}
			TweakSnapshot tweakSnapshot = SnapshotEvolution.Seed(id, delegate(string other)
			{
				string path = SnapshotPath(other);
				return File.Exists(path) ? json.Deserialize<TweakSnapshot>(File.ReadAllText(path)) : null;
			});
			if (tweakSnapshot != null)
			{
				tweakSnapshot.Id = id;
				AtomicSave(SnapshotPath(id), json.Serialize(tweakSnapshot));
			}
		}
		catch
		{
		}
	}

	public int CaptureOriginals(Func<bool> cancelled)
	{
		SeedMerged("disable-animations");
		int num = 0;
		List<Tweak> list;
		lock (gate)
		{
			list = Tweaks.ToList();
		}
		string[] source = new string[8] { "Unavailable", "Timer", "GpuMsi", "Action", "Shortcut", "SystemRestore", "NvidiaScaling", "PowerConfigure" };
		foreach (Tweak item in list)
		{
			if (cancelled())
			{
				break;
			}
			if (source.Contains(item.Kind))
			{
				continue;
			}
			try
			{
				lock (GateFor(item.Id))
				{
					if (item.Kind == "PowerSwitch")
					{
						if (PowerControls.CaptureOriginal(dataPath, item.Id))
						{
							num++;
						}
					}
					else if (!CanRestore(item.Id))
					{
						TweakStatus tweakStatus = ScanOne(item, native: false);
						if (!(tweakStatus.State == "Unavailable") && (!(item.Kind == "Service") || !(tweakStatus.Detail ?? "").Contains("not installed")))
						{
							TweakSnapshot obj = Capture(item);
							AtomicSave(SnapshotPath(item.Id), json.Serialize(obj));
							num++;
						}
					}
				}
			}
			catch
			{
			}
		}
		return num;
	}

	private static bool Same(SavedValue v, RegistryOperation o)
	{
		if (string.Equals(v.Hive, o.Hive, StringComparison.OrdinalIgnoreCase) && string.Equals(v.Path, o.Path, StringComparison.OrdinalIgnoreCase))
		{
			return string.Equals(v.Name, o.Name, StringComparison.OrdinalIgnoreCase);
		}
		return false;
	}

	private TweakSnapshot Original(string id)
	{
		string path = SnapshotPath(id);
		if (!File.Exists(path))
		{
			return null;
		}
		return json.Deserialize<TweakSnapshot>(File.ReadAllText(path));
	}

	public string OriginalValue(string id)
	{
		Tweak tweak = Find(id);
		if (tweak == null || tweak.Kind == "PowerSwitch" || tweak.Kind == "PowerConfigure")
		{
			return null;
		}
		try
		{
			TweakSnapshot s = Original(id);
			if (s == null)
			{
				return null;
			}
			if (tweak.Kind == "Service")
			{
				return (s.ServiceStart >= 0 && s.ServiceStart <= 4) ? s.ServiceStart.ToString() : null;
			}
			if (tweak.Kind == "Bcd")
			{
				return string.IsNullOrEmpty(s.Native) ? null : ((s.Native == (tweak.BcdOnValue ?? "yes")) ? "Enabled" : "Disabled");
			}
			if (!string.IsNullOrEmpty(tweak.ReadMode) || !string.IsNullOrEmpty(tweak.ProbeScript) || tweak.Kind != "Registry")
			{
				return null;
			}
			Func<RegistryOperation, bool> predicate = delegate(RegistryOperation o)
			{
				if (tweak.Id == "disable-animations" && o.Kind == "Binary")
				{
					// Windows rewrites UserPreferencesMask itself; the live reading ignores it too.
					return true;
				}
				SavedValue savedValue2 = s.Values.FirstOrDefault((SavedValue x) => Same(x, o));
				if (savedValue2 == null || !string.IsNullOrEmpty(o.Token) || o.Kind == "PageVisibility" || o.Kind == "StickyFlags")
				{
					return false;
				}
				if (o.Value == null)
				{
					return !savedValue2.Exists;
				}
				return savedValue2.Exists && Same(savedValue2.Value, o.Value);
			};
			List<RegistryOperation> list = Expand(tweak.Enable);
			List<RegistryOperation> list2 = Expand(tweak.Disable);
			if (tweak.Choices != null && tweak.Choices.Count > 0)
			{
				RegistryOperation first = list.FirstOrDefault();
				SavedValue savedValue = ((first == null) ? null : s.Values.FirstOrDefault((SavedValue x) => Same(x, first)));
				return (savedValue != null && savedValue.Exists) ? Convert.ToString(savedValue.Value, CultureInfo.InvariantCulture) : null;
			}
			if (list.Count > 0 && list.All(predicate))
			{
				return "Enabled";
			}
			if (list2.Count > 0 && list2.All(predicate))
			{
				return "Disabled";
			}
		}
		catch
		{
		}
		return null;
	}

	public bool? MatchesOriginal(string id)
	{
		Tweak tweak = Find(id);
		if (tweak == null)
		{
			return null;
		}
		try
		{
			if (tweak.Kind == "PowerSwitch" || tweak.Kind == "PowerConfigure")
			{
				return PowerControls.MatchesOriginal(dataPath, id);
			}
			TweakSnapshot tweakSnapshot = Original(id);
			if (tweakSnapshot == null)
			{
				return null;
			}
			if (tweak.Kind == "Bcd")
			{
				return BcdRead(tweak.BcdKey) == tweakSnapshot.Native;
			}
			// Script options: reading their full saved state costs a PowerShell run each, so they count as "may differ" and the
			// caller compares their On/Off with the original (before, they were never restored by Windows Default).
			if (!string.IsNullOrEmpty(tweakSnapshot.Native))
			{
				return false;
			}
			if (tweak.Kind == "Service")
			{
				using RegistryKey registryKey = Root("HKLM");
				using RegistryKey registryKey2 = registryKey.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + tweak.Service);
				if (registryKey2 == null || Convert.ToInt32(registryKey2.GetValue("Start", -1)) != tweakSnapshot.ServiceStart)
				{
					return false;
				}
			}
			foreach (SavedValue value in tweakSnapshot.Values)
			{
				if (!Same(Read(new RegistryOperation
				{
					Hive = value.Hive,
					Path = value.Path,
					Name = value.Name
				}), value.Exists ? value.Value : null))
				{
					return false;
				}
			}
			return true;
		}
		catch
		{
			return null;
		}
	}

	// One-off settings (per-game GPU, MSI for one device) live beside the catalog while they apply: the shared Tweaks list
	// that the window reads is never changed, and other changes are not held up behind the lock.
	private readonly Dictionary<string, Tweak> scoped = new Dictionary<string, Tweak>();

	private Tweak Find(string id)
	{
		lock (gate)
		{
			Tweak value = Tweaks.FirstOrDefault((Tweak x) => x.Id == id);
			if (value == null)
			{
				scoped.TryGetValue(id, out value);
			}
			return value;
		}
	}

	internal ActionResult ApplyScoped(Tweak tweak, bool restore)
	{
		lock (gate)
		{
			if (Tweaks.Any((Tweak x) => x.Id == tweak.Id) || scoped.ContainsKey(tweak.Id))
			{
				throw new InvalidOperationException("Scoped setting already active");
			}
			scoped[tweak.Id] = tweak;
		}
		try
		{
			return restore ? Restore(tweak.Id) : Apply(tweak.Id, enabled: true);
		}
		finally
		{
			lock (gate)
			{
				scoped.Remove(tweak.Id);
			}
		}
	}

	public string ConfiguredChoice(string id)
	{
		lock (gate)
		{
			Tweak tweak = Tweaks.First((Tweak x) => x.Id == id);
			List<RegistryOperation> list = Expand(tweak.Enable);
			if (list.Count == 0)
			{
				return null;
			}
			object value = Read(list[0]);
			return (value != null && list.All((RegistryOperation o) => Same(Read(o), value))) ? Convert.ToString(value, CultureInfo.InvariantCulture) : null;
		}
	}

	public ActionResult Apply(string id, bool enabled)
	{
		return Change(id, enabled, null, restore: false);
	}

	public ActionResult ApplyChoice(string id, string value)
	{
		return Change(id, enabled: true, value, restore: false);
	}

	public ActionResult Restore(string id)
	{
		return Change(id, enabled: false, null, restore: true);
	}

	private object GateFor(string id)
	{
		lock (idGates)
		{
			if (!idGates.TryGetValue(id, out var value))
			{
				return idGates[id] = new object();
			}
			return value;
		}
	}

	private static bool Servicing(Tweak t)
	{
		string s = t.EnableScript + t.DisableScript + t.RestoreScript;
		return new string[4] { "OptionalFeature", "dism", "AppxPackage", "WindowsCapability" }.Any((string x) => s.IndexOf(x, StringComparison.OrdinalIgnoreCase) >= 0);
	}

	private static readonly object sharedLane = new object();

	private HashSet<string> sharedKeys;

	// Options that edit the same registry value (a token inside one string, or a value two options own) take turns,
	// so two parallel changes can never overwrite each other's write or roll back each other's value.
	private object SharedLane(Tweak t)
	{
		if (sharedKeys == null)
		{
			Dictionary<string, HashSet<string>> dictionary = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
			List<Tweak> list;
			lock (gate)
			{
				list = Tweaks.ToList();
			}
			foreach (Tweak item in list)
			{
				foreach (RegistryOperation item2 in (item.Enable ?? new List<RegistryOperation>()).Concat(item.Disable ?? new List<RegistryOperation>()))
				{
					string key = item2.Hive + "|" + item2.Path + "|" + item2.Name;
					if (!dictionary.TryGetValue(key, out var value))
					{
						value = (dictionary[key] = new HashSet<string>());
					}
					value.Add(item.Id);
				}
			}
			sharedKeys = new HashSet<string>(from x in dictionary
				where x.Value.Count > 1
				select x.Key, StringComparer.OrdinalIgnoreCase);
		}
		if (!(t.Enable ?? new List<RegistryOperation>()).Concat(t.Disable ?? new List<RegistryOperation>()).Any((RegistryOperation o) => !string.IsNullOrEmpty(o.Token) || sharedKeys.Contains(o.Hive + "|" + o.Path + "|" + o.Name)))
		{
			return null;
		}
		return sharedLane;
	}

	private static object LaneFor(Tweak t)
	{
		if (t.Kind == "Bcd")
		{
			return bcdLane;
		}
		if (t.Kind == "PowerSwitch" || t.Kind == "PowerConfigure" || (t.EnableScript ?? "").IndexOf("powercfg", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return powerLane;
		}
		// Every Set-ProcessMitigation -System rewrites the same system mitigation value: two at once lose one change
		// (CFG read On again after One Click). SysMain/memory compression scripts share one service, too.
		string text = (t.EnableScript ?? "") + (t.DisableScript ?? "");
		if (text.IndexOf("Set-ProcessMitigation", StringComparison.OrdinalIgnoreCase) >= 0)
		{
			return mitigationLane;
		}
		if (text.IndexOf("SysMain", StringComparison.OrdinalIgnoreCase) >= 0 || string.Equals(t.Service, "SysMain", StringComparison.OrdinalIgnoreCase))
		{
			return sysmainLane;
		}
		if (!Servicing(t))
		{
			return null;
		}
		return componentLane;
	}

	private ActionResult Change(string id, bool enabled, string choice, bool restore)
	{
		Tweak tweak = Find(id);
		if (tweak == null)
		{
			return new ActionResult
			{
				Message = "Unknown tweak."
			};
		}
		lock (GateFor(id))
		{
			bool lockTaken = false;
			object obj = null;
			try
			{
				object obj2 = LaneFor(tweak) ?? SharedLane(tweak) ?? GateFor(id);
				obj = obj2;
				Monitor.Enter(obj2, ref lockTaken);
				if (!IsAdministrator)
				{
					return new ActionResult
					{
						Message = "Run AZIZ Gaming Optimizer as administrator to change system settings."
					};
				}
				if (tweak.Kind == "PowerSwitch" || tweak.Kind == "PowerConfigure")
				{
					if (tweak.Kind == "PowerConfigure" && !restore)
					{
						return new ActionResult
						{
							Message = "Open Configure to select values."
						};
					}
					ActionResult actionResult = PowerControls.Toggle(tweak.Id, enabled, restore, dataPath);
					Log(tweak, restore ? "Restore original" : (enabled ? "Enable" : "Windows defaults"), "Power values", PowerControls.State(tweak.Id).State, actionResult.Message);
					return actionResult;
				}
				if (tweak.Kind == "Unavailable")
				{
					return new ActionResult
					{
						Message = tweak.AvailabilityNote
					};
				}
				if (tweak.Kind == "NvidiaScaling")
				{
					ActionResult actionResult2 = NvidiaScaling.Set(!restore && enabled, dataPath);
					Log(tweak, enabled ? "Enable" : "Disable", "NVIDIA display state", ScanOne(tweak, native: true).State, actionResult2.Message);
					return actionResult2;
				}
				if (!restore && tweak.Choices != null && tweak.Choices.Count > 0 && choice == null)
				{
					return new ActionResult
					{
						Message = "Choose a specific value for this setting."
					};
				}
				int result;
				bool flag = tweak.CustomDecimal && int.TryParse(choice, out result) && result >= 0 && result <= 63;
				if (choice != null && !flag && (tweak.Choices == null || !tweak.Choices.Any((TweakChoice x) => x.Value == choice)))
				{
					return new ActionResult
					{
						Message = "Unsupported choice."
					};
				}
				TweakStatus tweakStatus = ScanOne(tweak, native: true);
				if (tweak.Kind == "Service" && !restore && tweakStatus.Detail.Contains("not installed") && (choice == "4" || (choice == null && !enabled)))
				{
					return new ActionResult
					{
						Success = true,
						Message = "The service is absent and already disabled."
					};
				}
				if (!restore && tweakStatus.State == "Unavailable")
				{
					return new ActionResult
					{
						Message = tweakStatus.Detail
					};
				}
				TweakSnapshot tweakSnapshot = null;
				string action = (restore ? "Restore original" : ((choice != null) ? ("Set " + choice) : (enabled ? "Enable" : "Disable")));
				try
				{
					SeedMerged(id);
					tweakSnapshot = Capture(tweak);
					if (CanRestore(id))
					{
						string text = SnapshotPath(id);
						TweakSnapshot tweakSnapshot2 = json.Deserialize<TweakSnapshot>(File.ReadAllText(text));
						if (SnapshotEvolution.Extend(id, tweakSnapshot2, tweakSnapshot, delegate(string other)
						{
							string path = SnapshotPath(other);
							return File.Exists(path) ? json.Deserialize<TweakSnapshot>(File.ReadAllText(path)) : null;
						}))
						{
							if (!File.Exists(text + ".v17.bak"))
							{
								File.Copy(text, text + ".v17.bak");
							}
							AtomicSave(text, json.Serialize(tweakSnapshot2));
						}
					}
					if (tweak.Kind != "Bcd" && CanRestore(id) && !string.IsNullOrEmpty(tweakSnapshot.Native))
					{
						string text2 = SnapshotPath(id);
						TweakSnapshot tweakSnapshot3 = json.Deserialize<TweakSnapshot>(File.ReadAllText(text2));
						string text3 = NativeSnapshotUpgrade.Merge(id, tweakSnapshot3.Native, tweakSnapshot.Native);
						if (text3 != tweakSnapshot3.Native)
						{
							if (!File.Exists(text2 + ".v16.bak"))
							{
								File.Copy(text2, text2 + ".v16.bak");
							}
							tweakSnapshot3.Native = text3;
							AtomicSave(text2, json.Serialize(tweakSnapshot3));
						}
					}
					if (restore)
					{
						if (!CanRestore(id))
						{
							throw new InvalidOperationException("No saved original state exists for this user and device.");
						}
						RestoreSnapshot(tweak, json.Deserialize<TweakSnapshot>(File.ReadAllText(SnapshotPath(id))));
					}
					else
					{
						if (!CanRestore(id))
						{
							AtomicSave(SnapshotPath(id), json.Serialize(tweakSnapshot));
						}
						Log(tweak, action, tweakStatus.State, "Pending", "Started; recovery snapshot saved before changes.");
						if (tweak.Kind == "Service")
						{
							int num = ((choice != null) ? int.Parse(choice) : ((!enabled) ? 4 : ((tweak.ServiceEnabledStart == 0) ? 3 : tweak.ServiceEnabledStart)));
							Tweak t = tweak;
							int start = num;
							SetService(t, start, num switch
							{
								4 => false, 
								2 => true, 
								_ => tweakSnapshot.ServiceRunning, 
							}, delayed: false);
						}
						if (tweak.Kind == "Bcd")
						{
							BcdWrite(tweak.BcdKey, choice ?? (enabled ? tweak.BcdOnValue : ((tweak.BcdKey == "allowedinmemorysettings") ? "0x15000075" : "delete")));
							Log(tweak, action, tweakStatus.State, ScanOne(tweak, native: true).State, "BCD value verified; restart required.");
							return new ActionResult
							{
								Success = true,
								Message = "BCD setting saved and verified. Restart Windows to activate."
							};
						}
						List<RegistryOperation> list = Expand(enabled ? tweak.Enable : tweak.Disable);
						if (choice != null)
						{
							list = list.Select((RegistryOperation o) => new RegistryOperation
							{
								Hive = o.Hive,
								Path = o.Path,
								Name = o.Name,
								Kind = o.Kind,
								Value = int.Parse(choice),
								Token = o.Token
							}).ToList();
						}
						if (list.Count == 0 && tweak.Kind != "Service" && string.IsNullOrEmpty(enabled ? tweak.EnableScript : tweak.DisableScript))
						{
							throw new InvalidOperationException("No applicable hardware or settings found.");
						}
						foreach (RegistryOperation item in list)
						{
							Write(item);
						}
						string text4 = (enabled ? tweak.EnableScript : tweak.DisableScript);
						if (!string.IsNullOrEmpty(text4))
						{
							PowerShell(text4, (tweak.Id == "hyper-v" || tweak.Id == "virtualization-stack") ? 1800000 : 120000);
						}
						foreach (RegistryOperation item2 in list)
						{
							if (!Matches(item2))
							{
								throw new IOException("Read-back verification failed: " + item2.Path + " / " + item2.Name);
							}
						}
					}
					TweakStatus tweakStatus2 = ScanOne(tweak, native: true);
					if (!restore && choice == null && !string.IsNullOrEmpty(tweak.ProbeScript) && tweakStatus2.State != (enabled ? "Enabled" : "Disabled"))
					{
						throw new IOException("Native read-back did not confirm the requested state: " + tweakStatus2.Detail);
					}
					string text5 = (restore ? "Original saved values restored and verified." : "Change applied and verified.");
					if (tweak.Kind == "Service")
					{
						text5 = text5 + " Startup type configured through Windows Service Control Manager. Current runtime: " + tweakStatus2.Detail + ". Restart if the service has not transitioned.";
					}
					text5 += ShellRefresh.After(tweak);
					if (tweak.RequiresRestart)
					{
						text5 += " Restart Windows to activate all changes.";
					}
					Log(tweak, action, tweakStatus.State, tweakStatus2.State, text5);
					return new ActionResult
					{
						Success = true,
						Message = text5
					};
				}
				catch (Exception ex)
				{
					string text6 = "Failed: " + ex.Message;
					if (tweakSnapshot != null)
					{
						try
						{
							RestoreSnapshot(tweak, tweakSnapshot);
							text6 += " Changes rolled back to the state before this attempt.";
						}
						catch (Exception ex2)
						{
							text6 = text6 + " Rollback incomplete: " + ex2.Message + ". Original snapshot is retained.";
						}
					}
					try
					{
						Log(tweak, action, tweakStatus.State, ScanOne(tweak, native: true).State, text6);
					}
					catch
					{
					}
					return new ActionResult
					{
						Success = false,
						Message = text6
					};
				}
			}
			finally
			{
				if (lockTaken)
				{
					Monitor.Exit(obj);
				}
			}
		}
	}

	private void Log(Tweak t, string action, string before, string after, string result)
	{
		Directory.CreateDirectory(dataPath);
		string s = json.Serialize(new HistoryEntry
		{
			Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss zzz"),
			Name = t.Name,
			Action = action,
			Before = before,
			After = after,
			Result = result,
			Profile = ActiveProfileName
		}) + Environment.NewLine;
		lock (logGate)
		{
			using FileStream fileStream = new FileStream(Path.Combine(dataPath, "history.jsonl"), FileMode.Append, FileAccess.Write, FileShare.Read);
			byte[] bytes = Encoding.UTF8.GetBytes(s);
			fileStream.Write(bytes, 0, bytes.Length);
			fileStream.Flush(flushToDisk: true);
		}
	}

	public List<HistoryEntry> History()
	{
		lock (logGate)
		{
			List<HistoryEntry> list = new List<HistoryEntry>();
			string path = Path.Combine(dataPath, "history.jsonl");
			if (!File.Exists(path))
			{
				return list;
			}
			foreach (string item in File.ReadLines(path))
			{
				try
				{
					HistoryEntry historyEntry = json.Deserialize<HistoryEntry>(item);
					if (historyEntry != null)
					{
						list.Add(historyEntry);
					}
				}
				catch
				{
				}
			}
			list.Reverse();
			return list;
		}
	}

	internal static bool PageHomeVisible(string value)
	{
		string[] array = (value ?? "").Split(':');
		if (array.Length != 2)
		{
			return true;
		}
		bool flag = array[1].Split(';').Any((string x) => x.Equals("home", StringComparison.OrdinalIgnoreCase));
		if (!array[0].Equals("showonly", StringComparison.OrdinalIgnoreCase))
		{
			return !flag;
		}
		return flag;
	}

	internal static string SetPageHome(string value, bool visible)
	{
		string text = value ?? "";
		bool flag = text.StartsWith("showonly:", StringComparison.OrdinalIgnoreCase);
		if (text.Length > 0 && !flag && !text.StartsWith("hide:", StringComparison.OrdinalIgnoreCase))
		{
			throw new IOException("Unrecognized Settings visibility policy");
		}
		List<string> list = (from x in (text.Contains(":") ? text.Substring(text.IndexOf(':') + 1) : "").Split(';')
			where x.Length > 0 && !x.Equals("home", StringComparison.OrdinalIgnoreCase)
			select x).ToList();
		if (flag == visible)
		{
			list.Add("home");
		}
		return (flag ? "showonly:" : "hide:") + string.Join(";", list);
	}

	internal static string ParseBcd(string text, string key)
	{
		Match match = Regex.Match(text, "(?im)^\\s*" + Regex.Escape(key) + "\\s+([^\\r\\n]+)");
		if (!match.Success)
		{
			return "delete";
		}
		string text2 = match.Groups[1].Value.Trim();
		if (text2.Equals("Yes", StringComparison.OrdinalIgnoreCase) || text2.Equals("True", StringComparison.OrdinalIgnoreCase))
		{
			return "yes";
		}
		if (text2.Equals("No", StringComparison.OrdinalIgnoreCase) || text2.Equals("False", StringComparison.OrdinalIgnoreCase))
		{
			return "no";
		}
		if (text2.Equals("Legacy", StringComparison.OrdinalIgnoreCase))
		{
			return "Legacy";
		}
		if (text2.Equals("Enhanced", StringComparison.OrdinalIgnoreCase))
		{
			return "Enhanced";
		}
		if (text2.Equals("Default", StringComparison.OrdinalIgnoreCase))
		{
			return "Default";
		}
		if (Regex.IsMatch(text2, "^0x[0-9a-fA-F]+$"))
		{
			return "0x" + Convert.ToUInt64(text2.Substring(2), 16).ToString("x");
		}
		throw new IOException("Unrecognized BCD value: " + text2);
	}

	private static void ValidateBcd(string key)
	{
		if (key != "useplatformtick" && key != "tscsyncpolicy" && key != "disabledynamictick" && key != "useplatformclock" && key != "disableelamdrivers" && key != "allowedinmemorysettings")
		{
			throw new ArgumentException("Unsupported boot option");
		}
	}

	private static readonly object bcdGate = new object();

	private static string bcdText;

	private static DateTime bcdTime;

	// One bcdedit run serves every boot option of a scan (six tweaks); writes always read fresh.
	private static string BcdRead(string key, bool fresh = false)
	{
		ValidateBcd(key);
		lock (bcdGate)
		{
			if (fresh || bcdText == null || (DateTime.UtcNow - bcdTime).TotalSeconds > 5.0)
			{
				bcdText = Run("bcdedit.exe", "/enum {current}", 15000);
				bcdTime = DateTime.UtcNow;
			}
			return ParseBcd(bcdText, key);
		}
	}

	private static void BcdWrite(string key, string value)
	{
		ValidateBcd(key);
		// allowedinmemorysettings also takes Windows' own hexadecimal value back (Off and Restore original).
		if (!((!(key == "allowedinmemorysettings")) ? ((!(key != "tscsyncpolicy")) ? new string[4] { "Legacy", "Enhanced", "Default", "delete" } : new string[3] { "yes", "no", "delete" }) : new string[2] { "0x0", "delete" }).Contains(value) && !(key == "allowedinmemorysettings" && Regex.IsMatch(value ?? "", "^0x[0-9a-fA-F]{1,8}$")))
		{
			throw new ArgumentException("Unsupported boot option value");
		}
		if (value == "delete")
		{
			if (BcdRead(key, fresh: true) != "delete")
			{
				Run("bcdedit.exe", "/deletevalue {current} " + key, 20000);
			}
		}
		else
		{
			Run("bcdedit.exe", "/set {current} " + key + " " + value, 20000);
		}
		if (BcdRead(key, fresh: true) != value)
		{
			throw new IOException("BCD verification failed");
		}
	}

	private static string PowerShell(string script, int timeout)
	{
		// Admin PowerShell loads modules only from Windows' own folders, never from the user's Documents.
		string s = "$env:PSModulePath=[Environment]::GetEnvironmentVariable('PSModulePath','Machine');$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);" + script + "\n;[void]0";
		return Run(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell\\v1.0\\powershell.exe"), "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes(s)), timeout);
	}

	// A capture that is just a quoted constant ('{"tasks":"windows-update"}') needs no PowerShell start.
	private static string Capture(string script, Tweak t)
	{
		Match match = Regex.Match(script ?? "", "^\\s*'([^']*)'\\s*$");
		if (match.Success)
		{
			return match.Groups[1].Value;
		}
		return PowerShell(script, CaptureTimeout(t));
	}

	// Reading Windows optional features can take minutes on a busy PC (seen on Windows Server): the virtualization
	// options get more time than the usual 45 seconds.
	private static int CaptureTimeout(Tweak t)
	{
		return (t.Id == "hyper-v" || t.Id == "virtualization-stack") ? 600000 : 45000;
	}

	private static string Run(string file, string args, int timeout)
	{
		file = Utilities.Tool(file);
		using Process process = new Process
		{
			StartInfo = new ProcessStartInfo
			{
				FileName = file,
				Arguments = args,
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				StandardOutputEncoding = Encoding.UTF8,
				StandardErrorEncoding = Encoding.UTF8
			}
		};
		process.Start();
		if (StartupBoost.Active > 0)
		{
			try
			{
				process.PriorityClass = ProcessPriorityClass.AboveNormal;
			}
			catch
			{
			}
		}
		Task<string> task = process.StandardOutput.ReadToEndAsync();
		Task<string> task2 = process.StandardError.ReadToEndAsync();
		if (!process.WaitForExit(timeout))
		{
			try
			{
				process.Kill();
			}
			catch
			{
			}
			throw new System.TimeoutException("System command timed out; inspect the saved history before retrying.");
		}
		Task.WaitAll(task, task2);
		if (process.ExitCode != 0)
		{
			throw new InvalidOperationException(Utilities.CleanMessage(task2.Result + " " + task.Result));
		}
		return task.Result.Trim();
	}
}
