using System.Collections.Generic;

namespace Aziz;

public sealed class UserProfile
{
	public int Version { get; set; }

	public string Name { get; set; }

	public string CreatedUtc { get; set; }

	public string SavedUtc { get; set; }

	public Dictionary<string, string> Values { get; set; }
}
