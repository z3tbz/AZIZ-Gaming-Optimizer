using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace Aziz;

public sealed class Telemetry : IDisposable
{
	private struct NativeTime
	{
		public uint Low;

		public uint High;

		public ulong Value => ((ulong)High << 32) | Low;
	}

	private struct MemoryStatus
	{
		public uint Length;

		public uint MemoryLoad;

		public ulong TotalPhysical;

		public ulong AvailablePhysical;

		public ulong TotalPageFile;

		public ulong AvailablePageFile;

		public ulong TotalVirtual;

		public ulong AvailableVirtual;

		public ulong AvailableExtendedVirtual;
	}

	private struct NvmlRates
	{
		public uint Gpu;

		public uint Memory;
	}

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NvmlInit();

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NvmlShutdown();

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NvmlCount(out uint count);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NvmlHandle(uint index, out IntPtr handle);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NvmlTemperature(IntPtr handle, uint type, out uint temperature);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NvmlUtilization(IntPtr handle, out NvmlRates rates);

	private readonly object sync = new object();

	private readonly bool sensors;

	private bool disposed;

	private bool initialized;

	private bool cpuPrimed;

	private ulong priorIdle;

	private ulong priorKernel;

	private ulong priorUser;

	private object computer;

	private ResolveEventHandler resolver;

	private string sensorStatus = "";

	private IntPtr nvmlModule;

	private NvmlShutdown nvmlShutdown;

	private NvmlCount nvmlCount;

	private NvmlHandle nvmlHandle;

	private NvmlTemperature nvmlTemperature;

	private NvmlUtilization nvmlUtilization;

	private bool nvmlReady;

	private DateTime gpuEnginesNext;

	private double? gpuEngines;

	public Telemetry(bool sensors)
	{
		this.sensors = sensors;
		PrimeCpu();
	}

	public Telemetry()
		: this(sensors: true)
	{
	}

	public MachineInfo Inspect()
	{
		MachineInfo machineInfo = new MachineInfo
		{
			ComputerName = Environment.MachineName,
			CpuName = "Unavailable",
			GpuName = "Unavailable",
			OsName = Environment.OSVersion.ToString(),
			FormFactor = "Unknown"
		};
		Add(machineInfo, "Computer", machineInfo.ComputerName);
		foreach (Dictionary<string, object> item in Rows("SELECT Manufacturer,Model,SystemType,TotalPhysicalMemory,PCSystemType FROM Win32_ComputerSystem"))
		{
			Add(machineInfo, "Manufacturer / model", Text(item, "Manufacturer") + " / " + Text(item, "Model"));
			Add(machineInfo, "Architecture", Text(item, "SystemType"));
			Add(machineInfo, "Installed memory", Bytes(Number(item, "TotalPhysicalMemory")));
			MachineInfo machineInfo2 = machineInfo;
			machineInfo2.FormFactor = (int)Number(item, "PCSystemType") switch
			{
				0 => "Unknown", 
				1 => "Desktop", 
				3 => "Workstation", 
				2 => "Laptop", 
				_ => "Server / other", 
			};
			Add(machineInfo, "Device type", machineInfo.FormFactor);
		}
		List<string> list = new List<string>();
		foreach (Dictionary<string, object> item2 in Rows("SELECT Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,SocketDesignation FROM Win32_Processor"))
		{
			list.Add(Text(item2, "Name"));
			Add(machineInfo, "Processor", Text(item2, "Name"));
			Add(machineInfo, "CPU configuration", Text(item2, "NumberOfCores") + " cores / " + Text(item2, "NumberOfLogicalProcessors") + " threads / " + Text(item2, "MaxClockSpeed") + " MHz rated / " + Text(item2, "SocketDesignation"));
		}
		if (list.Count > 0)
		{
			machineInfo.CpuName = string.Join(" + ", list.ToArray());
		}
		List<string> list2 = new List<string>();
		foreach (Dictionary<string, object> item3 in Rows("SELECT Name,DriverVersion,VideoProcessor,CurrentHorizontalResolution,CurrentVerticalResolution,CurrentRefreshRate FROM Win32_VideoController"))
		{
			list2.Add(Text(item3, "Name"));
			Add(machineInfo, "Graphics adapter", Text(item3, "Name"));
			Add(machineInfo, "Graphics driver", Text(item3, "DriverVersion"));
			if (Number(item3, "CurrentHorizontalResolution") > 0.0)
			{
				Add(machineInfo, "Active display", Text(item3, "CurrentHorizontalResolution") + " × " + Text(item3, "CurrentVerticalResolution") + " @ " + Text(item3, "CurrentRefreshRate") + " Hz");
			}
		}
		if (list2.Count > 0)
		{
			machineInfo.GpuName = string.Join(" + ", list2.ToArray());
		}
		foreach (Dictionary<string, object> item4 in Rows("SELECT Caption,Version,BuildNumber,OSArchitecture,LastBootUpTime FROM Win32_OperatingSystem"))
		{
			machineInfo.OsName = Text(item4, "Caption");
			Add(machineInfo, "Operating system", machineInfo.OsName);
			Add(machineInfo, "Windows build", Text(item4, "Version") + " (" + Text(item4, "BuildNumber") + ") / " + Text(item4, "OSArchitecture"));
			string text = Text(item4, "LastBootUpTime");
			try
			{
				text = ManagementDateTimeConverter.ToDateTime(text).ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
			}
			catch
			{
			}
			Add(machineInfo, "Last boot", text);
		}
		foreach (Dictionary<string, object> item5 in Rows("SELECT Manufacturer,Product,Version FROM Win32_BaseBoard"))
		{
			Add(machineInfo, "Motherboard", Text(item5, "Manufacturer") + " / " + Text(item5, "Product") + " / " + Text(item5, "Version"));
		}
		foreach (Dictionary<string, object> item6 in Rows("SELECT Manufacturer,SMBIOSBIOSVersion,ReleaseDate FROM Win32_BIOS"))
		{
			string text2 = Text(item6, "ReleaseDate");
			try
			{
				text2 = ManagementDateTimeConverter.ToDateTime(text2).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
			}
			catch
			{
			}
			Add(machineInfo, "BIOS / UEFI", Text(item6, "Manufacturer") + " / " + Text(item6, "SMBIOSBIOSVersion") + " / " + text2);
		}
		foreach (Dictionary<string, object> item7 in Rows("SELECT DeviceLocator,Manufacturer,PartNumber,Capacity,ConfiguredClockSpeed,Speed FROM Win32_PhysicalMemory"))
		{
			string text3 = ((Number(item7, "ConfiguredClockSpeed") > 0.0) ? Text(item7, "ConfiguredClockSpeed") : Text(item7, "Speed"));
			Add(machineInfo, "Memory " + Text(item7, "DeviceLocator"), Bytes(Number(item7, "Capacity")) + " / " + text3 + " MT/s / " + Text(item7, "Manufacturer") + " " + Text(item7, "PartNumber"));
		}
		foreach (Dictionary<string, object> item8 in Rows("SELECT Model,Size,InterfaceType,MediaType FROM Win32_DiskDrive"))
		{
			Add(machineInfo, "Storage", Text(item8, "Model") + " / " + Bytes(Number(item8, "Size")) + " / " + Text(item8, "InterfaceType") + " / " + Text(item8, "MediaType"));
		}
		foreach (Dictionary<string, object> item9 in Rows("SELECT DeviceID,FileSystem,Size,FreeSpace FROM Win32_LogicalDisk WHERE DriveType=3"))
		{
			Add(machineInfo, "Volume " + Text(item9, "DeviceID"), Bytes(Number(item9, "FreeSpace")) + " free / " + Bytes(Number(item9, "Size")) + " / " + Text(item9, "FileSystem"));
		}
		foreach (Dictionary<string, object> item10 in Rows("SELECT Name,Speed,NetConnectionStatus FROM Win32_NetworkAdapter WHERE PhysicalAdapter=True"))
		{
			double num = Number(item10, "Speed");
			Add(machineInfo, "Network adapter", Text(item10, "Name") + ((num > 0.0) ? (" / " + (num / 1000000.0).ToString("0", CultureInfo.InvariantCulture) + " Mbps") : "") + ((Number(item10, "NetConnectionStatus") == 2.0) ? " / connected" : " / disconnected"));
		}
		foreach (Dictionary<string, object> item11 in Rows("SELECT Name,EstimatedChargeRemaining,BatteryStatus FROM Win32_Battery"))
		{
			Add(machineInfo, "Battery", Text(item11, "Name") + " / " + Text(item11, "EstimatedChargeRemaining") + "%");
		}
		Add(machineInfo, "Telemetry", "CPU: Windows system time; RAM: physical memory; GPU: vendor sensors or busiest Windows GPU engine. Unavailable values remain unavailable.");
		return machineInfo;
	}

	public Sample Read()
	{
		lock (sync)
		{
			if (disposed)
			{
				throw new ObjectDisposedException("Telemetry");
			}
			Sample sample = new Sample
			{
				Time = DateTime.Now,
				Cpu = ReadCpu(),
				MemoryText = "Unavailable"
			};
			MemoryStatus status = default(MemoryStatus);
			status.Length = (uint)Marshal.SizeOf(typeof(MemoryStatus));
			if (GlobalMemoryStatusEx(ref status) && status.TotalPhysical != 0L)
			{
				sample.Ram = Clamp(100.0 * (double)(status.TotalPhysical - status.AvailablePhysical) / (double)status.TotalPhysical);
				sample.MemoryText = Bytes(status.TotalPhysical - status.AvailablePhysical) + " / " + Bytes(status.TotalPhysical);
			}
			if (!initialized)
			{
				initialized = true;
				if (sensors)
				{
					OpenSensors();
				}
				else
				{
					sensorStatus = "Low-level sensors disabled for this session.";
				}
			}
			if (sensors)
			{
				ReadHardware(sample);
				ReadNvidia(sample);
			}
			if (!sample.Gpu.HasValue)
			{
				// Windows GPU engine counters through WMI cost far more than the other reads: at most every 3 seconds,
				// and only once a minute while they are missing.
				if (DateTime.UtcNow >= gpuEnginesNext)
				{
					gpuEngines = ReadGpuEngines();
					gpuEnginesNext = DateTime.UtcNow.AddSeconds(gpuEngines.HasValue ? 3.0 : 60.0);
				}
				sample.Gpu = gpuEngines;
			}
			List<string> list = new List<string>();
			if (!string.IsNullOrEmpty(sensorStatus))
			{
				list.Add(sensorStatus);
			}
			if (!sample.CpuTemp.HasValue)
			{
				list.Add("CPU temperature unavailable: sensor support / permission required.");
			}
			if (!sample.GpuTemp.HasValue)
			{
				list.Add("GPU temperature unavailable on this adapter or driver.");
			}
			if (!sample.Gpu.HasValue)
			{
				list.Add("GPU utilization counter unavailable.");
			}
			sample.SensorNote = string.Join(" ", list.ToArray());
			return sample;
		}
	}

	private void OpenSensors()
	{
		string folder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sensors");
		string text = Path.Combine(folder, "LibreHardwareMonitorLib.dll");
		try
		{
			if (File.Exists(text))
			{
				resolver = delegate(object sender, ResolveEventArgs args)
				{
					string name = new AssemblyName(args.Name).Name;
					if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
					{
						return (Assembly)null;
					}
					string text2 = Path.Combine(folder, name + ".dll");
					return File.Exists(text2) ? Assembly.LoadFrom(text2) : null;
				};
				AppDomain.CurrentDomain.AssemblyResolve += resolver;
				Type type = Assembly.LoadFrom(text).GetType("LibreHardwareMonitor.Hardware.Computer", throwOnError: true);
				computer = Activator.CreateInstance(type);
				Set(computer, "IsCpuEnabled", true);
				Set(computer, "IsGpuEnabled", true);
				Set(computer, "IsMotherboardEnabled", false);
				Set(computer, "IsMemoryEnabled", false);
				Set(computer, "IsStorageEnabled", false);
				Set(computer, "IsNetworkEnabled", false);
				Set(computer, "IsControllerEnabled", false);
				Set(computer, "IsPsuEnabled", false);
				type.GetMethod("Open").Invoke(computer, null);
				sensorStatus = "LibreHardwareMonitor 0.9.6 (read only). CPU sensors may require an existing PawnIO installation.";
			}
			else
			{
				sensorStatus = "Optional sensor library is unavailable.";
			}
		}
		catch (Exception e)
		{
			sensorStatus = "Sensor library unavailable: " + Root(e).Message;
			CloseComputer();
		}
		OpenNvidia();
	}

	private void ReadHardware(Sample sample)
	{
		if (computer == null)
		{
			return;
		}
		try
		{
			if (!(Get(computer, "Hardware") is IEnumerable enumerable))
			{
				return;
			}
			double? cpuPreferred = null;
			double? cpuOther = null;
			double? gpuTemp = null;
			double? gpuLoad = null;
			foreach (object item in enumerable)
			{
				ReadHardwareItem(item, ref cpuPreferred, ref cpuOther, ref gpuTemp, ref gpuLoad);
			}
			sample.CpuTemp = cpuPreferred ?? cpuOther;
			sample.GpuTemp = gpuTemp;
			sample.Gpu = gpuLoad;
		}
		catch (Exception e)
		{
			sensorStatus = "Sensor read unavailable: " + Root(e).Message;
		}
	}

	private static void ReadHardwareItem(object hw, ref double? cpuPreferred, ref double? cpuOther, ref double? gpuTemp, ref double? gpuLoad)
	{
		hw.GetType().GetMethod("Update").Invoke(hw, null);
		string text = Convert.ToString(Get(hw, "HardwareType"), CultureInfo.InvariantCulture);
		if (Get(hw, "Sensors") is IEnumerable enumerable)
		{
			foreach (object item in enumerable)
			{
				object obj = Get(item, "Value");
				if (obj == null)
				{
					continue;
				}
				double num = Convert.ToDouble(obj, CultureInfo.InvariantCulture);
				if (double.IsNaN(num) || double.IsInfinity(num))
				{
					continue;
				}
				string text2 = Convert.ToString(Get(item, "SensorType"), CultureInfo.InvariantCulture);
				string input = Convert.ToString(Get(item, "Name"), CultureInfo.InvariantCulture);
				if (text2 == "Temperature" && num > 0.0 && num < 150.0)
				{
					if (text == "Cpu")
					{
						if (Regex.IsMatch(input, "Package|Tctl|Tdie", RegexOptions.IgnoreCase))
						{
							Max(ref cpuPreferred, num);
						}
						else
						{
							Max(ref cpuOther, num);
						}
					}
					else if (text.StartsWith("Gpu", StringComparison.OrdinalIgnoreCase) && Regex.IsMatch(input, "GPU Core|GPU Temperature", RegexOptions.IgnoreCase))
					{
						Max(ref gpuTemp, num);
					}
				}
				if (text2 == "Load" && text.StartsWith("Gpu", StringComparison.OrdinalIgnoreCase) && Regex.IsMatch(input, "GPU Core|D3D 3D", RegexOptions.IgnoreCase))
				{
					Max(ref gpuLoad, Clamp(num));
				}
			}
		}
		if (!(Get(hw, "SubHardware") is IEnumerable enumerable2))
		{
			return;
		}
		foreach (object item2 in enumerable2)
		{
			ReadHardwareItem(item2, ref cpuPreferred, ref cpuOther, ref gpuTemp, ref gpuLoad);
		}
	}

	private double? ReadGpuEngines()
	{
		try
		{
			Dictionary<string, double> dictionary = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
			using (ManagementObjectSearcher managementObjectSearcher = Searcher("SELECT Name,UtilizationPercentage FROM Win32_PerfFormattedData_GPUPerformanceCounters_GPUEngine"))
			{
				using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
				foreach (ManagementObject item in managementObjectCollection)
				{
					using (item)
					{
						Match match = Regex.Match(Convert.ToString(item["Name"], CultureInfo.InvariantCulture), "luid_.*", RegexOptions.IgnoreCase);
						if (match.Success)
						{
							double num = Convert.ToDouble(item["UtilizationPercentage"], CultureInfo.InvariantCulture);
							dictionary.TryGetValue(match.Value, out var value);
							dictionary[match.Value] = value + num;
						}
					}
				}
			}
			return (dictionary.Count == 0) ? null : new double?(Clamp(dictionary.Values.Max()));
		}
		catch
		{
			return null;
		}
	}

	private void PrimeCpu()
	{
		if (GetSystemTimes(out var idle, out var kernel, out var user))
		{
			priorIdle = idle.Value;
			priorKernel = kernel.Value;
			priorUser = user.Value;
			cpuPrimed = true;
		}
	}

	private System.Diagnostics.PerformanceCounter utility;

	private bool utilityMissing;

	// Same number as Task Manager: "% Processor Utility" (counts boost clocks). Windows' idle-time math is the fallback.
	private double? ReadCpu()
	{
		if (!utilityMissing)
		{
			try
			{
				if (utility == null)
				{
					utility = new System.Diagnostics.PerformanceCounter("Processor Information", "% Processor Utility", "_Total", readOnly: true);
					utility.NextValue();
				}
				ReadIdleCpu();
				return Clamp(utility.NextValue());
			}
			catch
			{
				utilityMissing = true;
				utility?.Dispose();
				utility = null;
			}
		}
		return ReadIdleCpu();
	}

	private double? ReadIdleCpu()
	{
		if (!GetSystemTimes(out var idle, out var kernel, out var user))
		{
			return null;
		}
		ulong value = idle.Value;
		ulong value2 = kernel.Value;
		ulong value3 = user.Value;
		double? result = null;
		if (cpuPrimed && value >= priorIdle && value2 >= priorKernel && value3 >= priorUser)
		{
			ulong num = value2 - priorKernel + (value3 - priorUser);
			ulong val = value - priorIdle;
			if (num != 0L)
			{
				result = Clamp(100.0 * (double)(num - Math.Min(num, val)) / (double)num);
			}
		}
		priorIdle = value;
		priorKernel = value2;
		priorUser = value3;
		cpuPrimed = true;
		return result;
	}

	private void OpenNvidia()
	{
		string[] array = new string[2]
		{
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "nvml.dll"),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "NVIDIA Corporation", "NVSMI", "nvml.dll")
		};
		foreach (string path in array)
		{
			if (!File.Exists(path))
			{
				continue;
			}
			try
			{
				nvmlModule = LoadLibrary(path);
				if (nvmlModule == IntPtr.Zero)
				{
					continue;
				}
				NvmlInit nvmlInit = Export<NvmlInit>("nvmlInit_v2");
				nvmlShutdown = Export<NvmlShutdown>("nvmlShutdown");
				nvmlCount = Export<NvmlCount>("nvmlDeviceGetCount_v2");
				nvmlHandle = Export<NvmlHandle>("nvmlDeviceGetHandleByIndex_v2");
				nvmlTemperature = Export<NvmlTemperature>("nvmlDeviceGetTemperature");
				nvmlUtilization = Export<NvmlUtilization>("nvmlDeviceGetUtilizationRates");
				nvmlReady = nvmlInit() == 0;
				if (nvmlReady)
				{
					break;
				}
				goto IL_00f2;
			}
			catch
			{
				goto IL_00f2;
			}
			IL_00f2:
			if (nvmlModule != IntPtr.Zero)
			{
				FreeLibrary(nvmlModule);
				nvmlModule = IntPtr.Zero;
			}
		}
	}

	private T Export<T>(string name) where T : class
	{
		IntPtr procAddress = GetProcAddress(nvmlModule, name);
		if (procAddress == IntPtr.Zero)
		{
			throw new EntryPointNotFoundException(name);
		}
		return Marshal.GetDelegateForFunctionPointer(procAddress, typeof(T)) as T;
	}

	private void ReadNvidia(Sample sample)
	{
		if (!nvmlReady)
		{
			return;
		}
		try
		{
			if (nvmlCount(out var count) != 0)
			{
				return;
			}
			double? target = null;
			double? target2 = null;
			for (uint num = 0u; num < Math.Min(count, 16u); num++)
			{
				if (nvmlHandle(num, out var handle) == 0)
				{
					if (nvmlTemperature(handle, 0u, out var temperature) == 0 && temperature < 150)
					{
						Max(ref target, temperature);
					}
					if (nvmlUtilization(handle, out var rates) == 0)
					{
						Max(ref target2, Clamp(rates.Gpu));
					}
				}
			}
			if (target.HasValue && (!sample.GpuTemp.HasValue || target > sample.GpuTemp))
			{
				sample.GpuTemp = target;
			}
			if (target2.HasValue && (!sample.Gpu.HasValue || target2 > sample.Gpu))
			{
				sample.Gpu = target2;
			}
		}
		catch
		{
			nvmlReady = false;
		}
	}

	private static ManagementObjectSearcher Searcher(string query)
	{
		ManagementScope scope = new ManagementScope("\\\\.\\root\\cimv2");
		ObjectQuery query2 = new ObjectQuery(query);
		return new ManagementObjectSearcher(scope, query2, new System.Management.EnumerationOptions
		{
			Timeout = TimeSpan.FromSeconds(3.0),
			ReturnImmediately = false
		});
	}

	private static List<Dictionary<string, object>> Rows(string query)
	{
		List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = Searcher(query);
			using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
			foreach (ManagementObject item in managementObjectCollection)
			{
				using (item)
				{
					Dictionary<string, object> dictionary = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
					foreach (PropertyData property in item.Properties)
					{
						dictionary[property.Name] = property.Value;
					}
					list.Add(dictionary);
				}
			}
		}
		catch
		{
		}
		return list;
	}

	private static string Text(Dictionary<string, object> row, string key)
	{
		if (!row.TryGetValue(key, out var value) || value == null)
		{
			return "Unavailable";
		}
		return Convert.ToString(value, CultureInfo.InvariantCulture).Trim();
	}

	private static double Number(Dictionary<string, object> row, string key)
	{
		try
		{
			object value;
			return (row.TryGetValue(key, out value) && value != null) ? Convert.ToDouble(value, CultureInfo.InvariantCulture) : 0.0;
		}
		catch
		{
			return 0.0;
		}
	}

	private static void Add(MachineInfo m, string label, string value)
	{
		m.Specs.Add(new SpecItem(label, value));
	}

	private static string Bytes(double value)
	{
		if (!(value > 0.0))
		{
			return "Unavailable";
		}
		return (value / 1073741824.0).ToString("0.0", CultureInfo.InvariantCulture) + " GiB";
	}

	private static double Clamp(double value)
	{
		return Math.Max(0.0, Math.Min(100.0, value));
	}

	private static void Max(ref double? target, double value)
	{
		if (!target.HasValue || value > target.Value)
		{
			target = value;
		}
	}

	private static readonly Dictionary<Tuple<Type, string>, PropertyInfo> Properties = new Dictionary<Tuple<Type, string>, PropertyInfo>();

	// Sensor values are read through reflection every sample: look each property up once per type.
	private static object Get(object obj, string name)
	{
		Tuple<Type, string> key = Tuple.Create(obj.GetType(), name);
		PropertyInfo property;
		lock (Properties)
		{
			if (!Properties.TryGetValue(key, out property))
			{
				property = (Properties[key] = key.Item1.GetProperty(name));
			}
		}
		if (!(property == null))
		{
			return property.GetValue(obj, null);
		}
		return null;
	}

	private static void Set(object obj, string name, object value)
	{
		PropertyInfo property = obj.GetType().GetProperty(name);
		if (property != null && property.CanWrite)
		{
			property.SetValue(obj, value, null);
		}
	}

	private static Exception Root(Exception e)
	{
		while (e.InnerException != null)
		{
			e = e.InnerException;
		}
		return e;
	}

	private void CloseComputer()
	{
		if (computer != null)
		{
			try
			{
				computer.GetType().GetMethod("Close").Invoke(computer, null);
			}
			catch
			{
			}
			computer = null;
		}
	}

	public void Dispose()
	{
		lock (sync)
		{
			if (disposed)
			{
				return;
			}
			disposed = true;
			utility?.Dispose();
			CloseComputer();
			if (resolver != null)
			{
				AppDomain.CurrentDomain.AssemblyResolve -= resolver;
			}
			if (!(nvmlModule != IntPtr.Zero))
			{
				return;
			}
			try
			{
				if (nvmlReady && nvmlShutdown != null)
				{
					nvmlShutdown();
				}
			}
			catch
			{
			}
			FreeLibrary(nvmlModule);
			nvmlModule = IntPtr.Zero;
		}
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GetSystemTimes(out NativeTime idle, out NativeTime kernel, out NativeTime user);

	[DllImport("kernel32.dll", SetLastError = true)]
	[return: MarshalAs(UnmanagedType.Bool)]
	private static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);

	[DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern IntPtr LoadLibrary(string path);

	[DllImport("kernel32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
	private static extern IntPtr GetProcAddress(IntPtr module, string name);

	[DllImport("kernel32.dll")]
	private static extern bool FreeLibrary(IntPtr module);
}
