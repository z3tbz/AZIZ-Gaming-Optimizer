using System;
using System.Threading;

namespace Aziz;

internal static class TimerService
{
	private const string Task = "AZIZ Timer Resolution";

	private static string Exe => AgentFiles.Exe;

	public static bool Installed()
	{
		try
		{
			return Utilities.Run("schtasks.exe", "/Query /TN \"AZIZ Timer Resolution\"").Success;
		}
		catch
		{
			return false;
		}
	}

	public static int Run()
	{
		using TimerLease timerLease = new TimerLease();
		int num = 0;
		while (true)
		{
			Thread.Sleep(1000);
			if (num > 0)
			{
				num--;
			}
			else if (TimerLease.Query() > 0.51 && timerLease.Renew() > 0.51)
			{
				num = 30;
			}
		}
	}

	public static ActionResult Install()
	{
		try
		{
			AgentFiles.Stop(timerService: true);
			AgentFiles.Deploy();
			TimerLease.EnableGlobalRequests();
			string script = "$a=New-ScheduledTaskAction -Execute '" + Exe.Replace("'", "''") + "' -Argument '--timer-resolution';$t=@((New-ScheduledTaskTrigger -AtStartup),(New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 5)));$p=New-ScheduledTaskPrincipal -UserId 'S-1-5-18' -LogonType ServiceAccount -RunLevel Highest;$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -Hidden;Register-ScheduledTask -TaskName 'AZIZ Timer Resolution' -Action $a -Trigger $t -Principal $p -Settings $s -Force|Out-Null;Start-ScheduledTask -TaskName 'AZIZ Timer Resolution';'Boot timer service registered.'";
			return Utilities.Run("powershell.exe", GameWatch.PsArgs(script));
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static void EnsureRunning()
	{
		try
		{
			if (Installed())
			{
				if (!AgentFiles.Current())
				{
					Install();
					return;
				}
				AgentFiles.Stop(timerService: true, staleOnly: true);
				Utilities.Run("powershell.exe", GameWatch.PsArgs("$t=Get-ScheduledTask -TaskName 'AZIZ Timer Resolution' -ErrorAction SilentlyContinue;if($t -and $t.State -ne 'Running'){Start-ScheduledTask -TaskName 'AZIZ Timer Resolution'}"));
			}
		}
		catch
		{
		}
	}

	public static ActionResult Remove()
	{
		return Utilities.Run("powershell.exe", GameWatch.PsArgs("$t=Get-ScheduledTask -TaskName 'AZIZ Timer Resolution' -ErrorAction SilentlyContinue;if($t){Stop-ScheduledTask -TaskName 'AZIZ Timer Resolution' -ErrorAction SilentlyContinue;Unregister-ScheduledTask -TaskName 'AZIZ Timer Resolution' -Confirm:$false};'removed'"));
	}
}
