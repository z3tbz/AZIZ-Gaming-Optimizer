namespace Aziz;

public class TweakStatus
{
	public string State { get; set; }

	public string Detail { get; set; }
}
