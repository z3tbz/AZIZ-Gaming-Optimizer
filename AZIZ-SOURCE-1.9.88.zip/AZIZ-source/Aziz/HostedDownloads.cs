using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Aziz;

internal static class HostedDownloads
{
	public static async Task<bool> Fetch(HttpClient client, string url, string file, DownloadJob job, Action changed)
	{
		Uri source = new Uri(url);
		if (source.Scheme != "https")
		{
			throw new IOException("Secure package manifest required.");
		}
		Dictionary<string, object> dictionary;
		using (HttpResponseMessage response = await client.GetAsync(source, job.Cancel.Token))
		{
			response.EnsureSuccessStatusCode();
			JavaScriptSerializer obj = Program.Json;
			dictionary = obj.Deserialize<Dictionary<string, object>>(await response.Content.ReadAsStringAsync());
		}
		long num = Convert.ToInt64(dictionary["bytes"]);
		if (num <= 0 || num > 268435456)
		{
			throw new IOException("Invalid package length.");
		}
		if (!string.Equals(Convert.ToString(dictionary["sha256"]), job.Item.Sha256, StringComparison.OrdinalIgnoreCase))
		{
			throw new IOException("The hosted package does not match this AZIZ release.");
		}
		List<Dictionary<string, object>> list = ((IEnumerable)dictionary["parts"]).Cast<Dictionary<string, object>>().ToList();
		if (list.Count == 0 || list.Count > 32 || list.Sum((Dictionary<string, object> x) => Convert.ToInt64(x["bytes"])) != num)
		{
			throw new IOException("Invalid package parts.");
		}
		job.Total = num;
		job.State = "Downloading";
		changed();
		Stopwatch elapsed = Stopwatch.StartNew();
		using (FileStream output = new FileStream(file, FileMode.CreateNew, FileAccess.Write, FileShare.None, 262144, useAsync: true))
		{
			foreach (Dictionary<string, object> part in list)
			{
				string text = Convert.ToString(part["name"]);
				if (!Regex.IsMatch(text, "^part-[0-9]{3}\\.bin$"))
				{
					throw new IOException("Invalid package part name.");
				}
				long expected = Convert.ToInt64(part["bytes"]);
				if (expected <= 0 || expected > 16777216)
				{
					throw new IOException("Invalid part length.");
				}
				using HttpResponseMessage response = await client.GetAsync(new Uri(source, text), HttpCompletionOption.ResponseHeadersRead, job.Cancel.Token);
				response.EnsureSuccessStatusCode();
				using Stream input = await response.Content.ReadAsStreamAsync();
				using SHA256 sha = SHA256.Create();
				byte[] buffer = new byte[262144];
				long count = 0L;
				while (true)
				{
					int num2;
					int read = (num2 = await input.ReadAsync(buffer, 0, buffer.Length, job.Cancel.Token));
					if (num2 <= 0)
					{
						break;
					}
					count += read;
					if (count > expected)
					{
						throw new IOException("Downloaded part is too long.");
					}
					sha.TransformBlock(buffer, 0, read, null, 0);
					await output.WriteAsync(buffer, 0, read, job.Cancel.Token);
					job.Bytes += read;
					job.Speed = (double)job.Bytes / Math.Max(0.001, elapsed.Elapsed.TotalSeconds);
					changed();
				}
				sha.TransformFinalBlock(new byte[0], 0, 0);
				string text2 = BitConverter.ToString(sha.Hash).Replace("-", "");
				if (count != expected || !text2.Equals(Convert.ToString(part["sha256"]), StringComparison.OrdinalIgnoreCase))
				{
					throw new IOException("Package part verification failed.");
				}
			}
		}
		return true;
	}
}
