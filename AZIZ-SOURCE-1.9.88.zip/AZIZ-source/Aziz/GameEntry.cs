namespace Aziz;

internal class GameEntry
{
	public string Name { get; set; }

	public string Target { get; set; }

	public string Exe { get; set; }

	public string Library { get; set; }

	public override string ToString()
	{
		return Name + "  ·  " + Library;
	}
}
