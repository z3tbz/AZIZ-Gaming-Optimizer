using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Aziz;

internal static class PowerControls
{
	private const string Cpu = "54533251-82be-4824-96c1-47b60b740d00";

	internal static readonly PowerParameter[] Parameters = new PowerParameter[12]
	{
		new PowerParameter("nvme-primary-latency", "NVMe primary tolerance", "0012ee47-9041-4b5d-9b77-535fba8b1442", "fc95af4d-40e7-4b6d-835a-56d131dbc80e", uint.MaxValue, "ms"),
		new PowerParameter("nvme-secondary-latency", "NVMe secondary tolerance", "0012ee47-9041-4b5d-9b77-535fba8b1442", "dbc9e238-6de9-49e3-92cd-8c2b4946b472", uint.MaxValue, "ms"),
		new PowerParameter("responsive-time-trigger", "Responsive Time Trigger", "48672f38-7a9a-4bb2-8bf8-3d85be19de4e", "d6ba4903-386f-4c2c-8adb-5c21b3328d25", 100000u, "ms"),
		new PowerParameter("cpu-boost-policy", "Processor boost policy", "54533251-82be-4824-96c1-47b60b740d00", "45bcc044-d885-43e2-8605-ee0ec6e96b59", 100u, "%"),
		new PowerParameter("cpu-max-frequency", "Maximum processor frequency", "54533251-82be-4824-96c1-47b60b740d00", "75b0ae3f-bce0-45a7-8c89-c9611c25e100", uint.MaxValue, "MHz · 0 = no limit"),
		new PowerParameter("cpu-boost-mode", "Processor boost mode", "54533251-82be-4824-96c1-47b60b740d00", "be337238-0d82-4146-a960-4f3749d470c7", 6u, ""),
		new PowerParameter("usb3-link-power", "USB 3 link power management", "2a737441-1930-4402-8d77-b2bebba308a3", "d4e98f31-5ffe-4ce1-be31-1b38b384c009", 3u, ""),
		new PowerParameter("disable-throttle-states", "Allow throttle states", "54533251-82be-4824-96c1-47b60b740d00", "3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb", 2u, ""),
		new PowerParameter("deep-sleep", "Deep Sleep", "2e601130-5351-4d9d-8e04-252966bad054", "d502f7ee-1dc7-4efd-a55d-f04b6f5c0545", 1u, ""),
		new PowerParameter("core-parking-min", "Core parking minimum cores", "54533251-82be-4824-96c1-47b60b740d00", "0cc5b647-c1df-4637-891a-dec35c318583", 100u, "%"),
		new PowerParameter("core-parking-min-1", "Core parking minimum cores (class 1)", "54533251-82be-4824-96c1-47b60b740d00", "0cc5b647-c1df-4637-891a-dec35c318584", 100u, "%"),
		new PowerParameter("idle-disable", "Processor idle disable", "54533251-82be-4824-96c1-47b60b740d00", "5d76a2ca-e8c0-402f-a133-2158492d58ad", 1u, "")
	};

	private static bool? secondClass;

	internal static IPowerControlStore Store = new WindowsPowerControlStore();

	private static readonly object Gate = new object();

	private static bool SecondClass()
	{
		if (!secondClass.HasValue)
		{
			try
			{
				secondClass = GameNative.EfficiencyClasses() > 1;
				if (secondClass.Value)
				{
					Store.Read(Store.Active(), Parameter("core-parking-min-1"), battery: false);
				}
			}
			catch
			{
				secondClass = false;
			}
		}
		return secondClass.Value;
	}

	internal static PowerParameter Parameter(string key)
	{
		return Parameters.Single((PowerParameter x) => x.Key == key);
	}

	internal static string[] Keys(string id)
	{
		switch (id)
		{
		case "low-latency-cpu":
			if (SecondClass())
			{
				return new string[3] { "core-parking-min", "core-parking-min-1", "idle-disable" };
			}
			return new string[2] { "core-parking-min", "idle-disable" };
		default:
			return new string[1] { id };
		case "cpu-boost-settings":
			return new string[3] { "cpu-boost-policy", "cpu-max-frequency", "cpu-boost-mode" };
		case "nvme-latency":
			return new string[2] { "nvme-primary-latency", "nvme-secondary-latency" };
		}
	}

	private static uint TargetAc(string id, string key, bool enabled, uint plan)
	{
		switch (id)
		{
		case "usb3-link-power":
			if (!enabled)
			{
				return 0u;
			}
			return Math.Max(2u, plan);
		case "deep-sleep":
			if (!enabled)
			{
				return 0u;
			}
			return 1u;
		case "low-latency-cpu":
			if (!(key == "idle-disable"))
			{
				if (!enabled)
				{
					return plan;
				}
				return 100u;
			}
			return 0u;
		default:
			if (enabled)
			{
				return 0u;
			}
			if (!(id == "disable-throttle-states"))
			{
				return plan;
			}
			return 2u;
		}
	}

	private static string SnapshotPath(string folder, string id, Guid scheme)
	{
		return Path.Combine(folder, "power-settings", id + "-" + scheme.ToString("D") + ".json");
	}

	public static bool CaptureOriginal(string folder, string id)
	{
		Guid scheme = Store.Active();
		string path = SnapshotPath(folder, id, scheme);
		if (File.Exists(path) || Legacy(folder, id, scheme) != null)
		{
			return false;
		}
		Utilities.AtomicWrite(path, Program.Json.Serialize(Read(scheme, Keys(id))));
		return true;
	}

	public static bool? MatchesOriginal(string folder, string id)
	{
		try
		{
			Guid scheme = Store.Active();
			string path = SnapshotPath(folder, id, scheme);
			PowerSnapshot powerSnapshot = (File.Exists(path) ? Program.Json.Deserialize<PowerSnapshot>(File.ReadAllText(path)) : Legacy(folder, id, scheme));
			if (powerSnapshot == null)
			{
				return null;
			}
			PowerSnapshot now = Read(scheme, powerSnapshot.Values.Select((PowerValue v) => v.Key));
			return powerSnapshot.Values.All((PowerValue v) => now.Values.Any((PowerValue n) => n.Key == v.Key && n.AC == v.AC));
		}
		catch
		{
			return null;
		}
	}

	public static bool CanRestore(string folder, string id)
	{
		try
		{
			Guid scheme = Store.Active();
			return File.Exists(SnapshotPath(folder, id, scheme)) || Legacy(folder, id, scheme) != null;
		}
		catch
		{
			return false;
		}
	}

	private static PowerSnapshot Legacy(string folder, string id, Guid scheme)
	{
		if (id == "nvme-latency")
		{
			PowerSnapshot[] source = (from k in Keys(id)
				select Legacy(folder, k, scheme)).ToArray();
			if (source.All((PowerSnapshot x) => x == null))
			{
				return null;
			}
			PowerSnapshot powerSnapshot = Read(scheme, Keys(id));
			{
				foreach (PowerSnapshot item in source.Where((PowerSnapshot x) => x != null))
				{
					PowerValue prior = item.Values[0];
					powerSnapshot.Values.RemoveAll((PowerValue x) => x.Key == prior.Key);
					powerSnapshot.Values.Add(prior);
				}
				return powerSnapshot;
			}
		}
		if (id != "disable-throttle-states" && !id.StartsWith("nvme-"))
		{
			return null;
		}
		string path = Path.Combine(folder, "snapshots", id + ".json");
		if (!File.Exists(path))
		{
			return null;
		}
		TweakSnapshot tweakSnapshot = Program.Json.Deserialize<TweakSnapshot>(File.ReadAllText(path));
		if (tweakSnapshot == null || string.IsNullOrEmpty(tweakSnapshot.Native))
		{
			return null;
		}
		Dictionary<string, object> dictionary = Program.Json.Deserialize<Dictionary<string, object>>(tweakSnapshot.Native);
		if (!dictionary.ContainsKey("Scheme") || !dictionary.ContainsKey("AC") || !dictionary.ContainsKey("DC") || new Guid(Convert.ToString(dictionary["Scheme"])) != scheme)
		{
			return null;
		}
		return new PowerSnapshot
		{
			Scheme = scheme,
			Values = new List<PowerValue>
			{
				new PowerValue
				{
					Key = id,
					AC = Convert.ToUInt32(dictionary["AC"]),
					DC = Convert.ToUInt32(dictionary["DC"])
				}
			}
		};
	}

	public static PowerSnapshot Read(string id)
	{
		return Read(Store.Active(), Keys(id));
	}

	internal static PowerSnapshot Read(Guid scheme, IEnumerable<string> keys)
	{
		return new PowerSnapshot
		{
			Scheme = scheme,
			Values = keys.Select((string k) => new PowerValue
			{
				Key = k,
				AC = Store.Read(scheme, Parameter(k), battery: false),
				DC = Store.Read(scheme, Parameter(k), battery: true)
			}).ToList()
		};
	}

	private static uint DefaultOr(Guid scheme, PowerParameter p, bool battery)
	{
		try
		{
			return Store.Default(scheme, p, battery);
		}
		catch
		{
			return Store.Read(scheme, p, battery);
		}
	}

	public static PowerSnapshot Defaults(string id, Guid scheme)
	{
		return new PowerSnapshot
		{
			Scheme = scheme,
			Values = (from k in Keys(id)
				select new PowerValue
				{
					Key = k,
					AC = DefaultOr(scheme, Parameter(k), battery: false),
					DC = DefaultOr(scheme, Parameter(k), battery: true)
				}).ToList()
		};
	}

	public static TweakStatus State(string id)
	{
		try
		{
			Guid scheme = Store.Active();
			List<PowerValue> source = (from key in Keys(id)
				select new PowerValue
				{
					Key = key,
					AC = Store.Read(scheme, Parameter(key), battery: false),
					DC = Store.Read(scheme, Parameter(key), battery: true)
				}).ToList();
			bool flag = (id == "nvme-latency" || id == "responsive-time-trigger" || id == "disable-throttle-states" || id == "usb3-link-power" || id == "deep-sleep" || id == "low-latency-cpu") && ((id == "usb3-link-power") ? source.All((PowerValue v) => v.AC != 0) : ((id == "deep-sleep") ? source.All((PowerValue v) => v.AC == 1) : ((id == "low-latency-cpu") ? source.Where((PowerValue v) => v.Key != "idle-disable").All((PowerValue v) => v.AC == 100) : source.All((PowerValue v) => v.AC == 0))));
			return new TweakStatus
			{
				State = (flag ? "Enabled" : "Disabled"),
				Detail = "Active plan · " + string.Join(" · ", source.Select((PowerValue v) => Parameter(v.Key).Name + ": AC " + v.AC + ((!(id == "disable-throttle-states")) ? "" : ((v.AC == 0) ? " (throttle states off)" : ((v.AC == 1) ? " (on)" : " (automatic)"))) + " / battery " + v.DC))
			};
		}
		catch (Exception ex)
		{
			return new TweakStatus
			{
				State = "Unavailable",
				Detail = "Windows could not read this AC power setting: " + ex.Message
			};
		}
	}

	public static ActionResult Toggle(string id, bool enabled, bool restore, string folder)
	{
		try
		{
			if (restore)
			{
				return Restore(id, folder);
			}
			PowerSnapshot powerSnapshot = Read(id);
			PowerSnapshot defaults = Defaults(id, powerSnapshot.Scheme);
			PowerSnapshot target = new PowerSnapshot
			{
				Scheme = powerSnapshot.Scheme,
				Values = powerSnapshot.Values.Select((PowerValue x) => new PowerValue
				{
					Key = x.Key,
					DC = x.DC,
					AC = TargetAc(id, x.Key, enabled, defaults.Values.First((PowerValue d) => d.Key == x.Key).AC)
				}).ToList()
			};
			return Apply(id, target, folder);
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static ActionResult SetAc(string id, string key, uint value, string folder)
	{
		try
		{
			PowerSnapshot powerSnapshot = Read(id);
			PowerSnapshot target = new PowerSnapshot
			{
				Scheme = powerSnapshot.Scheme,
				Values = powerSnapshot.Values.Select((PowerValue x) => new PowerValue
				{
					Key = x.Key,
					DC = x.DC,
					AC = ((x.Key == key) ? value : x.AC)
				}).ToList()
			};
			return Apply(id, target, folder);
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static ActionResult Restore(string id, string folder)
	{
		try
		{
			Guid scheme = Store.Active();
			string path = SnapshotPath(folder, id, scheme);
			PowerSnapshot powerSnapshot = (File.Exists(path) ? Program.Json.Deserialize<PowerSnapshot>(File.ReadAllText(path)) : Legacy(folder, id, scheme));
			if (powerSnapshot == null)
			{
				throw new IOException("No saved original values exist for this power plan.");
			}
			return Apply(id, powerSnapshot, folder);
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static ActionResult Apply(string id, PowerSnapshot target, string folder)
	{
		lock (Gate)
		{
			PowerSnapshot powerSnapshot = null;
			bool flag = false;
			try
			{
				if (target == null || target.Scheme != Store.Active())
				{
					throw new IOException("The active power plan changed. Reopen Configure to read the current plan.");
				}
				string[] array = Keys(id);
				if (target.Values == null || target.Values.Count != array.Length || !(from x in target.Values
					select x.Key into x
					orderby x
					select x).SequenceEqual(array.OrderBy((string x) => x)))
				{
					throw new IOException("Invalid power setting selection.");
				}
				foreach (PowerValue value in target.Values)
				{
					PowerParameter powerParameter = Parameter(value.Key);
					if (value.AC > powerParameter.Maximum || value.DC > powerParameter.Maximum)
					{
						throw new ArgumentOutOfRangeException(powerParameter.Name);
					}
				}
				powerSnapshot = Read(target.Scheme, array);
				string path = SnapshotPath(folder, id, target.Scheme);
				if (!File.Exists(path))
				{
					Utilities.AtomicWrite(path, Program.Json.Serialize(Legacy(folder, id, target.Scheme) ?? powerSnapshot));
				}
				if (Store.Active() != target.Scheme)
				{
					throw new IOException("The active power plan changed before applying.");
				}
				flag = true;
				Write(target);
				Store.Refresh(target.Scheme);
				PowerSnapshot b = Read(target.Scheme, array);
				if (!Equal(target, b))
				{
					throw new IOException("Windows did not retain the requested power values.");
				}
				return new ActionResult
				{
					Success = true,
					Message = "Power settings saved and read back for this plan." + ((Store.Active() != target.Scheme) ? " Another plan is now active; it was not replaced." : "")
				};
			}
			catch (Exception ex)
			{
				string text = ex.Message;
				if (flag && powerSnapshot != null)
				{
					try
					{
						Write(powerSnapshot);
						Store.Refresh(powerSnapshot.Scheme);
						if (!Equal(powerSnapshot, Read(powerSnapshot.Scheme, powerSnapshot.Values.Select((PowerValue x) => x.Key))))
						{
							throw new IOException("Rollback read-back differs.");
						}
						text += " Previous values restored.";
					}
					catch (Exception ex2)
					{
						text = text + " Rollback incomplete: " + ex2.Message;
					}
				}
				return new ActionResult
				{
					Message = text
				};
			}
		}
	}

	private static void Write(PowerSnapshot snapshot)
	{
		foreach (PowerValue value in snapshot.Values)
		{
			Store.Write(snapshot.Scheme, Parameter(value.Key), battery: false, value.AC);
			Store.Write(snapshot.Scheme, Parameter(value.Key), battery: true, value.DC);
		}
	}

	private static bool Equal(PowerSnapshot a, PowerSnapshot b)
	{
		if (a.Scheme == b.Scheme)
		{
			return a.Values.All((PowerValue x) => b.Values.Any((PowerValue y) => x.Key == y.Key && x.AC == y.AC && x.DC == y.DC));
		}
		return false;
	}
}
