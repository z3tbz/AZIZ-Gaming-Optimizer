using System;
using System.Linq;
using System.Management;
using System.Net.Http;
using System.Text.RegularExpressions;

namespace Aziz;

internal static class BiosDrivers
{
	private static string Field(string cls, string field)
	{
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT " + field + " FROM " + cls);
			using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
			using ManagementObjectCollection.ManagementObjectEnumerator managementObjectEnumerator = managementObjectCollection.GetEnumerator();
			if (managementObjectEnumerator.MoveNext())
			{
				return Convert.ToString(((ManagementObject)managementObjectEnumerator.Current)[field]).Trim();
			}
		}
		catch
		{
		}
		return "";
	}

	private static bool Junk(string s)
	{
		if (!string.IsNullOrWhiteSpace(s))
		{
			return Regex.IsMatch(s, "to be filled|default string|system product|o\\.e\\.m\\.|not applicable|none", RegexOptions.IgnoreCase);
		}
		return true;
	}

	internal static BiosInfo Resolve(string systemVendor, string systemModel, string boardVendor, string boardModel, string version, string serial, string family, Func<string, string> lenovoPath)
	{
		if (new string[13]
		{
			"dell", "lenovo", "hewlett", "hp", "acer", "microsoft", "asus", "msi", "micro-star", "gigabyte",
			"razer", "samsung", "huawei"
		}.Any((string x) => systemVendor.ToLowerInvariant().Contains(x)))
		{
			Junk(systemModel);
		}
		bool flag = new string[9] { "dell", "lenovo", "hewlett", "hp", "acer", "microsoft", "razer", "samsung", "huawei" }.Any((string x) => systemVendor.ToLowerInvariant().Contains(x));
		BiosInfo biosInfo = new BiosInfo
		{
			Vendor = (flag ? systemVendor : boardVendor),
			Model = (flag ? systemModel : boardModel),
			Version = version,
			Board = boardVendor + " " + boardModel
		};
		string text = biosInfo.Vendor.ToLowerInvariant();
		string text2 = (Junk(biosInfo.Model) ? "" : biosInfo.Model);
		string text3 = Uri.EscapeDataString(text2);
		if (text.Contains("lenovo"))
		{
			string text4 = lenovoPath?.Invoke(text2);
			if (!string.IsNullOrEmpty(text4))
			{
				biosInfo.Url = "https://pcsupport.lenovo.com/products/" + text4.ToLowerInvariant() + "/downloads/driver-list";
				biosInfo.Exact = true;
			}
			else
			{
				biosInfo.Url = "https://pcsupport.lenovo.com/search?query=" + text3;
			}
			if (!Junk(family))
			{
				biosInfo.Model = family + " (" + text2 + ")";
			}
		}
		else if (text.Contains("dell"))
		{
			if (!Junk(serial))
			{
				biosInfo.Url = "https://www.dell.com/support/home/product-support/servicetag/" + Uri.EscapeDataString(serial) + "/drivers";
				biosInfo.Exact = true;
			}
			else
			{
				biosInfo.Url = "https://www.dell.com/support/home/drivers";
			}
		}
		else if (text.Contains("hp") || text.Contains("hewlett"))
		{
			biosInfo.Url = "https://support.hp.com/drivers/selfservice/swdetection?q=" + text3;
		}
		else if (text.Contains("asus") && text2 != "")
		{
			biosInfo.Url = "https://www.asus.com/supportonly/" + Uri.EscapeDataString(Regex.Replace(text2, "^ASUS\\s+", "", RegexOptions.IgnoreCase)) + "/helpdesk_bios/";
			biosInfo.Exact = true;
		}
		else if ((text.Contains("micro-star") || text.Contains("msi")) && text2 != "")
		{
			string text5 = Uri.EscapeDataString(Regex.Replace(text2, "\\s+\\(MS-[^)]+\\)$", "").Trim().Replace(' ', '-'));
			biosInfo.Url = "https://www.msi.com/Motherboard/" + text5 + "/support#bios";
			biosInfo.Exact = true;
		}
		else if (text.Contains("gigabyte"))
		{
			biosInfo.Url = "https://www.gigabyte.com/Search?kw=" + text3;
		}
		else if (text.Contains("asrock"))
		{
			biosInfo.Url = "https://www.asrock.com/search/index.asp?Keyword=" + text3;
		}
		else if (text.Contains("acer"))
		{
			biosInfo.Url = (Junk(serial) ? "https://www.acer.com/support/drivers-and-manuals" : ("https://www.acer.com/support/drivers-and-manuals?search=" + Uri.EscapeDataString(serial)));
		}
		else if (text.Contains("microsoft"))
		{
			biosInfo.Url = "https://support.microsoft.com/surface-drivers-and-firmware";
		}
		else if (text.Contains("biostar"))
		{
			biosInfo.Url = "https://www.biostar.com.tw/app/en/search.php?keyword=" + text3;
		}
		else
		{
			biosInfo.Url = "https://www.bing.com/search?q=" + Uri.EscapeDataString(biosInfo.Vendor + " " + text2 + " BIOS drivers support");
		}
		return biosInfo;
	}

	private static string LenovoPath(string machineType)
	{
		try
		{
			if (string.IsNullOrEmpty(machineType))
			{
				return null;
			}
			using HttpClient httpClient = new HttpClient
			{
				Timeout = TimeSpan.FromSeconds(8.0)
			};
			httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("AZIZ-Gaming-Optimizer/1.9.7");
			string stringToEscape = ((machineType.Length > 4) ? machineType.Substring(0, 4) : machineType);
			Match match = Regex.Match(httpClient.GetStringAsync("https://pcsupport.lenovo.com/us/en/api/v4/mse/getproducts?productId=" + Uri.EscapeDataString(stringToEscape)).Result, "\"Id\"\\s*:\\s*\"([^\"]+)\"");
			return (match.Success && Regex.IsMatch(match.Groups[1].Value, "^[A-Za-z0-9/._-]+$")) ? match.Groups[1].Value : null;
		}
		catch
		{
			return null;
		}
	}

	public static BiosInfo Read()
	{
		return Resolve(Field("Win32_ComputerSystem", "Manufacturer"), Field("Win32_ComputerSystem", "Model"), Field("Win32_BaseBoard", "Manufacturer"), Field("Win32_BaseBoard", "Product"), Field("Win32_BIOS", "SMBIOSBIOSVersion"), Field("Win32_BIOS", "SerialNumber"), Field("Win32_ComputerSystemProduct", "Version"), LenovoPath);
	}
}
