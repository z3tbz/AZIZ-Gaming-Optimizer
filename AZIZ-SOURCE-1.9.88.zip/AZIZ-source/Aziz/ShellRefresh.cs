using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.Win32;

namespace Aziz;

internal static class ShellRefresh
{
	private struct AnimationInfo
	{
		public uint Size;

		public int Enabled;
	}

	internal static bool Suppress = false;

	private static readonly object gate = new object();

	private static Timer refresh;

	private static readonly HashSet<string> shell = new HashSet<string>("legacy-context-menu center-taskbar combine-taskbar-buttons taskbar-search taskbar-task-view taskbar-battery end-task-right-click show-file-extensions show-hidden-files small-desktop-icons explorer-launch-target start-bing-search start-recommendations".Split(' '));

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern IntPtr SendMessageTimeout(IntPtr h, uint m, IntPtr w, string l, uint f, uint t, out IntPtr r);

	[DllImport("shell32.dll")]
	private static extern void SHChangeNotify(uint e, uint f, IntPtr a, IntPtr b);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern IntPtr FindWindow(string c, string n);

	[DllImport("user32.dll")]
	private static extern uint GetWindowThreadProcessId(IntPtr h, out uint p);

	[DllImport("user32.dll", SetLastError = true)]
	private static extern bool SystemParametersInfo(uint a, uint p, IntPtr v, uint f);

	[DllImport("user32.dll", EntryPoint = "SystemParametersInfoW")]
	private static extern bool Animation(uint a, uint p, ref AnimationInfo v, uint f);

	private static int Value(string path, string name, int fallback)
	{
		using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(path);
		return (registryKey == null) ? fallback : Convert.ToInt32(registryKey.GetValue(name, fallback));
	}

	public static string After(Tweak t)
	{
		if (Suppress || (!shell.Contains(t.Id) && !(t.Category == "Appearance") && !(t.Id == "disable-animations")))
		{
			return "";
		}
		try
		{
			SendMessageTimeout(new IntPtr(65535), 26u, IntPtr.Zero, "ImmersiveColorSet", 2u, 500u, out var r);
			SendMessageTimeout(new IntPtr(65535), 26u, IntPtr.Zero, "Windows", 2u, 500u, out r);
			SHChangeNotify(134217728u, 0u, IntPtr.Zero, IntPtr.Zero);
			if (t.Id == "disable-animations")
			{
				bool flag = Value("Control Panel\\Desktop\\WindowMetrics", "MinAnimate", 1) != 0;
				AnimationInfo animationInfo = default(AnimationInfo);
				animationInfo.Size = 8u;
				animationInfo.Enabled = (flag ? 1 : 0);
				AnimationInfo v = animationInfo;
				if (!Animation(73u, 8u, ref v, 2u))
				{
					return " Saved; Windows could not refresh animations. Sign out to activate.";
				}
				SystemParametersInfo(4163u, 0u, new IntPtr(flag ? 1 : 0), 2u);
			}
			if (t.Id == "window-snapping")
			{
				SystemParametersInfo(131u, 0u, new IntPtr(Value("Control Panel\\Desktop", "WindowArrangementActive", 1)), 2u);
			}
			if (!shell.Contains(t.Id))
			{
				return " Windows appearance refresh requested; applications that cache their theme may need reopening.";
			}
			lock (gate)
			{
				if (refresh != null)
				{
					refresh.Dispose();
				}
				refresh = new Timer(delegate
				{
					Restart();
				}, null, 1200, -1);
			}
			return " Explorer refresh scheduled; folder windows may briefly close.";
		}
		catch (Exception ex)
		{
			return " Saved; interface refresh failed: " + ex.Message;
		}
	}

	private static void Restart()
	{
		try
		{
			IntPtr intPtr = FindWindow("Shell_TrayWnd", null);
			if (intPtr == IntPtr.Zero)
			{
				return;
			}
			GetWindowThreadProcessId(intPtr, out var p);
			using (Process process = Process.GetProcessById((int)p))
			{
				if (process.SessionId != Process.GetCurrentProcess().SessionId || !process.ProcessName.Equals("explorer", StringComparison.OrdinalIgnoreCase))
				{
					return;
				}
				process.Kill();
				process.WaitForExit(5000);
			}
			Thread.Sleep(700);
			if (FindWindow("Shell_TrayWnd", null) == IntPtr.Zero)
			{
				Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe"))
				{
					UseShellExecute = true
				});
			}
		}
		catch
		{
		}
	}
}
