using System;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;

namespace Aziz;

internal static class DriverInstaller
{
	public static void VerifyPublisher(string file, string publisher)
	{
		ToolCompatibility.CheckExecutable(file);
		// The organisation (O=) of the signing certificate must be the vendor itself, not just contain its name.
		string text = ((publisher == "NVIDIA") ? "(^|,\\s*)O=NVIDIA Corporation(,|$)" : ((publisher == "Advanced Micro Devices") ? "(^|,\\s*)O=\"?Advanced Micro Devices" : Regex.Escape(publisher)));
		string script = "$s=Get-AuthenticodeSignature -LiteralPath '" + file.Replace("'", "''") + "';if($s.Status -ne 'Valid' -or $s.SignerCertificate.Subject -notmatch '" + text.Replace("'", "''") + "'){throw 'Installer publisher signature is not valid.'}";
		ActionResult actionResult = Utilities.Run("powershell.exe", GameWatch.PsArgs(script));
		if (!actionResult.Success)
		{
			throw new IOException(actionResult.Message);
		}
	}

	public static ActionResult Install(DownloadJob job, bool clean)
	{
		try
		{
			DownloadLibrary.Verify(job);
			VerifyPublisher(job.FilePath, "NVIDIA");
			string text = SecureWork.NewFolder("nvidia");
			PortableArchives.Extract(job.FilePath, text);
			string text2 = Path.Combine(text, "setup.exe");
			if (!File.Exists(text2))
			{
				throw new IOException("NVIDIA setup.exe was not found in the selected package.");
			}
			VerifyPublisher(text2, "NVIDIA");
			using Process process = Process.Start(new ProcessStartInfo(text2, "-s -noreboot -noeula -nofinish -passive -enableTelemetry:false" + (clean ? " -clean" : ""))
			{
				UseShellExecute = true,
				Verb = "runas",
				WindowStyle = ProcessWindowStyle.Hidden,
				WorkingDirectory = text
			});
			if (process == null)
			{
				throw new IOException("NVIDIA setup did not start.");
			}
			process.WaitForExit();
			bool flag = process.ExitCode == 0 || process.ExitCode == 3010;
			if (flag)
			{
				try
				{
					Directory.Delete(text, recursive: true);
				}
				catch
				{
				}
			}
			return new ActionResult
			{
				Success = flag,
				Message = (flag ? ("NVIDIA setup completed (exit " + process.ExitCode + "). Restart Windows before verifying the active driver.") : ("NVIDIA setup failed (exit " + process.ExitCode + "). Extracted files: " + text))
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
