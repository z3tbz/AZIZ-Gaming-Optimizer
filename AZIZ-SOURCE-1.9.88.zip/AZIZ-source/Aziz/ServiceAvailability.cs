using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class ServiceAvailability
{
	private static object Read(string name, string value)
	{
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + name);
		return registryKey?.GetValue(value);
	}

	internal static bool Ready(string name, out string reason)
	{
		return Ready(name, Read, File.Exists, new HashSet<string>(StringComparer.OrdinalIgnoreCase), out reason);
	}

	internal static bool Ready(string name, Func<string, string, object> read, Func<string, bool> exists, HashSet<string> visited, out string reason)
	{
		reason = "";
		if (!visited.Add(name))
		{
			return true;
		}
		object obj = read(name, "Start");
		if (obj == null || Convert.ToInt32(obj) == 4)
		{
			reason = "Missing or disabled dependency: " + name;
			return false;
		}
		string text = Convert.ToString(read(name, "ImagePath"));
		if (string.IsNullOrWhiteSpace(text) || !exists(BinaryPath(text)))
		{
			reason = "Service executable is missing: " + name;
			return false;
		}
		string text2 = Convert.ToString(read(name + "\\Parameters", "ServiceDll"));
		if (!string.IsNullOrWhiteSpace(text2) && !exists(BinaryPath(text2)))
		{
			reason = "Service component DLL is missing: " + name;
			return false;
		}
		string[] array = (read(name, "DependOnService") as string[]) ?? new string[0];
		foreach (string text3 in array)
		{
			if (!text3.StartsWith("+") && !Ready(text3, read, exists, visited, out reason))
			{
				return false;
			}
		}
		return true;
	}

	internal static string BinaryPath(string command)
	{
		string text = Environment.ExpandEnvironmentVariables(command).Trim();
		if (text.StartsWith("\""))
		{
			int num = text.IndexOf('"', 1);
			if (num > 0)
			{
				text = text.Substring(1, num - 1);
			}
		}
		else
		{
			Match match = Regex.Match(text, "^(.+?\\.(exe|sys|dll))(?=\\s|$)", RegexOptions.IgnoreCase);
			if (match.Success)
			{
				text = match.Groups[1].Value;
			}
		}
		if (text.StartsWith("\\??\\"))
		{
			text = text.Substring(4);
		}
		if (text.StartsWith("\\SystemRoot\\", StringComparison.OrdinalIgnoreCase))
		{
			text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), text.Substring(12));
		}
		if (!Path.IsPathRooted(text))
		{
			text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), text);
		}
		return text;
	}
}
