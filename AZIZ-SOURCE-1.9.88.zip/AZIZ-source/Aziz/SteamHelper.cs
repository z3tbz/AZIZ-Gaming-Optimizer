using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Microsoft.Win32;

namespace Aziz;

// NoSteamWebHelper: the bundled setup (Tools\NoSteamWebHelper\SteamTrayWebHelper.exe) is installed silently into
// a folder inside Steam's own folder and started with Windows; the tool itself switches the web helper off while a game runs.
internal static class SteamHelper
{
	private const string RunKey = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";

	private const string RunName = "AZIZ NoSteamWebHelper";

	private static readonly string[] OldFiles = new string[2] { "umpdc.dll", "umpdc_system.dll" };

	public static string SteamFolder()
	{
		using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Valve\\Steam");
		string text = ((registryKey == null) ? null : Convert.ToString(registryKey.GetValue("SteamPath")));
		if (string.IsNullOrEmpty(text))
		{
			return null;
		}
		text = Path.GetFullPath(text.Replace('/', '\\'));
		return File.Exists(Path.Combine(text, "steam.exe")) ? text : null;
	}

	private static string Setup()
	{
		return Path.Combine(Program.Root, "Tools", "NoSteamWebHelper", "SteamTrayWebHelper.exe");
	}

	internal static string Folder(string steam)
	{
		return Path.Combine(steam, "NoSteamWebHelper");
	}

	// The program the setup put in the folder (not its uninstaller).
	// Never guesses inside the Steam folder itself (that would find steam.exe): there only the files the setup
	// reported in its log (nosteamwebhelper.txt) count. In a folder of its own, the one exe that is not the uninstaller.
	private static string Executable(string folder)
	{
		string recorded = RecordedFiles().FirstOrDefault((string f) => f.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && !IsInnoUninstaller(f));
		if (recorded != null)
		{
			return recorded;
		}
		if (!Directory.Exists(folder) || SameFolder(folder, SteamFolder()))
		{
			return null;
		}
		return Directory.GetFiles(folder, "*.exe", SearchOption.TopDirectoryOnly).Where((string f) => !IsInnoUninstaller(f)).OrderByDescending((string f) => Path.GetFileName(f).IndexOf("steam", StringComparison.OrdinalIgnoreCase) >= 0)
			.FirstOrDefault();
	}

	// Inno Setup uninstallers are unins000.exe, unins001.exe… — Steam's own uninstall.exe must never match.
	private static bool IsInnoUninstaller(string file)
	{
		return System.Text.RegularExpressions.Regex.IsMatch(Path.GetFileName(file), "^unins\\d{3}\\.exe$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
	}

	private static bool SameFolder(string a, string b)
	{
		if (a == null || b == null)
		{
			return false;
		}
		return string.Equals(Path.GetFullPath(a).TrimEnd('\\'), Path.GetFullPath(b).TrimEnd('\\'), StringComparison.OrdinalIgnoreCase);
	}

	private static List<string> RecordedFiles()
	{
		try
		{
			return File.Exists(RecordFile) ? File.ReadAllLines(RecordFile).Where(File.Exists).ToList() : new List<string>();
		}
		catch
		{
			return new List<string>();
		}
	}

	// Starts a program as the signed-in user (not elevated like AZIZ): Explorer launches it at normal rights,
	// so Steam and every game it starts do not run as administrator.
	private static void StartAsUser(string exe)
	{
		try
		{
			Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe"), "\"" + exe + "\"")
			{
				UseShellExecute = false
			})?.Dispose();
		}
		catch
		{
		}
	}

	public static bool Installed()
	{
		string text = SteamFolder();
		if (text == null)
		{
			return false;
		}
		try
		{
			if (File.Exists(RecordFile) && File.ReadAllLines(RecordFile).Any(File.Exists))
			{
				return true;
			}
		}
		catch
		{
		}
		string text2 = InstallLocation();
		if (text2 != null && Executable(text2) != null)
		{
			return true;
		}
		if (Executable(Folder(text)) == null)
		{
			return OldFiles.Any((string f) => File.Exists(Path.Combine(text, f)));
		}
		return true;
	}

	// Where the setup put it (the user can choose the folder): read from the uninstall entries.
	private static string InstallLocation()
	{
		string[] array = new string[2] { "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall" };
		RegistryKey[] array2 = new RegistryKey[2] { Registry.LocalMachine, Registry.CurrentUser };
		foreach (RegistryKey registryKey in array2)
		{
			foreach (string name in array)
			{
				using RegistryKey registryKey2 = registryKey.OpenSubKey(name);
				if (registryKey2 == null)
				{
					continue;
				}
				foreach (string subKeyName in registryKey2.GetSubKeyNames())
				{
					using RegistryKey registryKey3 = registryKey2.OpenSubKey(subKeyName);
					string text = Convert.ToString(registryKey3?.GetValue("DisplayName"));
					if (text.IndexOf("SteamWebHelper", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("Steam Web Helper", StringComparison.OrdinalIgnoreCase) >= 0 || text.IndexOf("SteamTray", StringComparison.OrdinalIgnoreCase) >= 0)
					{
						string text2 = Convert.ToString(registryKey3.GetValue("InstallLocation")).Trim('"', ' ');
						if (text2.Length > 0 && Directory.Exists(text2))
						{
							return text2.TrimEnd('\\');
						}
					}
				}
			}
		}
		return null;
	}

	private static bool CloseSteam(string steam)
	{
		if (Process.GetProcessesByName("steam").Length == 0)
		{
			return true;
		}
		Process.Start(new ProcessStartInfo(Path.Combine(steam, "steam.exe"), "-shutdown")
		{
			UseShellExecute = false
		});
		for (int i = 0; i < 40; i++)
		{
			if (Process.GetProcessesByName("steam").Length == 0)
			{
				return true;
			}
			Thread.Sleep(500);
		}
		return Process.GetProcessesByName("steam").Length == 0;
	}

	private static string LogFile => Path.Combine(Program.Data, "nosteamwebhelper-setup.log");

	private static string RecordFile => Path.Combine(Program.Data, "nosteamwebhelper.txt");

	// Files the setup wrote, read from its own log ("Dest filename: …"), so the result does not depend on guessing its layout.
	private static List<string> LoggedFiles()
	{
		List<string> list = new List<string>();
		if (!File.Exists(LogFile))
		{
			return list;
		}
		foreach (string line in File.ReadAllLines(LogFile))
		{
			int num = line.IndexOf("Dest filename:", StringComparison.OrdinalIgnoreCase);
			if (num >= 0)
			{
				string text = line.Substring(num + 14).Trim();
				if (text.Length > 0 && File.Exists(text) && !list.Contains(text, StringComparer.OrdinalIgnoreCase))
				{
					list.Add(text);
				}
			}
		}
		return list;
	}

	private static string LogTail()
	{
		try
		{
			string[] array = File.ReadAllLines(LogFile);
			return string.Join(" | ", array.Skip(Math.Max(0, array.Length - 4)).Select((string l) => l.Trim()));
		}
		catch
		{
			return "";
		}
	}

	private static void StartSteam(string steam)
	{
		Process[] processesByName = Process.GetProcessesByName("steam");
		bool running = processesByName.Length != 0;
		foreach (Process item in processesByName)
		{
			item.Dispose();
		}
		if (!running)
		{
			StartAsUser(Path.Combine(steam, "steam.exe"));
		}
	}


	public static ActionResult Install(string target = null, bool interactiveFallback = true)
	{
		try
		{
			string text = SteamFolder();
			if (text == null)
			{
				return new ActionResult
				{
					Message = "Steam is not installed for this Windows user."
				};
			}
			string text2 = Setup();
			if (!File.Exists(text2))
			{
				return new ActionResult
				{
					Message = "The NoSteamWebHelper setup is missing from the AZIZ Tools folder. Extract the whole AZIZ zip again."
				};
			}
			if (!CloseSteam(text))
			{
				return new ActionResult
				{
					Message = "Close Steam completely, then press the button again."
				};
			}
			Directory.CreateDirectory(Program.Data);
			// Installed straight into the Steam folder (no subfolder), silently.
			string text3 = (string.IsNullOrEmpty(target) ? text : target);
			try
			{
				File.Delete(LogFile);
			}
			catch
			{
			}
			int exitCode;
			using (Process process = Process.Start(new ProcessStartInfo(text2, "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP- /ALLUSERS /DIR=\"" + text3 + "\" /LOG=\"" + LogFile + "\"")
			{
				UseShellExecute = false,
				CreateNoWindow = true
			}))
			{
				if (!process.WaitForExit(300000))
				{
					return new ActionResult
					{
						Message = "The setup did not finish in 5 minutes."
					};
				}
				exitCode = process.ExitCode;
			}
			List<string> list = LoggedFiles();
			if (list.Count == 0 && interactiveFallback)
			{
				// Silent mode wrote nothing: open the setup normally so the user can finish it.
				using (Process process2 = Process.Start(new ProcessStartInfo(text2, "/DIR=\"" + text3 + "\" /LOG=\"" + LogFile + "\"")
				{
					UseShellExecute = true
				}))
				{
					process2.WaitForExit();
				}
				list = LoggedFiles();
			}
			if (list.Count == 0)
			{
				return new ActionResult
				{
					Message = "The setup finished (code " + exitCode + ") but installed no files. Log: " + LogTail()
				};
			}
			File.WriteAllLines(RecordFile, list);
			string text4 = list.Where((string f) => f.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && !Path.GetFileName(f).StartsWith("unins", StringComparison.OrdinalIgnoreCase)).OrderByDescending((string f) => Path.GetFileName(f).IndexOf("steam", StringComparison.OrdinalIgnoreCase) >= 0).FirstOrDefault();
			string text5 = Path.GetDirectoryName(list[0]);
			if (text4 == null)
			{
				// No program: the tool is a library Steam loads itself (it sits next to steam.exe).
				StartSteam(text);
				return new ActionResult
				{
					Success = true,
					Message = "NoSteamWebHelper installed (" + string.Join(", ", list.Select(Path.GetFileName)) + ") in " + text5 + " · Steam loads it on start."
				};
			}
			using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey(RunKey))
			{
				registryKey.SetValue(RunName, "\"" + text4 + "\"");
			}
			string name = Path.GetFileNameWithoutExtension(text4);
			if (Process.GetProcessesByName(name).Length == 0)
			{
				StartAsUser(text4);
			}
			for (int i = 0; i < 20 && Process.GetProcessesByName(name).Length == 0; i++)
			{
				Thread.Sleep(500);
			}
			StartSteam(text);
			if (Process.GetProcessesByName(name).Length == 0)
			{
				return new ActionResult
				{
					Message = "Installed " + Path.GetFileName(text4) + " in " + Path.GetDirectoryName(text4) + " but it closed right after starting."
				};
			}
			return new ActionResult
			{
				Success = true,
				Message = "NoSteamWebHelper installed in " + Path.GetDirectoryName(text4) + " · " + Path.GetFileName(text4) + " is running and starts with Windows."
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static ActionResult Remove()
	{
		try
		{
			string text = SteamFolder();
			if (text == null)
			{
				return new ActionResult
				{
					Message = "Steam is not installed."
				};
			}
			string text2 = InstallLocation() ?? Folder(text);
			try
			{
				string text5 = File.ReadAllLines(RecordFile).FirstOrDefault(File.Exists);
				if (text5 != null && (!Directory.Exists(text2) || !Directory.GetFiles(text2, "unins*.exe").Any(IsInnoUninstaller)))
				{
					text2 = Path.GetDirectoryName(text5);
				}
			}
			catch
			{
			}
			string text3 = Executable(text2);
			if (text3 != null)
			{
				foreach (Process item in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(text3)))
				{
					try
					{
						item.Kill();
						item.WaitForExit(5000);
					}
					catch
					{
					}
				}
			}
			string text4 = RecordedFiles().FirstOrDefault(IsInnoUninstaller) ?? (Directory.Exists(text2) ? Directory.GetFiles(text2, "unins*.exe").Where(IsInnoUninstaller).OrderByDescending((string f) => f).FirstOrDefault() : null);
			if (text4 != null)
			{
				using Process process = Process.Start(new ProcessStartInfo(text4, "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART")
				{
					UseShellExecute = false,
					CreateNoWindow = true
				});
				process.WaitForExit(120000);
			}
			try
			{
				File.Delete(RecordFile);
			}
			catch
			{
			}
			using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey(RunKey, writable: true))
			{
				registryKey?.DeleteValue(RunName, throwOnMissingValue: false);
			}
			if (Process.GetProcessesByName("steam").Length == 0)
			{
				foreach (string item2 in OldFiles.Select((string f) => Path.Combine(text, f)).Where(File.Exists))
				{
					File.Delete(item2);
				}
			}
			return new ActionResult
			{
				Success = true,
				Message = "NoSteamWebHelper removed and no longer starts with Windows."
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
