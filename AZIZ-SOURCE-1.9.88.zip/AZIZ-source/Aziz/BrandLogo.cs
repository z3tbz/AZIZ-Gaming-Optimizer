using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Aziz;

internal static class BrandLogo
{
	public static ImageSource ExternalImage()
	{
		string text = Path.Combine(Program.Root, "aziz.ico");
		if (File.Exists(text))
		{
			try
			{
				BitmapFrame bitmapFrame = BitmapFrame.Create(new Uri(text, UriKind.Absolute), BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
				bitmapFrame.Freeze();
				return bitmapFrame;
			}
			catch
			{
			}
		}
		return Image(0);
	}

	public static DrawingImage Image(int variant)
	{
		DrawingImage drawingImage = new DrawingImage(BrandArt.Drawing());
		drawingImage.Freeze();
		return drawingImage;
	}

	public static FrameworkElement View(int variant, double size)
	{
		DrawingImage drawingImage = new DrawingImage(BrandArt.Wordmark());
		drawingImage.Freeze();
		Image obj = new Image
		{
			Source = drawingImage,
			Width = size,
			Height = size,
			Stretch = Stretch.Uniform
		};
		RenderOptions.SetBitmapScalingMode(obj, BitmapScalingMode.HighQuality);
		return obj;
	}
}
