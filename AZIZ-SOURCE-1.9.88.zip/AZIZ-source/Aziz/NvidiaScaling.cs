using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;

namespace Aziz;

internal static class NvidiaScaling
{
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int Init();

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int GetConfig(ref uint count, IntPtr paths);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int SetConfig(uint count, IntPtr paths, uint flags);

	private sealed class Config : IDisposable
	{
		private readonly List<IntPtr> buffers = new List<IntPtr>();

		public uint Count;

		public IntPtr Paths;

		public Dictionary<uint, IntPtr> Details = new Dictionary<uint, IntPtr>();

		private bool initialized;

		private IntPtr Alloc(int n)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(n);
			buffers.Add(intPtr);
			Marshal.Copy(new byte[n], 0, intPtr, n);
			return intPtr;
		}

		public Config()
		{
			try
			{
				if (IntPtr.Size != 8)
				{
					throw new NotSupportedException("NVIDIA display control requires x64.");
				}
				Check(Api<Init>(22079528u)());
				initialized = true;
				GetConfig getConfig = Api<GetConfig>(296471800u);
				Count = 0u;
				Check(getConfig(ref Count, IntPtr.Zero));
				if (Count == 0 || Count > 32)
				{
					throw new NotSupportedException("No supported display topology.");
				}
				Paths = Alloc((int)(Count * 48));
				for (int i = 0; i < Count; i++)
				{
					IntPtr ptr = IntPtr.Add(Paths, i * 48);
					Marshal.WriteInt32(ptr, 131120);
					Marshal.WriteIntPtr(ptr, 24, Alloc(32));
					Marshal.WriteIntPtr(ptr, 40, Alloc(8));
				}
				uint count = Count;
				Check(getConfig(ref Count, Paths));
				if (Count != count)
				{
					throw new InvalidOperationException("Display topology changed. Try again.");
				}
				for (int j = 0; j < Count; j++)
				{
					IntPtr ptr2 = IntPtr.Add(Paths, j * 48);
					int num = Marshal.ReadInt32(ptr2, 8);
					if (num < 0 || num > 32)
					{
						throw new InvalidDataException("Invalid display target count.");
					}
					bool flag = (Marshal.ReadInt32(ptr2, 32) & 1) != 0;
					IntPtr intPtr = Alloc(num * 24);
					Marshal.WriteIntPtr(ptr2, 16, intPtr);
					for (int k = 0; k < num; k++)
					{
						IntPtr ptr3 = IntPtr.Add(intPtr, k * 24);
						if (!flag)
						{
							IntPtr intPtr2 = Alloc(128);
							Marshal.WriteInt32(intPtr2, 65664);
							Marshal.WriteIntPtr(ptr3, 8, intPtr2);
						}
					}
				}
				Check(getConfig(ref Count, Paths));
				if (Count != count)
				{
					throw new InvalidOperationException("Display topology changed. Try again.");
				}
				for (int l = 0; l < Count; l++)
				{
					IntPtr ptr4 = IntPtr.Add(Paths, l * 48);
					if (((uint)Marshal.ReadInt32(ptr4, 32) & (true ? 1u : 0u)) != 0)
					{
						continue;
					}
					int num2 = Marshal.ReadInt32(ptr4, 8);
					IntPtr pointer = Marshal.ReadIntPtr(ptr4, 16);
					for (int m = 0; m < num2; m++)
					{
						IntPtr ptr5 = IntPtr.Add(pointer, m * 24);
						IntPtr intPtr3 = Marshal.ReadIntPtr(ptr5, 8);
						if (intPtr3 != IntPtr.Zero)
						{
							Details[(uint)Marshal.ReadInt32(ptr5)] = intPtr3;
						}
					}
				}
				if (Details.Count == 0)
				{
					throw new NotSupportedException("No display is driven directly by NVIDIA. On hybrid laptops the internal panel may be connected to another GPU.");
				}
			}
			catch
			{
				Dispose();
				throw;
			}
		}

		public Dictionary<string, int> Modes()
		{
			return Details.ToDictionary((KeyValuePair<uint, IntPtr> p) => p.Key.ToString(), (KeyValuePair<uint, IntPtr> p) => Marshal.ReadInt32(p.Value, 8));
		}

		public void Change(Dictionary<string, int> modes)
		{
			foreach (KeyValuePair<uint, IntPtr> detail in Details)
			{
				if (!modes.TryGetValue(detail.Key.ToString(), out var value))
				{
					throw new InvalidOperationException("The display arrangement changed. No saved scaling mode exists for this display.");
				}
				Marshal.WriteInt32(detail.Value, 8, value);
			}
			SetConfig setConfig = Api<SetConfig>(1569519838u);
			Check(setConfig(Count, Paths, 1u));
			Check(setConfig(Count, Paths, 2u));
		}

		public void Dispose()
		{
			foreach (IntPtr buffer in buffers)
			{
				Marshal.FreeHGlobal(buffer);
			}
			buffers.Clear();
			if (initialized)
			{
				initialized = false;
				try
				{
					Api<Init>(3526090110u)();
				}
				catch
				{
				}
			}
		}
	}

	[DllImport("nvapi64.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "nvapi_QueryInterface")]
	private static extern IntPtr Query(uint id);

	private static T Api<T>(uint id) where T : class
	{
		IntPtr intPtr = Query(id);
		if (intPtr == IntPtr.Zero)
		{
			throw new NotSupportedException("The installed NVIDIA driver does not expose this display API.");
		}
		return Marshal.GetDelegateForFunctionPointer(intPtr, typeof(T)) as T;
	}

	private static void Check(int result)
	{
		if (result != 0)
		{
			throw new InvalidOperationException("NVIDIA display configuration returned " + result + ". Use NVIDIA Control Panel for this driver/display.");
		}
	}

	internal static bool IsNoScaling(int mode)
	{
		if (mode != 3)
		{
			return mode == 7;
		}
		return true;
	}

	public static TweakStatus State()
	{
		try
		{
			using Config config = new Config();
			Dictionary<string, int> dictionary = config.Modes();
			return new TweakStatus
			{
				State = (dictionary.Values.All(IsNoScaling) ? "Enabled" : "Disabled"),
				Detail = "Current NVIDIA display scaling modes: " + string.Join(", ", dictionary.Select((KeyValuePair<string, int> x) => x.Key + "=" + x.Value)) + ". On = centered/no scaling. Off restores the saved modes."
			};
		}
		catch (Exception ex)
		{
			return new TweakStatus
			{
				State = "Unavailable",
				Detail = ex.Message
			};
		}
	}

	public static ActionResult Set(bool enable, string data)
	{
		try
		{
			string path = Path.Combine(data, "nvidia-display-scaling.json");
			using (Config config = new Config())
			{
				Dictionary<string, int> dictionary = config.Modes();
				Dictionary<string, int> modes;
				if (enable)
				{
					if (!File.Exists(path))
					{
						Utilities.AtomicWrite(path, Program.Json.Serialize(dictionary));
					}
					modes = dictionary.ToDictionary((KeyValuePair<string, int> p) => p.Key, (KeyValuePair<string, int> p) => 3);
				}
				else
				{
					if (!File.Exists(path))
					{
						return new ActionResult
						{
							Message = "No previous NVIDIA scaling modes were saved. Choose the preferred default in NVIDIA Control Panel."
						};
					}
					modes = Program.Json.Deserialize<Dictionary<string, int>>(File.ReadAllText(path));
				}
				try
				{
					config.Change(modes);
				}
				catch
				{
					try
					{
						config.Change(dictionary);
					}
					catch
					{
					}
					throw;
				}
			}
			using (Config config2 = new Config())
			{
				Dictionary<string, int> dictionary2 = config2.Modes();
				if (enable && !dictionary2.Values.All(IsNoScaling))
				{
					throw new IOException("The driver did not retain No scaling.");
				}
				if (!enable)
				{
					Dictionary<string, int> saved = Program.Json.Deserialize<Dictionary<string, int>>(File.ReadAllText(path));
					if (dictionary2.Any((KeyValuePair<string, int> p) => !saved.ContainsKey(p.Key) || saved[p.Key] != p.Value))
					{
						throw new IOException("Restored scaling differs from the saved settings.");
					}
					File.Delete(path);
				}
			}
			return new ActionResult
			{
				Success = true,
				Message = (enable ? "NVIDIA No scaling applied and read back." : "Previous display scaling restored and read back.")
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
