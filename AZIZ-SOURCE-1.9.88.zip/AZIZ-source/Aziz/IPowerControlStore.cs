using System;

namespace Aziz;

internal interface IPowerControlStore
{
	Guid Active();

	uint Read(Guid scheme, PowerParameter setting, bool battery);

	uint Default(Guid scheme, PowerParameter setting, bool battery);

	void Write(Guid scheme, PowerParameter setting, bool battery, uint value);

	void Refresh(Guid scheme);
}
