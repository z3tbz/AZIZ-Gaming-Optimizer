using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Aziz;

internal static class DownloadManager
{
	private static readonly HttpClient Client = CreateClient();

	private static readonly Lazy<List<DownloadItem>> Items = new Lazy<List<DownloadItem>>(ReadCatalog);

	private static HttpClient CreateClient()
	{
		ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
		ServicePointManager.DefaultConnectionLimit = Math.Max(48, ServicePointManager.DefaultConnectionLimit);
		HttpClient httpClient = new HttpClient(new HttpClientHandler
		{
			AllowAutoRedirect = true,
			MaxAutomaticRedirections = 8
		});
		httpClient.Timeout = TimeSpan.FromMinutes(30.0);
		httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AZIZ-Gaming-Optimizer/1.9.7");
		return httpClient;
	}

	public static List<DownloadItem> Catalog()
	{
		return Items.Value;
	}

	private static List<DownloadItem> ReadCatalog()
	{
		using Stream stream = typeof(DownloadManager).Assembly.GetManifestResourceStream("Aziz.downloads-local.json");
		using StreamReader streamReader = new StreamReader(stream);
		return Program.Json.Deserialize<List<DownloadItem>>(streamReader.ReadToEnd());
	}

	private static Uri Https(string url)
	{
		if (!Uri.TryCreate(url, UriKind.Absolute, out var result) || result.Scheme != "https" || !string.IsNullOrEmpty(result.UserInfo))
		{
			throw new InvalidDataException("A secure HTTPS download URL is required.");
		}
		return result;
	}

	public static Task Run(DownloadJob job, Action changed)
	{
		return RunWithClient(job, changed, Client, DownloadLibrary.Folder);
	}

	internal static async Task RunWithClient(DownloadJob job, Action changed, HttpClient client, string folder)
	{
		string temporary = null;
		try
		{
			job.State = "Resolving";
			changed();
			DownloadItem item = job.Item;
			string url = item.DirectUrl;
			string expectedDigest = (string.IsNullOrEmpty(job.Item.Sha256) ? null : ("sha256:" + job.Item.Sha256));
			string name = item.FileName;
			if (item.Resolver == "GamepadlaPolling2")
			{
				Match match = Regex.Match(await client.GetStringAsync("https://gamepadla.itch.io/polling"), "name=\"csrf_token\" value=\"([^\"]+)\"");
				if (!match.Success)
				{
					throw new IOException("Publisher download form unavailable.");
				}
				using HttpResponseMessage httpResponseMessage = await client.PostAsync("https://gamepadla.itch.io/polling/file/17851087", new FormUrlEncodedContent(new Dictionary<string, string> { 
				{
					"csrf_token",
					WebUtility.HtmlDecode(match.Groups[1].Value)
				} }), job.Cancel.Token);
				httpResponseMessage.EnsureSuccessStatusCode();
				JavaScriptSerializer obj = Program.Json;
				Dictionary<string, object> dictionary = obj.Deserialize<Dictionary<string, object>>(await httpResponseMessage.Content.ReadAsStringAsync());
				if (!dictionary.ContainsKey("url"))
				{
					throw new IOException("Publisher did not provide the download.");
				}
				Uri uri = Https(Convert.ToString(dictionary["url"]));
				if (!uri.Host.EndsWith(".cloudflarestorage.com", StringComparison.OrdinalIgnoreCase) && !uri.Host.EndsWith(".itch.zone", StringComparison.OrdinalIgnoreCase))
				{
					throw new IOException("Unexpected publisher download host.");
				}
				url = uri.AbsoluteUri;
			}
			if (item.Resolver == "TechPowerUpNVCleanstall")
			{
				using HttpRequestMessage httpRequestMessage2 = new HttpRequestMessage(HttpMethod.Post, "https://www.techpowerup.com/download/techpowerup-nvcleanstall/");
				httpRequestMessage2.Content = new FormUrlEncodedContent(new Dictionary<string, string>
				{
					{ "id", "2849" },
					{ "server_id", "5" }
				});
				using HttpResponseMessage httpResponseMessage2 = await client.SendAsync(httpRequestMessage2, HttpCompletionOption.ResponseHeadersRead, job.Cancel.Token);
				httpResponseMessage2.EnsureSuccessStatusCode();
				Uri requestUri = httpResponseMessage2.RequestMessage.RequestUri;
				if (!requestUri.Host.EndsWith(".techpowerup.com", StringComparison.OrdinalIgnoreCase) || !requestUri.AbsolutePath.EndsWith("NVCleanstall_1.19.0.exe", StringComparison.OrdinalIgnoreCase))
				{
					throw new IOException("The publisher did not provide the expected NVCleanstall package.");
				}
				url = requestUri.AbsoluteUri;
			}
			if (item.Resolver == "TechPowerUp")
			{
				Uri page = Https(url);
				if (!page.Host.EndsWith("techpowerup.com", StringComparison.OrdinalIgnoreCase))
				{
					throw new InvalidDataException("Unexpected publisher page");
				}
				Match match2 = Regex.Match(await client.GetStringAsync(page), "name=\"id\" value=\"(\\d+)\"");
				if (!match2.Success)
				{
					throw new IOException("Publisher download form unavailable.");
				}
				using HttpRequestMessage httpRequestMessage2 = new HttpRequestMessage(HttpMethod.Post, page);
				httpRequestMessage2.Content = new FormUrlEncodedContent(new Dictionary<string, string>
				{
					{
						"id",
						match2.Groups[1].Value
					},
					{ "server_id", "5" }
				});
				using HttpResponseMessage httpResponseMessage3 = await client.SendAsync(httpRequestMessage2, HttpCompletionOption.ResponseHeadersRead, job.Cancel.Token);
				httpResponseMessage3.EnsureSuccessStatusCode();
				Uri requestUri2 = httpResponseMessage3.RequestMessage.RequestUri;
				if (!requestUri2.Host.EndsWith(".techpowerup.com", StringComparison.OrdinalIgnoreCase) || !requestUri2.AbsolutePath.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
				{
					throw new IOException("The publisher did not provide the expected package.");
				}
				url = requestUri2.AbsoluteUri;
				name = Path.GetFileName(requestUri2.AbsolutePath);
			}
			if (item.Resolver == "MicrosoftMSRT")
			{
				using HttpResponseMessage httpResponseMessage = await client.GetAsync(Https("https://www.microsoft.com/en-us/download/details.aspx?id=9905"), job.Cancel.Token);
				httpResponseMessage.EnsureSuccessStatusCode();
				Match match3 = Regex.Match(await httpResponseMessage.Content.ReadAsStringAsync(), "https://download\\.microsoft\\.com/[^\"<>\\s]+?Windows-KB890830-x64-V[0-9.]+\\.exe");
				if (!match3.Success)
				{
					throw new IOException("Microsoft has not supplied a usable current MSRT link.");
				}
				url = WebUtility.HtmlDecode(match3.Value);
			}
			if (item.Resolver == "MediaFire")
			{
				Uri uri2 = Https(url);
				if (uri2.Host != "www.mediafire.com" || !uri2.AbsolutePath.Contains("/wt37sbsejk7iepm/"))
				{
					throw new InvalidDataException("Unexpected publisher page");
				}
				using HttpResponseMessage httpResponseMessage = await client.GetAsync(uri2, job.Cancel.Token);
				httpResponseMessage.EnsureSuccessStatusCode();
				Match match4 = Regex.Match(await httpResponseMessage.Content.ReadAsStringAsync(), "https://download[0-9]+\\.mediafire\\.com/[^\"<>\\s]+/PowerSettingsExplorer\\.zip");
				if (!match4.Success)
				{
					throw new IOException("Publisher download link is temporarily unavailable.");
				}
				url = WebUtility.HtmlDecode(match4.Value);
			}
			if (!string.IsNullOrEmpty(item.Repo))
			{
				if (!Regex.IsMatch(item.Repo, "^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$"))
				{
					throw new InvalidDataException("Invalid release repository.");
				}
				using HttpResponseMessage httpResponseMessage = await client.GetAsync(Https("https://api.github.com/repos/" + item.Repo + "/releases/latest"), job.Cancel.Token);
				httpResponseMessage.EnsureSuccessStatusCode();
				JavaScriptSerializer obj = Program.Json;
				IEnumerable obj3 = (IEnumerable)obj.Deserialize<Dictionary<string, object>>(await httpResponseMessage.Content.ReadAsStringAsync())["assets"];
				Dictionary<string, object> dictionary2 = null;
				foreach (Dictionary<string, object> item2 in obj3)
				{
					if (Regex.IsMatch(Convert.ToString(item2["name"]), item.Pattern, RegexOptions.IgnoreCase))
					{
						dictionary2 = item2;
						break;
					}
				}
				if (dictionary2 == null)
				{
					throw new InvalidOperationException("This release has no matching x64 package. Try again after the publisher updates it.");
				}
				url = Convert.ToString(dictionary2["browser_download_url"]);
				name = Convert.ToString(dictionary2["name"]);
				if (dictionary2.ContainsKey("digest"))
				{
					expectedDigest = Convert.ToString(dictionary2["digest"]);
				}
			}
			if (string.IsNullOrEmpty(name))
			{
				name = item.Id + "-setup.exe";
			}
			DownloadLibrary.CleanName(name);
			DownloadLibrary.NoLinks(folder);
			Directory.CreateDirectory(folder);
			temporary = Path.Combine(folder, ".download-" + Guid.NewGuid().ToString("N") + ".part");
			if (!((!(item.Resolver == "AZIZParts")) ? (await SegmentDownload.TryDownload(client, Https(url), temporary, job, changed)) : (await HostedDownloads.Fetch(client, url, temporary, job, changed))))
			{
				using HttpRequestMessage httpRequestMessage2 = new HttpRequestMessage(HttpMethod.Get, Https(url));
				if (!string.IsNullOrEmpty(item.Referer))
				{
					httpRequestMessage2.Headers.Referrer = Https(item.Referer);
				}
				using HttpResponseMessage httpResponseMessage = await client.SendAsync(httpRequestMessage2, HttpCompletionOption.ResponseHeadersRead, job.Cancel.Token);
				httpResponseMessage.EnsureSuccessStatusCode();
				Https(httpResponseMessage.RequestMessage.RequestUri.AbsoluteUri);
				if (httpResponseMessage.Content.Headers.ContentType != null && (httpResponseMessage.Content.Headers.ContentType.MediaType == "text/html" || httpResponseMessage.Content.Headers.ContentType.MediaType == "application/json"))
				{
					throw new InvalidDataException("The server returned a page rather than a package.");
				}
				job.Total = httpResponseMessage.Content.Headers.ContentLength;
				job.State = "Downloading";
				changed();
				Stopwatch watch = Stopwatch.StartNew();
				long lastBytes = 0L;
				TimeSpan last = watch.Elapsed;
				using (Stream input = await httpResponseMessage.Content.ReadAsStreamAsync())
				{
					using FileStream output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 262144, useAsync: true);
					byte[] buffer = new byte[262144];
					while (true)
					{
						int num;
						int i = (num = await input.ReadAsync(buffer, 0, buffer.Length, job.Cancel.Token));
						if (num <= 0)
						{
							break;
						}
						await output.WriteAsync(buffer, 0, i, job.Cancel.Token);
						job.Bytes += i;
						if ((watch.Elapsed - last).TotalMilliseconds >= 250.0)
						{
							job.Speed = (double)(job.Bytes - lastBytes) / (watch.Elapsed - last).TotalSeconds;
							lastBytes = job.Bytes;
							last = watch.Elapsed;
							changed();
						}
					}
				}
				if (job.Total.HasValue && job.Bytes != job.Total.Value)
				{
					throw new IOException("The downloaded size does not match the server response.");
				}
			}
			if (job.Bytes == 0L)
			{
				throw new IOException("The downloaded file is empty.");
			}
			job.State = "Verifying";
			changed();
			job.Hash = await Task.Run(delegate
			{
				using SHA256 sHA = SHA256.Create();
				using FileStream inputStream = File.OpenRead(temporary);
				return BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").ToLowerInvariant();
			}, job.Cancel.Token);
			if (!string.IsNullOrEmpty(expectedDigest) && expectedDigest.StartsWith("sha256:") && !string.Equals(expectedDigest.Substring(7), job.Hash, StringComparison.OrdinalIgnoreCase))
			{
				throw new InvalidDataException("Publisher SHA-256 validation failed.");
			}
			job.Cancel.Token.ThrowIfCancellationRequested();
			job.FilePath = DownloadLibrary.Commit(temporary, folder, name);
			temporary = null;
			job.State = "Completed";
		}
		catch (OperationCanceledException)
		{
			job.State = "Cancelled";
		}
		catch (UnauthorizedAccessException)
		{
			job.State = "Failed";
			job.Error = "AZIZ cannot write to its Downloads folder. Extract the application to a folder you can write to, then retry.";
		}
		catch (Exception ex3)
		{
			job.State = "Failed";
			job.Error = ex3.Message;
		}
		finally
		{
			if (temporary != null && File.Exists(temporary))
			{
				try
				{
					File.Delete(temporary);
				}
				catch
				{
				}
			}
			changed();
		}
	}
}
