using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace Aziz;

internal static class GpuInterrupt
{
	private static Lazy<List<GpuDevice>> devices = new Lazy<List<GpuDevice>>(Discover);

	public static List<GpuDevice> Devices => devices.Value;

	public static void Invalidate()
	{
		devices = new Lazy<List<GpuDevice>>(Discover);
	}

	private static List<GpuDevice> Discover()
	{
		List<GpuDevice> list = new List<GpuDevice>();
		foreach (DisplayDevice item in DisplayHardware.PciDisplays())
		{
			string instance = item.Instance;
			string text = "SYSTEM\\CurrentControlSet\\Enum\\" + instance + "\\Device Parameters\\Interrupt Management";
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(text + "\\MessageSignaledInterruptProperties");
			if (registryKey != null && registryKey.GetValue("MSISupported") != null)
			{
				list.Add(new GpuDevice
				{
					Name = item.Name,
					Instance = instance,
					BasePath = text
				});
			}
		}
		return list;
	}

	public static TweakStatus State()
	{
		List<GpuDevice> list = Devices;
		int num = list.Count((GpuDevice d) => Read(d, "MessageSignaledInterruptProperties", "MSISupported", 0) == 1);
		return new TweakStatus
		{
			State = ((list.Count == 0) ? "Unavailable" : ((num == list.Count) ? "Enabled" : ((num == 0) ? "Disabled" : "Mixed"))),
			Detail = num + " of " + list.Count + " driver-configured PCI GPUs have MSISupported=1. Configured state; restart required. Use the device dialog for individual settings."
		};
	}

	public static int Read(GpuDevice d, string sub, string name, int fallback)
	{
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(d.BasePath + "\\" + sub);
		return (registryKey == null) ? fallback : Convert.ToInt32(registryKey.GetValue(name, fallback));
	}

	public static byte[] Mask(IEnumerable<int> cpus, int processorCount)
	{
		if (processorCount < 1 || processorCount > 64)
		{
			throw new ArgumentException("Specific CPU masks require a single processor group with at most 64 processors.");
		}
		ulong num = 0uL;
		foreach (int cpu in cpus)
		{
			if (cpu < 0 || cpu >= processorCount)
			{
				throw new ArgumentException("CPU is outside this processor group.");
			}
			num |= (ulong)(1L << cpu);
		}
		if (num == 0L)
		{
			throw new ArgumentException("Select at least one CPU.");
		}
		return BitConverter.GetBytes(num);
	}

	public static string Key(GpuDevice d)
	{
		using SHA256 sHA = SHA256.Create();
		return "gpu-msi-" + BitConverter.ToString(sHA.ComputeHash(Encoding.UTF8.GetBytes(d.Instance))).Replace("-", "").Substring(0, 20)
			.ToLowerInvariant();
	}

	internal static Tweak Profile(GpuDevice d, bool on, int priority, int policy, byte[] mask)
	{
		if (!Devices.Any((GpuDevice x) => x.Instance == d.Instance && x.BasePath == d.BasePath))
		{
			throw new ArgumentException("GPU was not detected with a driver-provided MSI configuration.");
		}
		if (priority < 0 || priority > 3 || policy < 0 || policy > 5)
		{
			throw new ArgumentException("Unsupported interrupt policy.");
		}
		if (on && policy == 4 && (mask == null || mask.Length != 8 || mask.All((byte x) => x == 0)))
		{
			throw new ArgumentException("An eight-byte nonzero CPU mask is required.");
		}
		List<RegistryOperation> list = new List<RegistryOperation>();
		list.Add(Op(d, "MessageSignaledInterruptProperties", "MSISupported", on ? 1 : 0, "DWord"));
		list.Add(Op(d, "Affinity Policy", "DevicePriority", (on && priority != 0) ? ((object)priority) : null, "DWord"));
		list.Add(Op(d, "Affinity Policy", "DevicePolicy", (on && policy != 0) ? ((object)policy) : null, "DWord"));
		list.Add(Op(d, "Affinity Policy", "AssignmentSetOverride", (on && policy == 4) ? mask : null, "Binary"));
		return new Tweak
		{
			Id = Key(d),
			Name = "GPU MSI · " + d.Name,
			Kind = "Registry",
			Enable = list,
			Disable = new List<RegistryOperation> { Op(d, "MessageSignaledInterruptProperties", "MSISupported", (!on) ? 1 : 0, "DWord") },
			RequiresRestart = true
		};
	}

	public static GpuDevice Primary()
	{
		return Devices.OrderByDescending(VideoMemory).ThenBy((GpuDevice d) => (d.Instance.IndexOf("VEN_8086", StringComparison.OrdinalIgnoreCase) >= 0) ? 1 : 0).FirstOrDefault();
	}

	private static long VideoMemory(GpuDevice d)
	{
		try
		{
			string text;
			using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Enum\\" + d.Instance))
			{
				text = ((registryKey == null) ? null : Convert.ToString(registryKey.GetValue("Driver")));
			}
			if (string.IsNullOrEmpty(text))
			{
				return 0L;
			}
			using RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Class\\" + text);
			if (registryKey2 == null)
			{
				return 0L;
			}
			object obj = registryKey2.GetValue("HardwareInformation.qwMemorySize") ?? registryKey2.GetValue("HardwareInformation.MemorySize");
			if (obj is long result)
			{
				return result;
			}
			if (obj is int)
			{
				return (uint)(int)obj;
			}
			if (obj is byte[] array && array.Length >= 4)
			{
				return (array.Length >= 8) ? BitConverter.ToInt64(array, 0) : BitConverter.ToUInt32(array, 0);
			}
		}
		catch
		{
		}
		return 0L;
	}

	internal static Tweak MsiOnly(GpuDevice d)
	{
		return new Tweak
		{
			Id = Key(d),
			Name = "GPU MSI · " + d.Name,
			Kind = "Registry",
			Enable = new List<RegistryOperation> { Op(d, "MessageSignaledInterruptProperties", "MSISupported", 1, "DWord") },
			Disable = new List<RegistryOperation> { Op(d, "MessageSignaledInterruptProperties", "MSISupported", 0, "DWord") },
			RequiresRestart = true
		};
	}

	private static RegistryOperation Op(GpuDevice d, string sub, string name, object value, string kind)
	{
		return new RegistryOperation
		{
			Hive = "HKLM",
			Path = d.BasePath + "\\" + sub,
			Name = name,
			Kind = kind,
			Value = value
		};
	}
}
