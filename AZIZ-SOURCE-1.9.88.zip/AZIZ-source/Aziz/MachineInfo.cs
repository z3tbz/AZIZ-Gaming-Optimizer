using System.Collections.Generic;

namespace Aziz;

public sealed class MachineInfo
{
	public List<SpecItem> Specs { get; set; }

	public string CpuName { get; set; }

	public string GpuName { get; set; }

	public string OsName { get; set; }

	public string ComputerName { get; set; }

	public string FormFactor { get; set; }

	public MachineInfo()
	{
		Specs = new List<SpecItem>();
	}
}
