namespace Aziz;

internal sealed class DebloatRow
{
	public string Id { get; set; }

	public string Kind { get; set; }

	public string Target { get; set; }

	public string Name { get; set; }

	public string Group { get; set; }

	public string Action { get; set; }

	public string Detail { get; set; }

	public bool Present { get; set; }

	public bool Recommended { get; set; }

	public string Reason { get; set; }
}
