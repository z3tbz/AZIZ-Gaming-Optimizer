namespace Aziz;

public class GameRule
{
	public string Name { get; set; }

	public string Exe { get; set; }

	public string Launch { get; set; }

	public bool Enabled { get; set; }

	public bool Boost { get; set; }

	public string Cpu { get; set; }

	public int Gpu { get; set; }

	public int Io { get; set; }

	public uint[] CpuSets { get; set; }

	public string Library { get; set; }

	public bool Focus { get; set; }

	public bool PauseServices { get; set; }

	public bool Steam { get; set; }

	public bool Search { get; set; }

	public bool Network { get; set; }

	public bool Performance { get; set; }

	public bool Standby { get; set; }

	public bool CloseApp { get; set; }

	public GameRule()
	{
		Cpu = "Normal";
		Gpu = 2;
		Io = 2;
		Enabled = true;
		Boost = true;
		CpuSets = new uint[0];
	}
}
