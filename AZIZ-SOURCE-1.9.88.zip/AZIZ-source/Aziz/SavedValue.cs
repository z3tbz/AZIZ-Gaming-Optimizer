namespace Aziz;

public class SavedValue
{
	public string Hive { get; set; }

	public string Path { get; set; }

	public string Name { get; set; }

	public bool Exists { get; set; }

	public string Kind { get; set; }

	public object Value { get; set; }
}
