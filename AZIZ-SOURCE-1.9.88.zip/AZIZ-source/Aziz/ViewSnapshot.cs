using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace Aziz;

internal sealed class ViewSnapshot
{
	public StackPanel Panel;

	public Dictionary<string, TextBlock> Metrics;

	public Dictionary<string, Polyline> Traces;
}
