using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;

namespace Aziz;

internal static class SegmentDownload
{
	internal static async Task<bool> TryDownload(HttpClient client, Uri url, string path, DownloadJob job, Action changed)
	{
		Uri referer = (string.IsNullOrEmpty(job.Item.Referer) ? null : new Uri(job.Item.Referer));
		EntityTagHeaderValue tag;
		DateTimeOffset? stamp;
		long total;
		using (HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Get, url))
		{
			if (referer != null)
			{
				request.Headers.Referrer = referer;
			}
			request.Headers.Range = new RangeHeaderValue(0L, 0L);
			request.Headers.TryAddWithoutValidation("Accept-Encoding", "identity");
			using HttpResponseMessage httpResponseMessage = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, job.Cancel.Token).ConfigureAwait(continueOnCapturedContext: false);
			ContentRangeHeaderValue contentRange = httpResponseMessage.Content.Headers.ContentRange;
			tag = httpResponseMessage.Headers.ETag;
			stamp = httpResponseMessage.Content.Headers.LastModified;
			if (tag != null && tag.IsWeak)
			{
				tag = null;
			}
			if (httpResponseMessage.StatusCode != HttpStatusCode.PartialContent || contentRange == null || contentRange.From != 0 || contentRange.To != 0 || !contentRange.HasLength || contentRange.Length < 8388608 || (tag == null && !stamp.HasValue))
			{
				return false;
			}
			total = contentRange.Length.Value;
		}
		job.Total = total;
		job.Bytes = 0L;
		job.State = "Downloading";
		changed();
		using (FileStream fileStream = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.None))
		{
			fileStream.SetLength(total);
		}
		CancellationTokenSource linked = CancellationTokenSource.CreateLinkedTokenSource(job.Cancel.Token);
		try
		{
			long received = 0L;
			Stopwatch watch = Stopwatch.StartNew();
			int num = ((total > 268435456) ? 12 : ((total > 67108864) ? 8 : 4));
			long chunk = (total + num - 1) / num;
			Task[] tasks = Enumerable.Range(0, num).Select((Func<int, Task>)async delegate(int index)
			{
				long from = index * chunk;
				long to = Math.Min(total - 1, from + chunk - 1);
				try
				{
					using HttpRequestMessage req = new HttpRequestMessage(HttpMethod.Get, url);
					req.Headers.Range = new RangeHeaderValue(from, to);
					if (referer != null)
					{
						req.Headers.Referrer = referer;
					}
					req.Headers.IfRange = ((tag != null) ? new RangeConditionHeaderValue(tag) : new RangeConditionHeaderValue(stamp.Value));
					req.Headers.TryAddWithoutValidation("Accept-Encoding", "identity");
					using HttpResponseMessage res = await client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, linked.Token).ConfigureAwait(continueOnCapturedContext: false);
					ContentRangeHeaderValue contentRange2 = res.Content.Headers.ContentRange;
					if (res.StatusCode != HttpStatusCode.PartialContent || contentRange2 == null || contentRange2.From != from || contentRange2.To != to || contentRange2.Length != total || (tag != null && (res.Headers.ETag == null || res.Headers.ETag.Tag != tag.Tag)))
					{
						throw new IOException("Server did not honor a stable download range.");
					}
					using Stream input = await res.Content.ReadAsStreamAsync().ConfigureAwait(continueOnCapturedContext: false);
					using FileStream output = new FileStream(path, FileMode.Open, FileAccess.Write, FileShare.Write, 262144, useAsync: true);
					output.Position = from;
					long left = to - from + 1;
					byte[] buffer = new byte[262144];
					while (left > 0)
					{
						int i = await input.ReadAsync(buffer, 0, (int)Math.Min(buffer.Length, left), linked.Token).ConfigureAwait(continueOnCapturedContext: false);
						if (i == 0)
						{
							throw new IOException("Incomplete download range.");
						}
						await output.WriteAsync(buffer, 0, i, linked.Token).ConfigureAwait(continueOnCapturedContext: false);
						left -= i;
						Interlocked.Add(ref received, i);
					}
					if (await input.ReadAsync(buffer, 0, 1, linked.Token).ConfigureAwait(continueOnCapturedContext: false) != 0)
					{
						throw new IOException("Oversized download range.");
					}
				}
				catch
				{
					linked.Cancel();
					throw;
				}
			}).ToArray();
			Task all = Task.WhenAll(tasks);
			while (!all.IsCompleted)
			{
				await Task.WhenAny(all, Task.Delay(250)).ConfigureAwait(continueOnCapturedContext: false);
				job.Bytes = Interlocked.Read(ref received);
				job.Speed = (double)job.Bytes / Math.Max(0.001, watch.Elapsed.TotalSeconds);
				changed();
			}
			try
			{
				await all.ConfigureAwait(continueOnCapturedContext: false);
			}
			catch
			{
				job.Cancel.Token.ThrowIfCancellationRequested();
				File.Delete(path);
				job.Bytes = 0L;
				job.Total = null;
				job.Speed = 0.0;
				return false;
			}
			job.Bytes = received;
			if (received != total)
			{
				throw new IOException("Parallel download size mismatch.");
			}
			return true;
		}
		finally
		{
			if (linked != null)
			{
				((IDisposable)linked).Dispose();
			}
		}
	}
}
