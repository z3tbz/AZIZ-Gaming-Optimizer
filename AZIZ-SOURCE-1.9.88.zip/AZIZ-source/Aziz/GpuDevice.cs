namespace Aziz;

internal sealed class GpuDevice
{
	public string Name;

	public string Instance;

	public string BasePath;

	public override string ToString()
	{
		return Name;
	}
}
