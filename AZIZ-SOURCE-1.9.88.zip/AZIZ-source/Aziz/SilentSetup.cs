using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Aziz;

// Installs a downloaded setup without questions: the setup type is read from the file (Inno Setup, NSIS, MSI, Squirrel,
// WiX burn) and the matching silent switches are passed. Unknown setups return null and open normally.
internal static class SilentSetup
{
	public static string Arguments(string file)
	{
		string text = Path.GetExtension(file).ToLowerInvariant();
		if (text == ".msi")
		{
			return "msi";
		}
		if (text != ".exe")
		{
			return null;
		}
		try
		{
			byte[] array = new byte[Math.Min(new FileInfo(file).Length, 8388608L)];
			using (FileStream fileStream = File.OpenRead(file))
			{
				int num;
				for (int i = 0; i < array.Length; i += num)
				{
					num = fileStream.Read(array, i, array.Length - i);
					if (num <= 0)
					{
						break;
					}
				}
			}
			string @string = Encoding.ASCII.GetString(array);
			if (@string.Contains("Inno Setup"))
			{
				return "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP- /NOCANCEL";
			}
			if (@string.Contains("Nullsoft") || @string.Contains("NSIS"))
			{
				return "/S";
			}
			if (@string.Contains("Squirrel") || @string.Contains("SquirrelSetup"))
			{
				return "--silent";
			}
			if (@string.Contains("WixBundle") || @string.Contains("wixstdba"))
			{
				return "/quiet /norestart";
			}
			if (@string.Contains("InstallShield"))
			{
				return "/s /v\"/qn /norestart\"";
			}
		}
		catch
		{
		}
		return null;
	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct TrustFile
	{
		public uint Size;

		public string Path;

		public IntPtr Handle;

		public IntPtr Subject;
	}

	[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
	private struct TrustData
	{
		public uint Size;

		public IntPtr Policy;

		public IntPtr Sip;

		public uint UiChoice;

		public uint Revocation;

		public uint UnionChoice;

		public IntPtr File;

		public uint StateAction;

		public IntPtr State;

		public string Url;

		public uint ProvFlags;

		public uint UiContext;

		public IntPtr Settings;
	}

	[DllImport("wintrust.dll", CharSet = CharSet.Unicode)]
	private static extern int WinVerifyTrust(IntPtr window, ref Guid action, ref TrustData data);

	// Valid Authenticode signature (Windows' own check, no PowerShell). Only signed setups are installed silently with
	// AZIZ's admin rights; anything else opens normally so Windows and the user decide.
	public static bool Signed(string file)
	{
		IntPtr intPtr = IntPtr.Zero;
		try
		{
			TrustFile structure = new TrustFile
			{
				Size = (uint)Marshal.SizeOf(typeof(TrustFile)),
				Path = file
			};
			intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(TrustFile)));
			Marshal.StructureToPtr(structure, intPtr, fDeleteOld: false);
			TrustData data = new TrustData
			{
				Size = (uint)Marshal.SizeOf(typeof(TrustData)),
				UiChoice = 2u,
				UnionChoice = 1u,
				File = intPtr
			};
			Guid action = new Guid("00AAC56B-CD44-11d0-8CC2-00C04FC295EE");
			return WinVerifyTrust(new IntPtr(-1), ref action, ref data) == 0;
		}
		catch
		{
			return false;
		}
		finally
		{
			if (intPtr != IntPtr.Zero)
			{
				Marshal.DestroyStructure(intPtr, typeof(TrustFile));
				Marshal.FreeHGlobal(intPtr);
			}
		}
	}

	// A signed setup copied into AZIZ's admin-only work folder and checked again there; null when it is not signed.
	public static string SecureCopy(string file, bool withFolder = false)
	{
		if (!Signed(file))
		{
			return null;
		}
		string text = SecureWork.NewFolder("setup");
		// An installer unpacked from an archive needs the files beside it: the whole folder is copied.
		if (withFolder)
		{
			string text2 = Path.GetDirectoryName(Path.GetFullPath(file));
			foreach (string item in Directory.GetFiles(text2, "*", SearchOption.AllDirectories))
			{
				string text3 = Path.Combine(text, item.Substring(text2.Length).TrimStart('\\'));
				Directory.CreateDirectory(Path.GetDirectoryName(text3));
				File.Copy(item, text3);
			}
		}
		else
		{
			File.Copy(file, Path.Combine(text, Path.GetFileName(file)));
		}
		string text4 = Path.Combine(text, withFolder ? Path.GetFullPath(file).Substring(Path.GetDirectoryName(Path.GetFullPath(file)).Length).TrimStart('\\') : Path.GetFileName(file));
		return Signed(text4) ? text4 : null;
	}

	public static ActionResult Run(string file)
	{
		string text = Arguments(file);
		if (text == null || !Signed(file))
		{
			return null;
		}
		// The download folder is writable by any program of this user: the setup is copied into AZIZ's admin-only work
		// folder, checked again there, and that copy runs (also no DLL from Downloads can load into it).
		string folder = null;
		try
		{
			folder = SecureWork.NewFolder("setup");
			string copy = Path.Combine(folder, Path.GetFileName(file));
			File.Copy(file, copy);
			if (!Signed(copy))
			{
				return null;
			}
			file = copy;
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
		try
		{
			ProcessStartInfo startInfo = ((text == "msi") ? new ProcessStartInfo(Utilities.Tool("msiexec.exe"), "/i \"" + file + "\" /qn /norestart") : new ProcessStartInfo(file, text));
			startInfo.UseShellExecute = false;
			startInfo.CreateNoWindow = true;
			startInfo.WorkingDirectory = Path.GetDirectoryName(file);
			using Process process = Process.Start(startInfo);
			if (!process.WaitForExit(900000))
			{
				return new ActionResult
				{
					Message = "Setup is still running."
				};
			}
			bool flag = process.ExitCode == 0 || process.ExitCode == 3010 || process.ExitCode == 1641;
			return new ActionResult
			{
				Success = flag,
				Message = (flag ? "Installed silently." : ("Setup ended with code " + process.ExitCode + "."))
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
