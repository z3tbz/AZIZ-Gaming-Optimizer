namespace Aziz;

internal class RestoreApp
{
	public string Name;

	public string StoreId;

	public RestoreApp(string name, string id)
	{
		Name = name;
		StoreId = id;
	}
}
