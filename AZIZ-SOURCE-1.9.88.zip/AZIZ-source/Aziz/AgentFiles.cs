using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Aziz;

internal static class AgentFiles
{
	private static readonly object Gate = new object();

	internal static string Folder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AZIZ Game Agent");

	internal static string Exe => Path.Combine(Folder, "AZIZGamingOptimizer.exe");

	private static bool Same(string a, string b)
	{
		FileInfo fileInfo = new FileInfo(a);
		FileInfo fileInfo2 = new FileInfo(b);
		if (fileInfo.Length == fileInfo2.Length)
		{
			return File.ReadAllBytes(a).SequenceEqual(File.ReadAllBytes(b));
		}
		return false;
	}

	internal static bool Current()
	{
		try
		{
			return File.Exists(Exe) && Same(Exe, Program.ExePath);
		}
		catch
		{
			return false;
		}
	}

	public static bool Deploy()
	{
		lock (Gate)
		{
			Directory.CreateDirectory(Folder);
			if ((File.GetAttributes(Folder) & FileAttributes.ReparsePoint) != 0)
			{
				throw new IOException("The agent folder cannot be a link.");
			}
			string[] files = Directory.GetFiles(Folder, "*.old");
			foreach (string path in files)
			{
				try
				{
					File.Delete(path);
				}
				catch
				{
				}
			}
			string location = Program.ExePath;
			bool result = false;
			if (!Current())
			{
				if (File.Exists(Exe))
				{
					try
					{
						File.Copy(location, Exe, overwrite: true);
					}
					catch (Exception ex)
					{
						if (!(ex is IOException) && !(ex is UnauthorizedAccessException))
						{
							throw;
						}
						File.Move(Exe, Exe + "." + Guid.NewGuid().ToString("N") + ".old");
						File.Copy(location, Exe, overwrite: true);
					}
				}
				else
				{
					File.Copy(location, Exe);
				}
				result = true;
			}
			if (File.Exists(location + ".config"))
			{
				try
				{
					File.Copy(location + ".config", Exe + ".config", overwrite: true);
				}
				catch
				{
				}
			}
			return result;
		}
	}

	public static int Stop(bool timerService, bool staleOnly = false)
	{
		int num = 0;
		int self;
		using (Process current = Process.GetCurrentProcess())
		{
			self = current.Id;
		}
		Process[] processesByName = Process.GetProcessesByName("AZIZGamingOptimizer");
		foreach (Process process in processesByName)
		{
			using (process)
			{
				try
				{
					if (process.Id != self && process.SessionId == 0 == timerService)
					{
						string text = CompetitiveLaunch.ImagePath(process.Id);
						if (text != null && text.StartsWith(Folder + "\\", StringComparison.OrdinalIgnoreCase) && !(process.MainWindowHandle != IntPtr.Zero) && (!staleOnly || !string.Equals(text, Exe, StringComparison.OrdinalIgnoreCase)))
						{
							process.Kill();
							process.WaitForExit(5000);
							num++;
						}
					}
				}
				catch
				{
				}
			}
		}
		return num;
	}
}
