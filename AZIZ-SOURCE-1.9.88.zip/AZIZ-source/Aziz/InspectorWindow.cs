using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Aziz;

internal static class InspectorWindow
{
	private delegate bool EnumProc(IntPtr hwnd, IntPtr param);

	[DllImport("user32.dll")]
	private static extern bool PostMessage(IntPtr hwnd, uint msg, IntPtr w, IntPtr l);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GlobalAlloc(uint flags, UIntPtr bytes);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GlobalLock(IntPtr h);

	[DllImport("kernel32.dll")]
	private static extern bool GlobalUnlock(IntPtr h);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GlobalFree(IntPtr h);

	[DllImport("user32.dll")]
	private static extern bool EnumChildWindows(IntPtr parent, EnumProc proc, IntPtr param);

	[DllImport("user32.dll", CharSet = CharSet.Unicode)]
	private static extern int GetClassName(IntPtr hwnd, StringBuilder name, int count);

	[DllImport("user32.dll")]
	private static extern bool SetForegroundWindow(IntPtr hwnd);

	private static IntPtr ListView(IntPtr main)
	{
		IntPtr found = IntPtr.Zero;
		EnumChildWindows(main, delegate(IntPtr h, IntPtr p)
		{
			StringBuilder stringBuilder = new StringBuilder(256);
			GetClassName(h, stringBuilder, 256);
			if (stringBuilder.ToString().IndexOf("SysListView32", StringComparison.OrdinalIgnoreCase) >= 0)
			{
				found = h;
				return false;
			}
			return true;
		}, IntPtr.Zero);
		return found;
	}

	public static IntPtr WaitForWindow(string exe, int seconds)
	{
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(exe);
		Stopwatch stopwatch = Stopwatch.StartNew();
		while (stopwatch.Elapsed.TotalSeconds < (double)seconds)
		{
			Process[] processesByName = Process.GetProcessesByName(fileNameWithoutExtension);
			foreach (Process process in processesByName)
			{
				using (process)
				{
					try
					{
						process.Refresh();
						if (process.MainWindowHandle != IntPtr.Zero)
						{
							return process.MainWindowHandle;
						}
					}
					catch
					{
					}
				}
			}
			Thread.Sleep(250);
		}
		return IntPtr.Zero;
	}

	public static bool DropFile(IntPtr main, string file)
	{
		IntPtr intPtr = ListView(main);
		if (intPtr == IntPtr.Zero)
		{
			intPtr = main;
		}
		byte[] bytes = Encoding.Unicode.GetBytes(file + "\0\0");
		IntPtr intPtr2 = GlobalAlloc(66u, new UIntPtr((uint)(20 + bytes.Length)));
		IntPtr intPtr3 = GlobalLock(intPtr2);
		Marshal.WriteInt32(intPtr3, 0, 20);
		Marshal.WriteInt32(intPtr3, 16, 1);
		Marshal.Copy(bytes, 0, IntPtr.Add(intPtr3, 20), bytes.Length);
		GlobalUnlock(intPtr2);
		SetForegroundWindow(main);
		if (PostMessage(intPtr, 563u, intPtr2, IntPtr.Zero))
		{
			return true;
		}
		GlobalFree(intPtr2);
		return false;
	}
}
