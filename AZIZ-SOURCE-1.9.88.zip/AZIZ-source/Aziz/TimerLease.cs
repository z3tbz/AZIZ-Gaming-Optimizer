using System;
using Microsoft.Win32;

namespace Aziz;

internal sealed class TimerLease : IDisposable
{
	private const string KernelKey = "SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel";

	internal static ITimerApi Api = new WindowsTimerApi();

	private static readonly object Gate = new object();

	internal static int Active;

	private bool active;

	private static bool honored;

	public double ActualMs { get; private set; }

	public TimerLease()
	{
		lock (Gate)
		{
			try
			{
				if (Active == 0)
				{
					honored = Api.Honor(enabled: true);
				}
				uint num = Api.Set(enabled: true);
				if (num > 5100)
				{
					Api.Set(enabled: false);
					num = Api.Set(enabled: true);
				}
				active = true;
				Active++;
				ActualMs = (double)num / 10000.0;
			}
			catch
			{
				if (Active == 0 && honored)
				{
					Api.Honor(enabled: false);
					honored = false;
				}
				throw;
			}
		}
	}

	public double Renew()
	{
		lock (Gate)
		{
			if (!active)
			{
				return ActualMs;
			}
			Api.Set(enabled: false);
			ActualMs = (double)Api.Set(enabled: true) / 10000.0;
			return ActualMs;
		}
	}

	public static double Query()
	{
		return (double)Api.Query() / 10000.0;
	}

	internal static TweakStatus State()
	{
		try
		{
			double num = Query();
			TweakStatus tweakStatus = new TweakStatus();
			tweakStatus.State = ((num <= 0.51 || TimerService.Installed()) ? "Enabled" : "Disabled");
			tweakStatus.Detail = "Windows timer: " + num.ToString("0.000") + " ms · AZIZ request " + ((Active > 0) ? "active" : "released") + " · system-wide requests " + (GlobalRequests() ? "on" : "off (restart after first use)");
			return tweakStatus;
		}
		catch (Exception ex)
		{
			return new TweakStatus
			{
				State = "Unavailable",
				Detail = ex.Message
			};
		}
	}

	public static bool GlobalRequests()
	{
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel");
		return registryKey != null && Convert.ToInt32(registryKey.GetValue("GlobalTimerResolutionRequests", 0)) == 1;
	}

	public static bool EnableGlobalRequests()
	{
		if (GlobalRequests())
		{
			return false;
		}
		try
		{
			using (RegistryKey registryKey = Registry.LocalMachine.CreateSubKey("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\kernel"))
			{
				registryKey.SetValue("GlobalTimerResolutionRequests", 1, RegistryValueKind.DWord);
			}
			return true;
		}
		catch
		{
			return false;
		}
	}

	public static void WaitHalfMillisecond()
	{
		Api.WaitHalfMillisecond();
	}

	public void Dispose()
	{
		lock (Gate)
		{
			if (active)
			{
				Api.Set(enabled: false);
				active = false;
				Active--;
				if (Active == 0 && honored)
				{
					Api.Honor(enabled: false);
					honored = false;
				}
			}
		}
	}
}
