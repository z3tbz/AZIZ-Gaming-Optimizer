namespace Aziz;

internal static class NetworkApply
{
	public static ActionResult RestartAdapters()
	{
		return Utilities.Run("powershell.exe", GameWatch.PsArgs("$a=@(Get-NetAdapter -Physical -ErrorAction SilentlyContinue|Where-Object Status -eq 'Up');if(!$a.Count){'No connected adapter needed a restart.';return};foreach($x in $a){Restart-NetAdapter -Name $x.Name -Confirm:$false};'Network adapter restarted: '+(($a|ForEach-Object Name) -join ', ')+'. The change is active now.'"));
	}
}
