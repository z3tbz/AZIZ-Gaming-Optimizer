using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Script.Serialization;

namespace Aziz;

internal static class NativeSnapshotUpgrade
{
	internal static string Merge(string id, string saved, string current)
	{
		if (string.IsNullOrEmpty(saved) || string.IsNullOrEmpty(current))
		{
			return saved;
		}
		JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer
		{
			MaxJsonLength = 16777216
		};
		object obj;
		Dictionary<string, object> dictionary;
		try
		{
			obj = javaScriptSerializer.DeserializeObject(saved);
			dictionary = javaScriptSerializer.DeserializeObject(current) as Dictionary<string, object>;
		}
		catch (ArgumentException)
		{
			return saved;
		}
		if (dictionary == null)
		{
			return saved;
		}
		if ((id == "wifi" || id == "bluetooth") && obj is object[])
		{
			Dictionary<string, object>[] source = ((object[])dictionary["Services"]).Cast<Dictionary<string, object>>().ToArray();
			foreach (Dictionary<string, object> item in ((object[])obj).Cast<Dictionary<string, object>>())
			{
				Func<Dictionary<string, object>, bool> predicate = (Dictionary<string, object> s) => Convert.ToString(s["Name"]) == Convert.ToString(item["Name"]);
				Dictionary<string, object> obj2 = source.FirstOrDefault(predicate) ?? throw new InvalidOperationException("An originally saved wireless service is missing; restore its Windows component first.");
				string text = Convert.ToString(item["Start"]);
				if (text != "Auto" && text != "Manual" && text != "Disabled")
				{
					throw new InvalidOperationException("Unknown saved service startup mode.");
				}
				obj2["Start"] = ((text == "Auto") ? 2 : ((text == "Manual") ? 3 : 4));
				obj2["Delayed"] = (Convert.ToBoolean(item["Delayed"]) ? 1 : 0);
				obj2["Running"] = item["Running"];
			}
			return javaScriptSerializer.Serialize(dictionary);
		}
		Dictionary<string, object> dictionary2 = obj as Dictionary<string, object>;
		if (id == "hyper-v" && dictionary2 != null && dictionary2.ContainsKey("Present") && !dictionary2.ContainsKey("Features"))
		{
			if (Convert.ToBoolean(dictionary2["Present"]))
			{
				Dictionary<string, object> obj3 = ((object[])dictionary["Features"]).Cast<Dictionary<string, object>>().FirstOrDefault((Dictionary<string, object> f) => Convert.ToString(f["Name"]) == "Microsoft-Hyper-V-All") ?? throw new InvalidOperationException("The originally saved Hyper-V component is missing.");
				obj3["Enabled"] = dictionary2["Enabled"];
				obj3["Removed"] = false;
			}
			dictionary["Boot"] = dictionary2["Boot"];
			return javaScriptSerializer.Serialize(dictionary);
		}
		return saved;
	}
}
