using System.Collections.Generic;
using System.Linq;

namespace Aziz;

internal static class StoreInventory
{
	public const string ReadScript = "[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding;\r\n$items=@(foreach($app in (Get-AppxPackage | Where-Object {-not $_.IsFramework -and -not $_.IsResourcePackage -and -not $_.NonRemovable})){\r\n $icon='';$publisher=$app.Publisher;$aumid='';$display=$app.Name;try{$manifest=Get-AppxPackageManifest -Package $app.PackageFullName;$visual=$manifest.SelectSingleNode('//*[local-name()=\"VisualElements\"]');$relative=if($visual){$visual.GetAttribute('Square44x44Logo')}else{''};if(-not $relative){$relative=[string]$manifest.Package.Properties.Logo};if($relative){$full=[IO.Path]::GetFullPath([IO.Path]::Combine($app.InstallLocation,$relative));if($full.StartsWith($app.InstallLocation.TrimEnd('\\')+'\\',[StringComparison]::OrdinalIgnoreCase)){if(Test-Path -LiteralPath $full){$icon=$full}else{$dir=[IO.Path]::GetDirectoryName($full);$stem=[IO.Path]::GetFileNameWithoutExtension($full);$candidate=Get-ChildItem -LiteralPath $dir -Filter ($stem+'*.png') -ErrorAction SilentlyContinue | Sort-Object @{Expression={if($_.Name -match 'targetsize-48.*unplated'){0}elseif($_.Name -match 'scale-100'){1}else{2}}} | Select-Object -First 1;if($candidate){$icon=$candidate.FullName}}}};$application=$manifest.SelectSingleNode('//*[local-name()=\"Application\"]');if($application){$aumid=$app.PackageFamilyName+'!'+$application.GetAttribute('Id')};$title=[string]$manifest.Package.Properties.DisplayName;if($title -and $title -notlike 'ms-resource:*'){$display=$title};$p=[string]$manifest.Package.Properties.PublisherDisplayName;if($p -and $p -notlike 'ms-resource:*'){$publisher=$p}}catch{}\r\n [pscustomobject]@{Name=$app.Name;Version=$app.Version.ToString();PackageFullName=$app.PackageFullName;PackageFamilyName=$app.PackageFamilyName;Publisher=$publisher;InstallLocation=$app.InstallLocation;IconPath=$icon;AppUserModelId=$aumid;DisplayName=$display}\r\n});ConvertTo-Json -InputObject $items -Compress -Depth 4";

	public static List<InstalledApp> Read()
	{
		try
		{
			string input = Utilities.ReadCommand("powershell.exe", GameWatch.PsArgs("[Console]::OutputEncoding=New-Object System.Text.UTF8Encoding;\r\n$items=@(foreach($app in (Get-AppxPackage | Where-Object {-not $_.IsFramework -and -not $_.IsResourcePackage -and -not $_.NonRemovable})){\r\n $icon='';$publisher=$app.Publisher;$aumid='';$display=$app.Name;try{$manifest=Get-AppxPackageManifest -Package $app.PackageFullName;$visual=$manifest.SelectSingleNode('//*[local-name()=\"VisualElements\"]');$relative=if($visual){$visual.GetAttribute('Square44x44Logo')}else{''};if(-not $relative){$relative=[string]$manifest.Package.Properties.Logo};if($relative){$full=[IO.Path]::GetFullPath([IO.Path]::Combine($app.InstallLocation,$relative));if($full.StartsWith($app.InstallLocation.TrimEnd('\\')+'\\',[StringComparison]::OrdinalIgnoreCase)){if(Test-Path -LiteralPath $full){$icon=$full}else{$dir=[IO.Path]::GetDirectoryName($full);$stem=[IO.Path]::GetFileNameWithoutExtension($full);$candidate=Get-ChildItem -LiteralPath $dir -Filter ($stem+'*.png') -ErrorAction SilentlyContinue | Sort-Object @{Expression={if($_.Name -match 'targetsize-48.*unplated'){0}elseif($_.Name -match 'scale-100'){1}else{2}}} | Select-Object -First 1;if($candidate){$icon=$candidate.FullName}}}};$application=$manifest.SelectSingleNode('//*[local-name()=\"Application\"]');if($application){$aumid=$app.PackageFamilyName+'!'+$application.GetAttribute('Id')};$title=[string]$manifest.Package.Properties.DisplayName;if($title -and $title -notlike 'ms-resource:*'){$display=$title};$p=[string]$manifest.Package.Properties.PublisherDisplayName;if($p -and $p -notlike 'ms-resource:*'){$publisher=$p}}catch{}\r\n [pscustomobject]@{Name=$app.Name;Version=$app.Version.ToString();PackageFullName=$app.PackageFullName;PackageFamilyName=$app.PackageFamilyName;Publisher=$publisher;InstallLocation=$app.InstallLocation;IconPath=$icon;AppUserModelId=$aumid;DisplayName=$display}\r\n});ConvertTo-Json -InputObject $items -Compress -Depth 4")).Trim();
			List<InstalledApp> list = Program.Json.Deserialize<List<InstalledApp>>(input) ?? new List<InstalledApp>();
			foreach (InstalledApp item in list)
			{
				AppIcons.Load(item.IconPath);
			}
			return list.OrderBy((InstalledApp x) => x.Name).ToList();
		}
		catch
		{
			return new List<InstalledApp>();
		}
	}
}
