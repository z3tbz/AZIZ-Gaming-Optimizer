using Microsoft.Win32;

namespace Aziz;

internal class DesktopApp
{
	public string Name;

	public string Version;

	public string Publisher;

	public string Icon;

	public string InstallLocation;

	public string Command;

	public string KeyPath;

	public string Hive;

	public RegistryView View;
}
