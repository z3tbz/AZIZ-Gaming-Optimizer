using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class ServiceBatch
{
	private static readonly HashSet<string> EssentialAuto = new HashSet<string>("RpcSs RpcEptMapper DcomLaunch Power LSM SamSs BrokerInfrastructure SystemEventsBroker CoreMessagingRegistrar ProfSvc UserManager Schedule EventLog gpsvc Winmgmt Dhcp Dnscache nsi NlaSvc BFE mpssvc CryptSvc AudioEndpointBuilder Audiosrv DispBrokerDesktopSvc TextInputManagementService SgrmBroker WinDefend".Split(' '), StringComparer.OrdinalIgnoreCase);

	private static readonly HashSet<string> EssentialManual = new HashSet<string>("PlugPlay StateRepository Appinfo TimeBrokerSvc AppXSvc ClipSVC LicenseManager netprofm KeyIso DeviceInstall msiserver TrustedInstaller camsvc Wcmsvc StorSvc".Split(' '), StringComparer.OrdinalIgnoreCase);

	private static readonly HashSet<string> GamerKeep = new HashSet<string>("vgc EasyAntiCheat EasyAntiCheat_EOS EAAntiCheatService BEService FACEIT FACEITService Steam_Client_Service EpicOnlineServices GameInputSvc GameInputRedistService GamingServices GamingServicesNet XblAuthManager XblGameSave XboxNetApiSvc XboxGipSvc InstallService TokenBroker wlidsvc VaultSvc hidserv NVDisplay.ContainerLocalSystem RtkAudioUniversalService AudioEndpointBuilder".Split(' '), StringComparer.OrdinalIgnoreCase);

	private static readonly Regex KeepPattern = new Regex("anti.?cheat|battleye|faceit|vanguard|xigncode|nprotect|^ace-|steam client|^AMD External|^Rtk|realtek|^Waves|dolby|^DtsApo|^Nahimic|^igfx|^cplspcon|^jhi_service$|^esifsvc$", RegexOptions.IgnoreCase);

	private static readonly HashSet<string> NeverNeeded = new HashSet<string>("DiagTrack dmwappushservice diagnosticshub.standardcollector.service WerSvc wercplsupport PcaSvc DPS WdiServiceHost WdiSystemHost diagsvc TroubleshootingSvc InventorySvc MapsBroker lfsvc RetailDemo Fax Spooler PrintNotify PrintWorkflowUserSvc PrintDeviceConfigurationService PrintScanBrokerService WalletService wisvc SEMgrSvc PhoneSvc TapiSrv RemoteRegistry RemoteAccess RasAuto SessionEnv TermService UmRdpService SCardSvr ScDeviceEnum SCPolicySvc CertPropSvc WbioSrvc MixedRealityOpenXRSvc perceptionsimulation spectrum SharedRealitySvc SensorService SensrSvc SensorDataService icssvc WMPNetworkSvc lmhosts NetTcpPortSharing MSiSCSI SNMPTrap WpcMonSvc AJRouter ALG tzautoupdate fhsvc wbengine SDRSVC WSearch SysMain TrkWks CDPSvc CDPUserSvc OneSyncSvc MessagingService PimIndexMaintenanceSvc UnistoreSvc UserDataSvc CscService HvHost vmickvpexchange vmicguestinterface vmicshutdown vmicheartbeat vmicvmsession vmicrdv vmictimesync vmicvss edgeupdate edgeupdatem MicrosoftEdgeElevationService gupdate gupdatem brave bravem BraveElevationService MozillaMaintenance PeerDistSvc p2psvc p2pimsvc PNRPsvc PNRPAutoReg SSDPSRV upnphost fdPHost FDResPub lltdsvc WFDSConMgrSvc wcncsvc Wecsvc WEPHOSTSVC embeddedmode workfolderssvc AssignedAccessManagerSvc BcastDVRUserService SmsRouter NaturalAuthentication DmEnrollmentSvc EntAppSvc uhssvc wlpasvc WwanSvc RetailDemo dcsvc whesvc WarpJITSvc cloudidsvc DsSvc DsmSvc PushToInstall LxpSvc wuqisvc".Split(' '), StringComparer.OrdinalIgnoreCase);

	private static HashSet<string> cached;

	public static bool Hidden(string name)
	{
		return string.Equals(name, "DispBrokerDesktopSvc", StringComparison.OrdinalIgnoreCase);
	}

	private static string BaseName(string name)
	{
		Match match = Regex.Match(name ?? "", "^(.+)_[0-9a-fA-F]{4,8}$");
		string text;
		if (!match.Success)
		{
			text = name;
			if (text == null)
			{
				return "";
			}
		}
		else
		{
			text = match.Groups[1].Value;
		}
		return text;
	}

	public static bool KeptForGaming(string name, string display)
	{
		string text = BaseName(name);
		if (!GamerKeep.Contains(text) && !GamerKeep.Contains(text.Replace(' ', '_')) && !KeepPattern.IsMatch(text))
		{
			return KeepPattern.IsMatch(display ?? "");
		}
		return true;
	}

	public static bool Unneeded(string name)
	{
		if (!NeverNeeded.Contains(BaseName(name)))
		{
			return name.StartsWith("GoogleUpdater", StringComparison.OrdinalIgnoreCase);
		}
		return true;
	}

	public static bool Inbox(string name)
	{
		if (name == "TermService" || name == "WMPNetworkSvc")
		{
			return true;
		}
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + name);
			string text = ((registryKey == null) ? "" : Convert.ToString(registryKey.GetValue("ImagePath", "")));
			return (text.IndexOf("\\Windows\\", StringComparison.OrdinalIgnoreCase) >= 0 || text.StartsWith("%SystemRoot%", StringComparison.OrdinalIgnoreCase) || text.StartsWith("%windir%", StringComparison.OrdinalIgnoreCase) || text.IndexOf("system32", StringComparison.OrdinalIgnoreCase) >= 0) && text.IndexOf("DriverStore", StringComparison.OrdinalIgnoreCase) < 0;
		}
		catch
		{
			return false;
		}
	}

	public static int Recommended(string name, int current, string display)
	{
		if (Hidden(name))
		{
			return current;
		}
		if (EssentialAuto.Contains(name))
		{
			return 2;
		}
		if (ProtectedNames(manual: true).Contains(name) || KeptForGaming(name, display))
		{
			if (current != 4)
			{
				return current;
			}
			return 3;
		}
		if (!Unneeded(name))
		{
			return 3;
		}
		return 4;
	}

	public static bool Essential(string name)
	{
		if (!EssentialAuto.Contains(name))
		{
			return ProtectedNames(manual: true).Contains(name);
		}
		return true;
	}

	public static HashSet<string> ProtectedNames(bool manual)
	{
		if (cached != null)
		{
			return cached;
		}
		HashSet<string> hashSet = new HashSet<string>(EssentialAuto, StringComparer.OrdinalIgnoreCase);
		hashSet.UnionWith(EssentialManual);
		Queue<string> queue = new Queue<string>(EssentialAuto);
		while (queue.Count > 0)
		{
			string text = queue.Dequeue();
			try
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + text);
				if (registryKey == null)
				{
					continue;
				}
				string[] array = (registryKey.GetValue("DependOnService", new string[0]) as string[]) ?? new string[0];
				foreach (string text2 in array)
				{
					if (!text2.StartsWith("+") && hashSet.Add(text2))
					{
						queue.Enqueue(text2);
					}
				}
			}
			catch
			{
			}
		}
		cached = hashSet;
		return hashSet;
	}

	public static int Target(string name, bool manual, int current, string display = null)
	{
		if (Hidden(name))
		{
			return current;
		}
		if (EssentialAuto.Contains(name))
		{
			return 2;
		}
		if (ProtectedNames(manual: true).Contains(name) || KeptForGaming(name, display))
		{
			if (current != 4)
			{
				return current;
			}
			return 3;
		}
		if (manual)
		{
			if (!Unneeded(name))
			{
				return 3;
			}
			return 4;
		}
		return 4;
	}
}
