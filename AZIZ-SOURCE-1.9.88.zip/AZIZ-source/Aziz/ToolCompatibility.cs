using System;
using System.IO;
using System.Management;
using Microsoft.Win32;

namespace Aziz;

internal static class ToolCompatibility
{
	public static void CheckExecutable(string file)
	{
		using FileStream fileStream = File.OpenRead(file);
		using BinaryReader binaryReader = new BinaryReader(fileStream);
		if (fileStream.Length < 64 || binaryReader.ReadUInt16() != 23117)
		{
			throw new IOException("The downloaded package is not a Windows executable. Prepare/extract the archive before opening it.");
		}
		fileStream.Position = 60L;
		int num = binaryReader.ReadInt32();
		if (num < 0 || num > fileStream.Length - 6)
		{
			throw new IOException("Invalid executable header.");
		}
		fileStream.Position = num;
		if (binaryReader.ReadUInt32() != 17744)
		{
			throw new IOException("Invalid Windows executable.");
		}
		ushort num2 = binaryReader.ReadUInt16();
		if (num2 != 34404 && num2 != 332)
		{
			throw new IOException("This tool does not target Windows x64/x86.");
		}
	}

	public static void CheckRw()
	{
		bool flag = false;
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\CI\\Config"))
		{
			flag = registryKey != null && Convert.ToInt32(registryKey.GetValue("VulnerableDriverBlocklistEnable", 1)) != 0;
		}
		using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Control\\DeviceGuard\\Scenarios\\HypervisorEnforcedCodeIntegrity"))
		{
			flag |= registryKey2 != null && Convert.ToInt32(registryKey2.GetValue("Enabled", 0)) != 0;
		}
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("root\\Microsoft\\Windows\\DeviceGuard", "SELECT SecurityServicesRunning FROM Win32_DeviceGuard");
			foreach (ManagementObject item in managementObjectSearcher.Get())
			{
				if (item["SecurityServicesRunning"] is uint[] array && Array.IndexOf(array, 2u) >= 0)
				{
					flag = true;
				}
			}
		}
		catch
		{
		}
		if (flag)
		{
			throw new InvalidOperationException("RWEverything 1.7 uses an old kernel driver which Windows security can block. Reinstalling the same version does not fix that incompatibility. AZIZ leaves Memory Integrity and the vulnerable-driver blocklist unchanged. Use System for hardware information, or obtain a compatible signed driver from the publisher: https://rweverything.com/download/");
		}
	}
}
