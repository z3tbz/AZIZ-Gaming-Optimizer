using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Aziz;

internal static class Utilities
{
	public static string Sha256File(string path)
	{
		using SHA256 sHA = SHA256.Create();
		using FileStream inputStream = File.OpenRead(path);
		return BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").ToLowerInvariant();
	}

	public static List<T> Catalog<T>(string file)
	{
		string path = Path.Combine(Program.Root, file);
		if (!File.Exists(path))
		{
			return new List<T>();
		}
		return Program.Json.Deserialize<List<T>>(File.ReadAllText(path));
	}

	public static ActionResult ActivatePlan(string id)
	{
		if (!Guid.TryParse(id, out var result))
		{
			return new ActionResult
			{
				Success = false,
				Message = "Invalid power plan identifier."
			};
		}
		PowerPlan powerPlan = PowerPlans().FirstOrDefault((PowerPlan x) => x.Active);
		if (powerPlan != null)
		{
			AtomicWrite(Path.Combine(Program.Data, "previous-power-plan.txt"), powerPlan.Id);
		}
		Guid guid = result;
		ActionResult actionResult = Run("powercfg.exe", "/setactive " + guid.ToString());
		if (actionResult.Success && !PowerPlans().Any((PowerPlan x) => x.Active && x.Id.Equals(id, StringComparison.OrdinalIgnoreCase)))
		{
			return new ActionResult
			{
				Success = false,
				Message = "The requested power plan could not be verified as active."
			};
		}
		return actionResult;
	}

	public static ActionResult ImportPlan(BundledPlan plan, bool activate = true)
	{
		PowerPlan powerPlan = PowerPlans().FirstOrDefault((PowerPlan x) => x.Id == plan.BuiltInGuid || x.Name == plan.Name);
		if (powerPlan != null)
		{
			if (!activate)
			{
				return new ActionResult
				{
					Success = true,
					Message = "Plan already imported; the active plan was not changed."
				};
			}
			return ActivatePlan(powerPlan.Id);
		}
		string text = Guid.NewGuid().ToString();
		ActionResult actionResult;
		if (!string.IsNullOrEmpty(plan.DuplicateFromGuid))
		{
			actionResult = Run("powercfg.exe", "/duplicatescheme " + plan.DuplicateFromGuid + " " + text);
		}
		else
		{
			string fullPath = Path.GetFullPath(Path.Combine(Program.Root, "PowerPlans", plan.File));
			if (!fullPath.StartsWith(Path.GetFullPath(Path.Combine(Program.Root, "PowerPlans")) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) || !File.Exists(fullPath))
			{
				return new ActionResult
				{
					Success = false,
					Message = "The bundled power plan is missing."
				};
			}
			actionResult = Run("powercfg.exe", "/import \"" + fullPath + "\" " + text);
		}
		if (!actionResult.Success)
		{
			return actionResult;
		}
		if (!activate)
		{
			return new ActionResult
			{
				Success = true,
				Message = "Power plan imported; the active plan was not changed."
			};
		}
		return ActivatePlan(text);
	}

	public static string CleanMessage(string text)
	{
		if (string.IsNullOrEmpty(text))
		{
			return "";
		}
		int num = text.IndexOf("#< CLIXML", StringComparison.Ordinal);
		string text2 = ((num < 0) ? text : text.Substring(0, num));
		if (num >= 0)
		{
			text2 = string.Concat(text2, " ", string.Concat(from Match m in Regex.Matches(text.Substring(num), "<S S=\"Error\">(.*?)</S>", RegexOptions.Singleline)
				select WebUtility.HtmlDecode(m.Groups[1].Value)));
		}
		text2 = text2.Replace("_x000D__x000A_", "\n").Replace("_x000A_", "\n");
		List<string> list = (from x in text2.Split('\n')
			select x.Trim()).ToList();
		int num2 = list.FindIndex((string x) => x.StartsWith("At line:") || x.StartsWith("At C:") || x.StartsWith("+ CategoryInfo") || x.StartsWith("+ FullyQualifiedErrorId"));
		if (num2 >= 0)
		{
			list = list.Take(num2).ToList();
		}
		string text3 = Regex.Replace(string.Join(" ", list.Where((string x) => x.Length > 0 && !x.StartsWith("+ ") && !x.StartsWith("~"))), "\\s+", " ").Trim();
		if (text3.Length <= 600)
		{
			return text3;
		}
		return text3.Substring(0, 600) + "…";
	}

	public static string Short(string message)
	{
		string text = CleanMessage(message);
		if (text.StartsWith("Failed:"))
		{
			text = text.Substring(7).Trim();
		}
		if (text.StartsWith("Failed."))
		{
			text = text.Substring(7).Trim();
		}
		int num = text.IndexOf(". ");
		if (num > 20)
		{
			text = text.Substring(0, num + 1);
		}
		if (text.Length <= 140)
		{
			return text;
		}
		return text.Substring(0, 140) + "…";
	}

	public static void AtomicWrite(string path, string text)
	{
		Directory.CreateDirectory(Path.GetDirectoryName(path));
		string text2 = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
		File.WriteAllText(text2, text, Encoding.UTF8);
		if (File.Exists(path))
		{
			File.Replace(text2, path, null);
		}
		else
		{
			File.Move(text2, path);
		}
	}

	public static ActionResult Run(string file, string args)
	{
		return Run(file, args, 90000);
	}

	// A bare tool name ("powershell.exe", "reg.exe") is searched in AZIZ's own folder and the current folder before
	// System32: Windows tools always start from System32, so a file planted beside a portable AZIZ never runs as admin.
	// winget resolves to its Windows package folder, not the user's PATH.
	public static string Tool(string file)
	{
		if (string.IsNullOrEmpty(file) || Path.IsPathRooted(file) || file.IndexOfAny(new char[2] { '\\', '/' }) >= 0)
		{
			return file;
		}
		string text = Path.Combine(Environment.SystemDirectory, file);
		if (File.Exists(text))
		{
			return text;
		}
		if (file.Equals("winget.exe", StringComparison.OrdinalIgnoreCase))
		{
			try
			{
				string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "WindowsApps");
				string text2 = (from d in Directory.GetDirectories(path, "Microsoft.DesktopAppInstaller_*_x64__8wekyb3d8bbwe")
					where File.Exists(Path.Combine(d, "winget.exe"))
					orderby d descending
					select Path.Combine(d, "winget.exe")).FirstOrDefault();
				if (text2 != null)
				{
					return text2;
				}
			}
			catch
			{
			}
		}
		return file;
	}

	public static string Explorer => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe");

	public static ActionResult Run(string file, string args, int timeout)
	{
		file = Tool(file);
		try
		{
			using Process process = Process.Start(new ProcessStartInfo(file, args)
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true
			});
			Task<string> task = process.StandardOutput.ReadToEndAsync();
			Task<string> task2 = process.StandardError.ReadToEndAsync();
			if (!process.WaitForExit(timeout))
			{
				try
				{
					process.Kill();
				}
				catch
				{
				}
				return new ActionResult
				{
					Success = false,
					Message = "The operation timed out. Refresh the system state before retrying."
				};
			}
			Task.WaitAll(task, task2);
			return new ActionResult
			{
				Success = (process.ExitCode == 0),
				Message = ((process.ExitCode == 0) ? ("Completed. " + CleanMessage(task.Result)).Trim() : ("Failed. " + CleanMessage(task2.Result + " " + task.Result)).Trim())
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Success = false,
				Message = ex.Message
			};
		}
	}

	// Like Run, but keeps the whole output line by line (Run shortens it to one readable line for messages).
	public static ActionResult RunRaw(string file, string args, int timeout)
	{
		try
		{
			return new ActionResult
			{
				Success = true,
				Message = ReadCommand(file, args, timeout)
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static string ReadCommand(string file, string args)
	{
		return ReadCommand(file, args, 45000);
	}

	public static string ReadCommand(string file, string args, int timeout)
	{
		using Process process = Process.Start(new ProcessStartInfo(Tool(file), args)
		{
			UseShellExecute = false,
			CreateNoWindow = true,
			RedirectStandardOutput = true,
			RedirectStandardError = true
		});
		Task<string> task = process.StandardOutput.ReadToEndAsync();
		Task<string> task2 = process.StandardError.ReadToEndAsync();
		if (!process.WaitForExit(timeout))
		{
			try
			{
				process.Kill();
			}
			catch
			{
			}
			throw new TimeoutException("Read timed out: " + file);
		}
		Task.WaitAll(task, task2);
		if (process.ExitCode != 0)
		{
			throw new InvalidOperationException(CleanMessage(task2.Result));
		}
		return task.Result;
	}

	private static string PsArguments(string script)
	{
		return "-NoLogo -NoProfile -NonInteractive -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes("$env:PSModulePath=[Environment]::GetEnvironmentVariable('PSModulePath','Machine');$ErrorActionPreference='Stop'; " + script));
	}

	public static List<PowerPlan> PowerPlans()
	{
		List<PowerPlan> list = new List<PowerPlan>();
		try
		{
			foreach (Match item in Regex.Matches(ReadCommand("powercfg.exe", "/list"), "([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\\s+\\((.*?)\\)(\\s*\\*)?"))
			{
				list.Add(new PowerPlan
				{
					Id = item.Groups[1].Value,
					Name = item.Groups[2].Value,
					Active = item.Groups[3].Success
				});
			}
		}
		catch
		{
		}
		return list;
	}

	public static List<InstalledApp> InstalledApps()
	{
		return StoreInventory.Read();
	}

	public static ActionResult RemoveApp(InstalledApp app)
	{
		if (app == null || string.IsNullOrWhiteSpace(app.PackageFullName))
		{
			return new ActionResult
			{
				Success = false,
				Message = "Package identity is missing."
			};
		}
		string text = "'" + app.PackageFullName.Replace("'", "''") + "'";
		return Run("powershell.exe", PsArguments("$id=" + text + "; $p=Get-AppxPackage | Where-Object PackageFullName -eq $id; if(-not $p){throw 'This package is no longer installed.'}; if($p.NonRemovable -or $p.IsFramework){throw 'This package is protected.'}; Remove-AppxPackage -Package $id -ErrorAction Stop; if(Get-AppxPackage | Where-Object PackageFullName -eq $id){throw 'Removal could not be verified.'}; Write-Output 'Package removal verified for current user.'"));
	}
}
