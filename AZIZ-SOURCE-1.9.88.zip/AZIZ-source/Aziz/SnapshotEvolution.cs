using System;
using System.Collections.Generic;
using System.Linq;

namespace Aziz;

internal static class SnapshotEvolution
{
	private static bool Same(SavedValue a, SavedValue b)
	{
		if (string.Equals(a.Hive, b.Hive, StringComparison.OrdinalIgnoreCase) && string.Equals(a.Path, b.Path, StringComparison.OrdinalIgnoreCase))
		{
			return string.Equals(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
		}
		return false;
	}

	// Disable Animations took over two older options. Its first snapshot is built from theirs (the real Windows originals),
	// never from today's values, which AZIZ may already have changed.
	public static TweakSnapshot Seed(string id, Func<string, TweakSnapshot> load)
	{
		if (id != "disable-animations")
		{
			return null;
		}
		TweakSnapshot tweakSnapshot = load("animations");
		TweakSnapshot tweakSnapshot2 = load("visual-best-performance");
		if (tweakSnapshot == null && tweakSnapshot2 == null)
		{
			return null;
		}
		TweakSnapshot tweakSnapshot3 = tweakSnapshot ?? tweakSnapshot2;
		if (tweakSnapshot3.Values == null)
		{
			tweakSnapshot3.Values = new List<SavedValue>();
		}
		if (tweakSnapshot != null && tweakSnapshot2 != null)
		{
			foreach (SavedValue value in tweakSnapshot2.Values ?? new List<SavedValue>())
			{
				if (!tweakSnapshot3.Values.Any((SavedValue v) => Same(v, value)))
				{
					tweakSnapshot3.Values.Add(value);
				}
			}
		}
		return tweakSnapshot3;
	}

	public static bool Extend(string id, TweakSnapshot original, TweakSnapshot current, Func<string, TweakSnapshot> load)
	{
		if (original.Values == null)
		{
			original.Values = new List<SavedValue>();
		}
		bool result = false;
		// Options merged into another one: the older option's snapshot holds the real Windows originals of the values it owned
		// (Animations & Visual Effects took over "custom performance" in 1.9.7).
		TweakSnapshot tweakSnapshot = ((id == "show-hidden-files") ? load("show-file-extensions") : ((id == "disable-animations") ? load("visual-best-performance") : null));
		foreach (SavedValue value in current.Values ?? new List<SavedValue>())
		{
			if (!original.Values.Any((SavedValue v) => Same(v, value)))
			{
				SavedValue savedValue = ((tweakSnapshot == null || tweakSnapshot.Values == null) ? null : tweakSnapshot.Values.FirstOrDefault((SavedValue v) => Same(v, value)));
				original.Values.Add(savedValue ?? value);
				result = true;
			}
		}
		return result;
	}
}
