using System;
using System.Runtime.InteropServices;

namespace Aziz;

// Start type through the Service Control Manager API: the running SCM sees the change at once, like sc.exe config.
internal static class ServiceConfig
{
	private const uint ScManagerConnect = 1u;

	private const uint ServiceChangeConfig = 2u;

	private const uint NoChange = 0xFFFFFFFFu;

	private const uint DelayedAutoStartInfo = 3u;

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern IntPtr OpenSCManager(string machine, string database, uint access);

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern IntPtr OpenService(IntPtr manager, string name, uint access);

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool ChangeServiceConfig(IntPtr service, uint type, uint start, uint error, string path, string group, IntPtr tag, string dependencies, string user, string password, string display);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool ChangeServiceConfig2(IntPtr service, uint level, ref int info);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool CloseServiceHandle(IntPtr handle);

	public static bool SetStart(string name, int start, bool delayed)
	{
		IntPtr intPtr = OpenSCManager(null, null, ScManagerConnect);
		if (intPtr == IntPtr.Zero)
		{
			return false;
		}
		try
		{
			IntPtr intPtr2 = OpenService(intPtr, name, ServiceChangeConfig);
			if (intPtr2 == IntPtr.Zero)
			{
				return false;
			}
			try
			{
				if (!ChangeServiceConfig(intPtr2, NoChange, (uint)start, NoChange, null, null, IntPtr.Zero, null, null, null, null))
				{
					return false;
				}
				if (start == 2)
				{
					// sc.exe "auto" clears the delayed flag and "delayed-auto" sets it: same here.
					int info = (delayed ? 1 : 0);
					ChangeServiceConfig2(intPtr2, DelayedAutoStartInfo, ref info);
				}
				return true;
			}
			finally
			{
				CloseServiceHandle(intPtr2);
			}
		}
		finally
		{
			CloseServiceHandle(intPtr);
		}
	}
}
