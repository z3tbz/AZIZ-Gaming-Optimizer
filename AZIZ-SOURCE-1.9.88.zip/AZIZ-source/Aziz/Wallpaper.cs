using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace Aziz;

internal static class Wallpaper
{
	[DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool SystemParametersInfo(int action, int param, string value, int flags);

	[DllImport("user32.dll")]
	private static extern IntPtr GetDC(IntPtr hWnd);

	[DllImport("user32.dll")]
	private static extern int ReleaseDC(IntPtr hWnd, IntPtr hdc);

	[DllImport("gdi32.dll")]
	private static extern int GetDeviceCaps(IntPtr hdc, int index);

	// Real pixel size of the main screen, whatever the Windows scaling is.
	public static Size ScreenPixels()
	{
		IntPtr dC = GetDC(IntPtr.Zero);
		try
		{
			int num = GetDeviceCaps(dC, 118);
			int num2 = GetDeviceCaps(dC, 117);
			if (num > 0 && num2 > 0)
			{
				return new Size(num, num2);
			}
		}
		finally
		{
			ReleaseDC(IntPtr.Zero, dC);
		}
		return new Size(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight);
	}

	private static readonly double[] Navy = Hex(4, 6, 26);

	private static readonly double[] Ink = Hex(11, 10, 42);

	private static readonly double[] Violet = Hex(74, 35, 168);

	private static readonly double[] Blue = Hex(22, 60, 158);

	private static readonly double[] Mauve = Hex(78, 31, 120);

	private static double[] Hex(int r, int g, int b)
	{
		return new double[3]
		{
			(double)r / 255.0,
			(double)g / 255.0,
			(double)b / 255.0
		};
	}

	private static double[] Scale(double[] c, double k)
	{
		return new double[3]
		{
			c[0] * k,
			c[1] * k,
			c[2] * k
		};
	}

	// Piecewise colour ramp with smoothstep between stops (same as the approved design files).
	private static void Ramp(double t, double[] offsets, double[][] colors, double[] o)
	{
		t = Math.Max(0.0, Math.Min(1.0, t));
		for (int i = 0; i < offsets.Length - 1; i++)
		{
			if (t <= offsets[i + 1] || i == offsets.Length - 2)
			{
				double num = Math.Max(0.0, Math.Min(1.0, (t - offsets[i]) / (offsets[i + 1] - offsets[i])));
				num = num * num * (3.0 - 2.0 * num);
				for (int j = 0; j < 3; j++)
				{
					o[j] = colors[i][j] * (1.0 - num) + colors[i + 1][j] * num;
				}
				return;
			}
		}
	}

	public static readonly string[] Styles = new string[2] { "Horizon", "Split" };

	// Renders the AZIZ wallpaper at the screen's real pixel size (any resolution and aspect ratio) and returns the PNG path.
	public static string Render(int width, int height, int style = 1)
	{
		if (width <= 0 || height <= 0)
		{
			Size size = ScreenPixels();
			width = (int)size.Width;
			height = (int)size.Height;
		}
		int W = Math.Max(640, Math.Min(7680, width));
		int H = Math.Max(480, Math.Min(4320, height));
		double a = (double)W / (double)H;
		double diag = Math.Sqrt(a * 0.5 * (a * 0.5) + 0.25);
		double[] offsets;
		double[][] colors;
		if (style == 0)
		{
			offsets = new double[4] { 0.0, 0.4, 0.75, 1.0 };
			colors = new double[4][]
			{
				Scale(Mauve, 0.8),
				Ink,
				Navy,
				Scale(Blue, 0.6)
			};
		}
		else
		{
			offsets = new double[4] { 0.0, 0.45, 0.55, 1.0 };
			colors = new double[4][]
			{
				Scale(Violet, 0.7),
				Ink,
				Ink,
				Scale(Blue, 0.75)
			};
		}
		int stride = W * 4;
		byte[] pixels = new byte[stride * H];
		System.Threading.Tasks.Parallel.For(0, H, delegate(int y)
		{
			Random random = new Random(y * 7919 + 17);
			double[] array = new double[3];
			double num = ((double)y + 0.5) / (double)H;
			for (int i = 0; i < W; i++)
			{
				double num2 = ((double)i + 0.5) / (double)W;
				double t = ((style == 0) ? num : ((num2 - 0.5) * a * 0.9 + (num - 0.5) * 0.5 + 0.5));
				Ramp(t, offsets, colors, array);
				double num3 = (num2 - 0.5) * a;
				double num4 = num - 0.45;
				double num5 = Math.Max(0.0, Math.Min(1.0, (Math.Sqrt(num3 * num3 + num4 * num4) / diag - 0.3) / 0.8));
				double num6 = 0.82 * (1.0 - 0.6 * Math.Pow(num5, 1.5));
				int num7 = (y * W + i) * 4;
				pixels[num7] = Tone(array[2] * num6, random);
				pixels[num7 + 1] = Tone(array[1] * num6, random);
				pixels[num7 + 2] = Tone(array[0] * num6, random);
				pixels[num7 + 3] = byte.MaxValue;
			}
		});
		BitmapSource imageSource = BitmapSource.Create(W, H, 96.0, 96.0, PixelFormats.Bgra32, null, pixels, stride);
		double num8 = (double)H * 0.44;
		DrawingVisual drawingVisual = new DrawingVisual();
		using (DrawingContext drawingContext = drawingVisual.RenderOpen())
		{
			drawingContext.DrawImage(imageSource, new Rect(0.0, 0.0, W, H));
			drawingContext.PushTransform(new MatrixTransform(num8 / 100.0, 0.0, 0.0, num8 / 100.0, ((double)W - num8) / 2.0, (double)H * 0.45 - num8 / 2.0));
			drawingContext.DrawDrawing(BrandArt.WallpaperMark());
			drawingContext.Pop();
		}
		RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap(W, H, 96.0, 96.0, PixelFormats.Pbgra32);
		RenderOptions.SetEdgeMode(drawingVisual, EdgeMode.Unspecified);
		renderTargetBitmap.Render(drawingVisual);
		string text = Path.Combine(Program.Data, "AZIZ-Wallpaper-" + Styles[Math.Max(0, Math.Min(1, style))] + "-" + W + "x" + H + ".png");
		Directory.CreateDirectory(Program.Data);
		PngBitmapEncoder pngBitmapEncoder = new PngBitmapEncoder();
		pngBitmapEncoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));
		using (FileStream stream = File.Create(text))
		{
			pngBitmapEncoder.Save(stream);
		}
		return text;
	}

	private static byte Tone(double v, Random random)
	{
		double num = (1.0 - Math.Exp((0.0 - Math.Max(0.0, v)) * 1.2)) * 255.0 + (random.NextDouble() - random.NextDouble());
		if (num < 0.0)
		{
			return 0;
		}
		if (num > 255.0)
		{
			return byte.MaxValue;
		}
		return (byte)Math.Round(num);
	}

	public static void Set(string file)
	{
		using (RegistryKey registryKey = Registry.CurrentUser.CreateSubKey("Control Panel\\Desktop"))
		{
			registryKey.SetValue("WallpaperStyle", "10");
			registryKey.SetValue("TileWallpaper", "0");
		}
		if (!SystemParametersInfo(20, 0, file, 3))
		{
			throw new IOException("Windows did not accept the wallpaper.");
		}
	}
}
