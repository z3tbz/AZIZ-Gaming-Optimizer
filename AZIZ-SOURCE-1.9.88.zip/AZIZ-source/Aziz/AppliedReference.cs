using System.Collections.Generic;

namespace Aziz;

internal sealed class AppliedReference
{
	public string Name { get; set; }

	public Dictionary<string, string> Values { get; set; }

	public Dictionary<string, string> Accepted { get; set; }
}
