using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class AppLauncher
{
	private static readonly Dictionary<string, string[]> Names = new Dictionary<string, string[]>
	{
		{
			"latencymon",
			new string[1] { "LatMon.exe" }
		},
		{
			"msi-afterburner",
			new string[1] { "MSIAfterburner.exe" }
		},
		{
			"chrome",
			new string[1] { "chrome.exe" }
		},
		{
			"firefox",
			new string[1] { "firefox.exe" }
		},
		{
			"brave",
			new string[1] { "brave.exe" }
		},
		{
			"processlasso",
			new string[1] { "ProcessLasso.exe" }
		},
		{
			"gointerrupt",
			new string[1] { "GoInterruptPolicy.exe" }
		},
		{
			"rweverything",
			new string[1] { "Rw.exe" }
		},
		{
			"steam",
			new string[1] { "steam.exe" }
		},
		{
			"epic",
			new string[1] { "EpicGamesLauncher.exe" }
		},
		{
			"ea",
			new string[1] { "EADesktop.exe" }
		},
		{
			"discord",
			new string[1] { "Discord.exe" }
		},
		{
			"notepad-plus-plus",
			new string[1] { "notepad++.exe" }
		},
		{
			"vscode",
			new string[1] { "Code.exe" }
		},
		{
			"cru",
			new string[1] { "CRU.exe" }
		},
		{
			"power-settings-explorer",
			new string[1] { "PowerSettingsExplorer.exe" }
		},
		{
			"rockstar",
			new string[1] { "Launcher.exe" }
		},
		{
			"ubisoft",
			new string[1] { "UbisoftConnect.exe" }
		},
		{
			"gog",
			new string[1] { "GalaxyClient.exe" }
		},
		{
			"heroic",
			new string[1] { "Heroic.exe" }
		},
		{
			"playnite",
			new string[1] { "Playnite.DesktopApp.exe" }
		}
	};

	internal static string DesktopOverride { get; set; }

	private static object Invoke(object o, string name, params object[] args)
	{
		return o.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, o, args);
	}

	private static object Get(object o, string name)
	{
		return o.GetType().InvokeMember(name, BindingFlags.GetProperty, null, o, null);
	}

	private static void Set(object o, string name, object value)
	{
		o.GetType().InvokeMember(name, BindingFlags.SetProperty, null, o, new object[1] { value });
	}

	private static void Release(object o)
	{
		if (o != null && Marshal.IsComObject(o))
		{
			Marshal.FinalReleaseComObject(o);
		}
	}

	private static string Key(string s)
	{
		return Regex.Replace((s ?? "").ToLowerInvariant(), "[^a-z0-9]", "");
	}

	private static bool Tool(string path)
	{
		if (Path.GetFileName(path).Equals("Setup.exe", StringComparison.OrdinalIgnoreCase) && DownloadLibrary.Within(path, Path.Combine(DownloadLibrary.Folder, "Portable")) && Path.GetFullPath(path).Substring(Path.GetFullPath(DownloadLibrary.Folder).Length).Split(Path.DirectorySeparatorChar)
			.Any((string x) => x.Equals("hidusbf", StringComparison.OrdinalIgnoreCase) || x.StartsWith("hidusbf (", StringComparison.OrdinalIgnoreCase) || x.StartsWith("hidusbf-", StringComparison.OrdinalIgnoreCase)))
		{
			return false;
		}
		string text = Path.GetFileNameWithoutExtension(path).ToLowerInvariant();
		if (!new string[7] { "unins", "uninstall", "setup", "crash", "update", "helper", "redist" }.Any(text.Contains))
		{
			return new string[8] { "cmd", "powershell", "pwsh", "rundll32", "msiexec", "regsvr32", "wscript", "cscript" }.Contains(text);
		}
		return true;
	}

	public static bool ValidExe(string path)
	{
		try
		{
			return !string.IsNullOrWhiteSpace(path) && Path.IsPathRooted(path) && !path.StartsWith("\\\\") && Path.GetExtension(path).Equals(".exe", StringComparison.OrdinalIgnoreCase) && File.Exists(path) && (Path.GetFileName(path).Equals("Display Driver Uninstaller.exe", StringComparison.OrdinalIgnoreCase) || !Tool(path));
		}
		catch
		{
			return false;
		}
	}

	private static string[] Executables(DownloadItem item)
	{
		if (!Names.TryGetValue(item.Id, out var value))
		{
			if (string.IsNullOrEmpty(item.EntryExe))
			{
				return new string[0];
			}
			return new string[1] { item.EntryExe };
		}
		return value;
	}

	public static string FindInstalled(DownloadItem item)
	{
		string[] array = Executables(item);
		foreach (string path in array)
		{
			foreach (string item2 in new string[2]
			{
				Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
				Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86)
			}.Distinct())
			{
				try
				{
					string[] directories = Directory.GetDirectories(item2);
					for (int j = 0; j < directories.Length; j++)
					{
						string text = Path.Combine(directories[j], path);
						if (ValidExe(text))
						{
							return text;
						}
					}
				}
				catch
				{
				}
			}
		}
		return null;
	}

	internal static string Match(LaunchEntry entry, IEnumerable<DownloadItem> items)
	{
		string text = Key(entry.Name);
		foreach (DownloadItem item in items)
		{
			string text2 = Key(item.Name.Replace(" · Portable", "").Replace(" · Installer", ""));
			if (text == text2 || (text2.Length >= 5 && (text == text2 + "64bit" || text == text2 + "x64" || text == text2 + "launcher")))
			{
				return item.Id;
			}
		}
		foreach (DownloadItem item2 in items)
		{
			if (Executables(item2).Any((string n) => Path.GetFileName(entry.Target).Equals(n, StringComparison.OrdinalIgnoreCase)) && (!(item2.Id == "rockstar") || entry.Target.IndexOf("Rockstar", StringComparison.OrdinalIgnoreCase) >= 0) && (!(item2.Id == "chrome") || entry.Target.IndexOf("Google", StringComparison.OrdinalIgnoreCase) >= 0) && (!(item2.Id == "firefox") || entry.Target.IndexOf("Mozilla", StringComparison.OrdinalIgnoreCase) >= 0))
			{
				return item2.Id;
			}
		}
		return null;
	}

	public static List<LaunchEntry> Discover(List<DesktopApp> desktop, List<InstalledApp> store)
	{
		List<LaunchEntry> list = new List<LaunchEntry>();
		List<DownloadItem> list2 = DownloadManager.Catalog();
		foreach (DownloadRecord record in DownloadLibrary.Read())
		{
			Func<DownloadItem, bool> predicate = (DownloadItem x) => x.Id == record.Id;
			DownloadItem downloadItem = list2.FirstOrDefault(predicate);
			if (downloadItem != null && ValidExe(record.OpenPath))
			{
				list.Add(Portable(new DownloadJob
				{
					Item = downloadItem
				}, record.OpenPath));
			}
		}
		object o = null;
		try
		{
			o = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
			string[] array = new string[3]
			{
				Environment.GetFolderPath(Environment.SpecialFolder.Programs),
				Environment.GetFolderPath(Environment.SpecialFolder.CommonPrograms),
				Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory)
			};
			foreach (string root in array)
			{
				int budget = 1800;
				foreach (string item in Links(root, 0, () => budget-- > 0))
				{
					object o2 = null;
					try
					{
						o2 = Invoke(o, "CreateShortcut", item);
						string text = Environment.ExpandEnvironmentVariables(Convert.ToString(Get(o2, "TargetPath")));
						if (ValidExe(text))
						{
							list.Add(new LaunchEntry
							{
								Name = Path.GetFileNameWithoutExtension(item),
								Target = text,
								Arguments = Convert.ToString(Get(o2, "Arguments")),
								Directory = Convert.ToString(Get(o2, "WorkingDirectory")),
								Icon = Convert.ToString(Get(o2, "IconLocation")),
								Category = "Tools",
								Source = "Installed in Windows"
							});
						}
					}
					catch
					{
					}
					finally
					{
						Release(o2);
					}
				}
			}
		}
		catch
		{
		}
		finally
		{
			Release(o);
		}
		foreach (InstalledApp item2 in store ?? new List<InstalledApp>())
		{
			if (!string.IsNullOrWhiteSpace(item2.AppUserModelId))
			{
				list.Add(new LaunchEntry
				{
					Name = (item2.DisplayName ?? item2.Name.Replace("Microsoft.", "")),
					Target = "shell:AppsFolder\\" + item2.AppUserModelId,
					Icon = item2.IconPath,
					Category = "Microsoft",
					Source = "Microsoft Store"
				});
			}
		}
		foreach (DesktopApp app in desktop ?? new List<DesktopApp>())
		{
			List<LaunchEntry> source = list;
			Func<LaunchEntry, bool> predicate2 = (LaunchEntry x) => Key(x.Name) == Key(app.Name);
			if (source.Any(predicate2))
			{
				continue;
			}
			LaunchEntry launchEntry = new LaunchEntry
			{
				Name = app.Name,
				Icon = app.Icon,
				Source = "Installed in Windows",
				Category = "Tools"
			};
			string text2 = AppIcons.ExecutablePath(app.Icon);
			if (ValidExe(text2))
			{
				launchEntry.Target = text2;
			}
			else if (!string.IsNullOrEmpty(app.InstallLocation) && Directory.Exists(app.InstallLocation))
			{
				foreach (DownloadItem item3 in list2.Where((DownloadItem x) => Key(app.Name).Contains(Key(x.Name))))
				{
					launchEntry.Target = (from x in Executables(item3)
						select Path.Combine(app.InstallLocation, x)).FirstOrDefault(ValidExe);
					if (launchEntry.Target != null)
					{
						break;
					}
				}
			}
			if (launchEntry.Target != null)
			{
				list.Add(launchEntry);
			}
		}
		RegistryHive[] array2 = new RegistryHive[2]
		{
			RegistryHive.CurrentUser,
			RegistryHive.LocalMachine
		};
		foreach (RegistryHive hKey in array2)
		{
			RegistryView[] array3 = new RegistryView[2]
			{
				RegistryView.Registry64,
				RegistryView.Registry32
			};
			foreach (RegistryView view in array3)
			{
				try
				{
					using RegistryKey registryKey = RegistryKey.OpenBaseKey(hKey, view);
					using RegistryKey registryKey2 = registryKey.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths");
					if (registryKey2 == null)
					{
						continue;
					}
					string[] array = registryKey2.GetSubKeyNames();
					foreach (string name in array)
					{
						using RegistryKey registryKey3 = registryKey2.OpenSubKey(name);
						string text3 = ((registryKey3 == null) ? null : Environment.ExpandEnvironmentVariables(Convert.ToString(registryKey3.GetValue(""))).Trim('"'));
						if (!ValidExe(text3))
						{
							continue;
						}
						string name2 = Path.GetFileNameWithoutExtension(text3);
						try
						{
							FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(text3);
							if (!string.IsNullOrWhiteSpace(versionInfo.ProductName))
							{
								name2 = versionInfo.ProductName;
							}
						}
						catch
						{
						}
						list.Add(new LaunchEntry
						{
							Name = name2,
							Target = text3,
							Icon = text3,
							Category = "Tools",
							Source = "Windows App Paths"
						});
					}
				}
				catch
				{
				}
			}
		}
		try
		{
			List<LaunchEntry> source2 = Program.Json.Deserialize<List<LaunchEntry>>(File.ReadAllText(Path.Combine(Program.Data, "manual-apps.json")));
			list.AddRange(source2.Where((LaunchEntry x) => ValidExe(x.Target)));
		}
		catch
		{
		}
		list = (from g in list.Where((LaunchEntry x) => x.Target != null && x.Target.IndexOf("AZIZGamingOptimizer", StringComparison.OrdinalIgnoreCase) < 0).GroupBy((LaunchEntry x) => x.Target + "|" + x.Arguments, StringComparer.OrdinalIgnoreCase)
			select g.First()).ToList();
		foreach (LaunchEntry entry in list)
		{
			entry.CatalogId = Match(entry, list2);
			Func<DownloadItem, bool> predicate3 = (DownloadItem x) => x.Id == entry.CatalogId;
			DownloadItem downloadItem2 = list2.FirstOrDefault(predicate3);
			if (downloadItem2 != null)
			{
				entry.Category = downloadItem2.Category;
			}
			AppIcons.Load(entry.Icon);
		}
		return list.OrderBy((LaunchEntry x) => x.Name).ToList();
	}

	private static IEnumerable<string> Links(string root, int depth, Func<bool> budget)
	{
		if (depth > 7 || string.IsNullOrEmpty(root) || !Directory.Exists(root))
		{
			yield break;
		}
		string[] array = new string[0];
		string[] dirs = new string[0];
		try
		{
			if ((File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0)
			{
				yield break;
			}
			array = Directory.GetFiles(root, "*.lnk");
			dirs = Directory.GetDirectories(root);
		}
		catch
		{
		}
		string[] array2 = array;
		string[] array3 = array2;
		int num = 0;
		while (true)
		{
			if (num < array3.Length)
			{
				string text = array3[num];
				if (budget())
				{
					yield return text;
					num++;
					continue;
				}
				break;
			}
			array3 = dirs;
			foreach (string root2 in array3)
			{
				foreach (string item in Links(root2, depth + 1, budget))
				{
					yield return item;
				}
			}
			break;
		}
	}

	public static void Open(LaunchEntry entry)
	{
		if (entry.Target.StartsWith("shell:AppsFolder\\", StringComparison.Ordinal))
		{
			Process.Start(Utilities.Explorer, entry.Target);
			return;
		}
		if (!ValidExe(entry.Target))
		{
			throw new IOException("The app executable is missing. Refresh installed apps or choose its new location.");
		}
		// Apps and games open with normal user rights (through Explorer), not with AZIZ's admin rights. Tools that need
		// admin ask Windows themselves.
		if (string.IsNullOrEmpty(entry.Arguments))
		{
			Process.Start(Utilities.Explorer, "\"" + entry.Target + "\"");
			return;
		}
		Process.Start(new ProcessStartInfo(entry.Target, entry.Arguments)
		{
			UseShellExecute = true,
			WorkingDirectory = (Directory.Exists(entry.Directory) ? entry.Directory : Path.GetDirectoryName(entry.Target))
		});
	}

	public static LaunchEntry Portable(DownloadJob job, string target)
	{
		return new LaunchEntry
		{
			Name = job.Item.Name,
			Target = target,
			Arguments = ((job.Item.Portable && (job.Item.Id == "brave" || job.Item.Id == "helium")) ? ("--user-data-dir=\"" + Path.Combine(Path.GetDirectoryName(target), "UserData") + "\"") : ""),
			Directory = Path.GetDirectoryName(target),
			Icon = target,
			Category = job.Item.Category,
			Source = "AZIZ download",
			CatalogId = job.Item.Id
		};
	}

	public static string Shortcut(LaunchEntry entry)
	{
		if (!ValidExe(entry.Target) && !entry.Target.StartsWith("shell:AppsFolder\\", StringComparison.Ordinal))
		{
			throw new IOException("There is no launchable application for this shortcut.");
		}
		string text = DesktopOverride ?? Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
		Directory.CreateDirectory(text);
		string text2 = string.Concat(entry.Name.Select((char c) => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
		if (text2.Length > 80)
		{
			text2 = text2.Substring(0, 80);
		}
		string text3 = Path.Combine(text, text2 + " - AZIZ.lnk");
		object o = null;
		object obj = null;
		try
		{
			o = Activator.CreateInstance(Type.GetTypeFromProgID("WScript.Shell"));
			if (File.Exists(text3))
			{
				obj = Invoke(o, "CreateShortcut", text3);
				if (!string.Equals(Convert.ToString(Get(obj, "TargetPath")), entry.Target.StartsWith("shell:AppsFolder\\", StringComparison.Ordinal) ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe") : entry.Target, StringComparison.OrdinalIgnoreCase))
				{
					Release(obj);
					obj = null;
					text3 = Path.Combine(text, text2 + " - AZIZ " + Guid.NewGuid().ToString("N").Substring(0, 6) + ".lnk");
				}
			}
			if (obj == null)
			{
				obj = Invoke(o, "CreateShortcut", text3);
			}
			bool flag = entry.Target.StartsWith("shell:AppsFolder\\", StringComparison.Ordinal);
			Set(obj, "TargetPath", flag ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "explorer.exe") : entry.Target);
			Set(obj, "Arguments", flag ? entry.Target : (entry.Arguments ?? ""));
			if (!flag)
			{
				Set(obj, "WorkingDirectory", entry.Directory ?? Path.GetDirectoryName(entry.Target));
			}
			if (!string.IsNullOrWhiteSpace(entry.Icon))
			{
				Set(obj, "IconLocation", entry.Icon);
			}
			Set(obj, "Description", "Open " + entry.Name + " · AZIZ");
			Invoke(obj, "Save");
			return text3;
		}
		finally
		{
			Release(obj);
			Release(o);
		}
	}

	public static void RememberManual(LaunchEntry entry)
	{
		if (!ValidExe(entry.Target))
		{
			throw new IOException("Choose an existing local application EXE.");
		}
		string path = Path.Combine(Program.Data, "manual-apps.json");
		List<LaunchEntry> list = new List<LaunchEntry>();
		try
		{
			list = Program.Json.Deserialize<List<LaunchEntry>>(File.ReadAllText(path));
		}
		catch
		{
		}
		list.RemoveAll((LaunchEntry x) => string.Equals(x.Target, entry.Target, StringComparison.OrdinalIgnoreCase));
		list.Add(entry);
		Utilities.AtomicWrite(path, Program.Json.Serialize(list));
	}
}
