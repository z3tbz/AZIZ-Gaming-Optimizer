using System.Collections.Generic;

namespace Aziz;

public class Tweak
{
	public string Id { get; set; }

	public string Name { get; set; }

	public string Category { get; set; }

	public string Description { get; set; }

	public string Risk { get; set; }

	public string Source { get; set; }

	public bool RequiresRestart { get; set; }

	public string AvailabilityNote { get; set; }

	public string Group { get; set; }

	public bool ProbeAuthoritative { get; set; }

	public bool CustomDecimal { get; set; }

	public string ReadMode { get; set; }

	public string BcdKey { get; set; }

	public string BcdOnValue { get; set; }

	public string Kind { get; set; }

	public string Service { get; set; }

	public int ServiceEnabledStart { get; set; }

	public int MinBuild { get; set; }

	public string ApplyNow { get; set; }

	public string CpuVendor { get; set; }

	public List<TweakChoice> Choices { get; set; }

	public List<RegistryOperation> Enable { get; set; }

	public List<RegistryOperation> Disable { get; set; }

	public string ProbeScript { get; set; }

	public string CaptureScript { get; set; }

	public string EnableScript { get; set; }

	public string DisableScript { get; set; }

	public string RestoreScript { get; set; }
}
