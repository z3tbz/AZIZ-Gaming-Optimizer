using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Security.Principal;
using Microsoft.Win32;

namespace Aziz;

// Install, start with Windows, desktop shortcut, uninstall and updates. Profiles, history, snapshots and settings live in
// %LocalAppData%\AZIZ and downloads in Downloads\AZIZ, so updating or removing the app folder never loses them.
internal static class AppInstall
{
	public const string UninstallKey = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\AZIZGamingOptimizer";

	public const string UpdateManifest = "https://raw.githubusercontent.com/z3tbz/AZIZ-Gaming-Optimizer/main/version.json";

	// package-files.txt (shipped with AZIZ) lists every file of the package. Uninstall removes exactly those files and
	// then only folders left empty, so nothing else that sits in the same folder is ever touched.
	private static string Manifest => Path.Combine(Program.Root, "package-files.txt");

	private static string Exe => Path.Combine(Program.Root, "AZIZGamingOptimizer.exe");

	private static string TaskName => "AZIZ Gaming Optimizer - " + WindowsIdentity.GetCurrent().User.Value;

	public static bool Installed => Program.Root.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), StringComparison.OrdinalIgnoreCase);

	private static string Q(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	// AZIZ at sign-in, straight to the tray (elevated through Task Scheduler, so no UAC prompt at every start).
	public static ActionResult StartWithWindows(bool on)
	{
		try
		{
			if (!on)
			{
				return Utilities.Run("schtasks.exe", "/Delete /TN \"" + TaskName + "\" /F");
			}
			string value = WindowsIdentity.GetCurrent().User.Value;
			string script = "$a=New-ScheduledTaskAction -Execute " + Q(Exe) + " -Argument '--tray';$t=New-ScheduledTaskTrigger -AtLogOn -User " + Q(value) + ";$p=New-ScheduledTaskPrincipal -UserId " + Q(value) + " -LogonType Interactive -RunLevel Highest;$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew;Register-ScheduledTask -TaskName " + Q(TaskName) + " -Action $a -Trigger $t -Principal $p -Settings $s -Force|Out-Null;'AZIZ starts with Windows.'";
			return Utilities.Run("powershell.exe", GameWatch.PsArgs(script));
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}

	public static void DesktopShortcut()
	{
		try
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "AZIZ Gaming Optimizer.lnk");
			Type typeFromProgID = Type.GetTypeFromProgID("WScript.Shell");
			dynamic val = Activator.CreateInstance(typeFromProgID);
			dynamic val2 = val.CreateShortcut(text);
			val2.TargetPath = Exe;
			val2.WorkingDirectory = Program.Root;
			val2.IconLocation = Exe + ",0";
			val2.Description = "AZIZ Gaming Optimizer";
			val2.Save();
		}
		catch
		{
		}
	}

	// Installed copies appear in Windows Settings ▸ Apps with a working Uninstall.
	public static void RegisterUninstall()
	{
		if (!Installed || !Program.IsAdmin)
		{
			return;
		}
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.CreateSubKey(UninstallKey);
			registryKey.SetValue("DisplayName", "AZIZ Gaming Optimizer");
			registryKey.SetValue("DisplayVersion", AppVersion.Text);
			registryKey.SetValue("Publisher", "AZIZ");
			registryKey.SetValue("DisplayIcon", Exe + ",0");
			registryKey.SetValue("InstallLocation", Program.Root);
			registryKey.SetValue("UninstallString", "\"" + Exe + "\" --uninstall");
			registryKey.SetValue("NoModify", 1, RegistryValueKind.DWord);
			registryKey.SetValue("NoRepair", 1, RegistryValueKind.DWord);
		}
		catch
		{
		}
	}

	// Stops and removes every AZIZ helper (game watch, memory cleaner, Reflex limiter, timer service, start with Windows),
	// then removes the app files after AZIZ exits. Profiles, history and downloads stay; nothing starts again until the
	// user applies a profile in a new copy.
	public static void Uninstall()
	{
		try
		{
			GameConfig gameConfig = GameWatch.Load();
			if (gameConfig.Enabled)
			{
				gameConfig.Enabled = false;
				GameWatch.Save(gameConfig);
			}
		}
		catch
		{
		}
		try
		{
			// Helpers are stopped and removed; AZIZ's own sign-in task is only unregistered (stopping it would end this process).
			Utilities.Run("powershell.exe", GameWatch.PsArgs("Get-ScheduledTask -ErrorAction SilentlyContinue|Where-Object {$_.TaskName -like 'AZIZ *'}|ForEach-Object{if($_.TaskName -notlike 'AZIZ Gaming Optimizer*'){Stop-ScheduledTask -InputObject $_ -ErrorAction SilentlyContinue};Unregister-ScheduledTask -InputObject $_ -Confirm:$false -ErrorAction SilentlyContinue}"));
		}
		catch
		{
		}
		try
		{
			ReflexFallback.RemoveAll();
			ReflexFallback.RemoveTray();
		}
		catch
		{
		}
		try
		{
			AgentFiles.Stop(timerService: false);
			AgentFiles.Stop(timerService: true);
			if (Directory.Exists(AgentFiles.Folder))
			{
				Directory.Delete(AgentFiles.Folder, recursive: true);
			}
		}
		catch
		{
		}
		try
		{
			File.Delete(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "AZIZ Gaming Optimizer.lnk"));
			Registry.LocalMachine.DeleteSubKeyTree(UninstallKey, throwOnMissingSubKey: false);
		}
		catch
		{
		}
		List<string> lines = new List<string>();
		string root = Path.GetFullPath(Program.Root).TrimEnd('\\');
		if ((File.GetAttributes(root) & FileAttributes.ReparsePoint) == 0 && File.Exists(Manifest))
		{
			List<string> files = (from x in File.ReadAllLines(Manifest)
				select x.Trim() into x
				where x.Length > 0 && !x.Contains("..") && !Path.IsPathRooted(x)
				select x).ToList();
			foreach (string file in files)
			{
				lines.Add("del /f /q \"" + Path.Combine(root, file) + "\" 2>nul");
			}
			foreach (string dir in (from f in files
				select Path.GetDirectoryName(f) into d
				where !string.IsNullOrEmpty(d)
				from p in Parents(d)
				select p).Distinct(StringComparer.OrdinalIgnoreCase).OrderByDescending((string d) => d.Length))
			{
				lines.Add("rmdir \"" + Path.Combine(root, dir) + "\" 2>nul");
			}
			lines.Add("del /f /q \"" + Manifest + "\" 2>nul");
			lines.Add("rmdir \"" + root + "\" 2>nul");
		}
		AfterExit(lines);
	}

	private static IEnumerable<string> Parents(string dir)
	{
		for (string text = dir; !string.IsNullOrEmpty(text); text = Path.GetDirectoryName(text))
		{
			yield return text;
		}
	}

	// Runs the commands once this AZIZ process has really ended (waits as long as it takes), from a script in %TEMP%.
	private static void AfterExit(List<string> commands)
	{
		using Process current = Process.GetCurrentProcess();
		string text = Path.Combine(SecureWork.Root, "aziz-after-" + Guid.NewGuid().ToString("N") + ".cmd");
		List<string> list = new List<string> { "@echo off", ":wait", "tasklist /fi \"PID eq " + current.Id + "\" | find \"" + current.Id + "\" >nul && (ping 127.0.0.1 -n 2 >nul & goto wait)" };
		list.AddRange(commands);
		list.Add("del /f /q \"%~f0\"");
		File.WriteAllLines(text, list, System.Text.Encoding.Default);
		Process.Start(new ProcessStartInfo(Utilities.Tool("cmd.exe"), "/c \"" + text + "\"")
		{
			UseShellExecute = false,
			CreateNoWindow = true,
			WindowStyle = ProcessWindowStyle.Hidden
		});
	}

	public class UpdateInfo
	{
		public string Version { get; set; }

		public string Zip { get; set; }

		public string Sha256 { get; set; }

		public string Notes { get; set; }
	}

	// Looks once per start for a newer AZIZ (a small JSON file published with every release).
	public static UpdateInfo Check()
	{
		try
		{
			ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
			using WebClient webClient = new WebClient();
			webClient.Headers["User-Agent"] = "AZIZ-Gaming-Optimizer/" + AppVersion.Text;
			UpdateInfo updateInfo = Program.Json.Deserialize<UpdateInfo>(webClient.DownloadString(UpdateManifest));
			if (updateInfo != null && Version.TryParse(updateInfo.Version, out var result) && result > Version.Parse(AppVersion.Text) && Uri.TryCreate(updateInfo.Zip, UriKind.Absolute, out var result2) && result2.Scheme == "https" && (result2.Host.Equals("github.com", StringComparison.OrdinalIgnoreCase) || result2.Host.EndsWith(".github.com", StringComparison.OrdinalIgnoreCase) || result2.Host.EndsWith(".githubusercontent.com", StringComparison.OrdinalIgnoreCase)) && !string.IsNullOrEmpty(updateInfo.Sha256))
			{
				return updateInfo;
			}
		}
		catch
		{
		}
		return null;
	}

	// Downloads the new package, checks its hash, and replaces the app files after AZIZ closes, then starts it again.
	public static ActionResult Update(UpdateInfo info, Action<int> progress)
	{
		string text = SecureWork.NewFolder("update");
		try
		{
			Directory.CreateDirectory(text);
			string text2 = Path.Combine(text, "aziz.zip");
			using (WebClient webClient = new WebClient())
			{
				webClient.Headers["User-Agent"] = "AZIZ-Gaming-Optimizer/" + AppVersion.Text;
				webClient.DownloadProgressChanged += delegate(object s, DownloadProgressChangedEventArgs e)
				{
					progress?.Invoke(e.ProgressPercentage);
				};
				webClient.DownloadFileTaskAsync(info.Zip, text2).GetAwaiter().GetResult();
			}
			using (SHA256 sHA = SHA256.Create())
			{
				using FileStream inputStream = File.OpenRead(text2);
				if (!BitConverter.ToString(sHA.ComputeHash(inputStream)).Replace("-", "").Equals(info.Sha256, StringComparison.OrdinalIgnoreCase))
				{
					throw new InvalidDataException("The update did not match its published checksum.");
				}
			}
			string text3 = Path.Combine(text, "new");
			System.IO.Compression.ZipFile.ExtractToDirectory(text2, text3);
			string text4 = (File.Exists(Path.Combine(text3, "AZIZGamingOptimizer.exe")) ? text3 : Directory.GetDirectories(text3).FirstOrDefault((string d) => File.Exists(Path.Combine(d, "AZIZGamingOptimizer.exe"))));
			if (text4 == null)
			{
				throw new FileNotFoundException("The update package is incomplete.");
			}
			string text5 = Program.Root.TrimEnd('\\');
			AfterExit(new List<string>
			{
				"robocopy \"" + text4 + "\" \"" + text5 + "\" /E /R:5 /W:1 /NFL /NDL /NJH /NJS >nul",
				"start \"\" \"" + Path.Combine(text5, "AZIZGamingOptimizer.exe") + "\"",
				"rmdir /s /q \"" + text + "\""
			});
			return new ActionResult
			{
				Success = true,
				Message = "AZIZ " + info.Version + " is ready; AZIZ restarts now."
			};
		}
		catch (Exception ex)
		{
			try
			{
				Directory.Delete(text, recursive: true);
			}
			catch
			{
			}
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
