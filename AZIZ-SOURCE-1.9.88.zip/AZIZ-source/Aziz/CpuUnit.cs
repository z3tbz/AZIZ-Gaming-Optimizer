namespace Aziz;

internal class CpuUnit
{
	public uint Id;

	public int Group;

	public int Index;

	public int Core;

	public bool Smt;

	public override string ToString()
	{
		return "CPU " + Index + ((Group > 0) ? (" / G" + Group) : "") + (Smt ? " (T)" : "");
	}
}
