namespace Aziz;

internal class LaunchEntry
{
	public string Name { get; set; }

	public string Target { get; set; }

	public string Arguments { get; set; }

	public string Directory { get; set; }

	public string Icon { get; set; }

	public string Category { get; set; }

	public string Source { get; set; }

	public string CatalogId { get; set; }
}
