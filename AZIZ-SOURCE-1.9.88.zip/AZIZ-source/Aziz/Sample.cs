using System;

namespace Aziz;

public sealed class Sample
{
	public double? Cpu { get; set; }

	public double? Gpu { get; set; }

	public double? Ram { get; set; }

	public double? CpuTemp { get; set; }

	public double? GpuTemp { get; set; }

	public string MemoryText { get; set; }

	public string SensorNote { get; set; }

	public DateTime Time { get; set; }
}
