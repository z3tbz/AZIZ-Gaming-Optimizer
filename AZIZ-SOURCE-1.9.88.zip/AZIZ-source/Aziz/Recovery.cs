﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Aziz;

internal static class Recovery
{
	public static readonly RestoreApp[] Apps = new RestoreApp[16]
	{
		new RestoreApp("Microsoft Store", "9WZDNCRFJBMP"),
		new RestoreApp("Xbox", "9MV0B5HZVK9Z"),
		new RestoreApp("Photos", "9WZDNCRFJBH4"),
		new RestoreApp("Notepad", "9MSMLRH6LZF3"),
		new RestoreApp("Media Player", "9WZDNCRFJ3PT"),
		new RestoreApp("Calculator", "9WZDNCRFHVN5"),
		new RestoreApp("Sticky Notes", "9NBLGGH4QGHW"),
		new RestoreApp("Clock", "9WZDNCRFJ3PR"),
		new RestoreApp("Feedback Hub", "9NBLGGH4R32N"),
		new RestoreApp("Microsoft To Do", "9NBLGGH5R558"),
		new RestoreApp("Phone Link", "9NMPJ99VJBWV"),
		new RestoreApp("Xbox Game Bar", "9NZKPSTSNW4P"),
		new RestoreApp("Gaming Services", "9MWPM2CQNLHN"),
		new RestoreApp("Clipchamp", "9P1J8S7CCWWT"),
		new RestoreApp("Quick Assist", "9P7BP5VNWKX5"),
		new RestoreApp("Outlook (New)", "9NRX63209R7B")
	};

	private static readonly Dictionary<string, string> StorePackages = new Dictionary<string, string>
	{
		{ "9WZDNCRFHVN5", "Microsoft.WindowsCalculator" },
		{ "9MSMLRH6LZF3", "Microsoft.WindowsNotepad" },
		{ "9PCFS5B6T72H", "Microsoft.Paint" },
		{ "9WZDNCRFJBH4", "Microsoft.Windows.Photos" },
		{ "9MZ95KL8MR0L", "Microsoft.ScreenSketch" },
		{ "9WZDNCRFJ3PT", "Microsoft.ZuneMusic" },
		{ "9WZDNCRFJBBG", "Microsoft.WindowsCamera" },
		{ "9WZDNCRFJ3PR", "Microsoft.WindowsAlarms" },
		{ "9NBLGGH4QGHW", "Microsoft.MicrosoftStickyNotes" },
		{ "9MV0B5HZVK9Z", "Microsoft.GamingApp" },
		{ "9NZKPSTSNW4P", "Microsoft.XboxGamingOverlay" },
		{ "9WZDNCRFJBMP", "Microsoft.WindowsStore" },
		{ "9NBLGGH4R32N", "Microsoft.WindowsFeedbackHub" },
		{ "9NBLGGH5R558", "Microsoft.Todos" },
		{ "9NMPJ99VJBWV", "Microsoft.YourPhone" },
		{ "9MWPM2CQNLHN", "Microsoft.GamingServices" },
		{ "9P1J8S7CCWWT", "Clipchamp.Clipchamp" },
		{ "9P7BP5VNWKX5", "MicrosoftCorporationII.QuickAssist" },
		{ "9NRX63209R7B", "Microsoft.OutlookForWindows" }
	};

	public static ActionResult Install(RestoreApp app)
	{
		if (app.Name == "Microsoft Store")
		{
			return RestoreStore();
		}
		return InstallStorePackage(app.StoreId);
	}

	public static ActionResult InstallStorePackage(string id)
	{
		if (!Regex.IsMatch(id ?? "", "^[A-Z0-9]{12}$"))
		{
			return new ActionResult
			{
				Message = "Invalid package id."
			};
		}
		StorePackages.TryGetValue(id, out var value);
		value = value ?? "";
		string script = "$id='" + id + "';$name='" + value + "';$appx='HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Appx\\AppxAllUserStore';function Have{if(!$name){return $false};[bool](Get-AppxPackage -Name $name -ErrorAction SilentlyContinue)};if($name){Get-ChildItem ($appx+'\\Deprovisioned') -ErrorAction SilentlyContinue|Where-Object {$_.PSChildName -like ($name+'_*')}|Remove-Item -Force -ErrorAction SilentlyContinue;Get-ChildItem ($appx+'\\EndOfLife') -ErrorAction SilentlyContinue|ForEach-Object{Get-ChildItem $_.PSPath -ErrorAction SilentlyContinue|Where-Object {$_.PSChildName -like ($name+'_*')}|Remove-Item -Force -Recurse -ErrorAction SilentlyContinue}};if(Have){'already installed';exit 0};$kept=@();$prov=@();if($name){try{$kept=@(Get-AppxPackage -AllUsers -Name $name -ErrorAction Stop|Sort-Object Version -Descending)}catch{};try{$prov=@(Get-AppxProvisionedPackage -Online -ErrorAction Stop|Where-Object DisplayName -eq $name)}catch{}};if($name){foreach($p in $kept){$m=Join-Path $p.InstallLocation 'AppxManifest.xml';if(Test-Path -LiteralPath $m){try{Add-AppxPackage -Register $m -DisableDevelopmentMode -ForceApplicationShutdown -ErrorAction Stop}catch{}};if(Have){'registered again from the copy Windows kept';exit 0}};foreach($p in $prov){$m=Join-Path $p.InstallLocation 'AppxManifest.xml';if(Test-Path -LiteralPath $m){try{Add-AppxPackage -Register $m -DisableDevelopmentMode -ErrorAction Stop}catch{}};if(Have){'registered again from the provisioned copy';exit 0}}};$saved=@{};foreach($s in 'wuauserv','BITS','DoSvc','InstallService','StorSvc','ClipSVC','LicenseManager'){$k='HKLM:\\SYSTEM\\CurrentControlSet\\Services\\'+$s;if(Test-Path -LiteralPath $k){$v=(Get-ItemProperty -LiteralPath $k).Start;$saved[$s]=$v;if($v -eq 4){Set-ItemProperty -LiteralPath $k -Name Start -Value 3}}};foreach($s in 'wuauserv','InstallService'){Start-Service $s -ErrorAction SilentlyContinue};try{$ErrorActionPreference='Continue';$out=(& winget.exe install --id $id --exact --source msstore --accept-package-agreements --accept-source-agreements --disable-interactivity --silent 2>&1|Out-String);if(-not (Have) -and $name){$out+=(& winget.exe install --id $id --exact --source msstore --accept-package-agreements --accept-source-agreements --disable-interactivity --silent --force 2>&1|Out-String)}}finally{foreach($s in $saved.Keys){if($saved[$s] -eq 4){Stop-Service $s -Force -ErrorAction SilentlyContinue;Set-ItemProperty -LiteralPath ('HKLM:\\SYSTEM\\CurrentControlSet\\Services\\'+$s) -Name Start -Value 4}}};if(!$name -and $LASTEXITCODE -eq 0){'installed';exit 0};if(Have){'installed from Microsoft';exit 0};$line=($out -split \"`n\"|Where-Object {$_ -match '[A-Za-z]{4}' -and $_ -notmatch '^\\s*[-\\\\|/█▒ ]+$'}|Select-Object -Last 2) -join ' ';throw ('Windows did not install it. '+$line.Trim())";
		ActionResult actionResult = EnsureWinget();
		ActionResult actionResult2 = LongRun("powershell.exe", GameWatch.PsArgs(script));
		actionResult2.Message = (actionResult2.Success ? "Installed" : Utilities.CleanMessage(actionResult2.Message.Replace("Exit 1. ", "")));
		if (!actionResult2.Success && !actionResult.Success)
		{
			actionResult2.Message = actionResult2.Message + " · Windows package manager: " + Utilities.Short(actionResult.Message);
		}
		return actionResult2;
	}

	internal static ActionResult EnsureWinget()
	{
		return LongRun("powershell.exe", GameWatch.PsArgs("if(Get-Command winget.exe -ErrorAction SilentlyContinue){'Windows package manager ready';exit 0}; if(-not (Get-Module -ListAvailable Microsoft.WinGet.Client)){Install-PackageProvider -Name NuGet -Scope AllUsers -Force | Out-Null;Install-Module -Name Microsoft.WinGet.Client -Repository PSGallery -Scope AllUsers -Force -AllowClobber};Import-Module Microsoft.WinGet.Client;Repair-WinGetPackageManager -Force; if(-not (Get-Command winget.exe -ErrorAction SilentlyContinue)){throw 'App Installer repair is incomplete; sign out or restart Windows and retry.'}"));
	}

	private static ActionResult RestoreStore()
	{
		return LongRun("powershell.exe", GameWatch.PsArgs("$existing=Get-AppxPackage -AllUsers -Name Microsoft.WindowsStore | Sort-Object Version -Descending | Select-Object -First 1;if($existing -and (Test-Path -LiteralPath ($existing.InstallLocation+'\\AppxManifest.xml'))){Add-AppxPackage -Register ($existing.InstallLocation+'\\AppxManifest.xml') -DisableDevelopmentMode -ErrorAction Stop};if(-not(Get-AppxPackage -Name Microsoft.WindowsStore)){ $tool=Join-Path $env:SystemRoot 'System32\\wsreset.exe';if(-not(Test-Path -LiteralPath $tool)){throw 'Windows Store bootstrap is missing. Use component repair or a matching Windows repair image.'};Start-Process -FilePath $tool -ArgumentList '-i' -WindowStyle Hidden;for($i=0;$i -lt 36;$i++){if(Get-AppxPackage -Name Microsoft.WindowsStore){break};Start-Sleep -Seconds 5}};if(-not(Get-AppxPackage -Name Microsoft.WindowsStore)){throw 'Store has not been restored. Check Windows Update and App Installer availability, internet access, then retry. Severely stripped Windows may require an in-place repair.'};'Microsoft Store registration verified.'"));
	}

	public static ActionResult InstallDesktop(string id)
	{
		if (id != "Microsoft.OneDrive" && id != "Microsoft.Edge")
		{
			return new ActionResult
			{
				Message = "Unsupported recovery package."
			};
		}
		ActionResult actionResult = EnsureWinget();
		if (!actionResult.Success)
		{
			return actionResult;
		}
		return LongRun("winget.exe", "install --id " + id + " --exact --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity");
	}

	public static ActionResult Repair(string image)
	{
		string args = "/Online /Cleanup-Image /RestoreHealth";
		if (!string.IsNullOrWhiteSpace(image))
		{
			if (!File.Exists(image) || (!image.EndsWith(".wim", StringComparison.OrdinalIgnoreCase) && !image.EndsWith(".esd", StringComparison.OrdinalIgnoreCase)))
			{
				return new ActionResult
				{
					Message = "Select a matching Windows install.wim or install.esd file."
				};
			}
			return new ActionResult
			{
				Message = "Use Windows recovery with a matching image and edition index. The automatic repair uses Windows Update."
			};
		}
		return LongRun("dism.exe", args);
	}

	public static ActionResult LongRun(string file, string args)
	{
		try
		{
			using Process process = Process.Start(new ProcessStartInfo(Utilities.Tool(file), args)
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true
			});
			Task<string> task = process.StandardOutput.ReadToEndAsync();
			Task<string> task2 = process.StandardError.ReadToEndAsync();
			if (!process.WaitForExit(1800000))
			{
				return new ActionResult
				{
					Message = "The operation is still running in Windows; review DISM or installer status before starting another operation."
				};
			}
			Task.WaitAll(task, task2);
			return new ActionResult
			{
				Success = (process.ExitCode == 0 || process.ExitCode == 3010),
				Message = ((process.ExitCode == 0) ? "Completed. " : ((process.ExitCode == 3010) ? "Completed. Restart required. " : ("Exit " + process.ExitCode + ". "))) + task.Result + task2.Result
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
