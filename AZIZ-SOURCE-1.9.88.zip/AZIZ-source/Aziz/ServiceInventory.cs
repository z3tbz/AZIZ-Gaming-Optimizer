using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using Microsoft.Win32;

namespace Aziz;

internal static class ServiceInventory
{
	internal const string MoreGroup = "More services";

	internal const string DriverGroup = "Drivers";

	public static void Merge(List<Tweak> tweaks)
	{
		HashSet<string> hashSet = new HashSet<string>(from t in tweaks
			where t.Kind == "Service"
			select t.Service, StringComparer.OrdinalIgnoreCase);
		ServiceController[] services = ServiceController.GetServices();
		foreach (ServiceController serviceController in services)
		{
			try
			{
				if (hashSet.Contains(serviceController.ServiceName) || ServiceBatch.Hidden(serviceController.ServiceName))
				{
					continue;
				}
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + serviceController.ServiceName);
				if (registryKey == null)
				{
					continue;
				}
				int num = Convert.ToInt32(registryKey.GetValue("Type", 0));
				int num2 = Convert.ToInt32(registryKey.GetValue("Start", -1));
				if (((uint)num & 0x30u) != 0 && num2 >= 2 && num2 <= 4)
				{
					string text = Convert.ToString(registryKey.GetValue("Description", ""));
					if (text.StartsWith("@"))
					{
						text = "Windows service · " + serviceController.ServiceName;
					}
					string text2 = Convert.ToString(registryKey.GetValue("ImagePath", ""));
					bool flag = text2.IndexOf("\\Windows\\", StringComparison.OrdinalIgnoreCase) >= 0 || text2.StartsWith("%SystemRoot%", StringComparison.OrdinalIgnoreCase) || text2.StartsWith("%windir%", StringComparison.OrdinalIgnoreCase) || text2.IndexOf("system32", StringComparison.OrdinalIgnoreCase) >= 0;
					string group = ((!ServicePresets.Listed(serviceController.ServiceName)) ? "More services" : (ServiceBatch.Essential(serviceController.ServiceName) ? "Essential · kept running" : (ServiceBatch.KeptForGaming(serviceController.ServiceName, serviceController.DisplayName) ? "Gaming, launchers & drivers" : (ServiceBatch.Unneeded(serviceController.ServiceName) ? "Not needed for gaming" : ((!flag) ? "Installed apps" : "Windows services")))));
					Add(tweaks, serviceController.ServiceName, serviceController.DisplayName, group, text + ". Startup type is read from the installed service registry.", driver: false);
				}
			}
			catch
			{
			}
			finally
			{
				serviceController.Dispose();
			}
		}
		hashSet = new HashSet<string>(from t in tweaks
			where t.Kind == "Service"
			select t.Service, StringComparer.OrdinalIgnoreCase);
		foreach (string item in ServicePresets.AllNames())
		{
			if (hashSet.Contains(item) || ServiceBatch.Hidden(item))
			{
				continue;
			}
			try
			{
				using RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + item);
				if (registryKey2 == null)
				{
					continue;
				}
				int num3 = Convert.ToInt32(registryKey2.GetValue("Type", 0));
				int num4 = Convert.ToInt32(registryKey2.GetValue("Start", -1));
				if (((uint)num3 & 3u) != 0 && num4 >= 0 && num4 <= 4)
				{
					string text3 = Convert.ToString(registryKey2.GetValue("DisplayName", ""));
					if (text3.StartsWith("@") || text3.Length == 0)
					{
						text3 = item;
					}
					Add(tweaks, item, text3, "Drivers", "Windows driver · " + item + ". Only the startup type changes; a running driver keeps running until the next restart.", driver: true);
				}
			}
			catch
			{
			}
		}
	}

	private static void Add(List<Tweak> tweaks, string service, string display, string group, string description, bool driver)
	{
		List<TweakChoice> list = new List<TweakChoice>();
		int? num = ServicePresets.Target("default", service);
		if (driver && (ServicePresets.BootDriver(service) || (num.HasValue && num.Value <= 1)))
		{
			list.Add(new TweakChoice
			{
				Value = "0",
				Label = "Boot"
			});
			list.Add(new TweakChoice
			{
				Value = "1",
				Label = "System"
			});
		}
		list.Add(new TweakChoice
		{
			Value = "2",
			Label = "Automatic"
		});
		list.Add(new TweakChoice
		{
			Value = "3",
			Label = "Manual"
		});
		list.Add(new TweakChoice
		{
			Value = "4",
			Label = "Disabled"
		});
		Tweak t2 = new Tweak
		{
			Id = (driver ? "driver-" : "service-") + service.ToLowerInvariant().Replace('.', '-').Replace(' ', '-'),
			Name = ((display == service) ? service : (display + " (" + service + ")")),
			Category = "Services",
			Group = group,
			Kind = "Service",
			Service = service,
			ServiceEnabledStart = 3,
			Description = description,
			Risk = (ServicePresets.Warning(service) ?? "Disabling a required Windows or vendor service can stop its dependent features. Runtime changes can require restart; protected services can reject writes."),
			Enable = new List<RegistryOperation>(),
			Disable = new List<RegistryOperation>(),
			Choices = list
		};
		if (!tweaks.Any((Tweak x) => x.Id == t2.Id))
		{
			tweaks.Add(t2);
		}
	}

	internal static bool IsDriver(string service)
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + service);
			return registryKey != null && (Convert.ToInt32(registryKey.GetValue("Type", 0)) & 3) != 0;
		}
		catch
		{
			return false;
		}
	}
}
