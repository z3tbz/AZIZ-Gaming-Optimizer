using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Aziz;

// --selftest <out.json>: test mode for a throwaway Windows machine (CI). For Ultra and then Low Latency it applies every
// profile value the way One Click does (options in parallel, then the registry set, debloat values and startup apps),
// reads every option back, then runs Windows Default and reads again. The report lists anything that did not apply,
// reads differently from its target, or did not come back. Never run this on a real PC.
internal static class SelfTest
{
	public static int Run(string output)
	{
		Dictionary<string, object> report = new Dictionary<string, object>();
		List<string> log = new List<string>();
		report["runtime"] = RuntimeInformation.FrameworkDescription;
		report["log"] = log;
		// Written after every phase, so a run that is stopped (time limit) still leaves what it found.
		Action save = delegate
		{
			Save(output, report);
		};
		Action<string> write = delegate(string s)
		{
			lock (log)
			{
				log.Add(DateTime.Now.ToString("HH:mm:ss") + "  " + s);
			}
		};
		try
		{
			Directory.CreateDirectory(Program.Data);
			Engine engine = new Engine(null, Program.Data);
			ServiceInventory.Merge(engine.Tweaks);
			Stopwatch stopwatch = Stopwatch.StartNew();
			Dictionary<string, TweakStatus> states = engine.Scan();
			report["firstScanSeconds"] = stopwatch.Elapsed.TotalSeconds;
			stopwatch.Restart();
			states = engine.Scan();
			report["secondScanSeconds"] = stopwatch.Elapsed.TotalSeconds;
			Dictionary<string, string> before = Values(engine, states);
			write("Original values read: " + before.Count);
			save();
			report["captured"] = engine.CaptureOriginals(() => false);
			report["unavailable"] = states.Where((KeyValuePair<string, TweakStatus> x) => x.Value.State == "Unavailable").Select((KeyValuePair<string, TweakStatus> x) => x.Key).ToList();
			foreach (bool item in new bool[2] { true, false })
			{
				string text = (item ? "ultra" : "low");
				Dictionary<string, object> dictionary = new Dictionary<string, object>();
				report[text] = dictionary;
				Dictionary<string, string> values = ProfileLogic.PresetValues(engine.Tweaks, item);
				states = engine.Scan();
				List<Tweak> list = engine.Tweaks.Where(delegate(Tweak t)
				{
					if (states.TryGetValue(t.Id, out var value6) && value6.State == "Unavailable")
					{
						return false;
					}
					string value7;
					return values.TryGetValue(t.Id, out value7) && ProfileLogic.ValueApplies(t, value7) && ProfileLogic.PresetSafe(t, value7) && ProfileLogic.CurrentValue(engine, states, t) != value7;
				}).ToList();
				List<string> failed = new List<string>();
				List<Tuple<double, string>> timings = new List<Tuple<double, string>>();
				stopwatch.Restart();
				Parallel.ForEach(list, new ParallelOptions
				{
					MaxDegreeOfParallelism = 6
				}, delegate(Tweak t)
				{
					string text3 = values[t.Id];
					Stopwatch one = Stopwatch.StartNew();
					ActionResult actionResult;
					try
					{
						actionResult = ((t.Kind == "Service" || (t.Choices != null && t.Choices.Count > 0)) ? engine.ApplyChoice(t.Id, text3) : ((t.Kind == "Timer") ? new ActionResult
						{
							Success = true
						} : ((t.Id == "cpu-boost-settings") ? PowerControls.SetAc(t.Id, "cpu-boost-policy", uint.Parse(text3.Substring(6)), engine.DataPath) : engine.Apply(t.Id, text3 == "Enabled"))));
					}
					catch (Exception ex2)
					{
						actionResult = new ActionResult
						{
							Message = ex2.Message
						};
					}
					lock (timings)
					{
						timings.Add(Tuple.Create(one.Elapsed.TotalSeconds, t.Id));
					}
					if (!actionResult.Success)
					{
						lock (failed)
						{
							failed.Add(t.Id + " → " + text3 + " · " + Utilities.Short(actionResult.Message));
						}
					}
				});
				dictionary["slowest"] = (from x in timings
					orderby x.Item1 descending
					select x.Item2 + " " + Math.Round(x.Item1, 1) + " s").Take(15).ToList();
				save();
				dictionary["changed"] = list.Count;
				dictionary["applySeconds"] = stopwatch.Elapsed.TotalSeconds;
				dictionary["applyFailed"] = failed;
				RegistryJournal.Originals = engine.OriginalIndex();
				dictionary["registrySet"] = SilentTweaks.Apply().Count;
				dictionary["debloatValues"] = DebloatList.ApplyRegistry().Sum((KeyValuePair<string, List<string>> x) => x.Value.Count);
				RegistryJournal.Save();
				dictionary["debloatRest"] = DebloatList.ApplyRest().Select((KeyValuePair<string, List<string>> x) => x.Key + ": " + x.Value.Count).ToList();
				dictionary["startupOff"] = StartupApps.DisableAll();
				save();
				states = engine.Scan();
				Dictionary<string, string> now = Values(engine, states);
				dictionary["wrongAfterApply"] = (from x in values
					where now.ContainsKey(x.Key) && ProfileLogic.ValueApplies(engine.Tweaks.First((Tweak t) => t.Id == x.Key), x.Value) && ProfileLogic.PresetSafe(engine.Tweaks.First((Tweak t) => t.Id == x.Key), x.Value) && now[x.Key] != x.Value && !failed.Any((string f) => f.StartsWith(x.Key + " "))
					select x.Key + ": target " + x.Value + ", reads " + now[x.Key] + " (" + Utilities.Short(states[x.Key].Detail) + ")").ToList();
				dictionary["mixedAfterApply"] = (from x in states
					where x.Value.State == "Mixed" && values.ContainsKey(x.Key)
					select x.Key + " · " + Utilities.Short(x.Value.Detail)).ToList();
				// Windows Default
				stopwatch.Restart();
				List<string> list2 = new List<string>();
				dictionary["registryBack"] = RegistryJournal.RestoreAll().Count;
				dictionary["startupBack"] = StartupApps.RestoreAll().Count;
				dictionary["tasksBack"] = TaskJournal.RestoreAll();
				foreach (Tweak item2 in engine.Tweaks.Where(ProfileLogic.Profileable).ToList())
				{
					if (engine.CanRestore(item2.Id) && engine.MatchesOriginal(item2.Id) == false)
					{
						string text4 = engine.OriginalValue(item2.Id);
						if (text4 == null || ProfileLogic.CurrentValue(engine, states, item2) != text4)
						{
							ActionResult actionResult2 = engine.Restore(item2.Id);
							if (!actionResult2.Success)
							{
								list2.Add(item2.Id + " · " + Utilities.Short(actionResult2.Message));
							}
						}
					}
				}
				dictionary["restoreSeconds"] = stopwatch.Elapsed.TotalSeconds;
				dictionary["restoreFailed"] = list2;
				states = engine.Scan();
				Dictionary<string, string> after = Values(engine, states);
				dictionary["notBackAfterDefault"] = (from x in before
					where after.ContainsKey(x.Key) && after[x.Key] != x.Value
					select x.Key + ": was " + x.Value + ", now " + after[x.Key]).ToList();
				write(text + ": " + list.Count + " changed, " + failed.Count + " failed");
				save();
			}
		}
		catch (Exception ex)
		{
			write("Stopped: " + ex);
			report["crash"] = ex.ToString();
		}
		Save(output, report);
		return report.ContainsKey("crash") ? 1 : 0;
	}

	private static void Save(string output, Dictionary<string, object> report)
	{
		lock (report)
		{
			try
			{
				File.WriteAllText(output, Program.Json.Serialize(report), Encoding.UTF8);
			}
			catch
			{
			}
		}
	}

	// Ids never switched one by one in the lab: very slow Windows features, encryption, and values that only have a meaning
	// together with other settings.
	private static readonly HashSet<string> NotToggled = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "hyper-v", "virtualization-stack", "bitlocker", "cpu-boost-settings" };

	// --selftest-toggle <out.json>: every option on its own — switch it, read it back, put it back, read again. Finds options
	// that fail, read wrong or do not come back, which a whole One Click run can hide. Never run this on a real PC.
	public static int Toggle(string output)
	{
		Dictionary<string, object> report = new Dictionary<string, object>();
		List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
		List<string> problems = new List<string>();
		report["runtime"] = RuntimeInformation.FrameworkDescription;
		report["problems"] = problems;
		report["rows"] = rows;
		try
		{
			Directory.CreateDirectory(Program.Data);
			Engine engine = new Engine(null, Program.Data);
			Dictionary<string, TweakStatus> states = engine.Scan();
			engine.CaptureOriginals(() => false);
			List<Tweak> list = engine.Tweaks.Where((Tweak t) => ProfileLogic.Profileable(t) && t.Kind != "Service" && t.Kind != "Timer" && !NotToggled.Contains(t.Id) && states.ContainsKey(t.Id) && states[t.Id].State != "Unavailable").ToList();
			report["count"] = list.Count;
			Stopwatch total = Stopwatch.StartNew();
			foreach (Tweak t in list)
			{
				Dictionary<string, object> row = new Dictionary<string, object>();
				row["id"] = t.Id;
				try
				{
					string from = ProfileLogic.CurrentValue(engine, engine.Scan(new string[1] { t.Id }), t);
					if (from == null)
					{
						continue;
					}
					string to = ((t.Choices != null && t.Choices.Count > 0) ? t.Choices.Select((TweakChoice c) => c.Value).FirstOrDefault((string v) => v != from && ProfileLogic.ValueApplies(t, v) && ProfileLogic.PresetSafe(t, v)) : ((from == "Enabled") ? "Disabled" : "Enabled"));
					if (to == null || !ProfileLogic.ValueApplies(t, to) || !ProfileLogic.PresetSafe(t, to))
					{
						continue;
					}
					row["from"] = from;
					row["to"] = to;
					Stopwatch stopwatch = Stopwatch.StartNew();
					ActionResult actionResult = ((t.Choices != null && t.Choices.Count > 0) ? engine.ApplyChoice(t.Id, to) : engine.Apply(t.Id, to == "Enabled"));
					row["applySeconds"] = Math.Round(stopwatch.Elapsed.TotalSeconds, 2);
					string read = ProfileLogic.CurrentValue(engine, engine.Scan(new string[1] { t.Id }), t);
					row["read"] = read;
					stopwatch.Restart();
					ActionResult actionResult2 = engine.Restore(t.Id);
					row["restoreSeconds"] = Math.Round(stopwatch.Elapsed.TotalSeconds, 2);
					string back = ProfileLogic.CurrentValue(engine, engine.Scan(new string[1] { t.Id }), t);
					row["back"] = back;
					if (!actionResult.Success)
					{
						problems.Add(t.Id + ": " + from + " → " + to + " failed · " + Utilities.Short(actionResult.Message));
					}
					else if (read != to)
					{
						problems.Add(t.Id + ": " + from + " → " + to + " reads " + read);
					}
					if (!actionResult2.Success)
					{
						problems.Add(t.Id + ": restore failed · " + Utilities.Short(actionResult2.Message));
					}
					else if (back != from)
					{
						problems.Add(t.Id + ": after restore reads " + back + ", was " + from);
					}
				}
				catch (Exception ex)
				{
					problems.Add(t.Id + ": " + Utilities.Short(ex.Message));
				}
				rows.Add(row);
				report["seconds"] = Math.Round(total.Elapsed.TotalSeconds);
				Save(output, report);
			}
		}
		catch (Exception ex2)
		{
			report["crash"] = ex2.ToString();
		}
		Save(output, report);
		return report.ContainsKey("crash") ? 1 : 0;
	}

	// --bench <out.json>: the same work on .NET Framework 4.8 and .NET 10 — catalog load, scans, hardware reads, JSON and
	// memory — to compare the two runtimes on one machine.
	public static int Bench(string output)
	{
		Dictionary<string, object> report = new Dictionary<string, object>();
		report["runtime"] = RuntimeInformation.FrameworkDescription;
		report["startToMainMs"] = Math.Round((DateTime.Now - Process.GetCurrentProcess().StartTime).TotalMilliseconds);
		try
		{
			Stopwatch stopwatch = Stopwatch.StartNew();
			Engine engine = new Engine(null, Program.Data);
			report["catalogLoadMs"] = stopwatch.ElapsedMilliseconds;
			stopwatch.Restart();
			ServiceInventory.Merge(engine.Tweaks);
			report["servicesMergeMs"] = stopwatch.ElapsedMilliseconds;
			report["options"] = engine.Tweaks.Count;
			for (int i = 1; i <= 2; i++)
			{
				stopwatch.Restart();
				engine.Scan();
				report["scan" + i + "Ms"] = stopwatch.ElapsedMilliseconds;
			}
			using (Telemetry telemetry = new Telemetry(sensors: false))
			{
				stopwatch.Restart();
				telemetry.Inspect();
				report["hardwareInspectMs"] = stopwatch.ElapsedMilliseconds;
				telemetry.Read();
				stopwatch.Restart();
				for (int j = 0; j < 10; j++)
				{
					telemetry.Read();
				}
				report["readingAvgMs"] = Math.Round(stopwatch.Elapsed.TotalMilliseconds / 10.0, 1);
			}
			stopwatch.Restart();
			string text = "";
			for (int k = 0; k < 20; k++)
			{
				text = Program.Json.Serialize(engine.Tweaks);
				Program.Json.Deserialize<List<Tweak>>(text);
			}
			report["json20xMs"] = stopwatch.ElapsedMilliseconds;
			report["jsonKB"] = text.Length / 1024;
			using (Process process = Process.GetCurrentProcess())
			{
				process.Refresh();
				report["peakWorkingSetMB"] = process.PeakWorkingSet64 / 1048576;
				report["privateMB"] = process.PrivateMemorySize64 / 1048576;
				report["cpuSeconds"] = Math.Round(process.TotalProcessorTime.TotalSeconds, 1);
			}
			report["gen0"] = GC.CollectionCount(0);
			report["gen2"] = GC.CollectionCount(2);
		}
		catch (Exception ex)
		{
			report["crash"] = ex.ToString();
		}
		Save(output, report);
		return report.ContainsKey("crash") ? 1 : 0;
	}

	private static Dictionary<string, string> Values(Engine engine, Dictionary<string, TweakStatus> states)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		foreach (Tweak item in engine.Tweaks.Where(ProfileLogic.Profileable))
		{
			string text = ProfileLogic.CurrentValue(engine, states, item);
			if (text != null)
			{
				dictionary[item.Id] = text;
			}
		}
		return dictionary;
	}
}
