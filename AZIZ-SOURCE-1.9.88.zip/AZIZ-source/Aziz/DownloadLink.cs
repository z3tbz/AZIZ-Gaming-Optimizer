namespace Aziz;

internal class DownloadLink
{
	public string Name { get; set; }

	public string Description { get; set; }

	public string Publisher { get; set; }

	public string Url { get; set; }
}
