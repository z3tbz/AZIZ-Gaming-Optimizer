using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace Aziz;

internal sealed class OptimizeVisual : Grid
{
	private const double Size = 260.0;

	private const double Center = 130.0;

	private const double Radius = 112.0;

	private static readonly Geometry BoltShape = Geometry.Parse("M 66,0 L 16,72 L 46,72 L 28,132 L 90,44 L 58,44 L 80,0 Z");

	private static readonly Color Violet = Color.FromRgb(139, 108, 245);

	private static readonly Color Lavender = Color.FromRgb(201, 186, byte.MaxValue);

	private static readonly Color Deep = Color.FromRgb(98, 70, 220);

	private readonly Ellipse halo;

	private readonly Ellipse track;

	private readonly Path ring;

	private readonly Path ringGlow;

	private readonly Ellipse orbit;

	private readonly RotateTransform orbitTurn = new RotateTransform(0.0, Center, Center);

	private readonly Ellipse ripple;

	private readonly ScaleTransform rippleScale = new ScaleTransform(1.0, 1.0, Center, Center);

	private readonly Path bolt;

	private readonly Path boltGlow;

	private readonly BlurEffect boltBlur;

	private readonly ScaleTransform boltScale = new ScaleTransform(1.0, 1.0);

	private readonly ScaleTransform glowScale = new ScaleTransform(1.0, 1.0);

	private readonly Canvas sparks;

	private readonly TextBlock percent;

	private readonly List<Tuple<Ellipse, double, double, double>> live = new List<Tuple<Ellipse, double, double, double>>();

	private readonly Random random = new Random();

	private double shown;

	private double target;

	private double time;

	private double flash;

	private TimeSpan last;

	private bool running;

	public double Progress => shown;

	public event Action Completed;

	public OptimizeVisual()
	{
		base.Width = Size;
		base.Height = Size;
		base.HorizontalAlignment = HorizontalAlignment.Center;
		base.VerticalAlignment = VerticalAlignment.Center;
		base.UseLayoutRounding = true;
		halo = new Ellipse
		{
			Width = 200.0,
			Height = 200.0,
			Fill = new RadialGradientBrush(Color.FromArgb(90, 139, 108, 245), Color.FromArgb(0, 98, 70, 220)),
			IsHitTestVisible = false
		};
		base.Children.Add(halo);
		ripple = new Ellipse
		{
			Width = Size,
			Height = Size,
			Stroke = new SolidColorBrush(Color.FromArgb(140, 168, 146, byte.MaxValue)),
			StrokeThickness = 1.5,
			Opacity = 0.0,
			RenderTransform = rippleScale,
			IsHitTestVisible = false
		};
		base.Children.Add(ripple);
		orbit = new Ellipse
		{
			Width = 252.0,
			Height = 252.0,
			Stroke = new LinearGradientBrush(Color.FromArgb(210, 168, 146, byte.MaxValue), Color.FromArgb(20, 139, 108, 245), 0.0),
			StrokeThickness = 1.4,
			StrokeDashArray = new DoubleCollection { 1.0, 7.0 },
			StrokeDashCap = PenLineCap.Round,
			RenderTransform = orbitTurn,
			Opacity = 0.6,
			IsHitTestVisible = false
		};
		base.Children.Add(orbit);
		track = new Ellipse
		{
			Width = Radius * 2.0,
			Height = Radius * 2.0,
			Stroke = new SolidColorBrush(Color.FromArgb(38, 168, 146, byte.MaxValue)),
			StrokeThickness = 6.0
		};
		base.Children.Add(track);
		ringGlow = new Path
		{
			StrokeThickness = 12.0,
			StrokeStartLineCap = PenLineCap.Round,
			StrokeEndLineCap = PenLineCap.Round,
			Stroke = new SolidColorBrush(Color.FromArgb(120, 139, 108, 245)),
			Effect = new BlurEffect
			{
				Radius = 10.0
			},
			IsHitTestVisible = false
		};
		base.Children.Add(ringGlow);
		ring = new Path
		{
			StrokeThickness = 6.0,
			StrokeStartLineCap = PenLineCap.Round,
			StrokeEndLineCap = PenLineCap.Round,
			Stroke = new LinearGradientBrush(Lavender, Violet, 45.0)
		};
		base.Children.Add(ring);
		sparks = new Canvas
		{
			Width = Size,
			Height = Size,
			IsHitTestVisible = false
		};
		base.Children.Add(sparks);
		boltBlur = new BlurEffect
		{
			Radius = 16.0
		};
		boltGlow = new Path
		{
			Data = BoltShape,
			Width = 84.0,
			Height = 122.0,
			Stretch = Stretch.Uniform,
			Fill = new SolidColorBrush(Color.FromRgb(255, 176, 32)),
			Opacity = 0.45,
			Effect = boltBlur,
			RenderTransformOrigin = new Point(0.5, 0.5),
			RenderTransform = glowScale,
			HorizontalAlignment = HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(0.0, 0.0, 0.0, 14.0),
			IsHitTestVisible = false
		};
		base.Children.Add(boltGlow);
		bolt = new Path
		{
			Data = BoltShape,
			Width = 84.0,
			Height = 122.0,
			Stretch = Stretch.Uniform,
			Fill = Gold(0.0),
			Stroke = new LinearGradientBrush(Color.FromRgb(255, 250, 225), Color.FromRgb(150, 78, 0), 90.0),
			StrokeThickness = 1.4,
			StrokeLineJoin = PenLineJoin.Miter,
			SnapsToDevicePixels = true,
			RenderTransformOrigin = new Point(0.5, 0.5),
			RenderTransform = boltScale,
			HorizontalAlignment = HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Center,
			Margin = new Thickness(0.0, 0.0, 0.0, 14.0)
		};
		RenderOptions.SetEdgeMode(bolt, EdgeMode.Unspecified);
		base.Children.Add(bolt);
		percent = new TextBlock
		{
			Text = "",
			FontSize = 15.0,
			FontWeight = FontWeights.SemiBold,
			Foreground = new SolidColorBrush(Lavender),
			HorizontalAlignment = HorizontalAlignment.Center,
			VerticalAlignment = VerticalAlignment.Bottom,
			Margin = new Thickness(0.0, 0.0, 0.0, 34.0)
		};
		TextOptions.SetTextFormattingMode(percent, TextFormattingMode.Display);
		base.Children.Add(percent);
		Draw();
	}

	public void Start()
	{
		shown = 0.0;
		target = 0.0;
		flash = 0.0;
		percent.Text = "0%";
		if (!running)
		{
			running = true;
			last = TimeSpan.Zero;
			CompositionTarget.Rendering += Frame;
		}
	}

	public void SetProgress(double value)
	{
		target = Math.Max(target, Math.Max(0.0, Math.Min(1.0, value)));
	}

	public void Stop()
	{
		if (running)
		{
			running = false;
			CompositionTarget.Rendering -= Frame;
		}
		foreach (Tuple<Ellipse, double, double, double> item in live)
		{
			sparks.Children.Remove(item.Item1);
		}
		live.Clear();
	}

	private void Frame(object sender, EventArgs e)
	{
		TimeSpan renderingTime = ((RenderingEventArgs)e).RenderingTime;
		double num = ((last == TimeSpan.Zero) ? (1.0 / 60.0) : Math.Min(0.1, (renderingTime - last).TotalSeconds));
		if (num <= 0.0)
		{
			return;
		}
		last = renderingTime;
		time += num;
		double num2 = ((target >= 1.0) ? 1.0 : Math.Min(target + 0.04, 0.97));
		shown += (num2 - shown) * Math.Min(1.0, num * ((target >= 1.0) ? 4.0 : 1.6));
		if (target >= 1.0 && 1.0 - shown < 0.004)
		{
			shown = 1.0;
		}
		flash = Math.Max(0.0, flash - num * 2.5);
		Draw();
		Spark(num);
		if (shown >= 1.0)
		{
			flash = 1.0;
			Draw();
			percent.Text = "100%";
			Stop();
			this.Completed?.Invoke();
		}
	}

	private void Draw()
	{
		double num = shown;
		percent.Text = ((num > 0.0 || running) ? (Math.Round(num * 100.0) + "%") : "");
		Geometry data = Arc(num);
		ring.Data = data;
		ringGlow.Data = data;
		ringGlow.Opacity = 0.35 + 0.4 * num;
		double num2 = 0.5 + 0.5 * Math.Sin(time * (2.4 + num * 3.0));
		double num3 = 1.0 + num * 0.06 + num2 * 0.025;
		boltScale.ScaleX = num3;
		boltScale.ScaleY = num3;
		double num4 = num3 * (1.04 + num2 * 0.06);
		glowScale.ScaleX = num4;
		glowScale.ScaleY = num4;
		boltGlow.Opacity = 0.35 + num * 0.3 + num2 * 0.12 + flash * 0.3;
		boltBlur.Radius = 14.0 + num * 8.0;
		bolt.Fill = Gold(num * 0.6 + flash * 0.4);
		orbitTurn.Angle = time * (20.0 + num * 50.0) % 360.0;
		orbit.Opacity = 0.35 + 0.4 * num;
		double num5 = time * 0.55 % 1.0;
		rippleScale.ScaleX = 0.82 + num5 * 0.26;
		rippleScale.ScaleY = rippleScale.ScaleX;
		ripple.Opacity = (running ? ((1.0 - num5) * (0.18 + 0.3 * num)) : 0.0);
		halo.Opacity = 0.55 + 0.3 * num + 0.15 * num2 + flash * 0.3;
	}

	private Geometry Arc(double p)
	{
		if (p <= 0.0)
		{
			return Geometry.Empty;
		}
		if (p >= 0.9999)
		{
			return new EllipseGeometry(new Point(Center, Center), Radius, Radius);
		}
		double num = p * Math.PI * 2.0 - Math.PI / 2.0;
		Point point = new Point(Center + Radius * Math.Cos(num), Center + Radius * Math.Sin(num));
		PathFigure pathFigure = new PathFigure
		{
			StartPoint = new Point(Center, Center - Radius),
			IsClosed = false
		};
		pathFigure.Segments.Add(new ArcSegment(point, new Size(Radius, Radius), 0.0, p > 0.5, SweepDirection.Clockwise, isStroked: true));
		return new PathGeometry
		{
			Figures = { pathFigure }
		};
	}

	private void Spark(double dt)
	{
		double num = shown;
		double num2 = (1.5 + num * 18.0) * dt;
		while (random.NextDouble() < num2)
		{
			num2 -= 1.0;
			double item = random.NextDouble() * Math.PI * 2.0;
			Ellipse ellipse = new Ellipse
			{
				Width = 1.6 + random.NextDouble() * 2.2,
				Fill = new SolidColorBrush(Mix(Violet, Lavender, random.NextDouble())),
				IsHitTestVisible = false
			};
			ellipse.Height = ellipse.Width;
			sparks.Children.Add(ellipse);
			live.Add(Tuple.Create(ellipse, item, 70.0, 30.0 + num * 60.0 + random.NextDouble() * 30.0));
		}
		for (int num3 = live.Count - 1; num3 >= 0; num3--)
		{
			Tuple<Ellipse, double, double, double> tuple = live[num3];
			double num4 = tuple.Item3 + tuple.Item4 * dt;
			if (num4 > 126.0)
			{
				sparks.Children.Remove(tuple.Item1);
				live.RemoveAt(num3);
				continue;
			}
			live[num3] = Tuple.Create(tuple.Item1, tuple.Item2, num4, tuple.Item4);
			Canvas.SetLeft(tuple.Item1, Center + Math.Cos(tuple.Item2) * num4 - tuple.Item1.Width / 2.0);
			Canvas.SetTop(tuple.Item1, Center + Math.Sin(tuple.Item2) * num4 - tuple.Item1.Height / 2.0);
			tuple.Item1.Opacity = 0.9 * (1.0 - (num4 - 70.0) / 56.0);
		}
	}

	// Polished gold: bright top, deep amber bottom, with a light band that brightens as the progress grows.
	private static LinearGradientBrush Gold(double shine)
	{
		LinearGradientBrush linearGradientBrush = new LinearGradientBrush
		{
			StartPoint = new Point(0.2, 0.0),
			EndPoint = new Point(0.8, 1.0)
		};
		linearGradientBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255, 250, 222), 0.0));
		linearGradientBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255, 214, 92), 0.22));
		linearGradientBrush.GradientStops.Add(new GradientStop(Mix(Color.FromRgb(255, 236, 160), Colors.White, shine), 0.4));
		linearGradientBrush.GradientStops.Add(new GradientStop(Color.FromRgb(255, 196, 40), 0.55));
		linearGradientBrush.GradientStops.Add(new GradientStop(Color.FromRgb(234, 132, 0), 0.82));
		linearGradientBrush.GradientStops.Add(new GradientStop(Color.FromRgb(196, 96, 0), 1.0));
		return linearGradientBrush;
	}

	private static Color Mix(Color a, Color b, double t)
	{
		t = Math.Max(0.0, Math.Min(1.0, t));
		return Color.FromRgb((byte)((double)(int)a.R + (double)(b.R - a.R) * t), (byte)((double)(int)a.G + (double)(b.G - a.G) * t), (byte)((double)(int)a.B + (double)(b.B - a.B) * t));
	}
}
