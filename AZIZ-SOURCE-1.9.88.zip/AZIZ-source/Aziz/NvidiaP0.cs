using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace Aziz;

internal static class NvidiaP0
{
	public static TweakStatus State()
	{
		List<DisplayDevice> list = DisplayHardware.Nvidia();
		if (list.Count == 0)
		{
			return new TweakStatus
			{
				State = "Unavailable",
				Detail = "No NVIDIA GPU with an installed driver was found."
			};
		}
		int num = 0;
		foreach (DisplayDevice item in list)
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(item.DriverPath);
			if (registryKey != null && Convert.ToInt32(registryKey.GetValue("DisableDynamicPstate", 0)) == 1)
			{
				num++;
			}
		}
		TweakStatus tweakStatus = new TweakStatus();
		tweakStatus.State = ((num == list.Count) ? "Enabled" : ((num == 0) ? "Disabled" : "Mixed"));
		tweakStatus.Detail = num + " / " + list.Count + " NVIDIA GPUs locked to P0 · " + string.Join(", ", list.Select((DisplayDevice c) => c.Name));
		return tweakStatus;
	}

	private static string Smi()
	{
		string[] array = new string[2]
		{
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "nvidia-smi.exe"),
			Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe")
		};
		foreach (string text in array)
		{
			if (File.Exists(text))
			{
				return text;
			}
		}
		return null;
	}

	public static ActionResult Set(bool on)
	{
		try
		{
			List<DisplayDevice> list = DisplayHardware.Nvidia();
			if (list.Count == 0)
			{
				return new ActionResult
				{
					Message = "No NVIDIA GPU with an installed driver was found."
				};
			}
			foreach (DisplayDevice item in list)
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(item.DriverPath, writable: true);
				if (registryKey == null)
				{
					throw new IOException("Driver key missing for " + item.Name);
				}
				if (on)
				{
					registryKey.SetValue("DisableDynamicPstate", 1, RegistryValueKind.DWord);
				}
				else
				{
					registryKey.DeleteValue("DisableDynamicPstate", throwOnMissingValue: false);
				}
			}
			string text = "";
			string text2 = Smi();
			if (text2 != null)
			{
				object obj = Utilities.ReadCommand(text2, "--query-gpu=index,clocks.max.graphics,clocks.max.memory --format=csv,noheader,nounits");
				int num = 0;
				if (obj == null)
				{
					obj = "";
				}
				string[] array = ((string)obj).Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
				for (int i = 0; i < array.Length; i++)
				{
					string[] array2 = (from x in array[i].Split(',')
						select x.Trim()).ToArray();
					if (array2.Length < 3 || !int.TryParse(array2[0], out var result))
					{
						continue;
					}
					if (on)
					{
						if (int.TryParse(array2[1], out var result2) && result2 > 0 && Utilities.Run(text2, "-i " + result + " -lgc " + result2 + "," + result2).Success)
						{
							num++;
						}
						if (int.TryParse(array2[2], out var result3) && result3 > 0)
						{
							Utilities.Run(text2, "-i " + result + " -lmc " + result3 + "," + result3);
						}
					}
					else
					{
						if (Utilities.Run(text2, "-i " + result + " -rgc").Success)
						{
							num++;
						}
						Utilities.Run(text2, "-i " + result + " -rmc");
					}
				}
				text = ((num > 0) ? " Active now; no restart needed." : " The driver did not accept a live clock lock; restart Windows to activate.");
			}
			else
			{
				text = " nvidia-smi is missing; restart Windows to activate.";
			}
			if (State().State != (on ? "Enabled" : "Disabled"))
			{
				throw new IOException("Read-back did not confirm the P0 setting.");
			}
			return new ActionResult
			{
				Success = true,
				Message = (on ? "P0 maximum performance locked on every NVIDIA GPU." : "Dynamic P-states restored (Windows/NVIDIA default).") + text
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
