using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class SilentTweaks
{
	public static List<string> Apply()
	{
		List<string> list = new List<string>();
		string text;
		try
		{
			using Stream stream = typeof(SilentTweaks).Assembly.GetManifestResourceStream("Aziz.silent.reg");
			using StreamReader streamReader = new StreamReader(stream);
			text = streamReader.ReadToEnd();
		}
		catch
		{
			return list;
		}
		string text2 = null;
		string[] array = text.Replace("\r", "").Split('\n');
		for (int i = 0; i < array.Length; i++)
		{
			string input = array[i].Trim();
			Match match = Regex.Match(input, "^\\[(HKEY_LOCAL_MACHINE|HKEY_CURRENT_USER)\\\\(.+)\\]$");
			if (match.Success)
			{
				text2 = match.Groups[1].Value + "|" + match.Groups[2].Value;
			}
			else
			{
				if (text2 == null)
				{
					continue;
				}
				Match match2 = Regex.Match(input, "^\"([^\"]+)\"=(?:dword:([0-9a-fA-F]{8})|\"([^\"]*)\")$");
				if (!match2.Success)
				{
					continue;
				}
				string[] array2 = text2.Split(new char[1] { '|' }, 2);
				RegistryKey registryKey = ((array2[0] == "HKEY_LOCAL_MACHINE") ? Registry.LocalMachine : Registry.CurrentUser);
				object obj2 = (match2.Groups[2].Success ? ((object)(int)uint.Parse(match2.Groups[2].Value, NumberStyles.HexNumber)) : match2.Groups[3].Value);
				RegistryValueKind valueKind = ((!match2.Groups[2].Success) ? RegistryValueKind.String : RegistryValueKind.DWord);
				foreach (string item in Targets(registryKey, array2[1]))
				{
					try
					{
						RegistryJournal.Remember((array2[0] == "HKEY_LOCAL_MACHINE") ? "HKLM" : "HKCU", item, match2.Groups[1].Value);
						using RegistryKey registryKey2 = registryKey.CreateSubKey(item);
						registryKey2.SetValue(match2.Groups[1].Value, obj2, valueKind);
						list.Add(((array2[0] == "HKEY_LOCAL_MACHINE") ? "HKLM\\" : "HKCU\\") + item + " · " + match2.Groups[1].Value + " = " + Convert.ToString(obj2));
					}
					catch
					{
					}
				}
			}
		}
		RegistryJournal.Save();
		return list;
	}

	private static IEnumerable<string> Targets(RegistryKey hive, string path)
	{
		if (!path.EndsWith("\\*"))
		{
			return new string[1] { path };
		}
		string text = path.Substring(0, path.Length - 2);
		List<string> list = new List<string>();
		try
		{
			using RegistryKey registryKey = hive.OpenSubKey(text);
			if (registryKey != null)
			{
				string[] subKeyNames = registryKey.GetSubKeyNames();
				foreach (string text2 in subKeyNames)
				{
					list.Add(text + "\\" + text2);
				}
			}
		}
		catch
		{
		}
		return list;
	}
}
