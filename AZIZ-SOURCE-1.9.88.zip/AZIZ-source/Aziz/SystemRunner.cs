using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Aziz;

internal static class SystemRunner
{
	private static readonly object Gate = new object();

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
	private static extern int RegCreateKeyEx(UIntPtr key, string sub, int reserved, string cls, int options, int sam, IntPtr security, out UIntPtr result, out int disposition);

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
	private static extern int RegSetValueEx(UIntPtr key, string name, int reserved, int type, byte[] data, int size);

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode)]
	private static extern int RegDeleteValue(UIntPtr key, string name);

	[DllImport("advapi32.dll")]
	private static extern int RegCloseKey(UIntPtr key);

	public static bool BackupWrite(RegistryOperation op)
	{
		if (!string.IsNullOrEmpty(op.Token) || op.Kind == "PageVisibility" || op.Kind == "StickyFlags")
		{
			return false;
		}
		try
		{
			GameNative.PrivilegeOn("SeRestorePrivilege");
			GameNative.PrivilegeOn("SeBackupPrivilege");
		}
		catch
		{
			return false;
		}
		if (RegCreateKeyEx(new UIntPtr((op.Hive == "HKCU") ? 2147483649u : 2147483650u), op.Path, 0, null, 4, 983359, IntPtr.Zero, out var result, out var _) != 0)
		{
			return false;
		}
		try
		{
			if (op.Value == null)
			{
				int num = RegDeleteValue(result, op.Name);
				return num == 0 || num == 2;
			}
			int type;
			byte[] array;
			switch (op.Kind)
			{
			case "DWord":
				type = 4;
				array = BitConverter.GetBytes((int)Convert.ToInt64(op.Value));
				break;
			case "QWord":
				type = 11;
				array = BitConverter.GetBytes(Convert.ToInt64(op.Value));
				break;
			case "String":
				type = 1;
				array = Encoding.Unicode.GetBytes(Convert.ToString(op.Value, CultureInfo.InvariantCulture) + "\0");
				break;
			case "ExpandString":
				type = 2;
				array = Encoding.Unicode.GetBytes(Convert.ToString(op.Value, CultureInfo.InvariantCulture) + "\0");
				break;
			case "Binary":
				type = 3;
				array = ((IEnumerable)op.Value).Cast<object>().Select(Convert.ToByte).ToArray();
				break;
			case "MultiString":
				type = 7;
				array = Encoding.Unicode.GetBytes(string.Join("\0", ((IEnumerable)op.Value).Cast<object>().Select(Convert.ToString)) + "\0\0");
				break;
			default:
				return false;
			}
			return RegSetValueEx(result, op.Name, 0, type, array, array.Length) == 0;
		}
		finally
		{
			RegCloseKey(result);
		}
	}

	private static string Q(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	public static void Run(string script, int seconds = 60)
	{
		lock (Gate)
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AZIZ Game Agent");
			Directory.CreateDirectory(text);
			string text2 = Guid.NewGuid().ToString("N");
			string text3 = Path.Combine(text, "system-" + text2 + ".ps1");
			string text4 = text3 + ".done";
			string text5 = "AZIZ System " + text2;
			File.WriteAllText(text3, "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';try{" + script + "\n;'OK'|Set-Content -LiteralPath " + Q(text4) + "}catch{('ERR '+$_.Exception.Message)|Set-Content -LiteralPath " + Q(text4) + "}", new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
			try
			{
				ActionResult actionResult = Utilities.Run("powershell.exe", GameWatch.PsArgs("$a=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument " + Q("-NoProfile -NonInteractive -ExecutionPolicy Bypass -File \"" + text3 + "\"") + ";$s=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -Hidden;Register-ScheduledTask -TaskName " + Q(text5) + " -Action $a -Settings $s -User 'NT AUTHORITY\\SYSTEM' -RunLevel Highest -Force|Out-Null;Start-ScheduledTask -TaskName " + Q(text5)));
				if (!actionResult.Success)
				{
					throw new IOException(actionResult.Message);
				}
				for (int i = 0; i < seconds * 4; i++)
				{
					if (File.Exists(text4))
					{
						break;
					}
					Thread.Sleep(250);
				}
				Thread.Sleep(100);
				if (!File.Exists(text4))
				{
					throw new TimeoutException("The SYSTEM helper did not finish.");
				}
				string text6 = File.ReadAllText(text4).Trim();
				if (text6.StartsWith("ERR"))
				{
					throw new IOException(text6.Substring(3).Trim());
				}
			}
			finally
			{
				Utilities.Run("schtasks.exe", "/Delete /TN \"" + text5 + "\" /F");
				try
				{
					File.Delete(text3);
				}
				catch
				{
				}
				try
				{
					File.Delete(text4);
				}
				catch
				{
				}
			}
		}
	}

	public static bool WriteRegistry(RegistryOperation op)
	{
		if (op.Hive != "HKLM" || !string.IsNullOrEmpty(op.Token))
		{
			return false;
		}
		string text = Q("Registry::HKEY_LOCAL_MACHINE\\" + op.Path);
		string script;
		if (op.Value == null)
		{
			script = "Remove-ItemProperty -LiteralPath " + text + " -Name " + Q(op.Name) + " -ErrorAction SilentlyContinue";
		}
		else
		{
			string text2;
			switch (op.Kind)
			{
			case "DWord":
				text2 = "([BitConverter]::ToInt32([BitConverter]::GetBytes([uint32]" + ((uint)Convert.ToInt64(op.Value)).ToString(CultureInfo.InvariantCulture) + "),0))";
				break;
			case "QWord":
				text2 = "([int64]" + Convert.ToInt64(op.Value).ToString(CultureInfo.InvariantCulture) + ")";
				break;
			case "String":
			case "ExpandString":
				text2 = Q(Convert.ToString(op.Value, CultureInfo.InvariantCulture));
				break;
			default:
				return false;
			}
			script = "if(!(Test-Path -LiteralPath " + text + ")){New-Item -Path " + text + " -Force|Out-Null};New-ItemProperty -LiteralPath " + text + " -Name " + Q(op.Name) + " -Value " + text2 + " -PropertyType " + op.Kind + " -Force|Out-Null";
		}
		Run(script);
		return true;
	}
}
