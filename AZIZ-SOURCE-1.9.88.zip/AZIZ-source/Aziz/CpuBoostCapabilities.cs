using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace Aziz;

internal static class CpuBoostCapabilities
{
	[UnmanagedFunctionPointer(CallingConvention.Winapi)]
	private delegate void Cpuid(uint leaf, uint subleaf, IntPtr output);

	private static readonly Lazy<bool> Efficient = new Lazy<bool>(ReadEpb);

	public static bool EfficientSupported => Efficient.Value;

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr VirtualAlloc(IntPtr address, UIntPtr size, uint allocation, uint protection);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool VirtualProtect(IntPtr address, UIntPtr size, uint protection, out uint previous);

	[DllImport("kernel32.dll")]
	private static extern bool VirtualFree(IntPtr address, UIntPtr size, uint freeType);

	[DllImport("kernel32.dll")]
	private static extern bool FlushInstructionCache(IntPtr process, IntPtr address, UIntPtr size);

	[DllImport("kernel32.dll")]
	private static extern IntPtr GetCurrentProcess();

	private static bool ReadEpb()
	{
		if (IntPtr.Size != 8)
		{
			return false;
		}
		IntPtr intPtr = IntPtr.Zero;
		IntPtr intPtr2 = IntPtr.Zero;
		try
		{
			byte[] array = new byte[24]
			{
				83, 139, 193, 139, 202, 15, 162, 65, 137, 0,
				65, 137, 88, 4, 65, 137, 72, 8, 65, 137,
				80, 12, 91, 195
			};
			intPtr = VirtualAlloc(IntPtr.Zero, new UIntPtr((uint)array.Length), 12288u, 4u);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			Marshal.Copy(array, 0, intPtr, array.Length);
			if (!VirtualProtect(intPtr, new UIntPtr((uint)array.Length), 32u, out var _) || !FlushInstructionCache(GetCurrentProcess(), intPtr, new UIntPtr((uint)array.Length)))
			{
				return false;
			}
			Cpuid cpuid = (Cpuid)Marshal.GetDelegateForFunctionPointer(intPtr, typeof(Cpuid));
			intPtr2 = Marshal.AllocHGlobal(16);
			cpuid(0u, 0u, intPtr2);
			byte[] array2 = new byte[16];
			Marshal.Copy(intPtr2, array2, 0, 16);
			if (Encoding.ASCII.GetString(array2, 4, 4) + Encoding.ASCII.GetString(array2, 12, 4) + Encoding.ASCII.GetString(array2, 8, 4) != "GenuineIntel" || BitConverter.ToUInt32(array2, 0) < 6)
			{
				return false;
			}
			cpuid(6u, 0u, intPtr2);
			return (Marshal.ReadInt32(intPtr2, 8) & 8) != 0;
		}
		catch
		{
			return false;
		}
		finally
		{
			if (intPtr2 != IntPtr.Zero)
			{
				Marshal.FreeHGlobal(intPtr2);
			}
			if (intPtr != IntPtr.Zero)
			{
				VirtualFree(intPtr, UIntPtr.Zero, 32768u);
			}
		}
	}

	internal static uint[] Filter(uint[] possible, bool efficient)
	{
		return (from v in possible.Where((uint v) => v <= 6 && (efficient || (v != 3 && v != 4 && v != 6))).Distinct()
			orderby v
			select v).ToArray();
	}

	public static uint[] Modes()
	{
		return Filter(WindowsPowerControlStore.Possible(PowerControls.Parameter("cpu-boost-mode")), EfficientSupported);
	}
}
