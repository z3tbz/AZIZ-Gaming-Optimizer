using System;
using System.Collections.Generic;

namespace Aziz;

internal class PowerSnapshot
{
	public Guid Scheme { get; set; }

	public List<PowerValue> Values { get; set; }
}
