using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace Aziz;

internal static class OlderGameCompatibility
{
	public const string Layers = "Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers";

	public static string Read(string exe)
	{
		using RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers");
		return (registryKey == null) ? null : Convert.ToString(registryKey.GetValue(exe, null));
	}

	public static string Value(string original, bool disable)
	{
		List<string> list = (from x in (original ?? "").Split(new char[1] { ' ' }, StringSplitOptions.RemoveEmptyEntries)
			where x != "~" && !x.Equals("DISABLEDXMAXIMIZEDWINDOWEDMODE", StringComparison.OrdinalIgnoreCase)
			select x).ToList();
		if (disable)
		{
			list.Add("DISABLEDXMAXIMIZEDWINDOWEDMODE");
		}
		if (list.Count != 0)
		{
			return "~ " + string.Join(" ", list);
		}
		return null;
	}

	public static Tweak Profile(string exe, bool disabled)
	{
		exe = Path.GetFullPath(exe);
		if (!AppLauncher.ValidExe(exe))
		{
			throw new IOException("Choose an existing local game executable.");
		}
		string id;
		using (SHA256 sHA = SHA256.Create())
		{
			id = "old-game-fso-" + BitConverter.ToString(sHA.ComputeHash(Encoding.UTF8.GetBytes(exe.ToUpperInvariant()))).Replace("-", "").Substring(0, 20);
		}
		List<RegistryOperation> list = new List<RegistryOperation>
		{
			new RegistryOperation
			{
				Hive = "HKCU",
				Path = "Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers",
				Name = exe,
				Kind = "String",
				Value = Value(Read(exe), disabled)
			}
		};
		return new Tweak
		{
			Id = id,
			Name = "Older game fullscreen optimization · " + Path.GetFileName(exe),
			Kind = "Registry",
			Enable = list,
			Disable = list
		};
	}
}
