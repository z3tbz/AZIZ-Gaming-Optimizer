namespace Aziz;

public class TweakChoice
{
	public string Value { get; set; }

	public string Label { get; set; }

	public override string ToString()
	{
		return Label;
	}
}
