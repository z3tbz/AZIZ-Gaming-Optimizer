using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Aziz;

internal static class BaselineStore
{
	private static Dictionary<string, DefaultReference> reference;

	private static Dictionary<string, TweakStatus> deployment;

	private static string FileName => Path.Combine(Program.Data, "playbook-baseline.json");

	private static void Load()
	{
		if (reference == null)
		{
			try
			{
				reference = Program.Json.Deserialize<Dictionary<string, DefaultReference>>(File.ReadAllText(Path.Combine(Program.Root, "baseline-reference.json")));
			}
			catch
			{
				reference = new Dictionary<string, DefaultReference>();
			}
		}
		if (deployment == null)
		{
			try
			{
				deployment = Program.Json.Deserialize<Dictionary<string, TweakStatus>>(File.ReadAllText(FileName));
			}
			catch
			{
				deployment = new Dictionary<string, TweakStatus>();
			}
		}
	}

	public static void UpdateDeployment(bool capture, Dictionary<string, TweakStatus> states)
	{
		Load();
		if (capture)
		{
			Utilities.AtomicWrite(FileName, Program.Json.Serialize(states));
			deployment = new Dictionary<string, TweakStatus>(states);
		}
	}

	public static string WindowsDefault(string id)
	{
		Load();
		if (!reference.TryGetValue(id, out var value))
		{
			return "Varies by Windows build, hardware and setup.";
		}
		return value.Windows;
	}

	public static string PlaybookDefault(string id)
	{
		Load();
		if (deployment.TryGetValue(id, out var value))
		{
			return Friendly(value) + " · recorded at AZIZ playbook completion";
		}
		if (!reference.TryGetValue(id, out var value2))
		{
			return "No deployment snapshot recorded on this account.";
		}
		return value2.Playbook + " · package default options";
	}

	public static string Friendly(TweakStatus s)
	{
		if (!(s.State == "Enabled"))
		{
			if (!(s.State == "Disabled"))
			{
				return "Needs a specific configuration · " + s.Detail;
			}
			return "Disabled" + (string.IsNullOrWhiteSpace(s.Detail) ? "" : (" · " + s.Detail));
		}
		return "Enabled" + (string.IsNullOrWhiteSpace(s.Detail) ? "" : (" · " + s.Detail));
	}

	public static List<string> Changes(List<Tweak> controls, Dictionary<string, TweakStatus> states)
	{
		Load();
		List<string> list = new List<string>();
		foreach (Tweak item in controls.Where((Tweak x) => x.Kind != "Unavailable"))
		{
			if (states.TryGetValue(item.Id, out var value))
			{
				string text = WindowsDefault(item.Id);
				if ((deployment.TryGetValue(item.Id, out var value2) && (value2.State != value.State || value2.Detail != value.Detail)) || ((text == "Enabled" || text == "Disabled") && value.State != text && (value.State == "Enabled" || value.State == "Disabled")))
				{
					list.Add(item.Name + "\nCurrent: " + Friendly(value) + "\nWindows: " + text + "\nAZIZ: " + PlaybookDefault(item.Id));
				}
			}
		}
		return list;
	}
}
