namespace Aziz;

internal sealed class DriverOption
{
	public string Name;

	public string Id;

	public string Parent;

	public override string ToString()
	{
		return Name;
	}
}
