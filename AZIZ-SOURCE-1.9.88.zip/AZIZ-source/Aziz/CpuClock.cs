using System;
using System.Diagnostics;
using Microsoft.Win32;

namespace Aziz;

internal static class CpuClock
{
	private static PerformanceCounter counter;

	private static double baseMhz;

	private static bool failed;

	public static double? ReadMhz()
	{
		if (failed)
		{
			return null;
		}
		try
		{
			if (counter == null)
			{
				using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0"))
				{
					baseMhz = Convert.ToDouble(registryKey?.GetValue("~MHz") ?? ((object)0));
				}
				counter = new PerformanceCounter("Processor Information", "% Processor Performance", "_Total", readOnly: true);
				counter.NextValue();
				return null;
			}
			double num = counter.NextValue();
			if (baseMhz <= 0.0 || num <= 0.0)
			{
				return null;
			}
			return baseMhz * num / 100.0;
		}
		catch
		{
			failed = true;
			return null;
		}
	}
}
