using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml;

namespace Aziz;

internal static class NvidiaProfilePreset
{
	public static string FileName => Path.Combine(Program.Root, "Profiles", "AZIZ_Ultra-Low-Latency.nip");

	private static string Marker => Path.Combine(Program.Data, "NvidiaProfiles", "imported.json");

	public static bool Imported => File.Exists(Marker);

	internal static bool FitsThisPc(string value, IEnumerable<string> instances)
	{
		Match match = Regex.Match(value ?? "", "id,2\\.0:([0-9A-Fa-f]{4})([0-9A-Fa-f]{4})");
		if (!match.Success)
		{
			return true;
		}
		string tag = "VEN_" + match.Groups[2].Value.ToUpperInvariant() + "&DEV_" + match.Groups[1].Value.ToUpperInvariant();
		return instances.Any((string x) => x.ToUpperInvariant().Contains(tag));
	}

	internal static Dictionary<uint, byte[]> Read(string file, IEnumerable<string> instances, List<string> skipped)
	{
		return Read(file, instances, skipped, null);
	}

	internal static Dictionary<uint, byte[]> Read(string file, IEnumerable<string> instances, List<string> skipped, Dictionary<uint, string> names)
	{
		XmlDocument xmlDocument = new XmlDocument
		{
			XmlResolver = null
		};
		using (XmlReader reader = XmlReader.Create(new StringReader(Regex.Replace(File.ReadAllText(file), "^\\s*<\\?xml[^>]*\\?>", "")), new XmlReaderSettings
		{
			DtdProcessing = DtdProcessing.Prohibit,
			XmlResolver = null,
			MaxCharactersInDocument = 1048576L
		}))
		{
			xmlDocument.Load(reader);
		}
		Dictionary<uint, byte[]> dictionary = new Dictionary<uint, byte[]>();
		foreach (XmlNode item in xmlDocument.SelectNodes("/ArrayOfProfile/Profile"))
		{
			if (item["ProfileName"].InnerText != "Base Profile")
			{
				throw new IOException("Expected the supplied global NVIDIA profile.");
			}
			foreach (XmlNode item2 in item.SelectNodes("Settings/ProfileSetting"))
			{
				uint num = uint.Parse(item2["SettingID"].InnerText);
				string innerText = item2["SettingValue"].InnerText;
				string innerText2 = item2["ValueType"].InnerText;
				if (dictionary.ContainsKey(num))
				{
					throw new IOException("Duplicate profile setting.");
				}
				if (names != null)
				{
					names[num] = ((item2["SettingNameInfo"].InnerText.Trim().Length > 0) ? item2["SettingNameInfo"].InnerText.Trim() : ("0x" + num.ToString("X8")));
				}
				if (innerText2 == "String" && !FitsThisPc(innerText, instances))
				{
					skipped?.Add(item2["SettingNameInfo"].InnerText);
					continue;
				}
				dictionary[num] = ((innerText2 == "Dword") ? NvidiaProfileSession.Dword(num, uint.Parse(innerText)) : ((innerText2 == "String") ? NvidiaProfileSession.String(num, innerText) : null));
				if (dictionary[num] == null)
				{
					throw new IOException("Unsupported profile value type.");
				}
			}
		}
		if (dictionary.Count == 0)
		{
			throw new IOException("The profile contains no settings.");
		}
		return dictionary;
	}

	public static string FileNameLow => Path.Combine(Program.Root, "Profiles", "AZIZ_Low-Latency.nip");

	// Low Latency uses its own file when it is there; Ultra (and the Profile page) use the main one.
	public static string Import(bool low)
	{
		return Import(low && File.Exists(FileNameLow) ? FileNameLow : FileName);
	}

	public static string Import()
	{
		return Import(FileName);
	}

	public static string Import(string file)
	{
		List<string> list = new List<string>();
		Dictionary<uint, string> dictionary = new Dictionary<uint, string>();
		Dictionary<uint, byte[]> dictionary2 = Read(file, from x in DisplayHardware.PciDisplays()
			select x.Instance, list, dictionary);
		List<string> list2 = new List<string>();
		Dictionary<uint, byte[]> dictionary3 = new Dictionary<uint, byte[]>();
		using (NvidiaProfileSession nvidiaProfileSession = new NvidiaProfileSession())
		{
			foreach (KeyValuePair<uint, byte[]> item in dictionary2)
			{
				dictionary3[item.Key] = nvidiaProfileSession.Read(item.Key);
			}
			Utilities.AtomicWrite(Path.Combine(Program.Data, "NvidiaProfiles", "before-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".json"), Program.Json.Serialize(dictionary3.ToDictionary((KeyValuePair<uint, byte[]> x) => x.Key.ToString(), (KeyValuePair<uint, byte[]> x) => x.Value)));
			try
			{
				foreach (uint item2 in dictionary2.Keys.ToList())
				{
					if (!nvidiaProfileSession.TryWrite(dictionary2[item2]))
					{
						list2.Add(dictionary[item2]);
						dictionary2.Remove(item2);
					}
				}
				if (dictionary2.Count == 0)
				{
					throw new IOException("This NVIDIA driver supports none of the profile settings.");
				}
				nvidiaProfileSession.Save();
				using (NvidiaProfileSession nvidiaProfileSession2 = new NvidiaProfileSession())
				{
					foreach (KeyValuePair<uint, byte[]> item3 in dictionary2)
					{
						if (!NvidiaProfileSession.EqualValue(nvidiaProfileSession2.Read(item3.Key), item3.Value))
						{
							throw new IOException("NVIDIA profile read-back differs for " + item3.Key);
						}
					}
				}
				Utilities.AtomicWrite(Marker, Program.Json.Serialize(new
				{
					Hash = Utilities.Sha256File(FileName),
					Imported = DateTime.UtcNow
				}));
			}
			catch
			{
				foreach (KeyValuePair<uint, byte[]> item4 in dictionary3)
				{
					nvidiaProfileSession.Restore(item4.Key, item4.Value);
				}
				nvidiaProfileSession.Save();
				throw;
			}
		}
		return dictionary2.Count + " settings applied to the global profile" + ((list.Count > 0) ? (" · skipped for a different GPU: " + string.Join(", ", list)) : "") + ((list2.Count > 0) ? (" · not in this NVIDIA driver: " + string.Join(", ", list2)) : "");
	}

	public static string EnsureGameProfile(string title, string exePath)
	{
		string exe = Path.GetFileName(exePath).ToLowerInvariant();
		using NvidiaProfileSession nvidiaProfileSession = new NvidiaProfileSession();
		string text = nvidiaProfileSession.ProfileFor(exe);
		if (text != null)
		{
			return text;
		}
		string result = nvidiaProfileSession.CreateFor(title, exe);
		nvidiaProfileSession.Save();
		return result;
	}
}
