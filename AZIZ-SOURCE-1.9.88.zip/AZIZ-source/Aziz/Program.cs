using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace Aziz;

internal static class Program
{
	public static string Root = AppDomain.CurrentDomain.BaseDirectory;

	public static string Data = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AZIZ", "GamingOptimizer");

	// The running AZIZ exe (on .NET 10 the assembly is a .dll beside its exe host).
#if NET
	public static string ExePath => Environment.ProcessPath;
#else
	public static string ExePath => System.Reflection.Assembly.GetExecutingAssembly().Location;
#endif

	public static JavaScriptSerializer Json => new JavaScriptSerializer
	{
		MaxJsonLength = 16000000
	};

	// --tray: started with Windows, stays in the tray. --uninstall: from Windows Settings ▸ Apps.
	public static bool TrayStart;

	public static bool UninstallRequested;

	// Held for the whole life of the app (a local would be collected and the single-instance lock lost).
	private static Mutex single;

	public static bool IsAdmin => new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);

	// Faster starts: once per build, ask the .NET native image service to precompile AZIZ at idle priority
	// (ngen /queue), so later starts skip most JIT work. Nothing runs if it is already queued for this build.
	private static void QueueNativeImage()
	{
		try
		{
			if (!IsAdmin)
			{
				return;
			}
			string location = Program.ExePath;
			string marker = Path.Combine(Data, "ngen-" + File.GetLastWriteTimeUtc(location).Ticks + ".done");
			if (File.Exists(marker))
			{
				return;
			}
			string ngen = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Microsoft.NET", Environment.Is64BitProcess ? "Framework64" : "Framework", "v4.0.30319", "ngen.exe");
			if (!File.Exists(ngen))
			{
				return;
			}
			System.Threading.Tasks.Task.Run(delegate
			{
				try
				{
					using (System.Diagnostics.Process process = System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(ngen, "install \"" + location + "\" /queue:3 /nologo")
					{
						UseShellExecute = false,
						CreateNoWindow = true
					}))
					{
						process.PriorityClass = System.Diagnostics.ProcessPriorityClass.Idle;
						process.WaitForExit(60000);
					}
					Directory.CreateDirectory(Data);
					foreach (string text in Directory.GetFiles(Data, "ngen-*.done"))
					{
						File.Delete(text);
					}
					File.WriteAllText(marker, DateTime.UtcNow.ToString("o"));
				}
				catch
				{
				}
			});
		}
		catch
		{
		}
	}

	[STAThread]
	public static int Main(string[] args)
	{
		try
		{
			TrayStart = args.Contains("--tray");
			UninstallRequested = args.Contains("--uninstall");
			if (args.Contains("--game-watch"))
			{
				return GameWatch.Run();
			}
			if (args.Length > 1 && args[0] == "--game-session")
			{
				return GameWatch.Session(args[1]);
			}
			if (args.Contains("--reflex-tray"))
			{
				return ReflexTray.Run();
			}
			if (args.Contains("--memory-clean"))
			{
				return MemoryCleaner.Run();
			}
			if (args.Contains("--timer-resolution"))
			{
				return TimerService.Run();
			}
			if (args.Length > 1 && args[0] == "--selftest")
			{
				return IsAdmin ? SelfTest.Run(args[1]) : 5;
			}
			if (args.Length > 1 && args[0] == "--selftest-toggle")
			{
				return IsAdmin ? SelfTest.Toggle(args[1]) : 5;
			}
			if (args.Length > 1 && args[0] == "--bench")
			{
				return SelfTest.Bench(args[1]);
			}
			if (args.Contains("--playbook-apply"))
			{
				return IsAdmin ? PlaybookApply.Run() : 5;
			}
			if (!IsAdmin && !args.Contains("--preview") && !args.Contains("--diagnostics") && !args.Contains("--read-only"))
			{
				try
				{
					Process.Start(new ProcessStartInfo(Program.ExePath, string.Join(" ", new string[3] { "--from-playbook", "--tray", "--uninstall" }.Where(args.Contains)))
					{
						Verb = "runas",
						UseShellExecute = true
					});
					return 0;
				}
				catch (Win32Exception ex)
				{
					if (ex.NativeErrorCode != 1223)
					{
						throw;
					}
				}
			}
			if (args.Contains("--diagnostics"))
			{
				string path = ((args.Length > 1) ? args[1] : Path.Combine(Root, "diagnostics.json"));
				using (Telemetry telemetry = new Telemetry(sensors: false))
				{
					Engine engine = new Engine();
					MachineInfo machine = telemetry.Inspect();
					telemetry.Read();
					Thread.Sleep(1200);
					File.WriteAllText(path, Json.Serialize(new
					{
						version = "1.9.7",
						machine = machine,
						sample = telemetry.Read(),
						tweaks = engine.Tweaks,
						states = engine.Scan(),
						administrator = IsAdmin,
						mode = "Read-only. No tweak applied. Sensor driver disabled."
					}), Encoding.UTF8);
				}
				return 0;
			}
			// One AZIZ per user: a second start (shortcut while AZIZ sits in the tray) just brings the running one forward.
			bool first = true;
			EventWaitHandle bringForward = null;
			EventWaitHandle uninstall = null;
			if (!args.Contains("--preview") && !args.Contains("--diagnostics"))
			{
				string sid = WindowsIdentity.GetCurrent().User.Value;
				single = new Mutex(initiallyOwned: true, "Local\\AZIZ-Main-" + sid, out first);
				bringForward = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Local\\AZIZ-Show-" + sid);
				uninstall = new EventWaitHandle(initialState: false, EventResetMode.AutoReset, "Local\\AZIZ-Uninstall-" + sid);
				if (!first)
				{
					if (UninstallRequested)
					{
						uninstall.Set();
					}
					else if (!TrayStart)
					{
						bringForward.Set();
					}
					return 0;
				}
			}
			Application app = new Application();
			app.ShutdownMode = ShutdownMode.OnMainWindowClose;
			app.DispatcherUnhandledException += delegate(object s, DispatcherUnhandledExceptionEventArgs e)
			{
				MainWindow.Say(e.Exception.Message, "AZIZ — operation failed");
				e.Handled = true;
			};
			bool flag = args.Contains("--preview");
			MainWindow window = new MainWindow(flag, args.Contains("--read-sensors"), flag && args.Contains("--sunset"));
			if (bringForward != null)
			{
				ThreadPool.RegisterWaitForSingleObject(bringForward, delegate
				{
					window.Dispatcher.BeginInvoke((Action)window.BringForward);
				}, null, -1, executeOnlyOnce: false);
				ThreadPool.RegisterWaitForSingleObject(uninstall, delegate
				{
					window.Dispatcher.BeginInvoke((Action)window.RequestUninstall);
				}, null, -1, executeOnlyOnce: false);
			}
			if (flag)
			{
				string target = ((args.Length > 1) ? args[1] : Path.Combine(Root, "preview.png"));
				window.Width = 1360.0;
				window.Height = 900.0;
				window.WindowStartupLocation = WindowStartupLocation.Manual;
				window.ShowActivated = false;
				window.ShowInTaskbar = false;
				window.Left = -20000.0;
				window.Top = -20000.0;
				window.Loaded += async delegate
				{
					Stopwatch ready = Stopwatch.StartNew();
					await window.InitializeAsync();
					// --preview <folder\x.png> all: one start, every page saved beside x.png (lab screenshots in one run).
					if (args.Length > 2 && args[2] == "all")
					{
						string folder = Path.GetDirectoryName(Path.GetFullPath(target));
						File.WriteAllText(Path.Combine(folder, "preview-startup.txt"), "process start → interface ready: " + Math.Round((DateTime.Now - Process.GetCurrentProcess().StartTime).TotalSeconds, 1) + " s (initialize " + Math.Round(ready.Elapsed.TotalSeconds, 1) + " s) · " + System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription);
						foreach (string page in new string[13] { "Home", "Toggles", "Tweaks", "Network", "Power plans", "Services", "Security", "Tools", "Downloads", "Uninstaller", "History", "Settings", "About" })
						{
							window.Go(page);
							await Task.Delay(1500);
							window.UpdateLayout();
							FrameworkElement element = (FrameworkElement)window.Content;
							RenderTargetBitmap bitmap = new RenderTargetBitmap((int)element.ActualWidth, (int)element.ActualHeight, 96.0, 96.0, PixelFormats.Pbgra32);
							bitmap.Render(element);
							PngBitmapEncoder encoder = new PngBitmapEncoder
							{
								Frames = { BitmapFrame.Create(bitmap) }
							};
							using (FileStream stream2 = File.Create(Path.Combine(folder, "page-" + page.Replace(" ", "") + ".png")))
							{
								encoder.Save(stream2);
							}
						}
						window.Close();
						return;
					}
					await Task.Delay(4200);
					if (args.Length > 2 && !args[2].StartsWith("--"))
					{
						window.Go(args[2]);
					}
					if (args.Contains("--competitive"))
					{
						window.PreviewCompetitive();
					}
					await Task.Delay(3000);
					window.UpdateLayout();
					FrameworkElement frameworkElement = (FrameworkElement)window.Content;
					RenderTargetBitmap renderTargetBitmap = new RenderTargetBitmap((int)frameworkElement.ActualWidth, (int)frameworkElement.ActualHeight, 96.0, 96.0, PixelFormats.Pbgra32);
					renderTargetBitmap.Render(frameworkElement);
					PngBitmapEncoder pngBitmapEncoder = new PngBitmapEncoder
					{
						Frames = { BitmapFrame.Create(renderTargetBitmap) }
					};
					using (FileStream stream = File.Create(target))
					{
						pngBitmapEncoder.Save(stream);
					}
					window.Close();
				};
			}
			if (!flag)
			{
				app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
				StartupWindow splash = new StartupWindow();
				if (TrayStart)
				{
					splash.Opacity = 0.0;
					splash.ShowInTaskbar = false;
				}
				splash.Loaded += async delegate
				{
					try
					{
						using (new StartupBoost())
						{
							await window.InitializeAsync(splash.Report);
						}
						if (splash.Cancelled)
						{
							app.Shutdown();
						}
						else
						{
							app.MainWindow = window;
							app.ShutdownMode = ShutdownMode.OnMainWindowClose;
							splash.Close();
							if (TrayStart)
							{
								window.StartInTray();
							}
							else
							{
								window.Show();
							}
							window.AfterStartup(args.Contains("--from-playbook"));
							if (UninstallRequested)
							{
								window.RequestUninstall();
							}
							QueueNativeImage();
						}
					}
					catch (Exception ex3)
					{
						MessageBox.Show(ex3.Message, "AZIZ startup");
						app.Shutdown();
					}
				};
				app.Run(splash);
			}
			else
			{
				app.Run(window);
			}
			return 0;
		}
		catch (Exception ex2)
		{
			try
			{
				Directory.CreateDirectory(Data);
				File.WriteAllText(Path.Combine(Data, "last-error.txt"), ex2.ToString());
			}
			catch
			{
			}
			// Background helpers have nobody to answer a dialog (the timer service runs in session 0, where it would hang
			// unseen): they only leave last-error.txt.
			if (!args.Contains("--diagnostics") && !args.Contains("--preview") && !new string[9] { "--game-watch", "--game-session", "--reflex-tray", "--memory-clean", "--timer-resolution", "--playbook-apply", "--selftest", "--selftest-toggle", "--bench" }.Any(args.Contains))
			{
				MessageBox.Show(ex2.Message, "AZIZ startup error");
			}
			return 1;
		}
	}
}
