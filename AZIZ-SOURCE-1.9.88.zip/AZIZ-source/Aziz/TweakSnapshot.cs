using System.Collections.Generic;

namespace Aziz;

public class TweakSnapshot
{
	public string Id { get; set; }

	public string CreatedUtc { get; set; }

	public List<SavedValue> Values { get; set; }

	public string Native { get; set; }

	public int ServiceStart { get; set; }

	public bool ServiceRunning { get; set; }

	public bool ServiceDelayed { get; set; }
}
