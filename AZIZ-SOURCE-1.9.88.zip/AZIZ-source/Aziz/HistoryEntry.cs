namespace Aziz;

public class HistoryEntry
{
	public string Time { get; set; }

	public string Name { get; set; }

	public string Action { get; set; }

	public string Before { get; set; }

	public string After { get; set; }

	public string Result { get; set; }

	public string Profile { get; set; }
}
