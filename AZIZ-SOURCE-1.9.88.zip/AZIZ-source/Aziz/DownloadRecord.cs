using System;

namespace Aziz;

internal class DownloadRecord
{
	public string Id { get; set; }

	public string FilePath { get; set; }

	public string Hash { get; set; }

	public long Bytes { get; set; }

	public DateTime FinishedUtc { get; set; }

	public string OpenPath { get; set; }

	public string OpenHash { get; set; }
}
