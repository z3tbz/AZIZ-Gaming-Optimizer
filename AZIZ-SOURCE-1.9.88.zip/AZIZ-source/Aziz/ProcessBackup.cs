namespace Aziz;

internal class ProcessBackup
{
	public int Pid { get; set; }

	public long Started { get; set; }

	public string Cpu { get; set; }

	public int? Gpu { get; set; }

	public int? Io { get; set; }

	public uint[] Sets { get; set; }
}
