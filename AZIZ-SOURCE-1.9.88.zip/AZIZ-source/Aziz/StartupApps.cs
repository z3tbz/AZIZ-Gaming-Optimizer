using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

// One Click: nothing starts with Windows except what a gaming PC needs from this list (Process Lasso, RivaTuner,
// MSI Afterburner, AZIZ) and Windows Security. Startup apps are switched off the way Task Manager does it
// (StartupApproved, nothing deleted); third-party services that start automatically become Manual. Everything is
// written to a journal, so Windows Default turns it all back on exactly as it was.
internal static class StartupApps
{
	private static readonly Regex Keep = new Regex("lasso|bitsum|processgovernor|rtss|rivatuner|afterburner|msi ?afterburner|aziz|securityhealth|windows ?defender|anti.?cheat|battleye|faceit|vanguard|vgtray|easyanticheat|antivirus|anti-malware|kaspersky|avast|avg|eset|bitdefender|norton|mcafee|malwarebytes|sophos|trend ?micro|webroot|f-secure|panda", RegexOptions.IgnoreCase);

	private const string Approved = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\StartupApproved\\";

	private static string JournalPath => Path.Combine(Program.Data, "startup-journal.json");

	// One run at a time (two One Clicks must not lose each other's entries).
	private static readonly object Gate = new object();

	public class Entry
	{
		public string Kind { get; set; }

		public string Hive { get; set; }

		public string Key { get; set; }

		public string Name { get; set; }

		public byte[] Before { get; set; }

		public int Start { get; set; }

		public bool Delayed { get; set; }
	}

	private static List<Entry> Load()
	{
		try
		{
			return (File.Exists(JournalPath) ? Program.Json.Deserialize<List<Entry>>(File.ReadAllText(JournalPath)) : null) ?? new List<Entry>();
		}
		catch
		{
			try
			{
				File.Move(JournalPath, JournalPath + ".bad-" + DateTime.Now.ToString("yyyyMMddHHmmss"));
			}
			catch
			{
			}
			return new List<Entry>();
		}
	}

	private static void Save(List<Entry> list)
	{
		Directory.CreateDirectory(Program.Data);
		Utilities.AtomicWrite(JournalPath, Program.Json.Serialize(list));
	}

	private static RegistryKey Root(string hive)
	{
		return (hive == "HKLM") ? Registry.LocalMachine : Registry.CurrentUser;
	}

	private static byte[] Disabled()
	{
		byte[] array = new byte[12];
		array[0] = 3;
		BitConverter.GetBytes(DateTime.UtcNow.ToFileTimeUtc()).CopyTo(array, 4);
		return array;
	}

	private static bool IsOff(object value)
	{
		return value is byte[] array && array.Length != 0 && (array[0] & 1) == 1;
	}

	// (hive, Run key, StartupApproved sub key) — 64-bit and 32-bit Run keys, both users.
	private static IEnumerable<Tuple<string, string, string>> RunKeys()
	{
		yield return Tuple.Create("HKCU", "Software\\Microsoft\\Windows\\CurrentVersion\\Run", "Run");
		yield return Tuple.Create("HKLM", "Software\\Microsoft\\Windows\\CurrentVersion\\Run", "Run");
		yield return Tuple.Create("HKLM", "Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Run", "Run32");
		yield return Tuple.Create("HKCU", "Software\\Microsoft\\Windows\\CurrentVersion\\Run32", "Run32");
	}

	public static List<string> DisableAll()
	{
		lock (Gate)
		{
			return DisableAllLocked();
		}
	}
	
	private static List<string> DisableAllLocked()
	{
		List<string> list = new List<string>();
		List<Entry> list2 = Load();
		Action<string, string, string, string> off = delegate(string hive, string sub, string name, string what)
		{
			if (Keep.IsMatch(name) || Keep.IsMatch(what ?? ""))
			{
				return;
			}
			using RegistryKey registryKey = Root(hive).CreateSubKey(Approved + sub);
			object value = registryKey.GetValue(name);
			if (IsOff(value))
			{
				return;
			}
			if (!list2.Any((Entry e) => e.Kind == "app" && e.Hive == hive && e.Key == sub && e.Name == name))
			{
				list2.Add(new Entry
				{
					Kind = "app",
					Hive = hive,
					Key = sub,
					Name = name,
					Before = (value as byte[])
				});
				// The way back is saved before anything changes (closing AZIZ mid-run must not lose it).
				Save(list2);
			}
			registryKey.SetValue(name, Disabled(), RegistryValueKind.Binary);
			list.Add(name + " · startup off");
		};
		foreach (Tuple<string, string, string> item in RunKeys())
		{
			try
			{
				using RegistryKey registryKey2 = Root(item.Item1).OpenSubKey(item.Item2);
				if (registryKey2 == null)
				{
					continue;
				}
				string[] valueNames = registryKey2.GetValueNames();
				foreach (string text in valueNames)
				{
					if (text.Length != 0)
					{
						off(item.Item1, item.Item3, text, Convert.ToString(registryKey2.GetValue(text)));
					}
				}
			}
			catch
			{
			}
		}
		foreach (Tuple<string, Environment.SpecialFolder> item2 in new Tuple<string, Environment.SpecialFolder>[2]
		{
			Tuple.Create("HKCU", Environment.SpecialFolder.Startup),
			Tuple.Create("HKLM", Environment.SpecialFolder.CommonStartup)
		})
		{
			try
			{
				string folderPath = Environment.GetFolderPath(item2.Item2);
				if (!Directory.Exists(folderPath))
				{
					continue;
				}
				foreach (string item3 in Directory.EnumerateFiles(folderPath).Where((string f) => !Path.GetFileName(f).Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)))
				{
					off(item2.Item1, "StartupFolder", Path.GetFileName(item3), item3);
				}
			}
			catch
			{
			}
		}
		// Third-party services that start with Windows → Manual. Windows' own services are handled by the services preset;
		// drivers, anti-cheat, GPU, audio and the listed gaming tools are never touched.
		try
		{
			ServiceController[] services = ServiceController.GetServices();
			foreach (ServiceController serviceController in services)
			{
				using (serviceController)
				{
					try
					{
						string serviceName = serviceController.ServiceName;
						using RegistryKey registryKey3 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + serviceName, writable: true);
						if (registryKey3 == null || Convert.ToInt32(registryKey3.GetValue("Start", -1)) != 2 || (Convert.ToInt32(registryKey3.GetValue("Type", 0)) & 0x30) == 0)
						{
							continue;
						}
						string text2 = Convert.ToString(registryKey3.GetValue("ImagePath", ""));
						string displayName = serviceController.DisplayName;
						if (text2.IndexOf("\\Windows\\", StringComparison.OrdinalIgnoreCase) >= 0 || text2.StartsWith("%SystemRoot%", StringComparison.OrdinalIgnoreCase) || text2.StartsWith("%windir%", StringComparison.OrdinalIgnoreCase) || text2.IndexOf("system32", StringComparison.OrdinalIgnoreCase) >= 0 || Keep.IsMatch(serviceName + " " + displayName + " " + text2) || ServiceBatch.KeptForGaming(serviceName, displayName) || ServiceBatch.Essential(serviceName) || Regex.IsMatch(serviceName + " " + displayName + " " + text2, "defender|security|antivirus|anti-malware|kaspersky|avast|avg|eset|bitdefender|norton|mcafee|malwarebytes|sophos|trend ?micro|webroot|f-secure|panda", RegexOptions.IgnoreCase))
						{
							continue;
						}
						bool delayed = Convert.ToInt32(registryKey3.GetValue("DelayedAutostart", 0)) == 1;
						list2.Add(new Entry
						{
							Kind = "service",
							Name = serviceName,
							Start = 2,
							Delayed = delayed
						});
						Save(list2);
						if (!ServiceConfig.SetStart(serviceName, 3, delayed: false))
						{
							registryKey3.SetValue("Start", 3, RegistryValueKind.DWord);
						}
						list.Add(displayName + " · service Manual");
					}
					catch
					{
					}
				}
			}
		}
		catch
		{
		}
		Save(list2);
		return list;
	}

	public static List<string> RestoreAll()
	{
		lock (Gate)
		{
			return RestoreAllLocked();
		}
	}
	
	// The journal is a file in the user's folder: only what DisableAll itself writes is restored (automatic start for a
	// service, an approved-startup value in the three StartupApproved lists).
	private static bool Valid(Entry e)
	{
		if (e.Kind == "service")
		{
			return !string.IsNullOrEmpty(e.Name) && e.Name.IndexOf('\\') < 0 && e.Start == 2;
		}
		return e.Kind == "app" && (e.Hive == "HKLM" || e.Hive == "HKCU") && (e.Key == "Run" || e.Key == "Run32" || e.Key == "StartupFolder") && !string.IsNullOrEmpty(e.Name) && (e.Before == null || e.Before.Length <= 64);
	}
	
	private static List<string> RestoreAllLocked()
	{
		List<string> list = new List<string>();
		List<Entry> list2 = Load();
		foreach (Entry item in list2.ToList())
		{
			if (!Valid(item))
			{
				list2.Remove(item);
				continue;
			}
			try
			{
				if (item.Kind == "service")
				{
					if (!ServiceConfig.SetStart(item.Name, item.Start, item.Delayed))
					{
						using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + item.Name, writable: true);
						registryKey?.SetValue("Start", item.Start, RegistryValueKind.DWord);
					}
					list.Add(item.Name + " · service Automatic");
				}
				else
				{
					using RegistryKey registryKey2 = Root(item.Hive).CreateSubKey(Approved + item.Key);
					if (item.Before != null)
					{
						registryKey2.SetValue(item.Name, item.Before, RegistryValueKind.Binary);
					}
					else
					{
						registryKey2.DeleteValue(item.Name, throwOnMissingValue: false);
					}
					list.Add(item.Name + " · startup on");
				}
				list2.Remove(item);
			}
			catch
			{
			}
		}
		Save(list2);
		return list;
	}
}
