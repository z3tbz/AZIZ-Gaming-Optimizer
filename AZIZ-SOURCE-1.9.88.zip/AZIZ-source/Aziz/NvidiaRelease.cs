namespace Aziz;

internal sealed class NvidiaRelease
{
	public string Id;

	public string Version;

	public string Date;

	public string Url;

	public string Size;
}
