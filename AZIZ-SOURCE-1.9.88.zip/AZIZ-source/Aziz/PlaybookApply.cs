using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aziz;

internal static class PlaybookApply
{
	public static int Run()
	{
		StringBuilder log = new StringBuilder();
		Action<string> write = delegate(string line)
		{
			lock (log)
			{
				log.AppendLine(DateTime.Now.ToString("HH:mm:ss") + "  " + line);
			}
		};
		int num = 0;
		try
		{
			Directory.CreateDirectory(Program.Data);
			Engine engine = new Engine(null, Program.Data);
			ServiceInventory.Merge(engine.Tweaks);
			Dictionary<string, TweakStatus> states = engine.Scan();
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			foreach (Tweak item in engine.Tweaks.Where(ProfileLogic.Profileable))
			{
				string value = ProfileLogic.CurrentValue(engine, states, item);
				if (ProfileLogic.ValueApplies(item, value))
				{
					dictionary[item.Id] = value;
				}
			}
			WindowsBaseline.Merge(dictionary);
			write("Windows Default: " + engine.CaptureOriginals(() => false) + " original values saved.");
			WindowsBaseline.MarkOriginals();
			AppSettings appSettings = AppSettings.Load();
			ActionResult actionResult = SystemRestore.EnsureBackupPoint();
			appSettings.BackupPointCreated = actionResult.Success;
			write("AZIZ Backup restore point: " + actionResult.Message);
			Dictionary<string, string> values = ProfileLogic.PresetValues(engine.Tweaks, ultra: false);
			List<Tweak> list = engine.Tweaks.Where(delegate(Tweak t)
			{
				if (states.TryGetValue(t.Id, out var value2) && value2.State == "Unavailable")
				{
					return false;
				}
				string value3;
				return values.TryGetValue(t.Id, out value3) && ProfileLogic.ValueApplies(t, value3) && ProfileLogic.PresetSafe(t, value3) && ProfileLogic.CurrentValue(engine, states, t) != value3;
			}).ToList();
			write("AZIZ Recommended: " + list.Count + " settings to change.");
			int failed = 0;
			Parallel.ForEach(list, new ParallelOptions
			{
				MaxDegreeOfParallelism = 4
			}, delegate(Tweak t)
			{
				string text = values[t.Id];
				ActionResult actionResult2;
				try
				{
					if (t.Id == "cpu-boost-settings")
					{
						actionResult2 = PowerControls.SetAc(t.Id, "cpu-boost-policy", uint.Parse(text.Substring(6)), engine.DataPath);
					}
					else if (t.Kind == "Timer")
					{
						if (text == "Enabled")
						{
							TimerLease.EnableGlobalRequests();
						}
						actionResult2 = ((text == "Enabled") ? TimerService.Install() : TimerService.Remove());
					}
					else
					{
						actionResult2 = ((t.Kind == "Service" || (t.Choices != null && t.Choices.Count > 0)) ? engine.ApplyChoice(t.Id, text) : engine.Apply(t.Id, text == "Enabled"));
					}
				}
				catch (Exception ex3)
				{
					actionResult2 = new ActionResult
					{
						Message = ex3.Message
					};
				}
				if (!actionResult2.Success)
				{
					lock (log)
					{
						failed++;
					}
				}
				write((actionResult2.Success ? "OK    " : "REVIEW") + "  " + t.Name + " → " + text + ((!actionResult2.Success) ? (" · " + actionResult2.Message) : ""));
			});
			try
			{
				GpuDevice gpuDevice = GpuInterrupt.Primary();
				if (gpuDevice != null && GpuInterrupt.Read(gpuDevice, "MessageSignaledInterruptProperties", "MSISupported", 0) != 1)
				{
					write("MSI mode for " + gpuDevice.Name + ": " + engine.ApplyScoped(GpuInterrupt.MsiOnly(gpuDevice), restore: false).Message);
				}
			}
			catch (Exception ex)
			{
				write("MSI mode: " + ex.Message);
			}
			write("AZIZ registry set: " + SilentTweaks.Apply().Count + " values.");
			foreach (KeyValuePair<string, List<string>> item2 in DebloatList.ApplyRegistry())
			{
				write("Debloat · " + item2.Key + ": " + item2.Value.Count + " values.");
			}
			appSettings.ActiveProfile = "aziz-recommended";
			appSettings.ProfileAutoSave = false;
			appSettings.Save();
			Utilities.AtomicWrite(Path.Combine(Program.Data, "applied-reference.json"), Program.Json.Serialize(new AppliedReference
			{
				Name = "AZIZ Recommended",
				Values = values,
				Accepted = new Dictionary<string, string>()
			}));
			Utilities.AtomicWrite(Path.Combine(Program.Data, "last-states.json"), Program.Json.Serialize(engine.Scan()));
			write("Done · " + (list.Count - failed) + " applied · " + failed + " need review.");
			num = ((failed != 0) ? 3 : 0);
		}
		catch (Exception ex2)
		{
			write("Stopped: " + ex2);
			num = 1;
		}
		try
		{
			File.WriteAllText(Path.Combine(Program.Data, "playbook-apply.log"), log.ToString(), Encoding.UTF8);
		}
		catch
		{
		}
		return num;
	}
}
