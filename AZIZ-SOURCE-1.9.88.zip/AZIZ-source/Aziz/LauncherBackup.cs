namespace Aziz;

internal class LauncherBackup
{
	public int Pid { get; set; }

	public long Started { get; set; }

	public long Mask { get; set; }
}
