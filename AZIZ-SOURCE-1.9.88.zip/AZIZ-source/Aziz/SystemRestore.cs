using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using Microsoft.Win32;

namespace Aziz;

internal static class SystemRestore
{
	internal const string BackupName = "AZIZ Backup";

	private static string Q(string s)
	{
		return "'" + s.Replace("'", "''") + "'";
	}

	public static bool ProtectionOn()
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SPP\\Clients");
			return ((registryKey == null) ? null : (registryKey.GetValue("{09F7EDC5-294E-4180-AF6A-FB0E6A0E9513}") as string[]))?.Any((string x) => !string.IsNullOrWhiteSpace(x)) ?? false;
		}
		catch
		{
			return false;
		}
	}

	public static List<RestorePointInfo> Points()
	{
		List<RestorePointInfo> list = new List<RestorePointInfo>();
		try
		{
			using ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(new ManagementScope("\\\\.\\root\\default"), new ObjectQuery("SELECT SequenceNumber,Description,CreationTime,RestorePointType FROM SystemRestore"));
			using ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
			foreach (ManagementObject item in managementObjectCollection)
			{
				using (item)
				{
					DateTime created = DateTime.MinValue;
					try
					{
						created = ManagementDateTimeConverter.ToDateTime(Convert.ToString(item["CreationTime"]));
					}
					catch
					{
					}
					list.Add(new RestorePointInfo
					{
						Sequence = Convert.ToUInt32(item["SequenceNumber"]),
						Description = Convert.ToString(item["Description"]),
						Created = created,
						Type = Convert.ToInt32(item["RestorePointType"])
					});
				}
			}
		}
		catch
		{
		}
		return list.OrderByDescending((RestorePointInfo x) => x.Created).ToList();
	}

	public static TweakStatus State()
	{
		bool flag = ProtectionOn();
		List<RestorePointInfo> list = Points();
		TweakStatus tweakStatus = new TweakStatus();
		tweakStatus.State = (flag ? "Enabled" : "Disabled");
		tweakStatus.Detail = (flag ? "Protection on" : "Protection off") + " · " + list.Count + " restore point" + ((list.Count == 1) ? "" : "s") + ((list.Count > 0) ? (" · latest " + list[0].Created.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture)) : "");
		return tweakStatus;
	}

	public static ActionResult Create(string name)
	{
		if (string.IsNullOrWhiteSpace(name))
		{
			return new ActionResult
			{
				Message = "Enter a name for the restore point."
			};
		}
		name = name.Trim();
		if (name.Length > 200)
		{
			name = name.Substring(0, 200);
		}
		int count = Points().Count;
		string text = null;
		try
		{
			PrepareProtection();
			using ManagementClass managementClass = new ManagementClass(new ManagementScope("\\\\.\\root\\default"), new ManagementPath("SystemRestore"), null);
			ManagementBaseObject methodParameters = managementClass.GetMethodParameters("CreateRestorePoint");
			methodParameters["Description"] = name;
			methodParameters["RestorePointType"] = 12u;
			methodParameters["EventType"] = 100u;
			uint num = Convert.ToUInt32(managementClass.InvokeMethod("CreateRestorePoint", methodParameters, null)["ReturnValue"]);
			if (num == 0 && Points().Count > count)
			{
				return new ActionResult
				{
					Success = true,
					Message = "Restore point created: " + name
				};
			}
			text = "Windows returned " + num;
		}
		catch (Exception ex)
		{
			text = ex.Message;
		}
		string script = "$p='HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\SystemRestore';if(Test-Path $p){Remove-ItemProperty -Path $p -Name DisableSR,DisableConfig -ErrorAction SilentlyContinue};foreach($s in 'VSS','swprv'){$x=Get-CimInstance Win32_Service -Filter (\"Name='\"+$s+\"'\");if($x -and $x.StartMode -eq 'Disabled'){Set-Service -Name $s -StartupType Manual}};$drive=$env:SystemDrive+'\\';Enable-ComputerRestore -Drive $drive;try{$ErrorActionPreference='Continue';& vssadmin.exe Resize ShadowStorage /For=$env:SystemDrive /On=$env:SystemDrive /MaxSize=8%|Out-Null}catch{};$ErrorActionPreference='Stop';New-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore' -Name SystemRestorePointCreationFrequency -Value 0 -PropertyType DWord -Force|Out-Null;$before=@(Get-ComputerRestorePoint -ErrorAction SilentlyContinue).Count;Checkpoint-Computer -Description " + Q(name) + " -RestorePointType MODIFY_SETTINGS;$after=@(Get-ComputerRestorePoint).Count;if($after -le $before){throw 'Windows did not create the restore point. Check free space on the Windows drive.'};'Restore point created: '+" + Q(name);
		ActionResult actionResult = Utilities.Run("powershell.exe", GameWatch.PsArgs(script));
		if (actionResult.Success)
		{
			actionResult.Message = actionResult.Message.Replace("Completed. ", "").Trim();
		}
		else if (text != null)
		{
			actionResult.Message = actionResult.Message + " (" + text + ")";
		}
		return actionResult;
	}

	private static void PrepareProtection()
	{
		try
		{
			using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Policies\\Microsoft\\Windows NT\\SystemRestore", writable: true);
			registryKey?.DeleteValue("DisableSR", throwOnMissingValue: false);
			registryKey?.DeleteValue("DisableConfig", throwOnMissingValue: false);
		}
		catch
		{
		}
		string[] array = new string[2] { "VSS", "swprv" };
		foreach (string text in array)
		{
			try
			{
				using RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + text, writable: true);
				if (registryKey2 != null && Convert.ToInt32(registryKey2.GetValue("Start", 3)) == 4)
				{
					registryKey2.SetValue("Start", 3, RegistryValueKind.DWord);
				}
			}
			catch
			{
			}
		}
		try
		{
			using RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore");
			registryKey3.SetValue("SystemRestorePointCreationFrequency", 0, RegistryValueKind.DWord);
		}
		catch
		{
		}
		if (ProtectionOn())
		{
			return;
		}
		try
		{
			using ManagementClass managementClass = new ManagementClass(new ManagementScope("\\\\.\\root\\default"), new ManagementPath("SystemRestore"), null);
			ManagementBaseObject methodParameters = managementClass.GetMethodParameters("Enable");
			methodParameters["Drive"] = Environment.GetEnvironmentVariable("SystemDrive") + "\\";
			managementClass.InvokeMethod("Enable", methodParameters, null);
		}
		catch
		{
		}
	}

	public static RestorePointInfo BackupPoint()
	{
		return (from x in Points()
			where string.Equals(x.Description, "AZIZ Backup", StringComparison.OrdinalIgnoreCase)
			orderby x.Created
			select x).FirstOrDefault();
	}

	public static ActionResult EnsureBackupPoint()
	{
		if (BackupPoint() != null)
		{
			return new ActionResult
			{
				Success = true,
				Message = "AZIZ Backup restore point already exists."
			};
		}
		return Create("AZIZ Backup");
	}

	public static ActionResult Restore(uint sequence)
	{
		try
		{
			using ManagementClass managementClass = new ManagementClass(new ManagementScope("\\\\.\\root\\default"), new ManagementPath("SystemRestore"), null);
			ManagementBaseObject methodParameters = managementClass.GetMethodParameters("Restore");
			methodParameters["SequenceNumber"] = sequence;
			if (Convert.ToUInt32(managementClass.InvokeMethod("Restore", methodParameters, null)["ReturnValue"]) == 0)
			{
				return Utilities.Run(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "shutdown.exe"), "/r /t 5 /c \"AZIZ: restoring Windows to the selected restore point\"");
			}
		}
		catch
		{
		}
		return Utilities.Run("powershell.exe", GameWatch.PsArgs("Restore-Computer -RestorePoint " + sequence + " -Confirm:$false"));
	}

	public static void OpenWindowsRestore()
	{
		string fileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "rstrui.exe");
		try
		{
			Process.Start(new ProcessStartInfo(fileName)
			{
				UseShellExecute = true
			});
		}
		catch
		{
			Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "SystemPropertiesProtection.exe"))
			{
				UseShellExecute = true
			});
		}
	}
}
