using System;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;

namespace Aziz;

// Work folder for anything that later runs with admin rights (update files, uninstall script, installers being
// extracted): %ProgramData%\AZIZ\Work, writable only by Administrators and SYSTEM, so a normal program cannot swap or
// append to those files while they wait.
internal static class SecureWork
{
	public static string Root
	{
		get
		{
			string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "AZIZ");
			Secure(text, usersRead: true);
			string text2 = Path.Combine(text, "Work");
			Secure(text2, usersRead: false);
			return text2;
		}
	}

	private static bool Trusted(SecurityIdentifier sid)
	{
		return sid != null && (sid.IsWellKnown(WellKnownSidType.BuiltinAdministratorsSid) || sid.IsWellKnown(WellKnownSidType.LocalSystemSid) || sid.Value == "S-1-5-80-956008885-3418522649-1831038044-1853292631-2271478464");
	}

	// Owned by Administrators with a protected list (Administrators and SYSTEM full; for the parent, users may only read).
	// Any normal user can create folders in ProgramData: a folder AZIZ did not make (someone else is its owner, or it is a
	// link) is thrown away and made again, so nobody keeps a way to swap files that later run with admin rights.
	private static void Secure(string path, bool usersRead)
	{
		SecurityIdentifier securityIdentifier = new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null);
		DirectorySecurity directorySecurity = new DirectorySecurity();
		directorySecurity.SetAccessRuleProtection(isProtected: true, preserveInheritance: false);
		directorySecurity.SetOwner(securityIdentifier);
		directorySecurity.AddAccessRule(new FileSystemAccessRule(securityIdentifier, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
		directorySecurity.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
		if (usersRead)
		{
			directorySecurity.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinUsersSid, null), FileSystemRights.ReadAndExecute, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
		}
		DirectoryInfo directoryInfo = new DirectoryInfo(path);
		if (directoryInfo.Exists)
		{
			bool flag = (directoryInfo.Attributes & FileAttributes.ReparsePoint) != 0;
			SecurityIdentifier sid = null;
			try
			{
				sid = directoryInfo.GetAccessControl(AccessControlSections.Owner).GetOwner(typeof(SecurityIdentifier)) as SecurityIdentifier;
			}
			catch
			{
			}
			if (flag || !Trusted(sid))
			{
				if (flag)
				{
					directoryInfo.Delete();
				}
				else
				{
					directoryInfo.Delete(recursive: true);
				}
				directoryInfo.Refresh();
			}
		}
		if (!directoryInfo.Exists)
		{
			directoryInfo.Create(directorySecurity);
		}
		else
		{
			directoryInfo.SetAccessControl(directorySecurity);
		}
		directoryInfo.Refresh();
		if ((directoryInfo.Attributes & FileAttributes.ReparsePoint) != 0 || !Trusted(directoryInfo.GetAccessControl(AccessControlSections.Owner).GetOwner(typeof(SecurityIdentifier)) as SecurityIdentifier))
		{
			throw new IOException("The AZIZ work folder is not safe to use.");
		}
	}

	public static string NewFolder(string prefix)
	{
		string root = Root;
		// Leftovers of earlier runs (a setup that was still running, a crash) go after a day.
		try
		{
			foreach (string item in Directory.EnumerateDirectories(root, prefix + "-*"))
			{
				if ((DateTime.UtcNow - Directory.GetCreationTimeUtc(item)).TotalDays > 1.0)
				{
					try
					{
						Directory.Delete(item, recursive: true);
					}
					catch
					{
					}
				}
			}
		}
		catch
		{
		}
		string text = Path.Combine(root, prefix + "-" + Guid.NewGuid().ToString("N"));
		Directory.CreateDirectory(text);
		return text;
	}
}
