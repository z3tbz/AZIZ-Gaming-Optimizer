using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Aziz;

internal static class InstallerRun
{
	public static string Kind(string file)
	{
		if (Path.GetExtension(file).Equals(".msi", StringComparison.OrdinalIgnoreCase))
		{
			return "msi";
		}
		try
		{
			using FileStream fileStream = File.OpenRead(file);
			byte[] array = new byte[Math.Min(fileStream.Length, 8388608L)];
			int count = fileStream.Read(array, 0, array.Length);
			string @string = Encoding.ASCII.GetString(array, 0, count);
			if (@string.Contains("Inno Setup"))
			{
				return "inno";
			}
			if (@string.Contains("Nullsoft.NSIS") || @string.Contains("NullsoftInst"))
			{
				return "nsis";
			}
		}
		catch
		{
		}
		return null;
	}

	public static bool IsArchive(string file)
	{
		string text = Path.GetExtension(file ?? "").ToLowerInvariant();
		if (!(text == ".zip") && !(text == ".7z"))
		{
			return text == ".rar";
		}
		return true;
	}

	public static ActionResult Run(string file)
	{
		return Run(file, interactive: false);
	}

	public static ActionResult Run(string file, bool interactive)
	{
		// Downloads are writable by any program: AZIZ (admin) only runs a setup with a valid signature, from a checked copy
		// in its admin-only folder. Anything unsigned opens like a double-click, without AZIZ's admin rights.
		try
		{
			string text0 = SilentSetup.SecureCopy(file, interactive);
			if (text0 == null)
			{
				Process.Start(Utilities.Explorer, "\"" + file + "\"");
				return new ActionResult
				{
					Success = true,
					Message = "The installer is not signed, so it opened normally (Windows asks for permission if it needs it)."
				};
			}
			file = text0;
		}
		catch (Exception ex0)
		{
			return new ActionResult
			{
				Message = ex0.Message
			};
		}
		try
		{
			string text = (interactive ? null : Kind(file));
			if (interactive && Path.GetExtension(file).Equals(".msi", StringComparison.OrdinalIgnoreCase))
			{
				Process.Start(new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "msiexec.exe"), "/i \"" + file + "\"")
				{
					UseShellExecute = true
				})?.WaitForExit(1200000);
				return new ActionResult
				{
					Success = true,
					Message = "Installer closed."
				};
			}
			ProcessStartInfo obj = ((!(text == "msi")) ? new ProcessStartInfo(file, (text == "inno") ? "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-" : ((text == "nsis") ? "/S" : "")) : new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "msiexec.exe"), "/i \"" + file + "\" /qn /norestart"));
			obj.UseShellExecute = true;
			obj.WorkingDirectory = Path.GetDirectoryName(file);
			using Process process = Process.Start(obj);
			if (process == null)
			{
				return new ActionResult
				{
					Message = "The installer did not start."
				};
			}
			if (!process.WaitForExit(1200000))
			{
				return new ActionResult
				{
					Message = "The installer is still running."
				};
			}
			int exitCode = process.ExitCode;
			bool flag = exitCode == 0 || exitCode == 3010 || exitCode == 1641;
			return new ActionResult
			{
				Success = flag,
				Message = ((text == null) ? "Installer closed" : "Installed silently") + (flag ? "" : (" (exit code " + exitCode + ")")) + ((exitCode == 3010 || exitCode == 1641) ? " · restart Windows to finish." : ".")
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
