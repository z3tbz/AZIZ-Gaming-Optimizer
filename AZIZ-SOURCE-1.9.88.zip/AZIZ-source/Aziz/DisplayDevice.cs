namespace Aziz;

internal sealed class DisplayDevice
{
	public string Name;

	public string Instance;

	public string DriverPath;

	public override string ToString()
	{
		return Name;
	}
}
