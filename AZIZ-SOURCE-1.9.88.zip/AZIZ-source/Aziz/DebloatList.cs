using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Win32;

namespace Aziz;

internal static class DebloatList
{
	internal sealed class RegValue
	{
		public string P { get; set; }

		public string N { get; set; }

		public string T { get; set; }

		public string D { get; set; }
	}

	internal sealed class Data
	{
		public List<string> Apps { get; set; }

		public List<string> Tasks { get; set; }

		public List<string> Services { get; set; }

		public Dictionary<string, List<RegValue>> Registry { get; set; }

		public Dictionary<string, List<RegValue>> Review { get; set; }

		public List<string> Audit { get; set; }
	}

	internal static string Json()
	{
		using Stream stream = typeof(DebloatList).Assembly.GetManifestResourceStream("Aziz.debloat.json");
		using StreamReader streamReader = new StreamReader(stream);
		return streamReader.ReadToEnd();
	}

	internal static Dictionary<string, List<string>> ApplyRegistry()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		Data data;
		try
		{
			data = Program.Json.Deserialize<Data>(Json());
		}
		catch
		{
			return dictionary;
		}
		foreach (KeyValuePair<string, List<RegValue>> item in data.Registry ?? new Dictionary<string, List<RegValue>>())
		{
			List<string> list = new List<string>();
			foreach (RegValue item2 in item.Value)
			{
				if (Write(item2))
				{
					list.Add(item2.P + " · " + item2.N + " = " + item2.D);
				}
			}
			if (list.Count > 0)
			{
				dictionary[item.Key] = list;
			}
		}
		return dictionary;
	}

	private static string Q(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	// Optimize applies the rest of the debloat file too: apps (Xbox and Microsoft Store items stay manual), scheduled tasks,
	// services and audit policy. Each step reports what it did.
	internal static Dictionary<string, List<string>> ApplyRest()
	{
		Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();
		Data data;
		try
		{
			data = Program.Json.Deserialize<Data>(Json());
		}
		catch
		{
			return dictionary;
		}
		List<string> list = (data.Apps ?? new List<string>()).Where((string a) => a.IndexOf("Xbox", StringComparison.OrdinalIgnoreCase) < 0 && a.IndexOf("Gaming", StringComparison.OrdinalIgnoreCase) < 0 && a.IndexOf("Store", StringComparison.OrdinalIgnoreCase) < 0).ToList();
		if (list.Count > 0)
		{
			// Installed and provisioned packages are read once, not once per app (each read takes seconds).
			string script = "$ErrorActionPreference='Continue';$n=@(" + string.Join(",", list.Select(Q)) + ");$done=@();$all=@(Get-AppxPackage -AllUsers -ErrorAction SilentlyContinue);$prov=@(Get-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue);foreach($a in $n){foreach($x in @($all|Where-Object Name -eq $a)){try{Remove-AppxPackage -Package $x.PackageFullName -AllUsers -ErrorAction Stop;$done+=$a}catch{}};foreach($x in @($prov|Where-Object DisplayName -eq $a)){try{Remove-AppxProvisionedPackage -Online -PackageName $x.PackageName -ErrorAction Stop|Out-Null;$done+=$a}catch{}}};($done|Select-Object -Unique) -join \"`n\"";
			Add(dictionary, "Apps", Utilities.RunRaw("powershell.exe", GameWatch.PsArgs(script), 600000));
		}
		if (data.Tasks != null && data.Tasks.Count > 0)
		{
			// Every listed task is disabled straight away, without looking it up first (the lookup missed tasks before):
			// schtasks first, Disable-ScheduledTask as a second try; tasks this PC does not have just fail quietly.
			// A task this PC does not have must not stop the list ($ErrorActionPreference Continue: schtasks' error text is
			// not fatal). Tasks that were on before are marked "+" and kept in a journal, so Windows Default turns them on again.
			string script2 = "$ErrorActionPreference='Continue';$t=@(" + string.Join(",", data.Tasks.Select(Q)) + ");$done=@();foreach($f in $t){$i=$f.LastIndexOf('\\');$was=$null;try{$was=[string](Get-ScheduledTask -TaskPath $f.Substring(0,$i+1) -TaskName $f.Substring($i+1) -ErrorAction Stop).State}catch{};$ok=$false;try{& schtasks.exe /Change /TN $f /Disable 2>$null|Out-Null;$ok=($LASTEXITCODE -eq 0)}catch{};if(-not $ok){try{Disable-ScheduledTask -TaskPath $f.Substring(0,$i+1) -TaskName $f.Substring($i+1) -ErrorAction Stop|Out-Null;$ok=$true}catch{}};if($ok){if($was -and $was -ne 'Disabled'){$done+=('+'+$f)}else{$done+=$f}}};$done -join \"`n\"";
			ActionResult tasks = Utilities.RunRaw("powershell.exe", GameWatch.PsArgs(script2), 300000);
			if (tasks.Success)
			{
				List<string> lines = (tasks.Message ?? "").Split('\r', '\n').Select((string x) => x.Trim()).Where((string x) => x.Length > 0).ToList();
				TaskJournal.Remember(from x in lines
					where x.StartsWith("+")
					select x.Substring(1));
				tasks.Message = string.Join("\n", lines.Select((string x) => x.TrimStart('+')));
			}
			Add(dictionary, "Scheduled tasks", tasks);
		}
		List<string> list2 = new List<string>();
		string[] names;
		using (RegistryKey services = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services"))
		{
			names = services?.GetSubKeyNames() ?? new string[0];
		}
		foreach (string item in data.Services ?? new List<string>())
		{
			try
			{
				string[] array = (from n in names
					where n.Equals(item, StringComparison.OrdinalIgnoreCase) || n.StartsWith(item + "_", StringComparison.OrdinalIgnoreCase)
					select n).ToArray();
				foreach (string text in array)
				{
					// Same guard as the service presets: a service this PC loads as a disk/volume filter is never disabled.
					if (ServicePresets.RegisteredFilter(text))
					{
						continue;
					}
					using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + text, writable: true);
					if (registryKey != null && !object.Equals(registryKey.GetValue("Start"), 4))
					{
						registryKey.SetValue("Start", 4, RegistryValueKind.DWord);
						list2.Add(text + " · Disabled");
					}
				}
			}
			catch
			{
			}
		}
		if (list2.Count > 0)
		{
			dictionary["Services"] = list2;
		}
		List<string> list3 = new List<string>();
		// The audit policy as it was before AZIZ, once, so Windows Default can put it back.
		if ((data.Audit ?? new List<string>()).Count > 0 && !File.Exists(TaskJournal.AuditBackup))
		{
			Directory.CreateDirectory(Program.Data);
			Utilities.Run("auditpol.exe", "/backup /file:\"" + TaskJournal.AuditBackup + "\"");
		}
		foreach (string item2 in data.Audit ?? new List<string>())
		{
			if (Utilities.Run("auditpol.exe", item2).Success)
			{
				list3.Add(item2);
			}
		}
		if (list3.Count > 0)
		{
			dictionary["Audit policy"] = list3;
		}
		return dictionary;
	}

	private static void Add(Dictionary<string, List<string>> into, string name, ActionResult r)
	{
		List<string> list = (r.Message ?? "").Split(new char[2] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Select((string x) => x.Trim()).Where((string x) => x.Length > 0).ToList();
		if (r.Success && list.Count > 0)
		{
			into[name] = list;
		}
	}

	private static bool Write(RegValue v)
	{
		try
		{
			RegistryKey registryKey;
			string subkey;
			if (v.P.StartsWith("HKLM:\\", StringComparison.OrdinalIgnoreCase))
			{
				registryKey = Registry.LocalMachine;
				subkey = v.P.Substring(6);
			}
			else if (v.P.StartsWith("HKCU:\\", StringComparison.OrdinalIgnoreCase))
			{
				registryKey = Registry.CurrentUser;
				subkey = v.P.Substring(6);
			}
			else
			{
				if (!v.P.StartsWith("Registry::HKEY_USERS\\", StringComparison.OrdinalIgnoreCase))
				{
					return false;
				}
				registryKey = Registry.Users;
				subkey = v.P.Substring(21);
			}
			RegistryJournal.Remember((registryKey == Registry.LocalMachine) ? "HKLM" : ((registryKey == Registry.Users) ? "HKU" : "HKCU"), subkey, v.N);
			using RegistryKey registryKey2 = registryKey.CreateSubKey(subkey);
			if (v.T == "REG_DWORD")
			{
				string text = (v.D ?? "0").Trim();
				int num = (int)(text.StartsWith("0x", StringComparison.OrdinalIgnoreCase) ? Convert.ToInt32(text.Substring(2), 16) : Convert.ToInt64(text));
				registryKey2.SetValue(v.N, num, RegistryValueKind.DWord);
			}
			else
			{
				registryKey2.SetValue(v.N, v.D ?? "", RegistryValueKind.String);
			}
			return true;
		}
		catch
		{
			return false;
		}
	}
}
