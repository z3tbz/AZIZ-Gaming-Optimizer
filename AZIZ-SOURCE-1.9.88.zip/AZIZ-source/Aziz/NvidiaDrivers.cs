using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;
using Microsoft.Win32;

namespace Aziz;

internal static class NvidiaDrivers
{
	private static readonly HttpClient client = Client();

	private static HttpClient Client()
	{
		ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
		// Without this the .NET default of 2 connections per host serialises the parallel product lookups behind each
		// other, which is what made the search crawl and look stuck.
		ServicePointManager.DefaultConnectionLimit = 24;
		HttpClient httpClient = new HttpClient();
		httpClient.Timeout = TimeSpan.FromSeconds(60.0);
		httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("AZIZ-Gaming-Optimizer/1.9.7");
		return httpClient;
	}

	internal static List<DriverOption> ParseOptions(string xml)
	{
		XmlDocument xmlDocument = new XmlDocument();
		xmlDocument.XmlResolver = null;
		xmlDocument.LoadXml(xml);
		return (from XmlNode n in xmlDocument.SelectNodes("//LookupValue")
			select new DriverOption
			{
				Name = n["Name"].InnerText,
				Id = n["Value"].InnerText,
				Parent = ((n.Attributes["ParentID"] == null) ? "" : n.Attributes["ParentID"].Value)
			} into x
			where Regex.IsMatch(x.Id, "^[0-9]+$")
			select x).ToList();
	}

	private static Task<string> Get(string url, CancellationToken token)
	{
		return Fetch(url, token);
	}

	private static async Task<string> Fetch(string url, CancellationToken token)
	{
		using CancellationTokenSource cts = CancellationTokenSource.CreateLinkedTokenSource(token);
		cts.CancelAfter(TimeSpan.FromSeconds(12.0));
		using HttpResponseMessage r = await client.GetAsync(url, cts.Token);
		r.EnsureSuccessStatusCode();
		return await r.Content.ReadAsStringAsync();
	}

	public static async Task<List<DriverOption>> Options(int type, string parent, CancellationToken token)
	{
		if (!Regex.IsMatch(parent, "^[0-9]+$"))
		{
			throw new ArgumentException("Invalid NVIDIA product selection.");
		}
		return ParseOptions(await Get("https://www.nvidia.com/Download/API/lookupValueSearch.aspx?TypeID=" + type + "&ParentID=" + parent, token));
	}

	internal static string Normal(string name)
	{
		return Regex.Replace(name.ToUpperInvariant().Replace("NVIDIA", "").Replace("LAPTOP GPU", "")
			.Replace("NOTEBOOK", "")
			.Replace("GPU", ""), "[^A-Z0-9]", "");
	}

	// The product found for this GPU last time: the page then reads the releases at once instead of searching every series.
	private static string RememberPath => Path.Combine(Program.Data, "nvidia-product.json");

	public static string[] Remembered(string gpu)
	{
		try
		{
			Dictionary<string, string> dictionary = Program.Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(RememberPath));
			if (dictionary != null && dictionary.TryGetValue("Gpu", out var value) && value == gpu && dictionary.TryGetValue("Series", out var value2) && dictionary.TryGetValue("Product", out var value3) && Regex.IsMatch(value2 + ":" + value3, "^[0-9]+:[0-9]+$"))
			{
				return new string[2] { value2, value3 };
			}
		}
		catch
		{
		}
		return null;
	}

	public static void Remember(string gpu, string series, string product)
	{
		try
		{
			Directory.CreateDirectory(Program.Data);
			Utilities.AtomicWrite(RememberPath, Program.Json.Serialize(new Dictionary<string, string>
			{
				["Gpu"] = gpu,
				["Series"] = series,
				["Product"] = product
			}));
		}
		catch
		{
		}
	}

	// Series that fit the GPU (same generation, desktop or laptop) are asked together, then the rest together — not one by one.
	public static async Task<Tuple<DriverOption, List<DriverOption>>> Detect(string name, List<DriverOption> series, CancellationToken token)
	{
		bool laptop = name.IndexOf("Laptop", StringComparison.OrdinalIgnoreCase) >= 0;
		Match match = Regex.Match(name, "\\b([1-9][0-9])[0-9]{2}\\b");
		string generation = (match.Success ? match.Groups[1].Value : "");
		List<DriverOption> list = series.Where((DriverOption s) => s.Name.IndexOf("Notebooks", StringComparison.OrdinalIgnoreCase) >= 0 == laptop).ToList();
		List<DriverOption> first = list.Where((DriverOption s) => generation.Length > 0 && s.Name.Contains(generation)).ToList();
		// Only the series that match the card's generation are probed (e.g. an RTX 4070 looks in the 40-series lists only):
		// a small, fast parallel burst. If the exact card is not there, the product list is already on screen to pick from.
		List<DriverOption> wave = ((first.Count > 0) ? first : list);
		List<DriverOption>[] products = await Task.WhenAll(wave.Select((DriverOption s) => Options(3, s.Id, token)));
		for (int i = 0; i < wave.Count; i++)
		{
			DriverOption driverOption = products[i].FirstOrDefault((DriverOption x) => Normal(x.Name) == Normal(name));
			if (driverOption != null)
			{
				driverOption.Parent = wave[i].Id;
				return Tuple.Create(driverOption, products[i]);
			}
		}
		return null;
	}

	internal static List<NvidiaRelease> ParseReleases(string json)
	{
		Dictionary<string, object> dictionary = Program.Json.Deserialize<Dictionary<string, object>>(json);
		List<NvidiaRelease> list = new List<NvidiaRelease>();
		if (!dictionary.TryGetValue("IDS", out var value))
		{
			return list;
		}
		foreach (Dictionary<string, object> item in (IEnumerable)value)
		{
			Dictionary<string, object> d = (Dictionary<string, object>)item["downloadInfo"];
			Func<string, string> func = (string k) => d.ContainsKey(k) ? Uri.UnescapeDataString(Convert.ToString(d[k])) : "";
			string text = func("DownloadURL");
			if (!(func("IsCRD") != "0") && !(func("IsBeta") != "0") && func("Name").IndexOf("Game Ready", StringComparison.OrdinalIgnoreCase) >= 0 && Uri.TryCreate(text, UriKind.Absolute, out var result) && !(result.Scheme != "https") && result.Host.EndsWith(".download.nvidia.com", StringComparison.OrdinalIgnoreCase) && result.AbsolutePath.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
			{
				list.Add(new NvidiaRelease
				{
					Id = func("ID"),
					Version = func("Version"),
					Date = func("ReleaseDateTime"),
					Url = text,
					Size = func("DownloadURLFileSize")
				});
			}
		}
		// Archive from 566.36 on (older drivers are not offered).
		Version minimum = new Version(566, 36);
		return (from x in list
			group x by x.Id into x
			select x.First() into x
			where !Version.TryParse(x.Version, out var v) || v >= minimum
			select x).ToList();
	}

	private static readonly Dictionary<string, Task<List<NvidiaRelease>>> searches = new Dictionary<string, Task<List<NvidiaRelease>>>();

	// One read per product per session: started early from the remembered product, reused when the page asks for it.
	public static Task<List<NvidiaRelease>> Search(string series, string product, CancellationToken token)
	{
		if (!Regex.IsMatch(series + ":" + product, "^[0-9]+:[0-9]+$"))
		{
			throw new ArgumentException("Select an exact NVIDIA product.");
		}
		string key = series + ":" + product;
		lock (searches)
		{
			if (searches.TryGetValue(key, out var value) && !value.IsFaulted && !value.IsCanceled)
			{
				return value;
			}
			Task<List<NvidiaRelease>> task = Read(series, product, CancellationToken.None);
			searches[key] = task;
			return task;
		}
	}

	private static async Task<List<NvidiaRelease>> Read(string series, string product, CancellationToken token)
	{
		int result = 0;
		using (RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"))
		{
			if (registryKey != null)
			{
				int.TryParse(Convert.ToString(registryKey.GetValue("CurrentBuildNumber")), out result);
			}
		}
		string text = ((result >= 22000) ? "135" : "57");
		return ParseReleases(await Get("https://gfwsl.geforce.com/services_toolkit/services/com/nvidia/services/AjaxDriverService.php?func=DriverManualLookup&psid=" + series + "&pfid=" + product + "&osID=" + text + "&languageCode=1033&beta=0&isWHQL=0&dltype=-1&dch=1&upCRD=0&qnf=null&ctk=null&sort1=1&numberOfResults=100", token));
	}
}
