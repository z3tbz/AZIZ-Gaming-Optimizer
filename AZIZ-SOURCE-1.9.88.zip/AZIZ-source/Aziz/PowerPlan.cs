namespace Aziz;

internal class PowerPlan
{
	public string Id { get; set; }

	public string Name { get; set; }

	public bool Active { get; set; }
}
