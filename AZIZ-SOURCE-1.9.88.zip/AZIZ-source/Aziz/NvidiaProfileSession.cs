using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Aziz;

internal sealed class NvidiaProfileSession : IDisposable
{
	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int Init();

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int Create(out IntPtr session);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int SessionCall(IntPtr session);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int ProfileCall(IntPtr session, out IntPtr profile);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int Get(IntPtr session, IntPtr profile, uint id, IntPtr setting);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int Set(IntPtr session, IntPtr profile, IntPtr setting);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int Reset(IntPtr session, IntPtr profile, uint id);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int FindApp(IntPtr session, IntPtr name, out IntPtr profile, IntPtr application);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int FindProfile(IntPtr session, IntPtr name, out IntPtr profile);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NewProfile(IntPtr session, IntPtr info, out IntPtr profile);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int ProfileInfo(IntPtr session, IntPtr profile, IntPtr info);

	[UnmanagedFunctionPointer(CallingConvention.Cdecl)]
	private delegate int NewApp(IntPtr session, IntPtr profile, IntPtr application);

	internal const int Size = 12320;

	internal const int ValueOffset = 8220;

	internal const int ProfileSize = 4116;

	internal const int AppSize = 12296;

	private IntPtr session;

	private IntPtr profile;

	private bool initialized;

	[DllImport("nvapi64.dll", CallingConvention = CallingConvention.Cdecl, EntryPoint = "nvapi_QueryInterface")]
	private static extern IntPtr Query(uint id);

	private static T Api<T>(uint id) where T : class
	{
		IntPtr intPtr = Query(id);
		if (intPtr == IntPtr.Zero)
		{
			throw new NotSupportedException("NVIDIA driver API unavailable.");
		}
		return Marshal.GetDelegateForFunctionPointer(intPtr, typeof(T)) as T;
	}

	private static void Check(int code)
	{
		if (code != 0)
		{
			throw new IOException("NVIDIA driver returned " + code + ".");
		}
	}

	public NvidiaProfileSession()
	{
		try
		{
			Check(Api<Init>(22079528u)());
			initialized = true;
			Check(Api<Create>(110417198u)(out session));
			Check(Api<SessionCall>(928890219u)(session));
			Check(Api<ProfileCall>(3666110112u)(session, out profile));
		}
		catch
		{
			Dispose();
			throw;
		}
	}

	private static byte[] Empty(uint id)
	{
		byte[] array = new byte[12320];
		Put(array, 0, 77856u);
		Put(array, 4100, id);
		return array;
	}

	internal static void Put(byte[] data, int offset, uint value)
	{
		Array.Copy(BitConverter.GetBytes(value), 0, data, offset, 4);
	}

	public byte[] Read(uint id)
	{
		byte[] array = Empty(id);
		IntPtr intPtr = Marshal.AllocHGlobal(12320);
		try
		{
			Marshal.Copy(array, 0, intPtr, 12320);
			int num = Api<Get>(1941930808u)(session, profile, id, intPtr);
			if (num == -160)
			{
				return null;
			}
			Check(num);
			Marshal.Copy(intPtr, array, 0, 12320);
			return array;
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr);
		}
	}

	public void Write(byte[] data)
	{
		if (!TryWrite(data))
		{
			Check(-160);
		}
	}

	public bool TryWrite(byte[] data)
	{
		IntPtr intPtr = Marshal.AllocHGlobal(12320);
		try
		{
			Marshal.Copy(data, 0, intPtr, 12320);
			int num = Api<Set>(1467863554u)(session, profile, intPtr);
			if (num == -160)
			{
				return false;
			}
			Check(num);
			return true;
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr);
		}
	}

	public void Restore(uint id, byte[] data)
	{
		if (data == null || BitConverter.ToUInt32(data, 4112) != 0)
		{
			int num = Api<Reset>(3835847522u)(session, profile, id);
			if (num != -160)
			{
				Check(num);
			}
		}
		else
		{
			Write(data);
		}
	}

	public void Save()
	{
		Check(Api<SessionCall>(4240211476u)(session));
	}

	private static IntPtr Unicode(string text)
	{
		IntPtr intPtr = Marshal.AllocHGlobal(4096);
		byte[] array = new byte[4096];
		byte[] bytes = Encoding.Unicode.GetBytes(text + "\0");
		Array.Copy(bytes, array, Math.Min(bytes.Length, 4094));
		Marshal.Copy(array, 0, intPtr, 4096);
		return intPtr;
	}

	private static string ReadUnicode(IntPtr p, int offset)
	{
		byte[] array = new byte[4096];
		Marshal.Copy(IntPtr.Add(p, offset), array, 0, 4096);
		string @string = Encoding.Unicode.GetString(array);
		int num = @string.IndexOf('\0');
		if (num >= 0)
		{
			return @string.Substring(0, num);
		}
		return @string;
	}

	private string ProfileName(IntPtr handle)
	{
		IntPtr intPtr = Marshal.AllocHGlobal(4116);
		try
		{
			Marshal.Copy(new byte[4116], 0, intPtr, 4116);
			Marshal.WriteInt32(intPtr, 69652);
			Check(Api<ProfileInfo>(1640853462u)(session, handle, intPtr));
			return ReadUnicode(intPtr, 4);
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr);
		}
	}

	public string ProfileFor(string exe)
	{
		IntPtr intPtr = Unicode(exe);
		IntPtr intPtr2 = Marshal.AllocHGlobal(12296);
		try
		{
			Marshal.Copy(new byte[12296], 0, intPtr2, 12296);
			Marshal.WriteInt32(intPtr2, 77832);
			IntPtr handle;
			int num = Api<FindApp>(4008011442u)(session, intPtr, out handle, intPtr2);
			if (num == -166 || num == -163)
			{
				return null;
			}
			Check(num);
			return ProfileName(handle);
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}
	}

	public string CreateFor(string title, string exe)
	{
		string text = title;
		int num = 2;
		while (true)
		{
			IntPtr intPtr = Unicode(text);
			int num2;
			try
			{
				num2 = Api<FindProfile>(2118818315u)(session, intPtr, out var _);
			}
			finally
			{
				Marshal.FreeHGlobal(intPtr);
			}
			if (num2 != 0)
			{
				break;
			}
			text = title + " (" + num + ")";
			num++;
		}
		IntPtr intPtr3 = Marshal.AllocHGlobal(4116);
		IntPtr intPtr4 = Marshal.AllocHGlobal(12296);
		try
		{
			Marshal.Copy(new byte[4116], 0, intPtr3, 4116);
			Marshal.WriteInt32(intPtr3, 69652);
			byte[] bytes = Encoding.Unicode.GetBytes(text + "\0");
			Marshal.Copy(bytes, 0, IntPtr.Add(intPtr3, 4), Math.Min(bytes.Length, 4094));
			Check(Api<NewProfile>(3424084072u)(session, intPtr3, out var intPtr5));
			Marshal.Copy(new byte[12296], 0, intPtr4, 12296);
			Marshal.WriteInt32(intPtr4, 77832);
			byte[] bytes2 = Encoding.Unicode.GetBytes(exe + "\0");
			Marshal.Copy(bytes2, 0, IntPtr.Add(intPtr4, 8), Math.Min(bytes2.Length, 4094));
			Marshal.Copy(bytes, 0, IntPtr.Add(intPtr4, 4104), Math.Min(bytes.Length, 4094));
			Check(Api<NewApp>(1128770014u)(session, intPtr5, intPtr4));
			return text;
		}
		finally
		{
			Marshal.FreeHGlobal(intPtr3);
			Marshal.FreeHGlobal(intPtr4);
		}
	}

	public static byte[] Dword(uint id, uint value)
	{
		byte[] array = Empty(id);
		Put(array, 8220, value);
		return array;
	}

	public static byte[] String(uint id, string value)
	{
		byte[] array = Empty(id);
		Put(array, 4104, 3u);
		byte[] bytes = Encoding.Unicode.GetBytes(value + "\0");
		if (bytes.Length > 4096)
		{
			throw new IOException("NVIDIA string setting is too long.");
		}
		Array.Copy(bytes, 0, array, 8220, bytes.Length);
		return array;
	}

	internal static bool EqualValue(byte[] actual, byte[] expected)
	{
		if (actual == null || BitConverter.ToUInt32(actual, 4104) != BitConverter.ToUInt32(expected, 4104))
		{
			return false;
		}
		if (BitConverter.ToUInt32(expected, 4104) != 0)
		{
			string @string = Encoding.Unicode.GetString(actual, 8220, 4096);
			char[] trimChars = new char[1];
			string text = @string.TrimEnd(trimChars);
			string string2 = Encoding.Unicode.GetString(expected, 8220, 4096);
			char[] trimChars2 = new char[1];
			return text == string2.TrimEnd(trimChars2);
		}
		return BitConverter.ToUInt32(actual, 8220) == BitConverter.ToUInt32(expected, 8220);
	}

	public void Dispose()
	{
		if (session != IntPtr.Zero)
		{
			Api<SessionCall>(3671707640u)(session);
			session = IntPtr.Zero;
		}
		if (initialized)
		{
			initialized = false;
			Api<Init>(3526090110u)();
		}
	}
}
