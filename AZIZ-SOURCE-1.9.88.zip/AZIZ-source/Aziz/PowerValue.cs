namespace Aziz;

internal class PowerValue
{
	public string Key { get; set; }

	public uint AC { get; set; }

	public uint DC { get; set; }
}
