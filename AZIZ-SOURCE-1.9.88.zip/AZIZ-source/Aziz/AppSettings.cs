﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Aziz;

internal class AppSettings
{
	public bool CompactControls { get; set; }

	public bool ShowInstalledDownloads { get; set; }

	public bool HideAvailableDownloads { get; set; }

	public int Logo { get; set; }

	public bool Light { get; set; }

	public string Theme { get; set; }

	public string Language { get; set; }

	public bool StartMinimized { get; set; }

	public bool CloseToTray { get; set; }

	public bool Minimal { get; set; }

	public bool Sounds { get; set; }

	public int MonitorSeconds { get; set; }

	public int Version { get; set; }

	public string InspectorVersion { get; set; }

	public string ActiveProfile { get; set; }

	public bool ProfileAutoSave { get; set; }

	public bool BackupPointCreated { get; set; }

	public bool EdgeRemovalDone { get; set; }

	public bool ShowTemperatures { get; set; }

	public bool FirstRunDone { get; set; }

	public bool AutoMemoryClean { get; set; }

	public bool StartWithWindows { get; set; }

	public string StartupPath { get; set; }

	public int WallpaperStyle { get; set; }

	// True once the user picked a wallpaper with the Set wallpaper buttons; until then Optimize uses the official one (Horizon).
	public bool WallpaperPicked { get; set; }

	public double WindowWidth { get; set; }

	public double WindowHeight { get; set; }

	public List<string> CollapsedGroups { get; set; }

	public List<string> ExpandedGroups { get; set; }

	public Dictionary<string, string> CardOrder { get; set; }

	public AppSettings()
	{
		Logo = 1;
		Theme = "Purple";
		Language = "English";
		MonitorSeconds = 1;
		Sounds = true;
		AutoMemoryClean = true;
		CloseToTray = true;
		Version = 21;
		WallpaperStyle = 0;
		CollapsedGroups = new List<string>();
		ExpandedGroups = new List<string>();
		CardOrder = new Dictionary<string, string>();
	}

	public static AppSettings Load()
	{
		try
		{
			string path = Path.Combine(Program.Data, "settings.json");
			AppSettings appSettings = (File.Exists(path) ? Program.Json.Deserialize<AppSettings>(File.ReadAllText(path)) : new AppSettings());
			appSettings.Logo = 1;
			if (appSettings.Version < 19)
			{
				appSettings.MonitorSeconds = 1;
				appSettings.HideAvailableDownloads = false;
				appSettings.Version = 19;
			}
			if (appSettings.Version < 20)
			{
				appSettings.CloseToTray = true;
				appSettings.MonitorSeconds = 1;
				appSettings.Version = 20;
			}
			if (appSettings.Version < 21)
			{
				// 1.9.7: opening, closing and click sounds are on by default (turn them off in Settings).
				appSettings.Sounds = true;
				appSettings.Version = 21;
			}
			appSettings.MonitorSeconds = Math.Max(1, Math.Min(30, appSettings.MonitorSeconds));
			if (appSettings.CollapsedGroups == null)
			{
				appSettings.CollapsedGroups = new List<string>();
			}
			if (appSettings.ExpandedGroups == null)
			{
				appSettings.ExpandedGroups = new List<string>();
			}
			if (appSettings.CardOrder == null)
			{
				appSettings.CardOrder = new Dictionary<string, string>();
			}
			return appSettings;
		}
		catch
		{
			return new AppSettings();
		}
	}

	public void Save()
	{
		Utilities.AtomicWrite(Path.Combine(Program.Data, "settings.json"), Program.Json.Serialize(this));
	}
}
