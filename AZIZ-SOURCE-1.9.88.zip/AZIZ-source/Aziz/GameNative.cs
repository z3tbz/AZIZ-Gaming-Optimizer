using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;

namespace Aziz;

internal static class GameNative
{
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	private struct Privilege
	{
		public uint Count;

		public long Luid;

		public uint Attributes;
	}

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern IntPtr OpenProcess(uint access, bool inherit, int id);

	[DllImport("kernel32.dll")]
	private static extern bool CloseHandle(IntPtr h);

	[DllImport("ntdll.dll")]
	private static extern int NtQueryInformationProcess(IntPtr h, int kind, out int value, int size, out int read);

	[DllImport("ntdll.dll")]
	private static extern int NtSetInformationProcess(IntPtr h, int kind, ref int value, int size);

	[DllImport("gdi32.dll")]
	private static extern int D3DKMTGetProcessSchedulingPriorityClass(IntPtr h, out int value);

	[DllImport("gdi32.dll")]
	private static extern int D3DKMTSetProcessSchedulingPriorityClass(IntPtr h, int value);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool GetSystemCpuSetInformation(IntPtr data, uint len, out uint required, IntPtr process, uint flags);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool GetProcessDefaultCpuSets(IntPtr h, [Out] uint[] data, uint count, out uint required);

	[DllImport("kernel32.dll", SetLastError = true)]
	private static extern bool SetProcessDefaultCpuSets(IntPtr h, uint[] data, uint count);

	[DllImport("ntdll.dll")]
	private static extern int NtSetSystemInformation(int kind, ref int value, int size);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool OpenProcessToken(IntPtr h, uint access, out IntPtr token);

	[DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
	private static extern bool LookupPrivilegeValue(string system, string name, out long luid);

	[DllImport("advapi32.dll", SetLastError = true)]
	private static extern bool AdjustTokenPrivileges(IntPtr token, bool disable, ref Privilege privileges, uint size, IntPtr previous, IntPtr returned);

	public static void PrivilegeOn(string name)
	{
		if (!OpenProcessToken(Process.GetCurrentProcess().Handle, 40u, out var token))
		{
			throw new Win32Exception();
		}
		try
		{
			if (!LookupPrivilegeValue(null, name, out var luid))
			{
				throw new Win32Exception();
			}
			Privilege privilege = default(Privilege);
			privilege.Count = 1u;
			privilege.Luid = luid;
			privilege.Attributes = 2u;
			Privilege privileges = privilege;
			if (!AdjustTokenPrivileges(token, disable: false, ref privileges, 0u, IntPtr.Zero, IntPtr.Zero) || Marshal.GetLastWin32Error() != 0)
			{
				throw new InvalidOperationException("Windows did not grant " + name);
			}
		}
		finally
		{
			CloseHandle(token);
		}
	}

	public static List<CpuUnit> CpuTopology()
	{
		List<CpuUnit> list = new List<CpuUnit>();
		try
		{
			GetSystemCpuSetInformation(IntPtr.Zero, 0u, out var required, IntPtr.Zero, 0u);
			if (required == 0 || required > 1048576)
			{
				return list;
			}
			IntPtr intPtr = Marshal.AllocHGlobal((int)required);
			try
			{
				if (!GetSystemCpuSetInformation(intPtr, required, out required, IntPtr.Zero, 0u))
				{
					return list;
				}
				int num;
				for (int i = 0; i + 24 <= required; i += num)
				{
					num = Marshal.ReadInt32(intPtr, i);
					if (num >= 24 && i + num <= required)
					{
						if (Marshal.ReadInt32(intPtr, i + 4) == 0)
						{
							list.Add(new CpuUnit
							{
								Id = (uint)Marshal.ReadInt32(intPtr, i + 8),
								Group = (ushort)Marshal.ReadInt16(intPtr, i + 12),
								Index = Marshal.ReadByte(intPtr, i + 14),
								Core = Marshal.ReadByte(intPtr, i + 15)
							});
						}
						continue;
					}
					break;
				}
			}
			finally
			{
				Marshal.FreeHGlobal(intPtr);
			}
			foreach (IGrouping<string, CpuUnit> item in from x in list
				group x by x.Group + ":" + x.Core)
			{
				foreach (CpuUnit item2 in item.OrderBy((CpuUnit x) => x.Index).Skip(1))
				{
					item2.Smt = true;
				}
			}
		}
		catch
		{
		}
		return list;
	}

	public static int EfficiencyClasses()
	{
		HashSet<byte> hashSet = new HashSet<byte>();
		try
		{
			GetSystemCpuSetInformation(IntPtr.Zero, 0u, out var required, IntPtr.Zero, 0u);
			if (required == 0 || required > 1048576)
			{
				return 1;
			}
			IntPtr intPtr = Marshal.AllocHGlobal((int)required);
			try
			{
				if (!GetSystemCpuSetInformation(intPtr, required, out required, IntPtr.Zero, 0u))
				{
					return 1;
				}
				int num;
				for (int i = 0; i + 24 <= required; i += num)
				{
					num = Marshal.ReadInt32(intPtr, i);
					if (num >= 24 && i + num <= required)
					{
						if (Marshal.ReadInt32(intPtr, i + 4) == 0)
						{
							hashSet.Add(Marshal.ReadByte(intPtr, i + 18));
						}
						continue;
					}
					break;
				}
			}
			finally
			{
				Marshal.FreeHGlobal(intPtr);
			}
		}
		catch
		{
		}
		return Math.Max(1, hashSet.Count);
	}

	public static ProcessBackup Capture(Process process, bool gpu, bool io, bool sets)
	{
		process.Refresh();
		ProcessBackup processBackup = new ProcessBackup
		{
			Pid = process.Id,
			Started = process.StartTime.ToUniversalTime().Ticks,
			Cpu = process.PriorityClass.ToString()
		};
		IntPtr intPtr = OpenProcess(5120u, inherit: false, process.Id);
		if (intPtr == IntPtr.Zero)
		{
			throw new Win32Exception();
		}
		try
		{
			if (gpu && D3DKMTGetProcessSchedulingPriorityClass(intPtr, out var value) == 0)
			{
				processBackup.Gpu = value;
			}
			if (io && NtQueryInformationProcess(intPtr, 33, out value, 4, out var _) == 0)
			{
				processBackup.Io = value;
			}
			if (sets)
			{
				uint required;
				bool processDefaultCpuSets = GetProcessDefaultCpuSets(intPtr, null, 0u, out required);
				if (required == 0 && processDefaultCpuSets)
				{
					processBackup.Sets = new uint[0];
				}
				else if (required != 0 && required < 4096)
				{
					uint[] array = new uint[required];
					if (GetProcessDefaultCpuSets(intPtr, array, required, out required))
					{
						processBackup.Sets = array;
					}
				}
			}
		}
		finally
		{
			CloseHandle(intPtr);
		}
		return processBackup;
	}

	public static List<string> Apply(Process process, ProcessBackup saved, GameRule rule)
	{
		List<string> list = new List<string>();
		try
		{
			process.PriorityClass = (ProcessPriorityClass)Enum.Parse(typeof(ProcessPriorityClass), rule.Cpu);
			process.Refresh();
			if (process.PriorityClass.ToString() != rule.Cpu)
			{
				throw new Exception("Readback mismatch");
			}
		}
		catch (Exception ex)
		{
			list.Add("CPU: " + ex.Message);
		}
		IntPtr intPtr = OpenProcess(5632u, inherit: false, process.Id);
		if (intPtr == IntPtr.Zero)
		{
			list.Add("GPU / I/O / CPU sets: access denied by Windows or the game");
			return list;
		}
		try
		{
			if (saved.Gpu.HasValue)
			{
				int num = D3DKMTSetProcessSchedulingPriorityClass(intPtr, rule.Gpu);
				if (num != 0 || D3DKMTGetProcessSchedulingPriorityClass(intPtr, out var value) != 0 || value != rule.Gpu)
				{
					list.Add("GPU scheduling was not accepted (0x" + num.ToString("X8") + ")");
				}
			}
			else if (rule.Gpu != 2)
			{
				list.Add("GPU priority could not be read; unchanged.");
			}
			if (saved.Io.HasValue)
			{
				try
				{
					if (rule.Io == 3)
					{
						PrivilegeOn("SeIncreaseBasePriorityPrivilege");
					}
					int value2 = rule.Io;
					int num2 = NtSetInformationProcess(intPtr, 33, ref value2, 4);
					if (num2 != 0 || NtQueryInformationProcess(intPtr, 33, out var value3, 4, out var _) != 0 || value3 != value2)
					{
						list.Add("I/O priority was not accepted (0x" + num2.ToString("X8") + ")");
					}
				}
				catch (Exception ex2)
				{
					list.Add("I/O: " + ex2.Message);
				}
			}
			else if (rule.Io != 2)
			{
				list.Add("I/O priority could not be read; unchanged.");
			}
			if (saved.Sets != null)
			{
				uint[] array = rule.CpuSets ?? new uint[0];
				if (!SetProcessDefaultCpuSets(intPtr, (array.Length == 0) ? null : array, (uint)array.Length))
				{
					list.Add("CPU sets: " + new Win32Exception().Message);
				}
				else
				{
					uint[] sets = Capture(process, gpu: false, io: false, sets: true).Sets;
					if (sets == null || !sets.OrderBy((uint x) => x).SequenceEqual(array.OrderBy((uint x) => x)))
					{
						list.Add("CPU sets: readback mismatch");
					}
				}
			}
			else if (rule.CpuSets != null && rule.CpuSets.Length != 0)
			{
				list.Add("CPU sets could not be read; unchanged.");
			}
		}
		finally
		{
			CloseHandle(intPtr);
		}
		return list;
	}

	public static bool Restore(ProcessBackup b)
	{
		try
		{
			using Process process = Process.GetProcessById(b.Pid);
			if (process.StartTime.ToUniversalTime().Ticks != b.Started)
			{
				return true;
			}
			GameRule rule = new GameRule
			{
				Cpu = b.Cpu,
				Gpu = (b.Gpu ?? 2),
				Io = (b.Io ?? 2),
				CpuSets = b.Sets
			};
			return Apply(process, b, rule).Count == 0;
		}
		catch (ArgumentException)
		{
			return true;
		}
		catch
		{
			return false;
		}
	}

	public static void ClearStandby()
	{
		PrivilegeOn("SeProfileSingleProcessPrivilege");
		int value = 4;
		int num = NtSetSystemInformation(80, ref value, 4);
		if (num != 0)
		{
			throw new InvalidOperationException("Windows rejected standby cleanup (0x" + num.ToString("X8") + ")");
		}
	}
}
