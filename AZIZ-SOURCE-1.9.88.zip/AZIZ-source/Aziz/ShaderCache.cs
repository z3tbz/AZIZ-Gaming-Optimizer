using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Aziz;

internal static class ShaderCache
{
	public static string[] Roots()
	{
		string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
		return new string[7] { "D3DSCache", "NVIDIA\\DXCache", "NVIDIA\\GLCache", "NVIDIA\\VkCache", "AMD\\DxCache", "AMD\\DxcCache", "AMD\\GLCache" }.Select((string x) => Path.Combine(local, x)).ToArray();
	}

	public static CacheResult ProcessRoots(IEnumerable<string> roots, bool remove)
	{
		CacheResult cacheResult = new CacheResult();
		foreach (string root in roots)
		{
			string text = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
			if (Directory.Exists(text))
			{
				if (HasReparseAncestor(text))
				{
					cacheResult.Skipped++;
				}
				else
				{
					Walk(text, text, remove, cacheResult);
				}
			}
		}
		return cacheResult;
	}

	private static bool HasReparseAncestor(string path)
	{
		try
		{
			for (DirectoryInfo directoryInfo = new DirectoryInfo(path); directoryInfo != null; directoryInfo = directoryInfo.Parent)
			{
				if ((directoryInfo.Attributes & FileAttributes.ReparsePoint) != 0)
				{
					return true;
				}
			}
			return false;
		}
		catch
		{
			return true;
		}
	}

	private static void Walk(string dir, string root, bool remove, CacheResult r)
	{
		if (!Path.GetFullPath(dir).StartsWith(root, StringComparison.OrdinalIgnoreCase))
		{
			throw new IOException("Cache path escaped its root.");
		}
		try
		{
			if ((File.GetAttributes(dir) & FileAttributes.ReparsePoint) != 0)
			{
				r.Skipped++;
				return;
			}
			string[] files = Directory.GetFiles(dir);
			foreach (string text in files)
			{
				try
				{
					if (!Path.GetFullPath(text).StartsWith(root, StringComparison.OrdinalIgnoreCase) || (File.GetAttributes(text) & FileAttributes.ReparsePoint) != 0)
					{
						r.Skipped++;
						continue;
					}
					long length = new FileInfo(text).Length;
					if (remove)
					{
						File.Delete(text);
					}
					r.Files++;
					r.Bytes += length;
				}
				catch
				{
					r.Skipped++;
				}
			}
			files = Directory.GetDirectories(dir);
			for (int i = 0; i < files.Length; i++)
			{
				Walk(files[i], root, remove, r);
			}
		}
		catch
		{
			r.Skipped++;
		}
	}
}
