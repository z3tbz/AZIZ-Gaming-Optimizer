using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aziz;

internal static class UltraLite
{
	internal static string LedgerPath => Path.Combine(Program.Data, "UltraLite", "removed.json");

	internal static string PendingPath => Path.Combine(Program.Data, "UltraLite", "pending.json");

	internal static string BatPath(string folder)
	{
		string text = Path.Combine(folder, "aziz-debloat.json");
		File.WriteAllText(text, DebloatList.Json(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
		return text;
	}

	internal static string Script()
	{
		using Stream stream = typeof(UltraLite).Assembly.GetManifestResourceStream("Aziz.UltraLite.ps1");
		using StreamReader streamReader = new StreamReader(stream);
		return streamReader.ReadToEnd();
	}

	private static string Quote(string s)
	{
		return "'" + s.Replace("'", "''") + "'";
	}

	internal static void Remember(IEnumerable<string> ids)
	{
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		try
		{
			dictionary = Program.Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(LedgerPath)) ?? dictionary;
		}
		catch
		{
		}
		foreach (string id in ids)
		{
			dictionary[id] = DateTime.Now.ToString("d MMM yyyy", CultureInfo.GetCultureInfo("en-US"));
		}
		Utilities.AtomicWrite(LedgerPath, Program.Json.Serialize(dictionary));
		Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
		try
		{
			dictionary2 = Program.Json.Deserialize<Dictionary<string, string>>(File.ReadAllText(PendingPath)) ?? dictionary2;
		}
		catch
		{
		}
		foreach (string id2 in ids)
		{
			dictionary2[id2] = DateTime.UtcNow.ToString("o");
		}
		Utilities.AtomicWrite(PendingPath, Program.Json.Serialize(dictionary2));
	}

	public static string Run(string mode, IEnumerable<string> selected, string report)
	{
		string text = Path.Combine(Program.Data, "UltraLite");
		Directory.CreateDirectory(text);
		// The script runs with admin rights: it is written into AZIZ's admin-only work folder, where no normal program can
		// change it before it runs.
		string text2 = Path.Combine(SecureWork.NewFolder("debloat"), "deep-debloat.ps1");
		File.WriteAllText(text2, Script(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
		string script = "& " + Quote(text2) + " -Mode " + mode + " -Ledger " + Quote(LedgerPath) + " -Pending " + Quote(PendingPath) + " -Bat " + Quote(BatPath(text)) + ((report == null) ? "" : (" -ReportPath " + Quote(report))) + " -Selected @(" + string.Join(",", selected.Select(Quote)) + ")";
		try
		{
			using Process process = Process.Start(new ProcessStartInfo(Utilities.Tool("powershell.exe"), GameWatch.PsArgs(script))
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				StandardOutputEncoding = Encoding.UTF8
			});
			Task<string> task = process.StandardOutput.ReadToEndAsync();
			Task<string> task2 = process.StandardError.ReadToEndAsync();
			process.WaitForExit();
			Task.WaitAll(task, task2);
			if (process.ExitCode != 0)
			{
				throw new IOException(Utilities.CleanMessage(task2.Result + " " + task.Result));
			}
			return task.Result;
		}
		finally
		{
			try
			{
				Directory.Delete(Path.GetDirectoryName(text2), recursive: true);
			}
			catch
			{
			}
		}
	}

	public static List<DebloatRow> Plan()
	{
		return Program.Json.Deserialize<List<DebloatRow>>(Run("Plan", new string[0], null));
	}
}
