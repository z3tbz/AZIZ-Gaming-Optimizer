namespace Aziz;

internal class ShortcutItem
{
	public string Name { get; set; }

	public string Description { get; set; }

	public string Category { get; set; }

	public string Kind { get; set; }

	public string Target { get; set; }

	public string Arguments { get; set; }

	public bool Elevate { get; set; }
}
