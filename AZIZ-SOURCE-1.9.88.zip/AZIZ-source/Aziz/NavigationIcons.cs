using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Aziz;

internal static class NavigationIcons
{
	public static FrameworkElement View(string page, Brush color)
	{
		string source;
		switch (page)
		{
		case "Tweaks":
		{
			Path path = new Path();
			path.Data = Geometry.Parse("M 66,0 L 16,72 L 46,72 L 28,132 L 90,44 L 58,44 L 80,0 Z");
			path.Fill = new LinearGradientBrush(Color.FromRgb(byte.MaxValue, 224, 138), Color.FromRgb(214, 120, 0), 90.0);
			path.Stretch = Stretch.Uniform;
			path.Width = 16.0;
			path.Height = 23.0;
			path.HorizontalAlignment = HorizontalAlignment.Left;
			path.Margin = new Thickness(3.0, 0.0, 0.0, 0.0);
			return new Border
			{
				Width = 29.0,
				Height = 26.0,
				Child = path
			};
		}
		case "Power plans":
			source = "M3,6 L19,6 L19,20 L3,20 Z M19,10 L22,10 L22,16 L19,16 M6,9 L6,17 M9,9 L9,17 M12,9 L12,17";
			break;
		case "Downloads":
			source = "M12,2 L12,16 M6,10 L12,16 L18,10 M3,17 L3,22 L21,22 L21,17";
			color = Brushes.DeepSkyBlue;
			break;
		case "Security":
			source = "M12,2 L21,6 L20,15 Q18,20 12,23 Q6,20 4,15 L3,6 Z M7,12 L11,16 L17,9";
			break;
		case "Uninstaller":
			source = "M3,5 L21,5 M8,5 L8,2 L16,2 L16,5 M5,5 L6,21 L18,21 L19,5 M9,9 L9,17 M15,9 L15,17 M1,23 L23,23";
			break;
		case "Network":
			source = "M2,7 Q12,-1 22,7 M5,11 Q12,5 19,11 M8,15 Q12,12 16,15 M12,19 L12,21";
			break;
		case "Home":
			source = "M2,11 L12,2 L22,11 M5,9 L5,22 L10,22 L10,15 L15,15 L15,22 L20,22 L20,9";
			break;
		case "Toggles":
			source = "M3,5 L22,5 M3,12 L22,12 M3,19 L22,19 M7,2 L7,8 M17,9 L17,15 M9,16 L9,22";
			break;
		case "Services":
			return new Grid
			{
				Width = 29.0,
				Height = 26.0,
				Children = 
				{
					(UIElement)new TextBlock
					{
						Text = "\ue713",
						FontFamily = new FontFamily("Segoe MDL2 Assets"),
						FontSize = 20.0,
						Foreground = color,
						Margin = new Thickness(0.0, 0.0, 7.0, 6.0)
					},
					(UIElement)new TextBlock
					{
						Text = "\ue713",
						FontFamily = new FontFamily("Segoe MDL2 Assets"),
						FontSize = 11.0,
						Foreground = color,
						HorizontalAlignment = HorizontalAlignment.Right,
						VerticalAlignment = VerticalAlignment.Bottom,
						Margin = new Thickness(0.0, 0.0, 2.0, 1.0)
					}
				}
			};
		default:
		{
			string text = page switch
			{
				"Favorites" => "\ue734", 
				"Shortcuts" => "\ue71b", 
				"Tools" => "\ue90f", 
				_ => "\ue946", 
			};
			return new TextBlock
			{
				Text = text,
				FontFamily = new FontFamily("Segoe MDL2 Assets"),
				FontSize = 20.0,
				Width = 29.0,
				Foreground = color,
				VerticalAlignment = VerticalAlignment.Center
			};
		}
		}
		Path path2 = new Path
		{
			Data = Geometry.Parse(source),
			Stroke = color,
			StrokeThickness = 1.8,
			StrokeLineJoin = PenLineJoin.Round,
			StrokeStartLineCap = PenLineCap.Round,
			StrokeEndLineCap = PenLineCap.Round,
			Stretch = Stretch.Uniform,
			Width = 22.0,
			Height = 22.0,
			HorizontalAlignment = HorizontalAlignment.Left
		};
		return new Border
		{
			Width = 29.0,
			Height = 26.0,
			Child = path2
		};
	}
}
