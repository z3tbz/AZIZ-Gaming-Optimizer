namespace Aziz;

internal sealed class PendingChange
{
	public Tweak T;

	public bool Enabled;

	public string Choice;

	public bool Restore;

	public int Version;
}
