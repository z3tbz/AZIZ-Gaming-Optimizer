using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;

namespace Aziz;

internal sealed class WindowsPowerControlStore : IPowerControlStore
{
	[DllImport("powrprof.dll")]
	private static extern uint PowerGetActiveScheme(IntPtr root, out IntPtr scheme);

	[DllImport("kernel32.dll")]
	private static extern IntPtr LocalFree(IntPtr pointer);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadACValueIndex(IntPtr root, ref Guid scheme, ref Guid group, ref Guid setting, out uint value);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadDCValueIndex(IntPtr root, ref Guid scheme, ref Guid group, ref Guid setting, out uint value);

	[DllImport("powrprof.dll")]
	private static extern uint PowerWriteACValueIndex(IntPtr root, ref Guid scheme, ref Guid group, ref Guid setting, uint value);

	[DllImport("powrprof.dll")]
	private static extern uint PowerWriteDCValueIndex(IntPtr root, ref Guid scheme, ref Guid group, ref Guid setting, uint value);

	[DllImport("powrprof.dll")]
	private static extern uint PowerSetActiveScheme(IntPtr root, ref Guid scheme);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadACValue(IntPtr root, ref Guid scheme, ref Guid group, ref Guid setting, out uint type, byte[] buffer, ref uint size);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadACDefaultIndex(IntPtr root, ref Guid personality, ref Guid group, ref Guid setting, out uint value);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadDCDefaultIndex(IntPtr root, ref Guid personality, ref Guid group, ref Guid setting, out uint value);

	[DllImport("powrprof.dll")]
	private static extern uint PowerReadPossibleValue(IntPtr root, ref Guid group, ref Guid setting, out uint type, uint index, byte[] buffer, ref uint size);

	private static void Check(uint error)
	{
		if (error != 0)
		{
			throw new Win32Exception((int)error);
		}
	}

	public Guid Active()
	{
		Check(PowerGetActiveScheme(IntPtr.Zero, out var scheme));
		try
		{
			return (Guid)Marshal.PtrToStructure(scheme, typeof(Guid));
		}
		finally
		{
			LocalFree(scheme);
		}
	}

	public uint Read(Guid scheme, PowerParameter setting, bool battery)
	{
		Guid group = setting.Group;
		Guid setting2 = setting.Id;
		Check(battery ? PowerReadDCValueIndex(IntPtr.Zero, ref scheme, ref group, ref setting2, out var value) : PowerReadACValueIndex(IntPtr.Zero, ref scheme, ref group, ref setting2, out value));
		return value;
	}

	public Guid Personality(Guid scheme)
	{
		Guid group = new Guid("fea3413e-7e05-4911-9a71-700331f1c294");
		Guid setting = new Guid("245d8541-3943-4422-b025-13a784f679b7");
		byte[] array = new byte[16];
		uint size = 16u;
		Check(PowerReadACValue(IntPtr.Zero, ref scheme, ref group, ref setting, out var _, array, ref size));
		if (size != 16)
		{
			throw new IOException("Windows did not return this plan's default personality.");
		}
		return new Guid(array);
	}

	public uint Default(Guid scheme, PowerParameter setting, bool battery)
	{
		Guid personality = Personality(scheme);
		Guid group = setting.Group;
		Guid setting2 = setting.Id;
		Check(battery ? PowerReadDCDefaultIndex(IntPtr.Zero, ref personality, ref group, ref setting2, out var value) : PowerReadACDefaultIndex(IntPtr.Zero, ref personality, ref group, ref setting2, out value));
		return value;
	}

	public void Write(Guid scheme, PowerParameter setting, bool battery, uint value)
	{
		Guid group = setting.Group;
		Guid setting2 = setting.Id;
		Check(battery ? PowerWriteDCValueIndex(IntPtr.Zero, ref scheme, ref group, ref setting2, value) : PowerWriteACValueIndex(IntPtr.Zero, ref scheme, ref group, ref setting2, value));
	}

	public void Refresh(Guid scheme)
	{
		if (Active() == scheme)
		{
			Check(PowerSetActiveScheme(IntPtr.Zero, ref scheme));
		}
	}

	public static uint[] Possible(PowerParameter setting)
	{
		List<uint> list = new List<uint>();
		for (uint num = 0u; num < 32; num++)
		{
			Guid group = setting.Group;
			Guid setting2 = setting.Id;
			uint size = 4u;
			byte[] array = new byte[4];
			if (PowerReadPossibleValue(IntPtr.Zero, ref group, ref setting2, out var _, num, array, ref size) != 0)
			{
				break;
			}
			if (size == 4)
			{
				list.Add(BitConverter.ToUInt32(array, 0));
			}
		}
		return list.ToArray();
	}
}
