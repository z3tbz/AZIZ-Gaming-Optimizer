using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Aziz;

internal static class AppInventory
{
	public static List<DesktopApp> Read()
	{
		List<DesktopApp> list = new List<DesktopApp>();
		RegistryHive[] array = new RegistryHive[2]
		{
			RegistryHive.LocalMachine,
			RegistryHive.CurrentUser
		};
		for (int i = 0; i < array.Length; i++)
		{
			RegistryHive hKey = array[i];
			RegistryView[] array2 = new RegistryView[2]
			{
				RegistryView.Registry64,
				RegistryView.Registry32
			};
			foreach (RegistryView view in array2)
			{
				using RegistryKey registryKey = RegistryKey.OpenBaseKey(hKey, view);
				using RegistryKey registryKey2 = registryKey.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall");
				if (registryKey2 == null)
				{
					continue;
				}
				string[] subKeyNames = registryKey2.GetSubKeyNames();
				foreach (string text in subKeyNames)
				{
					try
					{
						using RegistryKey registryKey3 = registryKey2.OpenSubKey(text);
						string text2 = Convert.ToString(registryKey3.GetValue("DisplayName"));
						string text3 = Convert.ToString(registryKey3.GetValue("UninstallString"));
						if (!string.IsNullOrWhiteSpace(text2) && !string.IsNullOrWhiteSpace(text3) && Convert.ToInt32(registryKey3.GetValue("SystemComponent", 0)) != 1)
						{
							list.Add(new DesktopApp
							{
								Name = text2,
								Version = Convert.ToString(registryKey3.GetValue("DisplayVersion")),
								Publisher = Convert.ToString(registryKey3.GetValue("Publisher")),
								Command = text3,
								Icon = Convert.ToString(registryKey3.GetValue("DisplayIcon")),
								InstallLocation = Convert.ToString(registryKey3.GetValue("InstallLocation")),
								Hive = hKey.ToString(),
								View = view,
								KeyPath = "Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\" + text
							});
						}
					}
					catch
					{
					}
				}
			}
		}
		foreach (DesktopApp item in list)
		{
			AppIcons.Load(item.Icon);
		}
		return (from x in list
			group x by x.Name + "|" + x.Command into g
			select g.First() into x
			orderby x.Name
			select x).ToList();
	}

	public static ActionResult Remove(DesktopApp app)
	{
		try
		{
			string input = Environment.ExpandEnvironmentVariables(app.Command).Trim();
			Match match = Regex.Match(input, "^\"([^\"]+)\"\\s*(.*)$");
			string text;
			string text2;
			if (match.Success)
			{
				text = match.Groups[1].Value;
				text2 = match.Groups[2].Value;
			}
			else
			{
				Match match2 = Regex.Match(input, "^(.+?\\.exe)\\s*(.*)$", RegexOptions.IgnoreCase);
				if (!match2.Success)
				{
					return new ActionResult
					{
						Message = "This application's uninstall command needs Windows Settings."
					};
				}
				text = match2.Groups[1].Value;
				text2 = match2.Groups[2].Value;
			}
			if (Path.GetFileName(text).Equals("msiexec.exe", StringComparison.OrdinalIgnoreCase))
			{
				text = Path.Combine(Environment.SystemDirectory, "msiexec.exe");
				text2 = Regex.Replace(text2, "(^|\\s)/I(?=\\s|\\{)", "$1/X", RegexOptions.IgnoreCase);
			}
			using (Process process = Process.Start(new ProcessStartInfo(text, text2)
			{
				UseShellExecute = true
			}))
			{
				if (process != null && !process.WaitForExit(1800000))
				{
					return new ActionResult
					{
						Message = "The vendor uninstaller is still running."
					};
				}
				if (process != null && process.ExitCode != 0 && process.ExitCode != 3010)
				{
					return new ActionResult
					{
						Message = "Vendor uninstaller exited with code " + process.ExitCode
					};
				}
			}
			using RegistryKey registryKey = RegistryKey.OpenBaseKey((app.Hive == "LocalMachine") ? RegistryHive.LocalMachine : RegistryHive.CurrentUser, app.View);
			using RegistryKey registryKey2 = registryKey.OpenSubKey(app.KeyPath);
			bool flag = registryKey2 == null;
			return new ActionResult
			{
				Success = flag,
				Message = (flag ? "Removal verified: the uninstall registration is gone." : "The vendor uninstaller finished, but the application registration remains. It may require a restart or completion in its own window.")
			};
		}
		catch (Exception ex)
		{
			return new ActionResult
			{
				Message = ex.Message
			};
		}
	}
}
