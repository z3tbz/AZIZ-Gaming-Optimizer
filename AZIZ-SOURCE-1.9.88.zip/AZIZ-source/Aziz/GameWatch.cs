﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using Microsoft.Win32;

namespace Aziz;

internal static class GameWatch
{
	// Read once: on .NET Framework every Process.GetCurrentProcess().SessionId call takes a full process snapshot.
	private static readonly int MySession = CurrentSession();

	private static int CurrentSession()
	{
		using Process process = Process.GetCurrentProcess();
		return process.SessionId;
	}

	private const string Ifeo = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\";

	public static string ConfigPath => Path.Combine(Program.Data, "game-profiles.json");

	private static readonly string[] PausableServices = new string[4] { "SysMain", "WerSvc", "DiagTrack", "WSearch" };

	private static string JournalPath => Path.Combine(Program.Data, "game-session.json");

	public static string TaskName => "AZIZ Game Watch - " + WindowsIdentity.GetCurrent().User.Value;

	public static GameConfig Load()
	{
		try
		{
			return Program.Json.Deserialize<GameConfig>(File.ReadAllText(ConfigPath)) ?? new GameConfig();
		}
		catch
		{
			return new GameConfig();
		}
	}

	private static DateTime loadedStamp;

	private static GameConfig loaded;

	// The watcher loop asks every five seconds; the file is parsed again only after AZIZ saved it.
	private static GameConfig LoadIfChanged()
	{
		DateTime stamp;
		try
		{
			stamp = File.GetLastWriteTimeUtc(ConfigPath);
		}
		catch
		{
			stamp = DateTime.MinValue;
		}
		if (loaded == null || stamp != loadedStamp)
		{
			loaded = Load();
			loadedStamp = stamp;
		}
		return loaded;
	}

	public static void Save(GameConfig c)
	{
		foreach (GameRule rule in c.Rules)
		{
			Validate(rule);
		}
		Utilities.AtomicWrite(ConfigPath, Program.Json.Serialize(c));
	}

	public static void Validate(GameRule r)
	{
		if (r == null || string.IsNullOrEmpty(r.Exe) || !Path.IsPathRooted(r.Exe) || !r.Exe.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) || r.Exe.Contains("\"") || r.Exe.StartsWith("\\\\"))
		{
			throw new InvalidDataException("Choose a local game executable.");
		}
		if (!new string[5] { "Idle", "BelowNormal", "Normal", "AboveNormal", "High" }.Contains(r.Cpu) || r.Gpu < 0 || r.Gpu > 4 || r.Io < 0 || r.Io > 3)
		{
			throw new InvalidDataException("Invalid priority profile.");
		}
		if (r.CpuSets != null && (r.CpuSets.Length > 4096 || r.CpuSets.Distinct().Count() != r.CpuSets.Length))
		{
			throw new InvalidDataException("Invalid CPU sets.");
		}
	}

	public static string PsArgs(string script)
	{
		return "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + Convert.ToBase64String(Encoding.Unicode.GetBytes("$env:PSModulePath=[Environment]::GetEnvironmentVariable('PSModulePath','Machine');$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'; " + script));
	}

	private static string Q(string v)
	{
		return "'" + v.Replace("'", "''") + "'";
	}

	public static void EnsureRunning()
	{
		try
		{
			if (Load().Enabled && Program.IsAdmin)
			{
				AgentFiles.Deploy();
				AgentFiles.Stop(timerService: false, staleOnly: true);
				Utilities.Run("powershell.exe", PsArgs("$t=Get-ScheduledTask -TaskName " + Q(TaskName) + " -ErrorAction SilentlyContinue;if($t -and $t.State -ne 'Running'){Start-ScheduledTask -TaskName " + Q(TaskName) + "}"));
			}
		}
		catch
		{
		}
	}

	public static ActionResult Install()
	{
		if (!Program.IsAdmin)
		{
			return new ActionResult
			{
				Message = "Run AZIZ as administrator to enable the independent game helper."
			};
		}
		try
		{
			try
			{
				SyncIfeo(Load());
			}
			catch (Exception ex)
			{
				Log("Game Watch", "Priority setup pending", ex.Message);
			}
			AgentFiles.Deploy();
			AgentFiles.Stop(timerService: false);
			string exe = AgentFiles.Exe;
			string value = WindowsIdentity.GetCurrent().User.Value;
			string script = "$action=New-ScheduledTaskAction -Execute " + Q(exe) + " -Argument '--game-watch'; $trigger=New-ScheduledTaskTrigger -AtLogOn -User " + Q(value) + "; $principal=New-ScheduledTaskPrincipal -UserId " + Q(value) + " -LogonType Interactive -RunLevel Highest; $settings=New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1); Register-ScheduledTask -TaskName " + Q(TaskName) + " -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null; Start-ScheduledTask -TaskName " + Q(TaskName) + "; $m=Get-ScheduledTask -TaskName " + Q(MemoryCleaner.TaskName) + " -ErrorAction SilentlyContinue; if($m){Start-ScheduledTask -TaskName " + Q(MemoryCleaner.TaskName) + "}; $r=Get-ScheduledTask -TaskName " + Q(ReflexFallback.TaskName) + " -ErrorAction SilentlyContinue; if($r){Start-ScheduledTask -TaskName " + Q(ReflexFallback.TaskName) + "}; 'Independent game monitor registered for this account.'";
			return Utilities.Run("powershell.exe", PsArgs(script));
		}
		catch (Exception ex2)
		{
			return new ActionResult
			{
				Message = ex2.Message
			};
		}
	}

	internal static void SyncIfeo(GameConfig c)
	{
		if (c.ManagedIfeo == null)
		{
			c.ManagedIfeo = new List<string>();
		}
		List<GameRule> list = (c.Enabled ? c.Rules.Where((GameRule x) => x.Enabled && x.Boost && !string.IsNullOrEmpty(x.Exe) && (x.Cpu != "Normal" || x.Io != 2)).ToList() : new List<GameRule>());
		HashSet<string> hashSet = new HashSet<string>(list.Select((GameRule r) => Path.GetFileName(r.Exe)), StringComparer.OrdinalIgnoreCase);
		foreach (string item in c.ManagedIfeo.ToList())
		{
			if (hashSet.Contains(item))
			{
				continue;
			}
			try
			{
				using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + item, writable: true);
				registryKey?.DeleteSubKeyTree("PerfOptions", throwOnMissingSubKey: false);
			}
			catch
			{
			}
			c.ManagedIfeo.Remove(item);
		}
		foreach (GameRule item2 in list)
		{
			string fileName = Path.GetFileName(item2.Exe);
			bool flag;
			using (RegistryKey registryKey2 = Registry.LocalMachine.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + fileName + "\\PerfOptions"))
			{
				flag = registryKey2 != null;
			}
			if (!flag || c.ManagedIfeo.Contains(fileName, StringComparer.OrdinalIgnoreCase))
			{
				using (RegistryKey registryKey3 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\" + fileName + "\\PerfOptions"))
				{
					registryKey3.SetValue("CpuPriorityClass", CompetitiveLaunch.CpuClass(item2.Cpu), RegistryValueKind.DWord);
					registryKey3.SetValue("IoPriority", Math.Min(2, item2.Io), RegistryValueKind.DWord);
				}
				if (!c.ManagedIfeo.Contains(fileName, StringComparer.OrdinalIgnoreCase))
				{
					c.ManagedIfeo.Add(fileName);
				}
			}
		}
		Utilities.AtomicWrite(ConfigPath, Program.Json.Serialize(c));
	}

	internal static void ResetLaunchers(GameConfig c)
	{
		foreach (GameRule item in c.Rules.Where((GameRule x) => x.CpuSets != null && x.CpuSets.Length != 0))
		{
			string[] array = CompetitiveLaunch.LauncherNames(CompetitiveLaunch.LibraryOf(item));
			for (int i = 0; i < array.Length; i++)
			{
				Process[] processesByName = Process.GetProcessesByName(array[i]);
				foreach (Process process in processesByName)
				{
					using (process)
					{
						try
						{
							ulong num = (from u in GameNative.CpuTopology()
								where u.Group == 0 && u.Index < 64
								select u).Aggregate(0uL, (ulong m, CpuUnit u) => m | (ulong)(1L << u.Index));
							if (num != 0L)
							{
								CompetitiveLaunch.SetMask(process.Id, num, out var _);
							}
						}
						catch
						{
						}
					}
				}
			}
		}
	}

	public static ActionResult Disable()
	{
		GameConfig gameConfig = Load();
		gameConfig.Enabled = false;
		try
		{
			Save(gameConfig);
		}
		catch
		{
			Utilities.AtomicWrite(ConfigPath, Program.Json.Serialize(gameConfig));
		}
		try
		{
			SyncIfeo(gameConfig);
			ResetLaunchers(gameConfig);
		}
		catch (Exception ex)
		{
			Log("Game Watch", "Cleanup pending", ex.Message);
		}
		return Utilities.Run("powershell.exe", PsArgs("$t=Get-ScheduledTask -TaskName " + Q(TaskName) + " -ErrorAction SilentlyContinue;if($t){Unregister-ScheduledTask -TaskName " + Q(TaskName) + " -Confirm:$false};'Monitor disabled. Active changes restore when its current scan finishes.'"));
	}

	public static void Log(string name, string action, string message)
	{
		try
		{
			Directory.CreateDirectory(Program.Data);
			HistoryEntry obj = new HistoryEntry
			{
				Time = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
				Name = name,
				Action = action,
				Result = message
			};
			File.AppendAllText(Path.Combine(Program.Data, "game-history.jsonl"), Program.Json.Serialize(obj) + Environment.NewLine);
		}
		catch
		{
		}
	}

	public static IEnumerable<HistoryEntry> History()
	{
		try
		{
			return (from x in File.ReadAllLines(Path.Combine(Program.Data, "game-history.jsonl")).Reverse().Take(200)
				select Program.Json.Deserialize<HistoryEntry>(x)).ToArray();
		}
		catch
		{
			return new HistoryEntry[0];
		}
	}

	private static void Persist(GameJournal j)
	{
		Utilities.AtomicWrite(JournalPath, Program.Json.Serialize(j));
	}

	internal static void ApplyGlobals(GameRule r, GameJournal j)
	{
		// A journal left by a crashed session still holds the user's original values: put them back before it is replaced.
		try
		{
			if (File.Exists(JournalPath))
			{
				GameJournal gameJournal = Program.Json.Deserialize<GameJournal>(File.ReadAllText(JournalPath));
				if (gameJournal != null && !Restore(gameJournal))
				{
					// Whatever is still pending moves into the new journal, so the original values are not lost.
					foreach (string service in gameJournal.Services.Where((string x) => !j.Services.Contains(x)))
					{
						j.Services.Add(service);
					}
					if (j.Power == null)
					{
						j.Power = gameJournal.Power;
						j.AppliedPower = gameJournal.AppliedPower;
					}
					if (j.Tcp == null)
					{
						j.Tcp = gameJournal.Tcp;
					}
				}
			}
		}
		catch (Exception ex)
		{
			Log("Competitive Mode", "Restore pending", ex.Message);
		}
		Globals(r, j);
	}

	private static string SessionMutex => "Local\\AZIZ-GameSession-" + WindowsIdentity.GetCurrent().User.Value;

	// A Competitive journal left by an AZIZ that closed mid-game (and no watcher or session helper looking after it):
	// the user's original services, power plan and network settings are put back.
	public static void RestoreLeftover()
	{
		try
		{
			if (!File.Exists(JournalPath) || Load().Enabled)
			{
				return;
			}
			try
			{
				using (Mutex.OpenExisting(SessionMutex))
				{
					return;
				}
			}
			catch (WaitHandleCannotBeOpenedException)
			{
			}
			GameJournal gameJournal = Program.Json.Deserialize<GameJournal>(File.ReadAllText(JournalPath));
			if (gameJournal != null && Restore(gameJournal))
			{
				Log("Competitive Mode", "Session ended", "Settings left by a closed AZIZ restored.");
			}
		}
		catch (Exception ex)
		{
			Log("Competitive Mode", "Restore pending", ex.Message);
		}
	}

	public static int Session(string exe)
	{
		using Mutex mutex = new Mutex(initiallyOwned: true, SessionMutex, out var _);
		try
		{
			string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(exe);
			Stopwatch stopwatch = Stopwatch.StartNew();
			Process process = null;
			while (process == null && stopwatch.Elapsed.TotalMinutes < 5.0)
			{
				Process[] processesByName = Process.GetProcessesByName(fileNameWithoutExtension);
				foreach (Process process2 in processesByName)
				{
					string text = CompetitiveLaunch.ImagePath(process2.Id);
					if (process == null && text != null && string.Equals(Path.GetFullPath(text), Path.GetFullPath(exe), StringComparison.OrdinalIgnoreCase))
					{
						process = process2;
					}
					else
					{
						process2.Dispose();
					}
				}
				if (process == null)
				{
					Thread.Sleep(1000);
				}
			}
			if (process != null)
			{
				using (process)
				{
					while (!process.HasExited)
					{
						Thread.Sleep(2000);
					}
				}
			}
		}
		catch
		{
		}
		CompetitiveLaunch.Restore();
		try
		{
			if (File.Exists(JournalPath))
			{
				GameJournal gameJournal = Program.Json.Deserialize<GameJournal>(File.ReadAllText(JournalPath));
				if (gameJournal != null && Restore(gameJournal))
				{
					Log("Competitive Mode", "Session ended", "Original priorities, services and system settings restored.");
				}
			}
		}
		catch (Exception ex)
		{
			Log("Competitive Mode", "Restore pending", ex.Message);
		}
		return 0;
	}

	public static void StartSession(string exe)
	{
		Process.Start(new ProcessStartInfo(Program.ExePath, "--game-session \"" + exe.Replace("\"", "") + "\"")
		{
			UseShellExecute = false,
			CreateNoWindow = true
		});
	}

	internal static void RestoreGlobals(GameJournal j)
	{
		try
		{
			Restore(j);
		}
		catch (Exception ex)
		{
			Log("Competitive Mode", "Restore pending", ex.Message);
		}
	}

	private static void Attempt(string name, Action action)
	{
		try
		{
			action();
		}
		catch (Exception ex)
		{
			Log(name, "Competitive setting skipped", ex.Message);
		}
	}

	private static void StopService(string name, GameJournal j)
	{
		using ServiceController serviceController = new ServiceController(name);
		if (serviceController.Status == ServiceControllerStatus.Running && serviceController.CanStop && !serviceController.DependentServices.Any((ServiceController x) => x.Status == ServiceControllerStatus.Running))
		{
			if (!j.Services.Contains(name))
			{
				j.Services.Add(name);
				Persist(j);
			}
			serviceController.Stop();
			serviceController.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(15.0));
		}
	}

	private static void Globals(GameRule r, GameJournal j)
	{
		if (r.Performance && j.Power == null)
		{
			Attempt("High performance", delegate
			{
				PowerPlan powerPlan = Utilities.PowerPlans().FirstOrDefault((PowerPlan x) => x.Active);
				if (powerPlan == null)
				{
					throw new Exception("Could not read the active power plan.");
				}
				j.Power = powerPlan.Id;
				Persist(j);
				PowerPlan powerPlan2 = Utilities.PowerPlans().FirstOrDefault((PowerPlan x) => x.Id.Equals("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c", StringComparison.OrdinalIgnoreCase));
				if (powerPlan2 == null)
				{
					string text2 = Guid.NewGuid().ToString();
					ActionResult actionResult2 = Utilities.Run("powercfg.exe", "/duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c " + text2);
					if (!actionResult2.Success)
					{
						throw new Exception(actionResult2.Message);
					}
					powerPlan2 = new PowerPlan
					{
						Id = text2
					};
				}
				j.AppliedPower = powerPlan2.Id;
				Persist(j);
				ActionResult actionResult3 = Utilities.ActivatePlan(powerPlan2.Id);
				if (!actionResult3.Success)
				{
					throw new Exception(actionResult3.Message);
				}
			});
		}
		if (r.Network && j.Tcp == null)
		{
			Attempt("TCP auto-tuning", delegate
			{
				string text = Utilities.ReadCommand("powershell.exe", PsArgs("(Get-NetTCPSetting -SettingName Internet).AutoTuningLevelLocal.ToString()")).Trim().ToLowerInvariant();
				if (!new string[5] { "normal", "disabled", "restricted", "highlyrestricted", "experimental" }.Contains(text))
				{
					throw new Exception("Could not capture TCP auto-tuning.");
				}
				j.Tcp = text;
				Persist(j);
				ActionResult actionResult = Utilities.Run("netsh.exe", "int tcp set global autotuninglevel=disabled");
				if (!actionResult.Success)
				{
					throw new Exception(actionResult.Message);
				}
			});
		}
		foreach (string name in ((!r.PauseServices) ? new string[0] : new string[3] { "SysMain", "WerSvc", "DiagTrack" }).Concat((!r.Search) ? new string[0] : new string[1] { "WSearch" }).Where((string x) => PausableServices.Contains(x)))
		{
			Attempt(name, delegate
			{
				StopService(name, j);
			});
		}
		if (r.Standby)
		{
			Attempt("Standby memory", delegate
			{
				GameNative.ClearStandby();
				Log(r.Name, "Standby memory", "Cleared once for this launch; Windows repopulates caches.");
			});
		}
	}

	private static bool Restore(GameJournal j)
	{
		ProcessBackup[] array = j.Processes.ToArray();
		foreach (ProcessBackup processBackup in array)
		{
			if (GameNative.Restore(processBackup))
			{
				j.Processes.Remove(processBackup);
				Persist(j);
			}
		}
		string[] array2 = j.Services.ToArray();
		foreach (string text in array2)
		{
			// The session file is in the user's folder: only the services Game Watch itself pauses are ever started again.
			if (!PausableServices.Contains(text, StringComparer.OrdinalIgnoreCase))
			{
				j.Services.Remove(text);
				Persist(j);
				continue;
			}
			try
			{
				using ServiceController serviceController = new ServiceController(text);
				if (!ServiceExists(text) || serviceController.StartType == ServiceStartMode.Disabled)
				{
					// Removed or disabled since the game started: nothing to start, and retrying would never succeed.
					j.Services.Remove(text);
					Persist(j);
					continue;
				}
				if (serviceController.Status == ServiceControllerStatus.Stopped)
				{
					serviceController.Start();
					serviceController.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(15.0));
				}
				j.Services.Remove(text);
				Persist(j);
			}
			catch (Exception ex)
			{
				Log(text, "Restore pending", ex.Message);
			}
		}
		if (j.Power != null)
		{
			PowerPlan powerPlan = Utilities.PowerPlans().FirstOrDefault((PowerPlan x) => x.Active);
			if (powerPlan != null && (powerPlan.Id != j.AppliedPower || Utilities.ActivatePlan(j.Power).Success))
			{
				j.Power = null;
				j.AppliedPower = null;
				Persist(j);
			}
		}
		if (j.Tcp != null)
		{
			try
			{
				string text2 = Utilities.ReadCommand("powershell.exe", PsArgs("(Get-NetTCPSetting -SettingName Internet).AutoTuningLevelLocal.ToString()")).Trim().ToLowerInvariant();
				if (new string[5] { "normal", "disabled", "restricted", "highlyrestricted", "experimental" }.Contains(j.Tcp) && (text2 != "disabled" || Utilities.Run("netsh.exe", "int tcp set global autotuninglevel=" + j.Tcp).Success))
				{
					j.Tcp = null;
					Persist(j);
				}
			}
			catch (Exception ex2)
			{
				Log("TCP auto-tuning", "Restore pending", ex2.Message);
			}
		}
		int num;
		if (j.Processes.Count == 0 && j.Services.Count == 0 && j.Power == null)
		{
			num = ((j.Tcp == null) ? 1 : 0);
			if (num != 0 && File.Exists(JournalPath))
			{
				File.Delete(JournalPath);
			}
		}
		else
		{
			num = 0;
		}
		return (byte)num != 0;
	}

	private static bool ServiceExists(string name)
	{
		using RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + name);
		return registryKey != null;
	}

	public static int Run()
	{
		bool createdNew;
		using (new Mutex(initiallyOwned: true, "Local\\AZIZ-GameWatch-" + WindowsIdentity.GetCurrent().User.Value, out createdNew))
		{
			if (!createdNew)
			{
				return 0;
			}
			GameJournal gameJournal = new GameJournal();
			bool flag = !File.Exists(JournalPath);
			HashSet<string> hashSet = new HashSet<string>();
			HashSet<string> hashSet2 = new HashSet<string>();
			DateTime nextRestore = DateTime.MinValue;
			try
			{
				if (File.Exists(JournalPath))
				{
					gameJournal = Program.Json.Deserialize<GameJournal>(File.ReadAllText(JournalPath));
					if (gameJournal == null)
					{
						throw new InvalidDataException("Unreadable recovery journal; preserved for review.");
					}
					flag = true;
					if (!Restore(gameJournal))
					{
						Log("Game Watch", "Recovery pending", "Previous settings could not be fully restored. Open AZIZ and review game history.");
						return 2;
					}
					gameJournal = new GameJournal();
				}
				Log("Game Watch", "Monitor started", "Reads game processes every five seconds. Library discovery runs only at startup or on manual rescan in AZIZ.");
				while (true)
				{
					GameConfig gameConfig = LoadIfChanged();
					if (!gameConfig.Enabled)
					{
						break;
					}
					List<GameRule> list = gameConfig.Rules.Where(delegate(GameRule x)
					{
						if (!x.Enabled)
						{
							return false;
						}
						try
						{
							Validate(x);
							return true;
						}
						catch
						{
							return false;
						}
					}).ToList();
					Process[] processesByName;
					foreach (GameRule item6 in list)
					{
						ulong num = CompetitiveLaunch.Mask(item6.CpuSets);
						if (num == 0L)
						{
							continue;
						}
						string[] array = CompetitiveLaunch.LauncherNames(CompetitiveLaunch.LibraryOf(item6));
						foreach (string text in array)
						{
							processesByName = Process.GetProcessesByName(text);
							foreach (Process process in processesByName)
							{
								using (process)
								{
									try
									{
										if (process.SessionId == MySession)
										{
											string text2 = process.Id.ToString();
											long previous = process.StartTime.ToUniversalTime().Ticks;
											string item = text2 + ":" + previous;
											if (!hashSet2.Contains(item) && CompetitiveLaunch.SetMask(process.Id, num, out previous))
											{
												hashSet2.Add(item);
												Log(item6.Name, "Launcher cores applied", text + " · games it starts inherit the profile cores.");
											}
										}
									}
									catch
									{
									}
								}
							}
						}
					}
					List<Tuple<Process, GameRule>> list2 = new List<Tuple<Process, GameRule>>();
					Process[] processes = Process.GetProcesses();
					processesByName = processes;
					foreach (Process p in processesByName)
					{
						try
						{
							if (p.SessionId != MySession)
							{
								continue;
							}
							List<GameRule> list3 = list.Where((GameRule x) => Path.GetFileNameWithoutExtension(x.Exe).Equals(p.ProcessName, StringComparison.OrdinalIgnoreCase)).ToList();
							if (list3.Count == 0)
							{
								continue;
							}
							string path = CompetitiveLaunch.ImagePath(p.Id);
							if (path != null)
							{
								GameRule gameRule = list3.FirstOrDefault((GameRule x) => Path.GetFullPath(x.Exe).Equals(path, StringComparison.OrdinalIgnoreCase));
								if (gameRule != null)
								{
									list2.Add(Tuple.Create(p, gameRule));
								}
							}
						}
						catch
						{
						}
					}
					if (list2.Count == 0)
					{
						if (hashSet.Count > 0 && DateTime.UtcNow >= nextRestore)
						{
							if (Restore(gameJournal))
							{
								gameJournal = new GameJournal();
								hashSet.Clear();
								Log("Competitive Mode", "Session ended", "Original priorities, services and system settings restored.");
							}
							else
							{
								// Something is still pending: try again in a minute, not every five seconds.
								nextRestore = DateTime.UtcNow.AddMinutes(1.0);
							}
						}
					}
					else
					{
						foreach (Tuple<Process, GameRule> item7 in list2)
						{
							Process item2 = item7.Item1;
							GameRule item3 = item7.Item2;
							try
							{
								string item4 = item2.Id + ":" + item2.StartTime.ToUniversalTime().Ticks;
								if (!hashSet.Add(item4))
								{
									continue;
								}
								Globals(item3, gameJournal);
								List<string> list4 = new List<string>();
								if (item3.Boost)
								{
									ProcessBackup processBackup = GameNative.Capture(item2, gpu: true, io: true, sets: true);
									gameJournal.Processes.Add(processBackup);
									Persist(gameJournal);
									list4.AddRange(GameNative.Apply(item2, processBackup, item3));
								}
								if (item3.Focus || item3.Steam)
								{
									processesByName = processes;
									foreach (Process background in processesByName)
									{
										try
										{
											if (background.SessionId == item2.SessionId && !list2.Any((Tuple<Process, GameRule> g) => g.Item1.Id == background.Id) && !gameJournal.Processes.Any((ProcessBackup existing) => existing.Pid == background.Id))
											{
												string text3 = background.ProcessName.ToLowerInvariant();
												if ((item3.Focus && new string[5] { "chrome", "msedge", "firefox", "brave", "discord" }.Contains(text3)))
												{
													ProcessBackup item5 = GameNative.Capture(background, gpu: false, io: false, sets: false);
													gameJournal.Processes.Add(item5);
													Persist(gameJournal);
													background.PriorityClass = ProcessPriorityClass.BelowNormal;
												}
											}
										}
										catch
										{
										}
									}
								}
								Log(item3.Name, "Competitive profile applied", (list4.Count == 0) ? ("Process settings accepted; system option results are recorded separately. PID " + item2.Id) : string.Join("; ", list4));
							}
							catch (Exception ex)
							{
								Log(item3.Name, "Profile needs review", ex.Message);
							}
						}
					}
					processesByName = processes;
					for (int i = 0; i < processesByName.Length; i++)
					{
						processesByName[i].Dispose();
					}
					Thread.Sleep(5000);
				}
			}
			catch (Exception ex2)
			{
				Log("Game Watch", "Monitor error", ex2.Message);
				return 1;
			}
			finally
			{
				try
				{
					if (flag)
					{
						Restore(gameJournal);
					}
				}
				catch (Exception ex3)
				{
					Log("Game Watch", "Restore pending", ex3.Message);
				}
			}
			return 0;
		}
	}
}
