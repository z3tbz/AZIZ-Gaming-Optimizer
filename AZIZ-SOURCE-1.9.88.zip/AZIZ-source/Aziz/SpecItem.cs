namespace Aziz;

public sealed class SpecItem
{
	public string Label { get; set; }

	public string Value { get; set; }

	public SpecItem()
	{
	}

	public SpecItem(string label, string value)
	{
		Label = label;
		Value = value;
	}
}
