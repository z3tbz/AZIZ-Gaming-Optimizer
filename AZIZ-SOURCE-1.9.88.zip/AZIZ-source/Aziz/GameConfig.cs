using System.Collections.Generic;

namespace Aziz;

internal class GameConfig
{
	public bool Enabled { get; set; }

	public List<GameRule> Rules { get; set; }

	public List<string> ManagedIfeo { get; set; }

	public GameConfig()
	{
		Rules = new List<GameRule>();
		ManagedIfeo = new List<string>();
	}
}
