using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

// AZIZ-Setup.exe: installs AZIZ Gaming Optimizer into Program Files with no questions (no terms, no folder, no Next),
// replaces an older copy (profiles, history and downloads live outside the app folder and stay), then opens AZIZ.
// /S = fully silent (no window, AZIZ is not opened).
internal static class Setup
{
	[STAThread]
	private static int Main(string[] args)
	{
		bool silent = args.Any((string a) => a.Equals("/S", StringComparison.OrdinalIgnoreCase) || a.Equals("/silent", StringComparison.OrdinalIgnoreCase));
		string target = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "AZIZ Gaming Optimizer");
		if (silent)
		{
			return Install(target, null) == null ? 0 : 1;
		}
		Application.EnableVisualStyles();
		Form form = new Form
		{
			FormBorderStyle = FormBorderStyle.None,
			StartPosition = FormStartPosition.CenterScreen,
			BackColor = Color.FromArgb(14, 12, 40),
			Size = new Size(420, 150),
			ShowInTaskbar = true,
			Text = "AZIZ Setup",
			Icon = Icon.ExtractAssociatedIcon(typeof(Setup).Assembly.Location)
		};
		Label title = new Label
		{
			Text = "Installing AZIZ Gaming Optimizer",
			ForeColor = Color.White,
			Font = new Font("Segoe UI Semibold", 13f),
			AutoSize = true,
			Location = new Point(24, 26)
		};
		Label status = new Label
		{
			Text = "Preparing…",
			ForeColor = Color.FromArgb(185, 176, 235),
			Font = new Font("Segoe UI", 9.5f),
			AutoSize = true,
			Location = new Point(25, 58)
		};
		Panel track = new Panel
		{
			BackColor = Color.FromArgb(45, 40, 90),
			Location = new Point(26, 96),
			Size = new Size(368, 6)
		};
		Panel fill = new Panel
		{
			BackColor = Color.FromArgb(120, 150, 255),
			Location = new Point(0, 0),
			Size = new Size(0, 6)
		};
		track.Controls.Add(fill);
		form.Controls.Add(title);
		form.Controls.Add(status);
		form.Controls.Add(track);
		int code = 0;
		form.Shown += async delegate
		{
			string error = await Task.Run(() => Install(target, delegate(int p, string s)
			{
				form.BeginInvoke((Action)delegate
				{
					fill.Width = 368 * p / 100;
					status.Text = s;
				});
			}));
			if (error != null)
			{
				code = 1;
				MessageBox.Show(form, error, "AZIZ Setup", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			else
			{
				try
				{
					Process.Start(new ProcessStartInfo(Path.Combine(target, "AZIZGamingOptimizer.exe"))
					{
						UseShellExecute = true,
						WorkingDirectory = target
					});
				}
				catch
				{
				}
			}
			form.Close();
		};
		Application.Run(form);
		return code;
	}

	private static string Install(string target, Action<int, string> report)
	{
		try
		{
			report?.Invoke(5, "Closing AZIZ if it is open…");
			foreach (Process process in Process.GetProcessesByName("AZIZGamingOptimizer"))
			{
				using (process)
				{
					try
					{
						string text = process.MainModule.FileName;
						if (text.StartsWith(target + "\\", StringComparison.OrdinalIgnoreCase))
						{
							process.Kill();
							process.WaitForExit(5000);
						}
					}
					catch
					{
					}
				}
			}
			Directory.CreateDirectory(target);
			using Stream stream = typeof(Setup).Assembly.GetManifestResourceStream("payload.zip");
			using ZipArchive zipArchive = new ZipArchive(stream, ZipArchiveMode.Read);
			int count = zipArchive.Entries.Count;
			int num = 0;
			string fullPath = Path.GetFullPath(target + "\\");
			foreach (ZipArchiveEntry entry in zipArchive.Entries)
			{
				num++;
				string text2 = entry.FullName.Replace('/', '\\');
				if (text2.StartsWith("AZIZ\\", StringComparison.OrdinalIgnoreCase))
				{
					text2 = text2.Substring(5);
				}
				if (text2.Length == 0)
				{
					continue;
				}
				string fullPath2 = Path.GetFullPath(Path.Combine(target, text2));
				if (!fullPath2.StartsWith(fullPath, StringComparison.OrdinalIgnoreCase))
				{
					continue;
				}
				if (text2.EndsWith("\\"))
				{
					Directory.CreateDirectory(fullPath2);
					continue;
				}
				Directory.CreateDirectory(Path.GetDirectoryName(fullPath2));
				entry.ExtractToFile(fullPath2, overwrite: true);
				if (num % 8 == 0)
				{
					report?.Invoke(10 + 85 * num / count, "Installing… " + Path.GetFileName(text2));
				}
			}
			report?.Invoke(100, "Done · opening AZIZ");
			return null;
		}
		catch (Exception ex)
		{
			return "AZIZ could not be installed: " + ex.Message;
		}
	}
}
